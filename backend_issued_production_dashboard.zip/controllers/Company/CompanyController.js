const db = require("../../config/db");
const { logActivity } = require("../../utils/activityLogger");

// =============================
// Add Company
// =============================
exports.addCompany = async (req, res) => {
    try {

        const {
            company_name,
            NTN_No,
            Business_Name,
            Province,
            Address,
            performed_by,
            system_name_ip
        } = req.body;

        const [exist] = await db.query(
            "SELECT id FROM CompanyName WHERE company_name=?",
            [company_name]
        );

        if (exist.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Company already exists."
            });
        }

        await db.query(
            "INSERT INTO CompanyName(company_name, NTN_No, Business_Name, Province, Address) VALUES(?, ?, ?, ?, ?)",
            [company_name, NTN_No, Business_Name, Province, Address]
        );

        await logActivity({
            document_type: "Company",
            document_no: company_name,
            status: "New",
            remarks: `Company "${company_name}" created`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.json({
            success: true,
            message: "Company Added Successfully"
        });

    } catch (err) {

        res.status(500).json(err);

    }
};


// =============================
// Update Company
// =============================
exports.updateCompany = async (req, res) => {

    try {

        const { id } = req.params;
        const {
            company_name,
            NTN_No,
            Business_Name,
            Province,
            Address,
            performed_by,
            system_name_ip
        } = req.body;

        await db.query(
            "UPDATE CompanyName SET company_name=?, NTN_No=?, Business_Name=?, Province=?, Address=? WHERE id=?",
            [company_name, NTN_No, Business_Name, Province, Address, id]
        );

        await logActivity({
            document_type: "Company",
            document_no: company_name,
            status: "Edit",
            remarks: `Company updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.json({
            success: true,
            message: "Company Updated Successfully"
        });

    } catch (err) {

        res.status(500).json(err);

    }

};


// =============================
// Delete Company
// =============================
exports.deleteCompany = async (req, res) => {

    try {

        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        // Capture the name before it's gone, so the log entry stays meaningful
        const [record] = await db.query(
            "SELECT company_name FROM CompanyName WHERE id=?",
            [id]
        );

        await db.query(
            "DELETE FROM CompanyName WHERE id=?",
            [id]
        );

        await logActivity({
            document_type: "Company",
            document_no: record[0]?.company_name || null,
            status: "Delete",
            remarks: `Company deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.json({
            success: true,
            message: "Company Deleted Successfully"
        });

    } catch (err) {

        res.status(500).json(err);

    }
};

// =============================
// Get All Companies
// =============================
exports.getCompanies = async (req, res) => {

    try {

        const [rows] = await db.query(
            `SELECT
        id,
        company_name,
        NTN_No,
        Business_Name,
        Province,
        Address,
        add_date,
        update_date
    FROM CompanyName
    ORDER BY company_name ASC`
        );

        res.json({
            success: true,
            data: rows
        });

    } catch (err) {

        res.status(500).json(err);

    }
};


// =============================
// Get Company By Id
// =============================
exports.getCompanyById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT
        id,
        company_name,
        NTN_No,
        Business_Name,
        Province,
        Address,
        add_date,
        update_date
    FROM CompanyName
    WHERE id=?`,
            [id]
        );

        if (rows.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Company Not Found"
            });

        }

        res.json({
            success: true,
            data: rows[0]
        });

    } catch (err) {

        res.status(500).json(err);

    }

};