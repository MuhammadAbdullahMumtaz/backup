const db = require("../../config/db");
const { logActivity } = require("../../utils/activityLogger");

// =============================
// Add Department
// =============================
exports.addDepartment = async (req, res) => {
    try {

        const {
            company_id,
            department_name,
            performed_by,
            system_name_ip
        } = req.body;

        if (!company_id || !department_name) {
            return res.status(400).json({
                success: false,
                message: "company_id and department_name are required."
            });
        }

        const [exist] = await db.query(
            "SELECT id FROM Department WHERE company_id=? AND department_name=?",
            [company_id, department_name]
        );

        if (exist.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Department already exists for this company."
            });
        }

        await db.query(
            "INSERT INTO Department(company_id, department_name) VALUES(?, ?)",
            [company_id, department_name]
        );

        await logActivity({
            document_type: "Department",
            document_no: department_name,
            status: "New",
            remarks: `Department "${department_name}" created`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.json({
            success: true,
            message: "Department Added Successfully"
        });

    } catch (err) {

        res.status(500).json(err);

    }
};


// =============================
// Update Department
// =============================
exports.updateDepartment = async (req, res) => {

    try {

        const { id } = req.params;
        const {
            company_id,
            department_name,
            performed_by,
            system_name_ip
        } = req.body;

        if (!company_id || !department_name) {
            return res.status(400).json({
                success: false,
                message: "company_id and department_name are required."
            });
        }

        await db.query(
            "UPDATE Department SET company_id=?, department_name=? WHERE id=?",
            [company_id, department_name, id]
        );

        await logActivity({
            document_type: "Department",
            document_no: department_name,
            status: "Edit",
            remarks: `Department updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.json({
            success: true,
            message: "Department Updated Successfully"
        });

    } catch (err) {

        res.status(500).json(err);

    }

};


// =============================
// Delete Department
// =============================
exports.deleteDepartment = async (req, res) => {

    try {

        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        // Capture the name before it's gone, so the log entry stays meaningful
        const [record] = await db.query(
            "SELECT department_name FROM Department WHERE id=?",
            [id]
        );

        await db.query(
            "DELETE FROM Department WHERE id=?",
            [id]
        );

        await logActivity({
            document_type: "Department",
            document_no: record[0]?.department_name || null,
            status: "Delete",
            remarks: `Department deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.json({
            success: true,
            message: "Department Deleted Successfully"
        });

    } catch (err) {

        res.status(500).json(err);

    }
};

// =============================
// Get All Departments
// =============================
exports.getDepartments = async (req, res) => {

    try {

        const [rows] = await db.query(
            `SELECT
        d.id,
        d.company_id,
        c.company_name,
        d.department_name,
        d.add_date,
        d.update_date
    FROM Department d
    INNER JOIN CompanyName c ON c.id = d.company_id
    ORDER BY d.department_name ASC`
        );

        res.json({
            success: true,
            data: rows
        });

    } catch (err) {

        res.status(500).json(err);

    }
};


// =============================
// Get Department By Id
// =============================
exports.getDepartmentById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT
        d.id,
        d.company_id,
        c.company_name,
        d.department_name,
        d.add_date,
        d.update_date
    FROM Department d
    INNER JOIN CompanyName c ON c.id = d.company_id
    WHERE d.id=?`,
            [id]
        );

        if (rows.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Department Not Found"
            });

        }

        res.json({
            success: true,
            data: rows[0]
        });

    } catch (err) {

        res.status(500).json(err);

    }

};