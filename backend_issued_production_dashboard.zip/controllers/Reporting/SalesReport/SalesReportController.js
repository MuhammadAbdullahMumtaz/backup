const db = require("../../../config/db");

function toSqlDate(d) {
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function requireCommon(query) {
  const { company_id, financialyear_id, start_date, end_date } = query;
  if (!company_id || !financialyear_id || !start_date || !end_date) {
    return {
      ok: false,
      message: "company_id, financialyear_id, start_date and end_date are required",
    };
  }
  return {
    ok: true,
    companyId: company_id,
    financialyearId: financialyear_id,
    startDate: toSqlDate(start_date),
    endDate: toSqlDate(end_date),
  };
}

// ============================================================================
// GET /sales-report/top-accounts
// ============================================================================
async function getTopAccounts(req, res) {
  try {
    const common = requireCommon(req.query);
    if (!common.ok) return res.status(400).json({ success: false, message: common.message });
    const { companyId, financialyearId, startDate, endDate } = common;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 500);

    const sql = `
      SELECT
        coa.id                       AS account_id,
        coa.code                     AS account_code,
        coa.account_name             AS account_name,
        cd.city                      AS city,
        COUNT(DISTINCT CASE WHEN t.type = 'sale' THEN t.doc_id END) AS invoice_count,
        COALESCE(SUM(CASE WHEN t.type = 'sale' THEN t.freight END), 0) AS total_freight,
        COALESCE(SUM(t.total), 0)    AS total_sales
      FROM (
        SELECT id AS doc_id, customer_code, total, freight, 'sale' AS type
        FROM SalesMain
        WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
          AND invoice_date BETWEEN ? AND ?
        UNION ALL
        SELECT id AS doc_id, customer_code, -total AS total, -freight AS freight, 'return' AS type
        FROM SalesReturnMain
        WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
          AND invoice_date BETWEEN ? AND ?
      ) t
      INNER JOIN ChartOfAccount coa ON coa.code = t.customer_code AND coa.company_id = ?
      LEFT JOIN ChartDetail cd ON cd.chartofaccount_id = coa.id
      GROUP BY coa.id, coa.code, coa.account_name, cd.city
      ORDER BY total_sales DESC
      LIMIT ?
    `;
    const params = [
      companyId, financialyearId, startDate, endDate,
      companyId, financialyearId, startDate, endDate,
      companyId, limit,
    ];
    const [rows] = await db.query(sql, params);

    const data = rows.map((r, idx) => ({
      s_no: idx + 1,
      account_id: r.account_id,
      account_code: r.account_code,
      account_name: r.account_name,
      city: r.city || "—",
      invoice_count: toNumber(r.invoice_count),
      total_sales: toNumber(r.total_sales),
      total_freight: toNumber(r.total_freight),
    }));

    return res.json({ success: true, data, start_date: startDate, end_date: endDate });
  } catch (err) {
    console.error("getTopAccounts error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate top accounts report" });
  }
}

// ============================================================================
// GET /sales-report/top-cities
// ============================================================================
async function getTopCities(req, res) {
  try {
    const common = requireCommon(req.query);
    if (!common.ok) return res.status(400).json({ success: false, message: common.message });
    const { companyId, financialyearId, startDate, endDate } = common;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 500);

    const sql = `
      SELECT
        COALESCE(NULLIF(TRIM(cd.city), ''), 'Unspecified') AS city,
        COUNT(DISTINCT coa.id) AS account_count,
        COUNT(DISTINCT CASE WHEN t.type = 'sale' THEN t.doc_id END) AS invoice_count,
        COALESCE(SUM(t.total), 0) AS total_sales
      FROM (
        SELECT id AS doc_id, customer_code, total, 'sale' AS type
        FROM SalesMain
        WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
          AND invoice_date BETWEEN ? AND ?
        UNION ALL
        SELECT id AS doc_id, customer_code, -total AS total, 'return' AS type
        FROM SalesReturnMain
        WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
          AND invoice_date BETWEEN ? AND ?
      ) t
      INNER JOIN ChartOfAccount coa ON coa.code = t.customer_code AND coa.company_id = ?
      LEFT JOIN ChartDetail cd ON cd.chartofaccount_id = coa.id
      GROUP BY city
      ORDER BY total_sales DESC
      LIMIT ?
    `;
    const params = [
      companyId, financialyearId, startDate, endDate,
      companyId, financialyearId, startDate, endDate,
      companyId, limit,
    ];
    const [rows] = await db.query(sql, params);

    const data = rows.map((r, idx) => ({
      s_no: idx + 1,
      city: r.city,
      account_count: toNumber(r.account_count),
      invoice_count: toNumber(r.invoice_count),
      total_sales: toNumber(r.total_sales),
    }));

    return res.json({ success: true, data, start_date: startDate, end_date: endDate });
  } catch (err) {
    console.error("getTopCities error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate top cities report" });
  }
}

// ============================================================================
// GET /sales-report/top-items
// ============================================================================
async function getTopItems(req, res) {
  try {
    const common = requireCommon(req.query);
    if (!common.ok) return res.status(400).json({ success: false, message: common.message });
    const { companyId, financialyearId, startDate, endDate } = common;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 500);
    const groupBy = ["item", "subitem", "mainitem"].includes(req.query.group_by)
      ? req.query.group_by
      : "subitem";

    let groupSelect, groupJoin, groupByClause;

    if (groupBy === "item") {
      groupSelect = `id.code AS group_code, id.details AS group_name`;
      groupJoin = `INNER JOIN ItemDetail id ON id.code = t.Item_code AND id.company_id = ?`;
      groupByClause = `id.id`;
    } else if (groupBy === "mainitem") {
      groupSelect = `mi.code AS group_code, mi.details AS group_name`;
      groupJoin = `
        INNER JOIN ItemDetail id ON id.code = t.Item_code AND id.company_id = ?
        INNER JOIN SubItem si ON si.id = id.subitem_id
        INNER JOIN MainItem mi ON mi.id = si.mainitem_id`;
      groupByClause = `mi.id`;
    } else {
      groupSelect = `si.code AS group_code, si.details AS group_name`;
      groupJoin = `
        INNER JOIN ItemDetail id ON id.code = t.Item_code AND id.company_id = ?
        INNER JOIN SubItem si ON si.id = id.subitem_id`;
      groupByClause = `si.id`;
    }

    const sql = `
      SELECT
        ${groupSelect},
        COUNT(DISTINCT CASE WHEN t.type = 'sale' THEN t.doc_id END) AS invoice_count,
        COALESCE(SUM(t.pieces), 0)     AS total_pieces,
        COALESCE(SUM(t.net_weight), 0) AS total_net_weight,
        COALESCE(SUM(t.amount), 0)     AS total_amount,
        COALESCE(SUM(t.total), 0)      AS total_sales
      FROM (
        SELECT sd.Item_code AS Item_code, sm.id AS doc_id,
               sd.pieces AS pieces, sd.net_weight AS net_weight,
               sd.amount AS amount, sd.total AS total, 'sale' AS type
        FROM SalesDetail sd
        INNER JOIN SalesMain sm ON sm.id = sd.sale_main
        WHERE sd.company_id = ? AND sm.financialyear_id = ? AND sm.entry = 'user'
          AND sm.invoice_date BETWEEN ? AND ?
        UNION ALL
        SELECT srd.Item_code, srm.id,
               -srd.pieces, -srd.net_weight,
               -srd.amount, -srd.total, 'return'
        FROM SalesReturnDetail srd
        INNER JOIN SalesReturnMain srm ON srm.id = srd.sales_return_main
        WHERE srd.company_id = ? AND srm.financialyear_id = ? AND srm.entry = 'user'
          AND srm.invoice_date BETWEEN ? AND ?
      ) t
      ${groupJoin}
      GROUP BY ${groupByClause}
      ORDER BY total_sales DESC
      LIMIT ?
    `;
    const params = [
      companyId, financialyearId, startDate, endDate,
      companyId, financialyearId, startDate, endDate,
      companyId, limit,
    ];
    const [rows] = await db.query(sql, params);

    const data = rows.map((r, idx) => ({
      s_no: idx + 1,
      group_code: r.group_code,
      group_name: r.group_name,
      invoice_count: toNumber(r.invoice_count),
      total_pieces: toNumber(r.total_pieces),
      total_net_weight: toNumber(r.total_net_weight),
      total_amount: toNumber(r.total_amount),
      total_sales: toNumber(r.total_sales),
    }));

    return res.json({ success: true, data, group_by: groupBy, start_date: startDate, end_date: endDate });
  } catch (err) {
    console.error("getTopItems error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate top items report" });
  }
}

// ============================================================================
// GET /sales-report/detailed
//   Row-level sales register. Returns every field the frontend's column
//   picker might want; the frontend decides what to render.
//   optional: customer_code, item_code, limit
// ============================================================================
async function getDetailedSales(req, res) {
  try {
    const common = requireCommon(req.query);
    if (!common.ok) return res.status(400).json({ success: false, message: common.message });
    const { companyId, financialyearId, startDate, endDate } = common;
    const { customer_code, item_code } = req.query;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 2000, 1), 20000);

    const params = [companyId, financialyearId, startDate, endDate];
    let extraWhere = "";
    if (customer_code) {
      extraWhere += " AND coa.code = ? ";
      params.push(customer_code);
    }
    if (item_code) {
      extraWhere += " AND sd.Item_code = ? ";
      params.push(item_code);
    }
    params.push(limit);

    const sql = `
      SELECT
        sm.id              AS sale_id,
        sm.invoice_no       AS invoice_no,
        sm.invoice_date      AS invoice_date,
        sm.gp_no            AS gp_no,
        sm.gp_date           AS gp_date,
        sm.po_no            AS po_no,
        sm.po_date           AS po_date,
        sm.builty_no         AS builty_no,
        sm.freight           AS main_freight,
        sm.total            AS main_total,
        sm.entry            AS main_entry,

        coa.code            AS customer_code,
        coa.account_name      AS customer_name,
        cd.city              AS city,
        cd.province           AS province,
        cd.address            AS address,
        cd.cell_no            AS cell_no,

        sd.entry_no          AS entry_no,
        sd.Item_code          AS item_code,
        itd.details           AS item_name,
        si.details            AS item_sub,
        sd.pieces            AS pieces,
        sd.gross_weight        AS gross_weight,
        sd.tear_weight         AS tear_weight,
        sd.net_weight         AS net_weight,
        sd.rate              AS rate,
        sd.amount             AS amount,
        sd.freight            AS detail_freight,
        sd.total             AS detail_total,
        sd.entry             AS detail_entry

      FROM SalesMain sm
      INNER JOIN SalesDetail sd ON sd.sale_main = sm.id
      INNER JOIN ChartOfAccount coa ON coa.code = sm.customer_code AND coa.company_id = sm.company_id
      LEFT JOIN ChartDetail cd ON cd.chartofaccount_id = coa.id
      LEFT JOIN ItemDetail itd ON itd.code = sd.Item_code AND itd.company_id = sd.company_id
      LEFT JOIN SubItem si ON si.id = itd.subitem_id
      WHERE sm.company_id = ?
        AND sm.financialyear_id = ?
        AND sm.entry = 'user'
        AND sm.invoice_date BETWEEN ? AND ?
        ${extraWhere}
      ORDER BY sm.invoice_date, sm.id, sd.entry_no
      LIMIT ?
    `;
    const [rows] = await db.query(sql, params);

    let totalAmount = 0;
    let totalNetWeight = 0;
    let totalPieces = 0;
    let totalValue = 0;

    const data = rows.map((r, idx) => {
      totalAmount += toNumber(r.amount);
      totalNetWeight += toNumber(r.net_weight);
      totalPieces += toNumber(r.pieces);
      totalValue += toNumber(r.detail_total);

      return {
        s_no: idx + 1,
        sale_id: r.sale_id,
        invoice_no: r.invoice_no,
        invoice_date: normalizeDbDate(r.invoice_date),
        gp_no: r.gp_no,
        gp_date: normalizeDbDate(r.gp_date),
        po_no: r.po_no,
        po_date: normalizeDbDate(r.po_date),
        builty_no: r.builty_no,
        main_freight: toNumber(r.main_freight),
        main_total: toNumber(r.main_total),

        customer_code: r.customer_code,
        customer_name: r.customer_name,
        city: r.city || "—",
        province: r.province || "—",
        address: r.address || "",
        cell_no: r.cell_no || "",

        entry_no: r.entry_no,
        item_code: r.item_code,
        item_name: r.item_name || r.item_code,
        item_sub: r.item_sub || "—",
        pieces: toNumber(r.pieces),
        gross_weight: toNumber(r.gross_weight),
        tear_weight: toNumber(r.tear_weight),
        net_weight: toNumber(r.net_weight),
        rate: toNumber(r.rate),
        amount: toNumber(r.amount),
        detail_freight: toNumber(r.detail_freight),
        detail_total: toNumber(r.detail_total),
      };
    });

    return res.json({
      success: true,
      data,
      totals: {
        pieces: totalPieces,
        net_weight: Number(totalNetWeight.toFixed(2)),
        amount: Number(totalAmount.toFixed(2)),
        detail_total: Number(totalValue.toFixed(2)),
      },
      start_date: startDate,
      end_date: endDate,
    });
  } catch (err) {
    console.error("getDetailedSales error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate detailed sales report" });
  }
}

module.exports = {
  getTopAccounts,
  getTopCities,
  getTopItems,
  getDetailedSales,
};