const db = require("../../../config/db");

/**
 * ============================================================================
 * LEDGER CONTROLLER
 * ============================================================================
 * Produces a unified ledger (Voucher + Purchase + Purchase Return + Sales +
 * Sales Return) for one account, between a start and end date.
 *
 * FLOW (matches the report the frontend renders):
 *   1. The financial year is NOT resolved by scanning date ranges anymore.
 *      The frontend already knows it (Redux: state.company.financialYearId)
 *      and sends it as `financialyear_id` — we just look that row up by PK.
 *   2. Opening balance =
 *        (that FY's stored OpeningBalance.debit - OpeningBalance.credit)
 *      + (debit - credit of every Voucher/Purchase/PurchaseReturn/Sales/
 *         SalesReturn transaction dated on/after that FY's start_date and
 *         strictly before `start_date`)
 *   3. Display rows = every transaction from all five sources dated between
 *      `start_date` and `end_date` (inclusive), merged and sorted
 *      chronologically.
 *   4. Running balance starts at the opening balance and is carried forward
 *      row by row; the last row's balance is the closing balance.
 *
 * Debit/Credit convention (confirmed):
 *   - Purchase:        entry='user' -> credit | entry='auto' -> debit
 *   - Purchase Return:  entry='user' -> debit  | entry='auto' -> credit  (reversal)
 *   - Sales:            entry='user' -> debit  | entry='auto' -> credit
 *   - Sales Return:      entry='user' -> credit | entry='auto' -> debit  (reversal)
 *
 * Table mapping used (matches the schema you shared):
 *   - ChartOfAccount(id, code, account_name, company_id)
 *       id           -> VoucherDetail.accountcode
 *       code         -> PurchaseMain.supplier_code / PurchaseReturnMain.supplier_code
 *                       / SalesMain.customer_code / SalesReturnMain.customer_code
 *       account_name -> used for search
 *   - ItemDetail(code, details) -> maps Item_code to a display name
 *   - FinancialYear(id, company_id, start_date, end_date)
 *   - OpeningBalance(company_id, chartofaccount_id, financialyear_id, debit, credit)
 * ============================================================================
 */

const ACCOUNTS_TABLE = {
  table: "ChartOfAccount",
  id: "id",              // numeric PK -> matches VoucherDetail.accountcode
  code: "code",           // CHAR(9) -> matches supplier_code / customer_code
  name: "account_name",
  company_id: "company_id",
};

const ITEMS_TABLE = {
  table: "ItemDetail",
  code: "code",
  name: "details",
};
// -----------------------------------------------------------------------------

/**
 * Recommended indexes (create once, huge impact on report speed):
 *
 *   ALTER TABLE VoucherDetail        ADD INDEX idx_vd_ledger (company_id, accountcode);
 *   ALTER TABLE VoucherMain          ADD INDEX idx_vm_date (voucher_date);
 *   ALTER TABLE PurchaseMain         ADD INDEX idx_pm_ledger (company_id, supplier_code, grn_date);
 *   ALTER TABLE PurchaseDetail       ADD INDEX idx_pd_main (purchasemain_id);
 *   ALTER TABLE PurchaseReturnMain   ADD INDEX idx_prm_ledger (company_id, supplier_code, return_date);
 *   ALTER TABLE PurchaseReturnDetail ADD INDEX idx_prd_main (purchasereturnmain_id);
 *   ALTER TABLE SalesMain            ADD INDEX idx_sm_ledger (company_id, customer_code, sale_date);
 *   ALTER TABLE SalesDetail          ADD INDEX idx_sd_main (sale_main);
 *   ALTER TABLE SalesReturnMain      ADD INDEX idx_srm_ledger (company_id, customer_code, sale_date);
 *   ALTER TABLE SalesReturnDetail    ADD INDEX idx_srd_main (sales_return_main);
 *   ALTER TABLE ChartOfAccount       ADD INDEX idx_coa_search (company_id, account_name);
 *   ALTER TABLE OpeningBalance       ADD INDEX idx_ob_lookup (company_id, chartofaccount_id, financialyear_id);
 */

// ============================================================================
// Helpers
// ============================================================================

// Format a JS Date / mysql DATE value as 'YYYY-MM-DD' for SQL params,
// and also as a plain string safe to send to the frontend (no timezone shift).
function toSqlDate(d) {
  if (d instanceof Date) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }

  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;

  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

// ============================================================================
// GET /ledger/accounts/search?company_id=&q=
// ============================================================================
async function searchAccounts(req, res) {
  try {
    const { company_id, q = "" } = req.query;

    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }

    const like = `%${q.trim()}%`;

    const sql = `
      SELECT ${ACCOUNTS_TABLE.id}   AS id,
             ${ACCOUNTS_TABLE.code} AS code,
             ${ACCOUNTS_TABLE.name} AS name
      FROM ${ACCOUNTS_TABLE.table}
      WHERE ${ACCOUNTS_TABLE.company_id} = ?
        AND (${ACCOUNTS_TABLE.name} LIKE ? OR ${ACCOUNTS_TABLE.code} LIKE ?)
      ORDER BY ${ACCOUNTS_TABLE.name} ASC
      LIMIT 20
    `;

    const [rows] = await db.query(sql, [company_id, like, like]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("searchAccounts error:", err);
    return res.status(500).json({ success: false, message: "Failed to search accounts" });
  }
}

// ============================================================================
// Financial year lookup + party's stored opening balance for that year
// ============================================================================
async function fetchFinancialYearById(companyId, financialYearId) {
  const sql = `
    SELECT id, start_date, end_date
    FROM FinancialYear
    WHERE company_id = ?
      AND id = ?
    LIMIT 1
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  if (!rows.length) return null;
  return {
    id: rows[0].id,
    start_date: normalizeDbDate(rows[0].start_date),
    end_date: normalizeDbDate(rows[0].end_date),
  };
}

async function fetchOpeningBalanceForYear(companyId, chartOfAccountId, financialYearId) {
  const sql = `
    SELECT COALESCE(SUM(ob.debit), 0)  AS total_debit,
           COALESCE(SUM(ob.credit), 0) AS total_credit
    FROM OpeningBalance ob
    WHERE ob.company_id = ?
      AND ob.chartofaccount_id = ?
      AND ob.financialyear_id = ?
  `;
  const [rows] = await db.query(sql, [companyId, chartOfAccountId, financialYearId]);
  return { debit: toNumber(rows[0]?.total_debit), credit: toNumber(rows[0]?.total_credit) };
}

// ============================================================================
// Internal query builders
// ============================================================================

// -------- Voucher rows (already one row per ledger entry) ------------------
async function fetchVoucherRows(companyId, accountId, startDate, endDate) {
  const sql = `
    SELECT
      vm.voucher_date        AS txn_date,
      COALESCE(vt.type, 'V') AS voucher_type,
      vm.voucher_no          AS voucher_no,
      vd.narration            AS narration,
      vd.debit                AS debit,
      vd.credit               AS credit
    FROM VoucherDetail vd
    INNER JOIN VoucherMain vm ON vm.id = vd.vouchermain_id
    LEFT JOIN VoucherType vt ON vt.id = vm.vouchertype_id
    WHERE vd.company_id = ?
      AND vd.accountcode = ?
      AND vm.voucher_date BETWEEN ? AND ?
    ORDER BY vm.voucher_date, vm.id, vd.entry_no
  `;
  const [rows] = await db.query(sql, [companyId, accountId, startDate, endDate]);
  return rows.map((r) => ({
    txn_date: normalizeDbDate(r.txn_date),
    voucher_type: r.voucher_type,
    voucher_no: r.voucher_no,
    narration: r.narration || "",
    debit: toNumber(r.debit),
    credit: toNumber(r.credit),
  }));
}

async function fetchVoucherOpeningTotals(companyId, accountId, fyStartDate, startDate) {
  const sql = `
    SELECT
      COALESCE(SUM(vd.debit), 0)  AS total_debit,
      COALESCE(SUM(vd.credit), 0) AS total_credit
    FROM VoucherDetail vd
    INNER JOIN VoucherMain vm ON vm.id = vd.vouchermain_id
    WHERE vd.company_id = ?
      AND vd.accountcode = ?
      AND vm.voucher_date >= ?
      AND vm.voucher_date <  ?
  `;
  const [rows] = await db.query(sql, [companyId, accountId, fyStartDate, startDate]);
  return { debit: toNumber(rows[0]?.total_debit), credit: toNumber(rows[0]?.total_credit) };
}

// -------- Purchase rows (header + detail merged, item narration built) -----
// entry='user' -> credit | entry='auto' -> debit
async function fetchPurchaseRows(companyId, accountCode, startDate, endDate) {
  const headerSql = `
    SELECT pm.id AS main_id, pm.grn_date AS txn_date, pm.grn_no AS voucher_no, 
           pm.gp_no AS gp_no, pm.entry AS entry
    FROM PurchaseMain pm
    WHERE pm.company_id = ?
      AND pm.supplier_code = ?
      AND pm.grn_date BETWEEN ? AND ?
    ORDER BY pm.grn_date, pm.id
  `;
  const [headers] = await db.query(headerSql, [companyId, accountCode, startDate, endDate]);
  if (headers.length === 0) return [];

  const mainIds = headers.map((h) => h.main_id);
  const detailSql = `
    SELECT pd.purchasemain_id AS main_id, pd.entry_no, pd.net_weight, pd.rate, pd.total,
           COALESCE(im.${ITEMS_TABLE.name}, pd.Item_code) AS item_name,
           pd.entry AS detail_entry
    FROM PurchaseDetail pd
    LEFT JOIN ${ITEMS_TABLE.table} im ON im.${ITEMS_TABLE.code} = pd.Item_code
    WHERE pd.purchasemain_id IN (?)
    ORDER BY pd.purchasemain_id, pd.entry_no
  `;
  const [details] = await db.query(detailSql, [mainIds]);

  const detailsByMain = new Map();
  for (const d of details) {
    if (!detailsByMain.has(d.main_id)) detailsByMain.set(d.main_id, []);
    detailsByMain.get(d.main_id).push(d);
  }

  return headers.map((h) => {
    const rows = detailsByMain.get(h.main_id) || [];
    const items = rows.map((r) => r.item_name).join(", ");
    const netWeights = rows.map((r) => toNumber(r.net_weight)).join(", ");
    const rates = rows.map((r) => toNumber(r.rate)).join(", ");
    const total = rows.reduce((sum, r) => sum + toNumber(r.total), 0);

    const isAuto = h.entry === 'auto' || rows.some(r => r.detail_entry === 'auto');

    const gpPart = h.gp_no ? `G.P #(${h.gp_no})` : "";
    const narration = [
      gpPart,
      rows.length ? `Item(${items})` : "",
      rows.length ? `NetW(${netWeights})` : "",
      rows.length ? `Rate(${rates})` : "",
    ]
      .filter(Boolean)
      .join(" ");

    return {
      txn_date: normalizeDbDate(h.txn_date),
      voucher_type: isAuto ? "P (Auto)" : "P",
      voucher_no: h.voucher_no,
      narration,
      debit: isAuto ? total : 0,
      credit: isAuto ? 0 : total,
      is_auto: isAuto,
    };
  });
}

async function fetchPurchaseOpeningTotal(companyId, accountCode, fyStartDate, startDate) {
  const sql = `
    SELECT 
      COALESCE(SUM(CASE WHEN pm.entry = 'auto' THEN pd.total ELSE 0 END), 0) AS auto_total_debit,
      COALESCE(SUM(CASE WHEN pm.entry = 'user' THEN pd.total ELSE 0 END), 0) AS user_total_credit
    FROM PurchaseDetail pd
    INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
    WHERE pd.company_id = ?
      AND pm.supplier_code = ?
      AND pm.grn_date >= ?
      AND pm.grn_date <  ?
  `;
  const [rows] = await db.query(sql, [companyId, accountCode, fyStartDate, startDate]);
  return { 
    debit: toNumber(rows[0]?.auto_total_debit), 
    credit: toNumber(rows[0]?.user_total_credit) 
  };
}

// -------- Purchase Return rows (mirror of Purchase, debit/credit flipped) --
// entry='user' -> debit | entry='auto' -> credit  (reversal of a purchase)
async function fetchPurchaseReturnRows(companyId, accountCode, startDate, endDate) {
  const headerSql = `
    SELECT prm.id AS main_id, prm.return_date AS txn_date, prm.return_no AS voucher_no,
           prm.gp_no AS gp_no, prm.entry AS entry
    FROM PurchaseReturnMain prm
    WHERE prm.company_id = ?
      AND prm.supplier_code = ?
      AND prm.return_date BETWEEN ? AND ?
    ORDER BY prm.return_date, prm.id
  `;
  const [headers] = await db.query(headerSql, [companyId, accountCode, startDate, endDate]);
  if (headers.length === 0) return [];

  const mainIds = headers.map((h) => h.main_id);
  const detailSql = `
    SELECT prd.purchasereturnmain_id AS main_id, prd.entry_no, prd.net_weight, prd.rate, prd.total,
           COALESCE(im.${ITEMS_TABLE.name}, prd.Item_code) AS item_name,
           prd.entry AS detail_entry
    FROM PurchaseReturnDetail prd
    LEFT JOIN ${ITEMS_TABLE.table} im ON im.${ITEMS_TABLE.code} = prd.Item_code
    WHERE prd.purchasereturnmain_id IN (?)
    ORDER BY prd.purchasereturnmain_id, prd.entry_no
  `;
  const [details] = await db.query(detailSql, [mainIds]);

  const detailsByMain = new Map();
  for (const d of details) {
    if (!detailsByMain.has(d.main_id)) detailsByMain.set(d.main_id, []);
    detailsByMain.get(d.main_id).push(d);
  }

  return headers.map((h) => {
    const rows = detailsByMain.get(h.main_id) || [];
    const items = rows.map((r) => r.item_name).join(", ");
    const netWeights = rows.map((r) => toNumber(r.net_weight)).join(", ");
    const rates = rows.map((r) => toNumber(r.rate)).join(", ");
    const total = rows.reduce((sum, r) => sum + toNumber(r.total), 0);

    const isAuto = h.entry === 'auto' || rows.some(r => r.detail_entry === 'auto');

    const gpPart = h.gp_no ? `G.P #(${h.gp_no})` : "";
    const narration = [
      gpPart,
      rows.length ? `Item(${items})` : "",
      rows.length ? `NetW(${netWeights})` : "",
      rows.length ? `Rate(${rates})` : "",
    ]
      .filter(Boolean)
      .join(" ");

    // Flipped vs. Purchase: user -> debit, auto -> credit
    return {
      txn_date: normalizeDbDate(h.txn_date),
      voucher_type: isAuto ? "PR (Auto)" : "PR",
      voucher_no: h.voucher_no,
      narration,
      debit: isAuto ? 0 : total,
      credit: isAuto ? total : 0,
      is_auto: isAuto,
    };
  });
}

async function fetchPurchaseReturnOpeningTotal(companyId, accountCode, fyStartDate, startDate) {
  const sql = `
    SELECT 
      COALESCE(SUM(CASE WHEN prm.entry = 'user' THEN prd.total ELSE 0 END), 0) AS user_total_debit,
      COALESCE(SUM(CASE WHEN prm.entry = 'auto' THEN prd.total ELSE 0 END), 0) AS auto_total_credit
    FROM PurchaseReturnDetail prd
    INNER JOIN PurchaseReturnMain prm ON prm.id = prd.purchasereturnmain_id
    WHERE prd.company_id = ?
      AND prm.supplier_code = ?
      AND prm.return_date >= ?
      AND prm.return_date <  ?
  `;
  const [rows] = await db.query(sql, [companyId, accountCode, fyStartDate, startDate]);
  return { 
    debit: toNumber(rows[0]?.user_total_debit), 
    credit: toNumber(rows[0]?.auto_total_credit) 
  };
}

// -------- Sales rows (header + detail merged, item narration built) --------
// entry='user' -> debit | entry='auto' -> credit
async function fetchSalesRows(companyId, accountCode, startDate, endDate) {
  const headerSql = `
    SELECT sm.id AS main_id, sm.invoice_date AS txn_date, sm.invoice_no AS voucher_no,
           sm.gp_no AS gp_no, sm.total AS total, sm.entry AS entry
    FROM SalesMain sm
    WHERE sm.company_id = ?
      AND sm.customer_code = ?
      AND sm.invoice_date BETWEEN ? AND ?
    ORDER BY sm.invoice_date, sm.id
  `;
  const [headers] = await db.query(headerSql, [companyId, accountCode, startDate, endDate]);
  if (headers.length === 0) return [];

  const mainIds = headers.map((h) => h.main_id);
  const detailSql = `
    SELECT sd.sale_main AS main_id, sd.entry_no, sd.net_weight, sd.rate, sd.total,
           COALESCE(im.${ITEMS_TABLE.name}, sd.Item_code) AS item_name,
           sd.entry AS detail_entry
    FROM SalesDetail sd
    LEFT JOIN ${ITEMS_TABLE.table} im ON im.${ITEMS_TABLE.code} = sd.Item_code
    WHERE sd.sale_main IN (?)
    ORDER BY sd.sale_main, sd.entry_no
  `;
  const [details] = await db.query(detailSql, [mainIds]);

  const detailsByMain = new Map();
  for (const d of details) {
    if (!detailsByMain.has(d.main_id)) detailsByMain.set(d.main_id, []);
    detailsByMain.get(d.main_id).push(d);
  }

  return headers.map((h) => {
    const rows = detailsByMain.get(h.main_id) || [];
    const items = rows.map((r) => r.item_name).join(", ");
    const netWeights = rows.map((r) => toNumber(r.net_weight)).join(", ");
    const rates = rows.map((r) => toNumber(r.rate)).join(", ");

    const isAuto = h.entry === 'auto' || rows.some(r => r.detail_entry === 'auto');

    const gpPart = h.gp_no ? `G.P #(${h.gp_no})` : "";
    const narration = [
      gpPart,
      rows.length ? `Item(${items})` : "",
      rows.length ? `NetW(${netWeights})` : "",
      rows.length ? `Rate(${rates})` : "",
    ]
      .filter(Boolean)
      .join(" ");

    return {
      txn_date: normalizeDbDate(h.txn_date),
      voucher_type: isAuto ? "S (Auto)" : "S",
      voucher_no: h.voucher_no,
      narration,
      debit: isAuto ? 0 : toNumber(h.total),
      credit: isAuto ? toNumber(h.total) : 0,
      is_auto: isAuto,
    };
  });
}

async function fetchSalesOpeningTotal(companyId, accountCode, fyStartDate, startDate) {
  const sql = `
    SELECT 
      COALESCE(SUM(CASE WHEN sm.entry = 'user' THEN sm.total ELSE 0 END), 0) AS user_total_debit,
      COALESCE(SUM(CASE WHEN sm.entry = 'auto' THEN sm.total ELSE 0 END), 0) AS auto_total_credit
    FROM SalesMain sm
    WHERE sm.company_id = ?
      AND sm.customer_code = ?
      AND sm.invoice_date >= ?
      AND sm.invoice_date <  ?
  `;
  const [rows] = await db.query(sql, [companyId, accountCode, fyStartDate, startDate]);
  return { 
    debit: toNumber(rows[0]?.user_total_debit), 
    credit: toNumber(rows[0]?.auto_total_credit) 
  };
}

// -------- Sales Return rows (mirror of Sales, debit/credit flipped) --------
// entry='user' -> credit | entry='auto' -> debit  (reversal of a sale)
async function fetchSalesReturnRows(companyId, accountCode, startDate, endDate) {
  const headerSql = `
    SELECT srm.id AS main_id, srm.invoice_date AS txn_date, srm.invoice_no AS voucher_no,
           srm.gp_no AS gp_no, srm.total AS total, srm.entry AS entry
    FROM SalesReturnMain srm
    WHERE srm.company_id = ?
      AND srm.customer_code = ?
      AND srm.invoice_date BETWEEN ? AND ?
    ORDER BY srm.invoice_date, srm.id
  `;
  const [headers] = await db.query(headerSql, [companyId, accountCode, startDate, endDate]);
  if (headers.length === 0) return [];

  const mainIds = headers.map((h) => h.main_id);
  const detailSql = `
    SELECT srd.sales_return_main AS main_id, srd.entry_no, srd.net_weight, srd.rate, srd.total,
           COALESCE(im.${ITEMS_TABLE.name}, srd.Item_code) AS item_name,
           srd.entry AS detail_entry
    FROM SalesReturnDetail srd
    LEFT JOIN ${ITEMS_TABLE.table} im ON im.${ITEMS_TABLE.code} = srd.Item_code
    WHERE srd.sales_return_main IN (?)
    ORDER BY srd.sales_return_main, srd.entry_no
  `;
  const [details] = await db.query(detailSql, [mainIds]);

  const detailsByMain = new Map();
  for (const d of details) {
    if (!detailsByMain.has(d.main_id)) detailsByMain.set(d.main_id, []);
    detailsByMain.get(d.main_id).push(d);
  }

  return headers.map((h) => {
    const rows = detailsByMain.get(h.main_id) || [];
    const items = rows.map((r) => r.item_name).join(", ");
    const netWeights = rows.map((r) => toNumber(r.net_weight)).join(", ");
    const rates = rows.map((r) => toNumber(r.rate)).join(", ");

    const isAuto = h.entry === 'auto' || rows.some(r => r.detail_entry === 'auto');

    const gpPart = h.gp_no ? `G.P #(${h.gp_no})` : "";
    const narration = [
      gpPart,
      rows.length ? `Item(${items})` : "",
      rows.length ? `NetW(${netWeights})` : "",
      rows.length ? `Rate(${rates})` : "",
    ]
      .filter(Boolean)
      .join(" ");

    // Flipped vs. Sales: user -> credit, auto -> debit
    return {
      txn_date: normalizeDbDate(h.txn_date),
      voucher_type: isAuto ? "SR (Auto)" : "SR",
      voucher_no: h.voucher_no,
      narration,
      debit: isAuto ? toNumber(h.total) : 0,
      credit: isAuto ? 0 : toNumber(h.total),
      is_auto: isAuto,
    };
  });
}

async function fetchSalesReturnOpeningTotal(companyId, accountCode, fyStartDate, startDate) {
  const sql = `
    SELECT 
      COALESCE(SUM(CASE WHEN srm.entry = 'auto' THEN srm.total ELSE 0 END), 0) AS auto_total_debit,
      COALESCE(SUM(CASE WHEN srm.entry = 'user' THEN srm.total ELSE 0 END), 0) AS user_total_credit
    FROM SalesReturnMain srm
    WHERE srm.company_id = ?
      AND srm.customer_code = ?
      AND srm.invoice_date >= ?
      AND srm.invoice_date <  ?
  `;
  const [rows] = await db.query(sql, [companyId, accountCode, fyStartDate, startDate]);
  return { 
    debit: toNumber(rows[0]?.auto_total_debit), 
    credit: toNumber(rows[0]?.user_total_credit) 
  };
}

// ============================================================================
// GET /ledger/report
//   query params: company_id, financialyear_id (sent straight from Redux),
//                 account_id (int, for VoucherDetail.accountcode),
//                 account_code (varchar, for supplier_code/customer_code),
//                 start_date (YYYY-MM-DD), end_date (YYYY-MM-DD)
// ============================================================================
async function getLedgerReport(req, res) {
  try {
    const { company_id, financialyear_id, account_id, account_code, start_date, end_date } = req.query;

    if (!company_id || !financialyear_id || !account_id || !account_code || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message:
          "company_id, financialyear_id, account_id, account_code, start_date and end_date are required",
      });
    }

    const startDate = toSqlDate(start_date);
    const endDate = toSqlDate(end_date);

    // ------------------------------------------------------------------
    // STEP 1: look up the financial year sent from the frontend (Redux)
    // by its PK — no date-range scanning, no ambiguity.
    // ------------------------------------------------------------------
    const financialYear = await fetchFinancialYearById(company_id, financialyear_id);
    if (!financialYear) {
      return res.status(400).json({
        success: false,
        message: `Financial year ${financialyear_id} was not found for this company.`,
      });
    }
    const fyStartDate = financialYear.start_date;

    // ------------------------------------------------------------------
    // STEP 2: opening balance = that FY's stored OpeningBalance
    // + every voucher/purchase/purchase-return/sales/sales-return
    // transaction dated from the FY's start up to (but excluding)
    // start_date, replayed on top of it.
    // ------------------------------------------------------------------
    const [
      storedOpening,
      voucherOpening,
      purchaseOpening,
      purchaseReturnOpening,
      salesOpening,
      salesReturnOpening,
    ] = await Promise.all([
      fetchOpeningBalanceForYear(company_id, account_id, financialYear.id),
      fetchVoucherOpeningTotals(company_id, account_code, fyStartDate, startDate),
      fetchPurchaseOpeningTotal(company_id, account_code, fyStartDate, startDate),
      fetchPurchaseReturnOpeningTotal(company_id, account_code, fyStartDate, startDate),
      fetchSalesOpeningTotal(company_id, account_code, fyStartDate, startDate),
      fetchSalesReturnOpeningTotal(company_id, account_code, fyStartDate, startDate),
    ]);

    const openingDebit =
      storedOpening.debit +
      voucherOpening.debit +
      purchaseOpening.debit +
      purchaseReturnOpening.debit +
      salesOpening.debit +
      salesReturnOpening.debit;
    const openingCredit =
      storedOpening.credit +
      voucherOpening.credit +
      purchaseOpening.credit +
      purchaseReturnOpening.credit +
      salesOpening.credit +
      salesReturnOpening.credit;
    const openingBalance = openingDebit - openingCredit;

    // ------------------------------------------------------------------
    // STEP 3: fetch the rows to actually display — everything dated
    // between start_date and end_date (inclusive), across all five
    // sources, merged and sorted chronologically.
    // ------------------------------------------------------------------
    const [voucherRows, purchaseRows, purchaseReturnRows, salesRows, salesReturnRows] = await Promise.all([
      fetchVoucherRows(company_id, account_code, startDate, endDate),
      fetchPurchaseRows(company_id, account_code, startDate, endDate),
      fetchPurchaseReturnRows(company_id, account_code, startDate, endDate),
      fetchSalesRows(company_id, account_code, startDate, endDate),
      fetchSalesReturnRows(company_id, account_code, startDate, endDate),
    ]);

    // Stable sort keeps same-day order as fetched (each source query is
    // already date-ordered).
    const merged = [
      ...voucherRows,
      ...purchaseRows,
      ...purchaseReturnRows,
      ...salesRows,
      ...salesReturnRows,
    ].sort((a, b) => {
      if (a.txn_date < b.txn_date) return -1;
      if (a.txn_date > b.txn_date) return 1;
      return 0;
    });

    // ------------------------------------------------------------------
    // STEP 4: running balance, starting from the opening balance.
    // ------------------------------------------------------------------
    let runningBalance = openingBalance;
    const rows = merged.map((r, idx) => {
      runningBalance = runningBalance + r.debit - r.credit;
      return {
        s_no: idx + 1,
        date: r.txn_date,
        voucher_type: r.voucher_type,
        voucher_no: r.voucher_no,
        narration: r.narration,
        debit: r.debit,
        credit: r.credit,
        balance: Number(runningBalance.toFixed(2)),
        is_auto: r.is_auto || false,
      };
    });

    const totals = rows.reduce(
      (acc, r) => {
        acc.debit += r.debit;
        acc.credit += r.credit;
        return acc;
      },
      { debit: 0, credit: 0 }
    );

    return res.json({
      success: true,
      data: {
        opening_balance: Number(openingBalance.toFixed(2)),
        rows,
        total_debit: Number(totals.debit.toFixed(2)),
        total_credit: Number(totals.credit.toFixed(2)),
        closing_balance: rows.length ? rows[rows.length - 1].balance : Number(openingBalance.toFixed(2)),
        start_date: startDate,
        end_date: endDate,
      },
    });
  } catch (err) {
    console.error("getLedgerReport error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate ledger report" });
  }
}

module.exports = {
  searchAccounts,
  getLedgerReport,
};