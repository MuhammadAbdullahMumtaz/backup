const db = require("../../../config/db");

/**
 * ============================================================================
 * TRIAL BALANCE CONTROLLER
 * ============================================================================
 * Produces a 4-level trial balance for one company / financial year:
 *
 *   Level 1 -> BalanceSheet   (e.g. "CAPITAL", "CURRENT LIABILITIES")
 *   Level 2 -> MainCode       (e.g. "1001  CAPITAL A/C")
 *   Level 3 -> SubCode        (e.g. "10010  SHARE CAPITAL")
 *   Level 4 -> ChartOfAccount (the actual ledger account — the leaf)
 *
 * This is the same 5-source merge idea used by the ledger report
 * (Voucher + Purchase + Purchase Return + Sales + Sales Return), just
 * computed for EVERY account at once instead of one account at a time,
 * then rolled up through ChartOfAccount -> SubCode -> MainCode ->
 * BalanceSheet.
 *
 * For each leaf account we compute:
 *   opening_debit / opening_credit  = stored OpeningBalance for the FY
 *                                      + every Voucher/Purchase/
 *                                        PurchaseReturn/Sales/SalesReturn
 *                                        dated on/after the FY's
 *                                        start_date and strictly before
 *                                        `start_date`
 *   period_debit  / period_credit   = every Voucher/Purchase/
 *                                      PurchaseReturn/Sales/SalesReturn
 *                                      dated between `start_date` and
 *                                      `end_date` (inclusive)
 *   closing_debit / closing_credit  = net of (opening + period), put back
 *                                      on whichever side is positive
 *
 * Every level above the leaf is just the sum of its children — same
 * approach the printed sample trial balance uses (a totals line under
 * every group, and under every group-of-groups).
 *
 * Debit/Credit convention (same as the ledger controller, confirmed):
 *   - Purchase:        entry='user' -> credit | entry='auto' -> debit
 *   - Purchase Return:  entry='user' -> debit  | entry='auto' -> credit  (reversal)
 *   - Sales:            entry='user' -> debit  | entry='auto' -> credit
 *   - Sales Return:      entry='user' -> credit | entry='auto' -> debit  (reversal)
 *
 * Table mapping (matches the schema you shared):
 *   - ChartOfAccount.id   -> VoucherDetail.accountcode
 *   - ChartOfAccount.code -> PurchaseMain.supplier_code / PurchaseReturnMain.supplier_code
 *                            / SalesMain.customer_code / SalesReturnMain.customer_code
 *   - ChartOfAccount.subcode_id -> SubCode.id
 *   - SubCode.maincode_id       -> MainCode.id
 *   - MainCode.balancesheet_id  -> BalanceSheet.id
 * ============================================================================
 */

/**
 * Recommended indexes (create once, huge impact on report speed):
 *
 *   ALTER TABLE ChartOfAccount       ADD INDEX idx_coa_scope (company_id, financialyear_id, subcode_id);
 *   ALTER TABLE SubCode              ADD INDEX idx_sc_maincode (maincode_id);
 *   ALTER TABLE MainCode             ADD INDEX idx_mc_balancesheet (balancesheet_id);
 *   ALTER TABLE OpeningBalance       ADD INDEX idx_ob_lookup (company_id, financialyear_id, chartofaccount_id);
 *   ALTER TABLE VoucherDetail        ADD INDEX idx_vd_tb (company_id, accountcode);
 *   ALTER TABLE VoucherMain          ADD INDEX idx_vm_date (voucher_date);
 *   ALTER TABLE PurchaseMain         ADD INDEX idx_pm_tb (company_id, supplier_code, grn_date);
 *   ALTER TABLE PurchaseDetail       ADD INDEX idx_pd_main (purchasemain_id);
 *   ALTER TABLE PurchaseReturnMain   ADD INDEX idx_prm_tb (company_id, supplier_code, return_date);
 *   ALTER TABLE PurchaseReturnDetail ADD INDEX idx_prd_main (purchasereturnmain_id);
 *   ALTER TABLE SalesMain            ADD INDEX idx_sm_tb (company_id, customer_code, sale_date);
 *   ALTER TABLE SalesReturnMain      ADD INDEX idx_srm_tb (company_id, customer_code, sale_date);
 */

// ============================================================================
// Helpers (same conventions as the ledger controller)
// ============================================================================

function toSqlDate(d) {
  if (d instanceof Date) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function emptyTotals() {
  return { opening_debit: 0, opening_credit: 0, period_debit: 0, period_credit: 0, closing_debit: 0, closing_credit: 0 };
}

function addTotals(target, src) {
  target.opening_debit += src.opening_debit;
  target.opening_credit += src.opening_credit;
  target.period_debit += src.period_debit;
  target.period_credit += src.period_credit;
  target.closing_debit += src.closing_debit;
  target.closing_credit += src.closing_credit;
}

function round2(n) {
  return Number((Math.round((n + Number.EPSILON) * 100) / 100).toFixed(2));
}

function roundTotals(t) {
  return {
    opening_debit: round2(t.opening_debit),
    opening_credit: round2(t.opening_credit),
    period_debit: round2(t.period_debit),
    period_credit: round2(t.period_credit),
    closing_debit: round2(t.closing_debit),
    closing_credit: round2(t.closing_credit),
  };
}

// ============================================================================
// GET /api/trial-balance/financial-year?company_id=&financialyear_id=
// Used by the frontend to pre-fill the Start date / End date inputs with
// the selected financial year's own start_date / end_date.
// ============================================================================
async function getFinancialYearRange(req, res) {
  try {
    const { company_id, financialyear_id } = req.query;
    if (!company_id || !financialyear_id) {
      return res.status(400).json({ success: false, message: "company_id and financialyear_id are required" });
    }

    const sql = `
      SELECT id, start_date, end_date
      FROM FinancialYear
      WHERE company_id = ?
        AND id = ?
      LIMIT 1
    `;
    const [rows] = await db.query(sql, [company_id, financialyear_id]);
    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Financial year not found" });
    }

    return res.json({
      success: true,
      data: {
        id: rows[0].id,
        start_date: normalizeDbDate(rows[0].start_date),
        end_date: normalizeDbDate(rows[0].end_date),
      },
    });
  } catch (err) {
    console.error("getFinancialYearRange error:", err);
    return res.status(500).json({ success: false, message: "Failed to fetch financial year" });
  }
}

async function fetchFinancialYearById(companyId, financialYearId) {
  const sql = `
    SELECT id, start_date, end_date
    FROM FinancialYear
    WHERE company_id = ?
      AND id = ?
    LIMIT 1
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  if (!rows.length) return null;
  return {
    id: rows[0].id,
    start_date: normalizeDbDate(rows[0].start_date),
    end_date: normalizeDbDate(rows[0].end_date),
  };
}

// ============================================================================
// Bulk fetchers — one query per source/period combo, grouped so we never
// loop per-account (would be N+1 across hundreds of accounts).
// ============================================================================

async function fetchCoaHierarchy(companyId, financialYearId) {
  const sql = `
    SELECT
      bs.id      AS bs_id,
      bs.details AS bs_details,
      mc.id      AS mc_id,
      mc.code    AS mc_code,
      mc.details AS mc_details,
      sc.id      AS sc_id,
      sc.code    AS sc_code,
      sc.details AS sc_details,
      coa.id           AS coa_id,
      coa.code         AS coa_code,
      coa.account_name AS coa_name
    FROM ChartOfAccount coa
    INNER JOIN SubCode sc ON sc.id = coa.subcode_id
    INNER JOIN MainCode mc ON mc.id = sc.maincode_id
    INNER JOIN BalanceSheet bs ON bs.id = mc.balancesheet_id
    WHERE coa.company_id = ?
      AND coa.financialyear_id = ?
    ORDER BY bs.id, mc.code, sc.code, coa.code
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  return rows;
}

async function fetchStoredOpeningMap(companyId, financialYearId) {
  const sql = `
    SELECT chartofaccount_id AS acc,
           COALESCE(SUM(debit), 0)  AS debit,
           COALESCE(SUM(credit), 0) AS credit
    FROM OpeningBalance
    WHERE company_id = ?
      AND financialyear_id = ?
    GROUP BY chartofaccount_id
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  const map = new Map();
  for (const r of rows) map.set(r.acc, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

// Voucher totals grouped by accountcode (ChartOfAccount.id), for a date window.
async function fetchVoucherMap(companyId, fromDate, toDate, inclusive) {
  const sql = `
    SELECT vd.accountcode AS acc,
           COALESCE(SUM(vd.debit), 0)  AS debit,
           COALESCE(SUM(vd.credit), 0) AS credit
    FROM VoucherDetail vd
    INNER JOIN VoucherMain vm ON vm.id = vd.vouchermain_id
    WHERE vd.company_id = ?
      AND vm.voucher_date >= ?
      AND vm.voucher_date ${inclusive ? "<=" : "<"} ?
    GROUP BY vd.accountcode
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.acc, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

// Purchase totals grouped by supplier_code (ChartOfAccount.code), for a date window.
// Mirrors the ledger controller's opening-total logic: 'auto' entries land on
// debit, 'user' entries land on credit (decided at the PurchaseMain header level).
async function fetchPurchaseMap(companyId, fromDate, toDate, inclusive) {
  const sql = `
    SELECT pm.supplier_code AS code,
           COALESCE(SUM(CASE WHEN pm.entry = 'auto' THEN pd.total ELSE 0 END), 0) AS debit,
           COALESCE(SUM(CASE WHEN pm.entry = 'user' THEN pd.total ELSE 0 END), 0) AS credit
    FROM PurchaseDetail pd
    INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
    WHERE pd.company_id = ?
      AND pm.grn_date >= ?
      AND pm.grn_date ${inclusive ? "<=" : "<"} ?
    GROUP BY pm.supplier_code
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.code, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

// Purchase Return totals grouped by supplier_code (ChartOfAccount.code), for a
// date window. Mirror of Purchase, debit/credit flipped (it's a reversal):
// 'user' entries land on debit, 'auto' entries land on credit.
async function fetchPurchaseReturnMap(companyId, fromDate, toDate, inclusive) {
  const sql = `
    SELECT prm.supplier_code AS code,
           COALESCE(SUM(CASE WHEN prm.entry = 'user' THEN prd.total ELSE 0 END), 0) AS debit,
           COALESCE(SUM(CASE WHEN prm.entry = 'auto' THEN prd.total ELSE 0 END), 0) AS credit
    FROM PurchaseReturnDetail prd
    INNER JOIN PurchaseReturnMain prm ON prm.id = prd.purchasereturnmain_id
    WHERE prd.company_id = ?
      AND prm.return_date >= ?
      AND prm.return_date ${inclusive ? "<=" : "<"} ?
    GROUP BY prm.supplier_code
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.code, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

// Sales totals grouped by customer_code (ChartOfAccount.code), for a date window.
// Mirrors the ledger controller: 'user' entries land on debit, 'auto' on credit.
async function fetchSalesMap(companyId, fromDate, toDate, inclusive) {
  const sql = `
    SELECT sm.customer_code AS code,
           COALESCE(SUM(CASE WHEN sm.entry = 'user' THEN sm.total ELSE 0 END), 0) AS debit,
           COALESCE(SUM(CASE WHEN sm.entry = 'auto' THEN sm.total ELSE 0 END), 0) AS credit
    FROM SalesMain sm
    WHERE sm.company_id = ?
      AND sm.invoice_date >= ?
      AND sm.invoice_date ${inclusive ? "<=" : "<"} ?
    GROUP BY sm.customer_code
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.code, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

// Sales Return totals grouped by customer_code (ChartOfAccount.code), for a
// date window. Mirror of Sales, debit/credit flipped (it's a reversal):
// 'auto' entries land on debit, 'user' entries land on credit.
async function fetchSalesReturnMap(companyId, fromDate, toDate, inclusive) {
  const sql = `
    SELECT srm.customer_code AS code,
           COALESCE(SUM(CASE WHEN srm.entry = 'auto' THEN srm.total ELSE 0 END), 0) AS debit,
           COALESCE(SUM(CASE WHEN srm.entry = 'user' THEN srm.total ELSE 0 END), 0) AS credit
    FROM SalesReturnMain srm
    WHERE srm.company_id = ?
      AND srm.invoice_date >= ?
      AND srm.invoice_date ${inclusive ? "<=" : "<"} ?
    GROUP BY srm.customer_code
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.code, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

// ============================================================================
// GET /api/trial-balance/report
//   query params: company_id, financialyear_id, start_date (YYYY-MM-DD),
//                 end_date (YYYY-MM-DD)
// ============================================================================
async function getTrialBalance(req, res) {
  try {
    const { company_id, financialyear_id, start_date, end_date } = req.query;

    if (!company_id || !financialyear_id || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: "company_id, financialyear_id, start_date and end_date are required",
      });
    }

    const startDate = toSqlDate(start_date);
    const endDate = toSqlDate(end_date);

    // STEP 1 — financial year, looked up by PK (no date scanning).
    const financialYear = await fetchFinancialYearById(company_id, financialyear_id);
    if (!financialYear) {
      return res.status(400).json({
        success: false,
        message: `Financial year ${financialyear_id} was not found for this company.`,
      });
    }
    const fyStartDate = financialYear.start_date;

    // STEP 2 — pull the full 4-level chart-of-account hierarchy, plus every
    // source's opening (replay) and period totals, in parallel bulk queries.
    const [
      coaRows,
      storedOpeningMap,
      voucherOpeningMap,
      voucherPeriodMap,
      purchaseOpeningMap,
      purchasePeriodMap,
      purchaseReturnOpeningMap,
      purchaseReturnPeriodMap,
      salesOpeningMap,
      salesPeriodMap,
      salesReturnOpeningMap,
      salesReturnPeriodMap,
    ] = await Promise.all([
      fetchCoaHierarchy(company_id, financialyear_id),
      fetchStoredOpeningMap(company_id, financialyear_id),
      fetchVoucherMap(company_id, fyStartDate, startDate, false),
      fetchVoucherMap(company_id, startDate, endDate, true),
      fetchPurchaseMap(company_id, fyStartDate, startDate, false),
      fetchPurchaseMap(company_id, startDate, endDate, true),
      fetchPurchaseReturnMap(company_id, fyStartDate, startDate, false),
      fetchPurchaseReturnMap(company_id, startDate, endDate, true),
      fetchSalesMap(company_id, fyStartDate, startDate, false),
      fetchSalesMap(company_id, startDate, endDate, true),
      fetchSalesReturnMap(company_id, fyStartDate, startDate, false),
      fetchSalesReturnMap(company_id, startDate, endDate, true),
    ]);

    // STEP 3 — compute each leaf account's opening / period / closing, then
    // fold it up into SubCode -> MainCode -> BalanceSheet totals.
    const balanceSheetMap = new Map(); // bs_id -> node
    const grandTotal = emptyTotals();

    for (const row of coaRows) {
      const so = storedOpeningMap.get(row.coa_id) || { debit: 0, credit: 0 }; // fine — OpeningBalance is keyed by chartofaccount_id, a real FK
      const vo = voucherOpeningMap.get(Number(row.coa_code)) || { debit: 0, credit: 0 };  // FIXED
      const po = purchaseOpeningMap.get(row.coa_code) || { debit: 0, credit: 0 };
      const pro = purchaseReturnOpeningMap.get(row.coa_code) || { debit: 0, credit: 0 };
      const zo = salesOpeningMap.get(row.coa_code) || { debit: 0, credit: 0 };
      const zro = salesReturnOpeningMap.get(row.coa_code) || { debit: 0, credit: 0 };

      const opening_debit = so.debit + vo.debit + po.debit + pro.debit + zo.debit + zro.debit;
      const opening_credit = so.credit + vo.credit + po.credit + pro.credit + zo.credit + zro.credit;

      const vp = voucherPeriodMap.get(Number(row.coa_code)) || { debit: 0, credit: 0 };  // FIXED
      const pp = purchasePeriodMap.get(row.coa_code) || { debit: 0, credit: 0 };
      const prp = purchaseReturnPeriodMap.get(row.coa_code) || { debit: 0, credit: 0 };
      const zp = salesPeriodMap.get(row.coa_code) || { debit: 0, credit: 0 };
      const zrp = salesReturnPeriodMap.get(row.coa_code) || { debit: 0, credit: 0 };

      const period_debit = vp.debit + pp.debit + prp.debit + zp.debit + zrp.debit;
      const period_credit = vp.credit + pp.credit + prp.credit + zp.credit + zrp.credit;

      const net = opening_debit - opening_credit + (period_debit - period_credit);
      const closing_debit = net > 0 ? net : 0;
      const closing_credit = net < 0 ? -net : 0;

      const account = {
        id: row.coa_id,
        code: row.coa_code,
        account_name: row.coa_name,
        ...roundTotals({ opening_debit, opening_credit, period_debit, period_credit, closing_debit, closing_credit }),
      };

      // ---- fold into SubCode ----
      if (!balanceSheetMap.has(row.bs_id)) {
        balanceSheetMap.set(row.bs_id, {
          id: row.bs_id,
          details: row.bs_details,
          maincodes: new Map(),
          totals: emptyTotals(),
        });
      }
      const bsNode = balanceSheetMap.get(row.bs_id);

      if (!bsNode.maincodes.has(row.mc_id)) {
        bsNode.maincodes.set(row.mc_id, {
          id: row.mc_id,
          code: row.mc_code,
          details: row.mc_details,
          subcodes: new Map(),
          totals: emptyTotals(),
        });
      }
      const mcNode = bsNode.maincodes.get(row.mc_id);

      if (!mcNode.subcodes.has(row.sc_id)) {
        mcNode.subcodes.set(row.sc_id, {
          id: row.sc_id,
          code: row.sc_code,
          details: row.sc_details,
          accounts: [],
          totals: emptyTotals(),
        });
      }
      const scNode = mcNode.subcodes.get(row.sc_id);

      scNode.accounts.push(account);
      addTotals(scNode.totals, account);
      addTotals(mcNode.totals, account);
      addTotals(bsNode.totals, account);
      addTotals(grandTotal, account);
    }

    // STEP 4 — flatten Maps to arrays (already ordered by the SQL ORDER BY).
    const balancesheets = Array.from(balanceSheetMap.values()).map((bs) => ({
      id: bs.id,
      details: bs.details,
      totals: roundTotals(bs.totals),
      maincodes: Array.from(bs.maincodes.values()).map((mc) => ({
        id: mc.id,
        code: mc.code,
        details: mc.details,
        totals: roundTotals(mc.totals),
        subcodes: Array.from(mc.subcodes.values()).map((sc) => ({
          id: sc.id,
          code: sc.code,
          details: sc.details,
          totals: roundTotals(sc.totals),
          accounts: sc.accounts,
        })),
      })),
    }));

    return res.json({
      success: true,
      data: {
        start_date: startDate,
        end_date: endDate,
        financial_year: financialYear,
        balancesheets,
        grand_total: roundTotals(grandTotal),
      },
    });
  } catch (err) {
    console.error("getTrialBalance error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate trial balance" });
  }
}

module.exports = {
  getFinancialYearRange,
  getTrialBalance,
};