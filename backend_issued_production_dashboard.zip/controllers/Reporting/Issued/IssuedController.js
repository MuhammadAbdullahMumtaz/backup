const db = require("../../../config/db");

/**
 * ============================================================================
 * ISSUED REPORT CONTROLLER
 * ============================================================================
 * Produces an item-wise stock-issue report (IssuedMain + IssuedDetail) for
 * one item, between a start and end date. Built the same way as the Ledger
 * report (LedgerController.js):
 *
 *   1. financialyear_id is sent straight from the frontend (Redux) and is
 *      looked up by PK — no date-range scanning.
 *   2. "Opening" quantity = sum of pieces / net_weight for this item (and,
 *      if given, this department) issued between the FY's start_date and
 *      (but excluding) `start_date`. IssuedDetail has no rate/amount/total
 *      columns (issued tracks stock movement only, not value), so there is
 *      no money opening balance here — only quantity.
 *   3. Display rows = every IssuedDetail line for this item dated between
 *      `start_date` and `end_date` (inclusive), one row per detail line
 *      (not merged per header, since each line can reference a different
 *      source GRN).
 *   4. Running net weight / pieces start at the opening quantity and are
 *      carried forward row by row; the last row's running value is the
 *      closing quantity.
 *
 * Table mapping used (matches schema v2):
 *   - ItemDetail(code, details, Unit, company_id)  -> item search + display
 *   - Department(id, company_id, department_name)  -> department filter
 *   - IssuedMain(id, company_id, department_id, financialyear_id,
 *                issued_no, issued_date, remarks)
 *   - IssuedDetail(issuedmain_id, Item_code, entry_no, stocks, pieces,
 *                  gross_weight, tear_weight, net_weight, source_type,
 *                  source_detail_id, grn_no, purchase_entry_no)
 *     NOTE: IssuedDetail has NO rate/amount/freight/total columns — those
 *     were intentionally dropped (issued only tracks stock movement).
 * ============================================================================
 */

const ITEMS_TABLE = {
  table: "ItemDetail",
  code: "code",
  name: "details",
  company_id: "company_id",
};

// -----------------------------------------------------------------------------
// Recommended indexes (create once):
//   ALTER TABLE IssuedMain   ADD INDEX idx_im_ledger (company_id, financialyear_id, department_id, issued_date);
//   ALTER TABLE IssuedDetail ADD INDEX idx_id_item (company_id, Item_code, issuedmain_id);
//   ALTER TABLE ItemDetail   ADD INDEX idx_item_search (company_id, details);
// -----------------------------------------------------------------------------

function toSqlDate(d) {
  if (d instanceof Date) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

// ============================================================================
// GET /issued/items/search?company_id=&q=
// ============================================================================
async function searchItems(req, res) {
  try {
    const { company_id, q = "" } = req.query;
    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }
    const like = `%${q.trim()}%`;
    const sql = `
      SELECT ${ITEMS_TABLE.code} AS code,
             ${ITEMS_TABLE.name} AS name,
             Unit AS unit
      FROM ${ITEMS_TABLE.table}
      WHERE ${ITEMS_TABLE.company_id} = ?
        AND (${ITEMS_TABLE.name} LIKE ? OR ${ITEMS_TABLE.code} LIKE ?)
      ORDER BY ${ITEMS_TABLE.name} ASC
      LIMIT 20
    `;
    const [rows] = await db.query(sql, [company_id, like, like]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("searchItems (issued) error:", err);
    return res.status(500).json({ success: false, message: "Failed to search items" });
  }
}

// ============================================================================
// GET /issued/departments?company_id=
// ============================================================================
async function getDepartments(req, res) {
  try {
    const { company_id } = req.query;
    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }
    const sql = `
      SELECT id, department_name
      FROM Department
      WHERE company_id = ?
      ORDER BY department_name ASC
    `;
    const [rows] = await db.query(sql, [company_id]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("getDepartments (issued) error:", err);
    return res.status(500).json({ success: false, message: "Failed to load departments" });
  }
}

// ============================================================================
// GET /issued/items/stock?company_id=&financialyear_id=&department_id=
//   "Show All Items" — one row per item currently holding issued stock
//   (stocks = 'available', i.e. not yet consumed by Production), for the
//   whole financial year to date. Items whose available quantity nets to
//   zero (or less) are dropped via HAVING, so this never lists an item
//   that has nothing left in stock.
// ============================================================================
async function getStockSummary(req, res) {
  try {
    const { company_id, financialyear_id, department_id } = req.query;
    if (!company_id || !financialyear_id) {
      return res.status(400).json({ success: false, message: "company_id and financialyear_id are required" });
    }

    const params = [company_id, financialyear_id];
    let departmentClause = "";
    if (department_id) {
      departmentClause = " AND im.department_id = ? ";
      params.push(department_id);
    }

    const sql = `
      SELECT
        idt.Item_code                      AS code,
        it.details                          AS name,
        it.Unit                              AS unit,
        COALESCE(SUM(idt.pieces), 0)          AS pieces,
        COALESCE(SUM(idt.net_weight), 0)       AS net_weight
      FROM IssuedDetail idt
      INNER JOIN IssuedMain im ON im.id = idt.issuedmain_id
      LEFT JOIN ${ITEMS_TABLE.table} it
        ON it.${ITEMS_TABLE.code} = idt.Item_code AND it.${ITEMS_TABLE.company_id} = idt.company_id
      WHERE idt.company_id = ?
        AND im.financialyear_id = ?
        AND idt.stocks = 'available'
        ${departmentClause}
      GROUP BY idt.Item_code, it.details, it.Unit
      HAVING SUM(idt.net_weight) > 0
      ORDER BY it.details ASC
    `;
    const [rows] = await db.query(sql, params);

    return res.json({
      success: true,
      data: rows.map((r) => ({
        code: r.code,
        name: r.name || r.code,
        unit: r.unit,
        pieces: toNumber(r.pieces),
        net_weight: toNumber(r.net_weight),
      })),
    });
  } catch (err) {
    console.error("getStockSummary (issued) error:", err);
    return res.status(500).json({ success: false, message: "Failed to load stock summary" });
  }
}

// ============================================================================
// Financial year lookup
// ============================================================================
async function fetchFinancialYearById(companyId, financialYearId) {
  const sql = `
    SELECT id, start_date, end_date
    FROM FinancialYear
    WHERE company_id = ?
      AND id = ?
    LIMIT 1
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  if (!rows.length) return null;
  return {
    id: rows[0].id,
    start_date: normalizeDbDate(rows[0].start_date),
    end_date: normalizeDbDate(rows[0].end_date),
  };
}

// ============================================================================
// Opening quantity totals (before start_date, within the FY)
// ============================================================================
async function fetchIssuedOpeningTotals(companyId, itemCode, departmentId, fyStartDate, startDate) {
  const params = [companyId, itemCode, fyStartDate, startDate];
  let departmentClause = "";
  if (departmentId) {
    departmentClause = " AND im.department_id = ? ";
    params.push(departmentId);
  }
  const sql = `
    SELECT
      COALESCE(SUM(idt.pieces), 0)      AS total_pieces,
      COALESCE(SUM(idt.net_weight), 0)  AS total_net_weight
    FROM IssuedDetail idt
    INNER JOIN IssuedMain im ON im.id = idt.issuedmain_id
    WHERE idt.company_id = ?
      AND idt.Item_code = ?
      AND im.issued_date >= ?
      AND im.issued_date <  ?
      ${departmentClause}
  `;
  const [rows] = await db.query(sql, params);
  return {
    pieces: toNumber(rows[0]?.total_pieces),
    net_weight: toNumber(rows[0]?.total_net_weight),
  };
}

// ============================================================================
// Period rows (start_date..end_date inclusive), one row per detail line
// ============================================================================
async function fetchIssuedRows(companyId, itemCode, departmentId, startDate, endDate) {
  const params = [companyId, itemCode, startDate, endDate];
  let departmentClause = "";
  if (departmentId) {
    departmentClause = " AND im.department_id = ? ";
    params.push(departmentId);
  }
  const sql = `
    SELECT
      im.issued_no          AS doc_no,
      im.issued_date        AS txn_date,
      im.remarks            AS header_remarks,
      d.department_name     AS department_name,
      idt.entry_no           AS entry_no,
      idt.stocks              AS stocks,
      idt.pieces               AS pieces,
      idt.gross_weight         AS gross_weight,
      idt.tear_weight          AS tear_weight,
      idt.net_weight           AS net_weight,
      idt.grn_no                AS grn_no,
      idt.purchase_entry_no     AS purchase_entry_no
    FROM IssuedDetail idt
    INNER JOIN IssuedMain im ON im.id = idt.issuedmain_id
    LEFT JOIN Department d ON d.id = im.department_id
    WHERE idt.company_id = ?
      AND idt.Item_code = ?
      AND im.issued_date BETWEEN ? AND ?
      ${departmentClause}
    ORDER BY im.issued_date, im.id, idt.entry_no
  `;
  const [rows] = await db.query(sql, params);
  return rows.map((r) => ({
    txn_date: normalizeDbDate(r.txn_date),
    doc_no: r.doc_no,
    department_name: r.department_name || "",
    stocks: r.stocks,
    pieces: toNumber(r.pieces),
    gross_weight: toNumber(r.gross_weight),
    tear_weight: toNumber(r.tear_weight),
    net_weight: toNumber(r.net_weight),
    source_ref: r.grn_no ? `GRN #${r.grn_no}${r.purchase_entry_no ? ` (Line ${r.purchase_entry_no})` : ""}` : "",
    remarks: r.header_remarks || "",
  }));
}

// ============================================================================
// GET /issued/report
//   query params: company_id, financialyear_id, item_code, department_id
//                 (optional), start_date, end_date
// ============================================================================
async function getIssuedReport(req, res) {
  try {
    const { company_id, financialyear_id, item_code, department_id, start_date, end_date } = req.query;

    if (!company_id || !financialyear_id || !item_code || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: "company_id, financialyear_id, item_code, start_date and end_date are required",
      });
    }

    const startDate = toSqlDate(start_date);
    const endDate = toSqlDate(end_date);
    const departmentId = department_id ? Number(department_id) : null;

    const financialYear = await fetchFinancialYearById(company_id, financialyear_id);
    if (!financialYear) {
      return res.status(400).json({
        success: false,
        message: `Financial year ${financialyear_id} was not found for this company.`,
      });
    }
    const fyStartDate = financialYear.start_date;

    const opening = await fetchIssuedOpeningTotals(company_id, item_code, departmentId, fyStartDate, startDate);
    const rows = await fetchIssuedRows(company_id, item_code, departmentId, startDate, endDate);

    let runningPieces = opening.pieces;
    let runningNetWeight = opening.net_weight;

    const outRows = rows.map((r, idx) => {
      runningPieces += r.pieces;
      runningNetWeight += r.net_weight;
      return {
        s_no: idx + 1,
        date: r.txn_date,
        doc_no: r.doc_no,
        department_name: r.department_name,
        stocks: r.stocks,
        pieces: r.pieces,
        gross_weight: r.gross_weight,
        tear_weight: r.tear_weight,
        net_weight: r.net_weight,
        running_pieces: runningPieces,
        running_net_weight: Number(runningNetWeight.toFixed(2)),
        source_ref: r.source_ref,
        remarks: r.remarks,
      };
    });

    const totals = outRows.reduce(
      (acc, r) => {
        acc.pieces += r.pieces;
        acc.net_weight += r.net_weight;
        return acc;
      },
      { pieces: 0, net_weight: 0 }
    );

    return res.json({
      success: true,
      data: {
        opening_pieces: opening.pieces,
        opening_net_weight: Number(opening.net_weight.toFixed(2)),
        rows: outRows,
        total_pieces: totals.pieces,
        total_net_weight: Number(totals.net_weight.toFixed(2)),
        closing_pieces: outRows.length ? outRows[outRows.length - 1].running_pieces : opening.pieces,
        closing_net_weight: outRows.length
          ? outRows[outRows.length - 1].running_net_weight
          : Number(opening.net_weight.toFixed(2)),
        start_date: startDate,
        end_date: endDate,
      },
    });
  } catch (err) {
    console.error("getIssuedReport error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate issued report" });
  }
}

module.exports = {
  searchItems,
  getDepartments,
  getStockSummary,
  getIssuedReport,
};