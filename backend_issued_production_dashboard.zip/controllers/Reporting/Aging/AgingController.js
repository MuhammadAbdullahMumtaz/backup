const db = require("../../../config/db");

/* ============================================================
   Shared FIFO allocation: applies a pool of reductions (returns +
   voucher payments/receipts) against bills oldest-first. A bill only
   makes it into the report while it still carries an outstanding
   balance; fully paid bills are dropped entirely, not just zeroed.
   ============================================================ */
function allocateAging(bills, reductions) {
    const totalReduction = reductions.reduce((s, r) => s + (Number(r.amount) || 0), 0);

    let cumulativeApplied = 0;
    let runningBalance = 0;
    const rows = [];

    for (const bill of bills) {
        const billAmount = Number(bill.bill_amount) || 0;
        const availableToApply = Math.max(0, totalReduction - cumulativeApplied);
        const appliedToThisBill = Math.min(billAmount, availableToApply);
        cumulativeApplied += appliedToThisBill;

        const outstanding = billAmount - appliedToThisBill;
        // Ignore rounding dust so a fully-paid bill doesn't leave a
        // phantom row behind.
        if (outstanding > 0.01) {
            runningBalance += outstanding;
            rows.push({
                bill_no: bill.bill_no,
                bill_date: bill.bill_date,
                narration: bill.narration,
                bill_amount: billAmount,
                outstanding: Number(outstanding.toFixed(2)),
                days: bill.days,
                balance: Number(runningBalance.toFixed(2)),
            });
        }
    }

    return { rows, total_outstanding: Number(runningBalance.toFixed(2)) };
}

/* ============================================================
   Core per-account aging computation, shared by the single-account
   detail endpoints AND the multi-account summary endpoints so the
   FIFO logic only lives in one place.
   ============================================================ */
async function computeAccountAging(mode, company_id, financialyear_id, account_code) {
    let bills, returnRows, voucherRows;

    if (mode === "receivable") {
        [bills] = await db.query(
            `
            SELECT
                sm.id,
                sm.invoice_no AS bill_no,
                sm.invoice_date AS bill_date,
                sm.total AS bill_amount,
                DATEDIFF(CURDATE(), sm.invoice_date) AS days,
                CONCAT(
                    'Item(', COALESCE(nar.items_list, ''), ') ',
                    'NetW(', COALESCE(nar.weights_list, ''), ') ',
                    'Rate(', COALESCE(nar.rates_list, ''), ')'
                ) AS narration
            FROM SalesMain sm
            LEFT JOIN (
                SELECT
                    sd.sale_main,
                    GROUP_CONCAT(CONCAT(sd.pieces, ' X ', item.details) ORDER BY sd.entry_no SEPARATOR ', ') AS items_list,
                    GROUP_CONCAT(sd.net_weight ORDER BY sd.entry_no SEPARATOR ', ') AS weights_list,
                    GROUP_CONCAT(sd.rate ORDER BY sd.entry_no SEPARATOR ', ') AS rates_list
                FROM SalesDetail sd
                INNER JOIN ItemDetail item
                    ON sd.Item_code = item.code AND sd.company_id = item.company_id
                WHERE sd.entry = 'user'
                GROUP BY sd.sale_main
            ) nar ON nar.sale_main = sm.id
            WHERE sm.company_id = ? AND sm.financialyear_id = ? AND sm.customer_code = ? AND sm.entry = 'user'
            ORDER BY sm.invoice_date ASC, sm.id ASC
            `,
            [company_id, financialyear_id, account_code]
        );

        [returnRows] = await db.query(
            `
            SELECT srm.invoice_date AS reduction_date, srm.total AS amount
            FROM SalesReturnMain srm
            WHERE srm.company_id = ? AND srm.financialyear_id = ? AND srm.customer_code = ? AND srm.entry = 'user'
            `,
            [company_id, financialyear_id, account_code]
        );

        [voucherRows] = await db.query(
            `
            SELECT vm.voucher_date AS reduction_date, vd.credit AS amount
            FROM VoucherDetail vd
            INNER JOIN VoucherMain vm ON vd.vouchermain_id = vm.id
            WHERE vd.company_id = ? AND vd.financialyear_id = ?
              AND CAST(vd.accountcode AS CHAR) = ?
              AND vd.credit > 0
            `,
            [company_id, financialyear_id, account_code]
        );
    } else {
        [bills] = await db.query(
            `
            SELECT
                pm.id,
                pm.grn_no AS bill_no,
                pm.grn_date AS bill_date,
                DATEDIFF(CURDATE(), pm.grn_date) AS days,
                COALESCE(amt.bill_amount, 0) AS bill_amount,
                CONCAT(
                    'Item(', COALESCE(nar.items_list, ''), ') ',
                    'NetW(', COALESCE(nar.weights_list, ''), ') ',
                    'Rate(', COALESCE(nar.rates_list, ''), ')'
                ) AS narration
            FROM PurchaseMain pm
            LEFT JOIN (
                SELECT purchasemain_id, SUM(total) AS bill_amount
                FROM PurchaseDetail
                WHERE entry = 'user'
                GROUP BY purchasemain_id
            ) amt ON amt.purchasemain_id = pm.id
            LEFT JOIN (
                SELECT
                    pd.purchasemain_id,
                    GROUP_CONCAT(CONCAT(pd.pieces, ' X ', item.details) ORDER BY pd.entry_no SEPARATOR ', ') AS items_list,
                    GROUP_CONCAT(pd.net_weight ORDER BY pd.entry_no SEPARATOR ', ') AS weights_list,
                    GROUP_CONCAT(pd.rate ORDER BY pd.entry_no SEPARATOR ', ') AS rates_list
                FROM PurchaseDetail pd
                INNER JOIN ItemDetail item
                    ON pd.Item_code = item.code AND pd.company_id = item.company_id
                WHERE pd.entry = 'user'
                GROUP BY pd.purchasemain_id
            ) nar ON nar.purchasemain_id = pm.id
            WHERE pm.company_id = ? AND pm.financialyear_id = ? AND pm.supplier_code = ? AND pm.entry = 'user'
            ORDER BY pm.grn_date ASC, pm.id ASC
            `,
            [company_id, financialyear_id, account_code]
        );

        [returnRows] = await db.query(
            `
            SELECT prm.return_date AS reduction_date, COALESCE(amt.amount, 0) AS amount
            FROM PurchaseReturnMain prm
            LEFT JOIN (
                SELECT purchasereturnmain_id, SUM(total) AS amount
                FROM PurchaseReturnDetail
                WHERE entry = 'user'
                GROUP BY purchasereturnmain_id
            ) amt ON amt.purchasereturnmain_id = prm.id
            WHERE prm.company_id = ? AND prm.financialyear_id = ? AND prm.supplier_code = ? AND prm.entry = 'user'
            `,
            [company_id, financialyear_id, account_code]
        );

        [voucherRows] = await db.query(
            `
            SELECT vm.voucher_date AS reduction_date, vd.debit AS amount
            FROM VoucherDetail vd
            INNER JOIN VoucherMain vm ON vd.vouchermain_id = vm.id
            WHERE vd.company_id = ? AND vd.financialyear_id = ?
              AND CAST(vd.accountcode AS CHAR) = ?
              AND vd.debit > 0
            `,
            [company_id, financialyear_id, account_code]
        );
    }

    const reductions = [...returnRows, ...voucherRows].sort(
        (a, b) => new Date(a.reduction_date) - new Date(b.reduction_date)
    );

    return allocateAging(bills, reductions);
}

/* ============================================================
   Bucketing helpers for summary reports.

   Buckets 0..numBuckets-1 are fixed-width windows starting at
   startDay; the final bucket (index numBuckets) is the open-ended
   overflow bucket. e.g. startDay=1, daysPerBucket=15, numBuckets=4
   -> "1-15", "16-30", "31-45", "46-60", "61+".
   ============================================================ */
function bucketLabels(numBuckets, daysPerBucket, startDay) {
    const labels = [];
    for (let i = 0; i < numBuckets; i++) {
        const start = startDay + i * daysPerBucket;
        const end = start + daysPerBucket - 1;
        labels.push(`${start}-${end}`);
    }
    labels.push(`${startDay + numBuckets * daysPerBucket}+`);
    return labels;
}

function bucketizeRows(rows, numBuckets, daysPerBucket, startDay) {
    const buckets = new Array(numBuckets + 1).fill(0);
    let maxDay = 0;

    for (const r of rows) {
        const days = Number(r.days) || 0;
        maxDay = Math.max(maxDay, days);

        let idx = numBuckets; // default: overflow bucket
        if (days < startDay) {
            idx = 0;
        } else {
            for (let i = 0; i < numBuckets; i++) {
                const start = startDay + i * daysPerBucket;
                const end = start + daysPerBucket - 1;
                if (days >= start && days <= end) {
                    idx = i;
                    break;
                }
            }
        }
        buckets[idx] += r.outstanding;
    }

    return { buckets: buckets.map((b) => Number(b.toFixed(2))), maxDay };
}

function parseBucketConfig(query) {
    const num_buckets = Math.max(1, Math.min(12, parseInt(query.num_buckets, 10) || 4));
    const days_per_bucket = Math.max(1, parseInt(query.days_per_bucket, 10) || 15);
    const start_day = Math.max(0, parseInt(query.start_day, 10) || 1);
    return { num_buckets, days_per_bucket, start_day };
}

// Generic comma-separated-or-array query param parser, used for both the
// city filter and the account filter.
function parseListParam(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value.filter(Boolean);
    return String(value)
        .split(",")
        .map((v) => v.trim())
        .filter(Boolean);
}

/* ============================================================
   Cities lookup - powers the checkbox list on the summary pages.
   ============================================================ */
exports.getCities = async (req, res) => {
    try {
        const { company_id } = req.query;
        if (!company_id) {
            return res.status(400).json({ message: "Company is required." });
        }

        const [rows] = await db.query(
            `
            SELECT DISTINCT cd.city
            FROM ChartDetail cd
            INNER JOIN ChartOfAccount coa ON coa.id = cd.chartofaccount_id
            WHERE coa.company_id = ? AND cd.city IS NOT NULL AND cd.city <> ''
            ORDER BY cd.city ASC
            `,
            [company_id]
        );

        res.status(200).json({ cities: rows.map((r) => r.city) });
    } catch (error) {
        console.error("Error fetching cities:", error);
        res.status(500).json({ message: "Failed to fetch cities.", error: error.message });
    }
};

/* ============================================================
   Receivables Aging (single account detail)
   ============================================================ */
exports.getReceivablesAging = async (req, res) => {
    try {
        const { company_id, financialyear_id, account_code } = req.query;

        if (!company_id || !financialyear_id || !account_code) {
            return res.status(400).json({
                message: "Company, financial year, and account are all required."
            });
        }

        const [accountRows] = await db.query(
            `SELECT code, account_name FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [account_code, company_id]
        );
        if (accountRows.length === 0) {
            return res.status(400).json({ message: "Invalid account for this company." });
        }

        const { rows, total_outstanding } = await computeAccountAging(
            "receivable", company_id, financialyear_id, account_code
        );

        res.status(200).json({
            account_code,
            account_name: accountRows[0].account_name,
            rows,
            total_outstanding
        });
    } catch (error) {
        console.error("Error generating receivables aging report:", error);
        res.status(500).json({
            message: "Failed to generate receivables aging report.",
            error: error.message
        });
    }
};

/* ============================================================
   Payables Aging (single account detail)
   ============================================================ */
exports.getPayablesAging = async (req, res) => {
    try {
        const { company_id, financialyear_id, account_code } = req.query;

        if (!company_id || !financialyear_id || !account_code) {
            return res.status(400).json({
                message: "Company, financial year, and account are all required."
            });
        }

        const [accountRows] = await db.query(
            `SELECT code, account_name FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [account_code, company_id]
        );
        if (accountRows.length === 0) {
            return res.status(400).json({ message: "Invalid account for this company." });
        }

        const { rows, total_outstanding } = await computeAccountAging(
            "payable", company_id, financialyear_id, account_code
        );

        res.status(200).json({
            account_code,
            account_name: accountRows[0].account_name,
            rows,
            total_outstanding
        });
    } catch (error) {
        console.error("Error generating payables aging report:", error);
        res.status(500).json({
            message: "Failed to generate payables aging report.",
            error: error.message
        });
    }
};

/* ============================================================
   Shared summary builder - finds every account that has at least
   one user bill in the given mode, optionally narrowed to a set of
   cities (via ChartDetail) and/or a specific set of account codes,
   computes each account's aging, buckets it, and drops accounts
   with nothing outstanding.
   ============================================================ */
async function buildAgingSummary(mode, company_id, financialyear_id, cities, accountCodes, bucketConfig) {
    const codeColumn = mode === "receivable" ? "sm.customer_code" : "pm.supplier_code";
    const mainTable = mode === "receivable" ? "SalesMain sm" : "PurchaseMain pm";
    const companyCol = mode === "receivable" ? "sm.company_id" : "pm.company_id";
    const finYearCol = mode === "receivable" ? "sm.financialyear_id" : "pm.financialyear_id";
    const entryCol = mode === "receivable" ? "sm.entry" : "pm.entry";

    let sql = `
        SELECT DISTINCT ${codeColumn} AS code, coa.account_name AS account_name
        FROM ${mainTable}
        INNER JOIN ChartOfAccount coa
            ON coa.code = ${codeColumn} AND coa.company_id = ${companyCol}
        LEFT JOIN ChartDetail cd ON cd.chartofaccount_id = coa.id
        WHERE ${companyCol} = ? AND ${finYearCol} = ? AND ${entryCol} = 'user'
    `;
    const params = [company_id, financialyear_id];

    if (cities.length > 0) {
        sql += ` AND cd.city IN (${cities.map(() => "?").join(",")})`;
        params.push(...cities);
    }

    if (accountCodes.length > 0) {
        sql += ` AND ${codeColumn} IN (${accountCodes.map(() => "?").join(",")})`;
        params.push(...accountCodes);
    }

    sql += ` ORDER BY coa.account_name ASC`;

    const [accounts] = await db.query(sql, params);

    const rows = [];
    for (const acc of accounts) {
        const { rows: billRows, total_outstanding } = await computeAccountAging(
            mode, company_id, financialyear_id, acc.code
        );
        if (total_outstanding <= 0.01) continue;

        const { buckets, maxDay } = bucketizeRows(
            billRows, bucketConfig.num_buckets, bucketConfig.days_per_bucket, bucketConfig.start_day
        );

        rows.push({
            code: acc.code,
            account_name: acc.account_name,
            balance: total_outstanding,
            buckets,
            max_day: maxDay
        });
    }

    const totals = {
        balance: Number(rows.reduce((s, r) => s + r.balance, 0).toFixed(2)),
        buckets: new Array(bucketConfig.num_buckets + 1).fill(0)
    };
    for (const r of rows) {
        r.buckets.forEach((v, i) => { totals.buckets[i] += v; });
    }
    totals.buckets = totals.buckets.map((v) => Number(v.toFixed(2)));

    return {
        labels: bucketLabels(bucketConfig.num_buckets, bucketConfig.days_per_bucket, bucketConfig.start_day),
        rows,
        totals
    };
}

/* ============================================================
   Receivables Aging Summary (all customers, bucketed)
   ============================================================ */
exports.getReceivablesAgingSummary = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.query;
        if (!company_id || !financialyear_id) {
            return res.status(400).json({ message: "Company and financial year are required." });
        }

        const cities = parseListParam(req.query.cities);
        const accountCodes = parseListParam(req.query.account_codes);
        const bucketConfig = parseBucketConfig(req.query);

        const summary = await buildAgingSummary(
            "receivable", company_id, financialyear_id, cities, accountCodes, bucketConfig
        );
        res.status(200).json(summary);
    } catch (error) {
        console.error("Error generating receivables aging summary:", error);
        res.status(500).json({
            message: "Failed to generate receivables aging summary.",
            error: error.message
        });
    }
};

/* ============================================================
   Payables Aging Summary (all suppliers, bucketed)
   ============================================================ */
exports.getPayablesAgingSummary = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.query;
        if (!company_id || !financialyear_id) {
            return res.status(400).json({ message: "Company and financial year are required." });
        }

        const cities = parseListParam(req.query.cities);
        const accountCodes = parseListParam(req.query.account_codes);
        const bucketConfig = parseBucketConfig(req.query);

        const summary = await buildAgingSummary(
            "payable", company_id, financialyear_id, cities, accountCodes, bucketConfig
        );
        res.status(200).json(summary);
    } catch (error) {
        console.error("Error generating payables aging summary:", error);
        res.status(500).json({
            message: "Failed to generate payables aging summary.",
            error: error.message
        });
    }
};