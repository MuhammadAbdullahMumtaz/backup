const db = require("../../../config/db");

/**
 * ============================================================================
 * FINISHED STOCK REPORT CONTROLLER
 * ============================================================================
 * "Finished stock" = stock created via Production (ProductionDetail). Unlike
 * a purchase lot, a production lot is drawn down by exactly ONE thing (see
 * the uploaded StockAllocation.js): SalesDetail rows where
 * source_type = 'production'. There is no ProductionReturn table in the
 * schema, so nothing else reduces a production lot.
 *
 * revertStockIfNeeded (Sales' own helper) already recomputes
 * ProductionDetail.stocks purely from SalesDetail consumption, so - unlike
 * the raw-stock case - the stored flag and this report's own recomputation
 * should always agree. We still recompute it directly rather than trusting
 * the flag, so the report is self-contained and correct even if the flag
 * update is ever missed by a caller.
 *
 * Built the same way as the Ledger / Issued / Production / Raw Stock
 * reports:
 *   1. financialyear_id is sent straight from the frontend (Redux) and is
 *      looked up by PK.
 *   2. "Opening" = the CURRENT remaining quantity of every production lot
 *      of this item dated (by production_date) before `start_date`, within
 *      the FY. This is a live snapshot, not a historical reconstruction.
 *   3. Display rows = one row per production lot (batch line) for this item
 *      dated between `start_date` and `end_date` (inclusive), each showing
 *      its original quantity/value, how much has been sold, and what's
 *      left, with a running total of remaining net weight and remaining
 *      value across rows.
 *   4. Closing = opening + sum of period rows' remaining amounts.
 * ============================================================================
 */

const ITEMS_TABLE = {
  table: "ItemDetail",
  code: "code",
  name: "details",
  company_id: "company_id",
};

// -----------------------------------------------------------------------------
// Recommended indexes (create once):
//   ALTER TABLE ProductionDetail ADD INDEX idx_prd_item (company_id, Item_code, productionmain_id);
//   ALTER TABLE SalesDetail      ADD INDEX idx_sd_source (source_type, source_detail_id);
// -----------------------------------------------------------------------------

function toSqlDate(d) {
  if (d instanceof Date) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function clampNonNegative(n) {
  return n > 0 ? n : 0;
}

// ============================================================================
// GET /finished-stock/items/search?company_id=&q=
// ============================================================================
async function searchItems(req, res) {
  try {
    const { company_id, q = "" } = req.query;
    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }
    const like = `%${q.trim()}%`;
    const sql = `
      SELECT ${ITEMS_TABLE.code} AS code,
             ${ITEMS_TABLE.name} AS name,
             Unit AS unit
      FROM ${ITEMS_TABLE.table}
      WHERE ${ITEMS_TABLE.company_id} = ?
        AND (${ITEMS_TABLE.name} LIKE ? OR ${ITEMS_TABLE.code} LIKE ?)
      ORDER BY ${ITEMS_TABLE.name} ASC
      LIMIT 20
    `;
    const [rows] = await db.query(sql, [company_id, like, like]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("searchItems (finished stock) error:", err);
    return res.status(500).json({ success: false, message: "Failed to search items" });
  }
}

// ============================================================================
// GET /finished-stock/departments?company_id=
// ============================================================================
async function getDepartments(req, res) {
  try {
    const { company_id } = req.query;
    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }
    const sql = `
      SELECT id, department_name
      FROM Department
      WHERE company_id = ?
      ORDER BY department_name ASC
    `;
    const [rows] = await db.query(sql, [company_id]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("getDepartments (finished stock) error:", err);
    return res.status(500).json({ success: false, message: "Failed to load departments" });
  }
}

// ============================================================================
// GET /finished-stock/items/stock?company_id=&financialyear_id=&department_id=
//   "Show All Items" — one row per item that still has finished-goods stock
//   on hand right now (net_weight - sold), zero/negative remainder items
//   excluded via HAVING.
// ============================================================================
async function getStockSummary(req, res) {
  try {
    const { company_id, financialyear_id, department_id } = req.query;
    if (!company_id || !financialyear_id) {
      return res.status(400).json({ success: false, message: "company_id and financialyear_id are required" });
    }

    const params = [company_id, financialyear_id];
    let departmentClause = "";
    if (department_id) {
      departmentClause = " AND prm.department_id = ? ";
      params.push(department_id);
    }

    const sql = `
      SELECT
        prd.Item_code AS code,
        it.details      AS name,
        it.Unit           AS unit,
        COALESCE(SUM(prd.pieces), 0)     AS total_pieces,
        COALESCE(SUM(prd.net_weight), 0)  AS total_net_weight,
        COALESCE(SUM(prd.total), 0)        AS total_amount,
        COALESCE(SUM(sal.sold_weight), 0)   AS sold_weight,
        COALESCE(SUM(sal.sold_amount_share), 0) AS sold_amount_share
      FROM ProductionDetail prd
      INNER JOIN ProductionMain prm ON prm.id = prd.productionmain_id
      LEFT JOIN ${ITEMS_TABLE.table} it
        ON it.${ITEMS_TABLE.code} = prd.Item_code AND it.${ITEMS_TABLE.company_id} = prd.company_id
      LEFT JOIN (
        SELECT source_detail_id,
               SUM(net_weight) AS sold_weight,
               SUM(net_weight) AS sold_amount_share
        FROM SalesDetail
        WHERE source_type = 'production'
        GROUP BY source_detail_id
      ) sal ON sal.source_detail_id = prd.id
      WHERE prd.company_id = ?
        AND prm.financialyear_id = ?
        ${departmentClause}
      GROUP BY prd.Item_code, it.details, it.Unit
      HAVING SUM(prd.net_weight) - SUM(COALESCE(sal.sold_weight,0)) > 0
      ORDER BY it.details ASC
    `;
    const [rows] = await db.query(sql, params);

    return res.json({
      success: true,
      data: rows.map((r) => {
        const totalNetWeight = toNumber(r.total_net_weight);
        const soldWeight = toNumber(r.sold_weight);
        const remainingNetWeight = clampNonNegative(totalNetWeight - soldWeight);
        const avgRate = totalNetWeight > 0 ? toNumber(r.total_amount) / totalNetWeight : 0;
        return {
          code: r.code,
          name: r.name || r.code,
          unit: r.unit,
          pieces: toNumber(r.total_pieces),
          net_weight: remainingNetWeight,
          amount: Number((avgRate * remainingNetWeight).toFixed(2)),
        };
      }),
    });
  } catch (err) {
    console.error("getStockSummary (finished stock) error:", err);
    return res.status(500).json({ success: false, message: "Failed to load stock summary" });
  }
}

// ============================================================================
// Financial year lookup
// ============================================================================
async function fetchFinancialYearById(companyId, financialYearId) {
  const sql = `
    SELECT id, start_date, end_date
    FROM FinancialYear
    WHERE company_id = ?
      AND id = ?
    LIMIT 1
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  if (!rows.length) return null;
  return {
    id: rows[0].id,
    start_date: normalizeDbDate(rows[0].start_date),
    end_date: normalizeDbDate(rows[0].end_date),
  };
}

// ============================================================================
// Production lots for an item, with everything sold against each lot,
// optionally bounded by a production_date range. Shared by the
// opening-totals query (range = [fyStartDate, startDate)) and the
// period-rows query (range = [startDate, endDate]).
// ============================================================================
async function fetchProductionLots(companyId, itemCode, departmentId, rangeStart, rangeEnd, inclusive) {
  const params = [companyId, itemCode, rangeStart, rangeEnd];
  let departmentClause = "";
  if (departmentId) {
    departmentClause = " AND prm.department_id = ? ";
    params.push(departmentId);
  }
  const dateOp = inclusive ? "BETWEEN ? AND ?" : ">= ? AND prm.production_date < ?";
  const sql = `
    SELECT
      prm.production_no   AS doc_no,
      prm.production_date  AS txn_date,
      prm.issued_no          AS source_issued_no,
      d.department_name        AS department_name,
      prd.id                     AS lot_id,
      prd.entry_no                 AS entry_no,
      prd.stocks                     AS stocks,
      prd.pieces                       AS pieces,
      prd.gross_weight                   AS gross_weight,
      prd.tear_weight                      AS tear_weight,
      prd.net_weight                         AS net_weight,
      prd.rate                                 AS rate,
      prd.amount                                 AS amount,
      prd.total                                    AS total,
      COALESCE(sal.sold_weight, 0)                    AS sold_weight,
      COALESCE(sal.sold_pieces, 0)                      AS sold_pieces
    FROM ProductionDetail prd
    INNER JOIN ProductionMain prm ON prm.id = prd.productionmain_id
    LEFT JOIN Department d ON d.id = prm.department_id
    LEFT JOIN (
      SELECT source_detail_id, SUM(net_weight) AS sold_weight, SUM(pieces) AS sold_pieces
      FROM SalesDetail
      WHERE source_type = 'production'
      GROUP BY source_detail_id
    ) sal ON sal.source_detail_id = prd.id
    WHERE prd.company_id = ?
      AND prd.Item_code = ?
      AND prm.production_date ${dateOp}
      ${departmentClause}
    ORDER BY prm.production_date, prm.id, prd.entry_no
  `;
  const [rows] = await db.query(sql, params);
  return rows.map((r) => {
    const netWeight = toNumber(r.net_weight);
    const soldWeight = toNumber(r.sold_weight);
    const remaining_pieces = clampNonNegative(toNumber(r.pieces) - toNumber(r.sold_pieces));
    const remaining_net_weight = clampNonNegative(netWeight - soldWeight);
    const rate = toNumber(r.rate);
    return {
      txn_date: normalizeDbDate(r.txn_date),
      doc_no: r.doc_no,
      source_issued_no: r.source_issued_no,
      department_name: r.department_name || "",
      stocks: r.stocks,
      pieces: toNumber(r.pieces),
      gross_weight: toNumber(r.gross_weight),
      tear_weight: toNumber(r.tear_weight),
      net_weight: netWeight,
      rate,
      total: toNumber(r.total),
      sold_weight: soldWeight,
      remaining_pieces,
      remaining_net_weight,
      // Remaining value uses the lot's own per-unit rate, so a partially
      // sold lot's leftover value scales with what's physically left.
      remaining_amount: Number((rate * remaining_net_weight).toFixed(2)),
    };
  });
}

// ============================================================================
// GET /finished-stock/report
//   query params: company_id, financialyear_id, item_code, department_id
//                 (optional), start_date, end_date
// ============================================================================
async function getFinishedStockReport(req, res) {
  try {
    const { company_id, financialyear_id, item_code, department_id, start_date, end_date } = req.query;

    if (!company_id || !financialyear_id || !item_code || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: "company_id, financialyear_id, item_code, start_date and end_date are required",
      });
    }

    const startDate = toSqlDate(start_date);
    const endDate = toSqlDate(end_date);
    const departmentId = department_id ? Number(department_id) : null;

    const financialYear = await fetchFinancialYearById(company_id, financialyear_id);
    if (!financialYear) {
      return res.status(400).json({
        success: false,
        message: `Financial year ${financialyear_id} was not found for this company.`,
      });
    }
    const fyStartDate = financialYear.start_date;

    const openingLots = await fetchProductionLots(company_id, item_code, departmentId, fyStartDate, startDate, false);
    const periodLots = await fetchProductionLots(company_id, item_code, departmentId, startDate, endDate, true);

    const opening = openingLots.reduce(
      (acc, l) => {
        acc.pieces += l.remaining_pieces;
        acc.net_weight += l.remaining_net_weight;
        acc.amount += l.remaining_amount;
        return acc;
      },
      { pieces: 0, net_weight: 0, amount: 0 }
    );

    let runningPieces = opening.pieces;
    let runningNetWeight = opening.net_weight;
    let runningAmount = opening.amount;

    const outRows = periodLots.map((l, idx) => {
      runningPieces += l.remaining_pieces;
      runningNetWeight += l.remaining_net_weight;
      runningAmount += l.remaining_amount;
      return {
        s_no: idx + 1,
        date: l.txn_date,
        doc_no: l.doc_no,
        source_issued_no: l.source_issued_no || "",
        department_name: l.department_name,
        stocks: l.stocks,
        pieces: l.pieces,
        net_weight: l.net_weight,
        rate: l.rate,
        total: l.total,
        sold_weight: Number(l.sold_weight.toFixed(2)),
        remaining_pieces: l.remaining_pieces,
        remaining_net_weight: Number(l.remaining_net_weight.toFixed(2)),
        remaining_amount: l.remaining_amount,
        running_pieces: runningPieces,
        running_net_weight: Number(runningNetWeight.toFixed(2)),
        running_amount: Number(runningAmount.toFixed(2)),
      };
    });

    const totals = outRows.reduce(
      (acc, r) => {
        acc.pieces += r.remaining_pieces;
        acc.net_weight += r.remaining_net_weight;
        acc.amount += r.remaining_amount;
        return acc;
      },
      { pieces: 0, net_weight: 0, amount: 0 }
    );

    return res.json({
      success: true,
      data: {
        opening_pieces: opening.pieces,
        opening_net_weight: Number(opening.net_weight.toFixed(2)),
        opening_amount: Number(opening.amount.toFixed(2)),
        rows: outRows,
        total_pieces: totals.pieces,
        total_net_weight: Number(totals.net_weight.toFixed(2)),
        total_amount: Number(totals.amount.toFixed(2)),
        closing_pieces: outRows.length ? outRows[outRows.length - 1].running_pieces : opening.pieces,
        closing_net_weight: outRows.length
          ? outRows[outRows.length - 1].running_net_weight
          : Number(opening.net_weight.toFixed(2)),
        closing_amount: outRows.length
          ? outRows[outRows.length - 1].running_amount
          : Number(opening.amount.toFixed(2)),
        start_date: startDate,
        end_date: endDate,
      },
    });
  } catch (err) {
    console.error("getFinishedStockReport error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate finished stock report" });
  }
}

module.exports = {
  searchItems,
  getDepartments,
  getStockSummary,
  getFinishedStockReport,
};