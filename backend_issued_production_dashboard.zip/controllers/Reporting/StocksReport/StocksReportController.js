const db = require("../../../config/db");
// NOTE ON PLACEMENT: this file assumes a location of
//   controllers/StockReport/StockReportController.js
// i.e. two levels above the project root's /config folder, the same depth
// as controllers/Sales/Shared/StockAllocation.js is from /config (see that
// file's `require("../../../config/db")`). If you place this file somewhere
// else, adjust the relative path above.

// ============================================================================
// Stock is tracked the same way the Sales module already tracks it (see
// StockAllocation.js): quantity math does NOT need FIFO lot ordering, only
// FIFO *needs* ordering to decide which physical lot an entry-level sale line
// draws down. For reporting *totals* (opening / in / out / closing) simple
// arithmetic on dated rows is exact, because:
//
//   closing = opening + received - issued
//
// regardless of which specific lot supplied which sale. So every report below
// is built from four date-stamped movement tables, aggregated per item code:
//
//   IN  : PurchaseDetail       (grn_date)      entry = 'user'
//   IN  : SalesReturnDetail    (invoice_date)  entry = 'user'
//   OUT : SalesDetail          (invoice_date)  entry = 'user'
//   OUT : PurchaseReturnDetail (return_date)   entry = 'user'
//
// `entry = 'user'` rows are the physical, quantity-moving rows; `entry =
// 'auto'` rows are GL-side postings only (see the SalesSequence /
// PurchaseSequence backfill comments in the schema), so they are excluded
// here exactly like getAvailableLots() already excludes them.
//
// "Opening" for the report = ItemOpening (start of the financial year) plus
// every movement dated strictly before the requested start_date, within the
// same financial year. "Period" = movements between start_date and end_date
// inclusive. "Closing" = opening + period-in - period-out. This mirrors how
// Trial Balance turns opening/period/closing debit-credit columns from dated
// voucher rows.
// ============================================================================

function n(v) {
    return Number(v) || 0;
}

function blankStat() {
    return {
        opening_pieces: 0, opening_weight: 0, opening_amount: 0,
        in_pieces: 0, in_weight: 0, in_amount: 0,
        out_pieces: 0, out_weight: 0, out_amount: 0,
        closing_pieces: 0, closing_weight: 0, closing_amount: 0
    };
}

function finalizeStat(s) {
    s.closing_pieces = s.opening_pieces + s.in_pieces - s.out_pieces;
    s.closing_weight = round2(s.opening_weight + s.in_weight - s.out_weight);
    s.closing_amount = round2(s.opening_amount + s.in_amount - s.out_amount);
    s.opening_weight = round2(s.opening_weight);
    s.opening_amount = round2(s.opening_amount);
    s.in_weight = round2(s.in_weight);
    s.in_amount = round2(s.in_amount);
    s.out_weight = round2(s.out_weight);
    s.out_amount = round2(s.out_amount);
    return s;
}

function round2(v) {
    return Math.round((Number(v) || 0) * 100) / 100;
}

function addStat(target, source) {
    target.opening_pieces += source.opening_pieces;
    target.opening_weight += source.opening_weight;
    target.opening_amount += source.opening_amount;
    target.in_pieces += source.in_pieces;
    target.in_weight += source.in_weight;
    target.in_amount += source.in_amount;
    target.out_pieces += source.out_pieces;
    target.out_weight += source.out_weight;
    target.out_amount += source.out_amount;
    target.closing_pieces += source.closing_pieces;
    target.closing_weight += source.closing_weight;
    target.closing_amount += source.closing_amount;
}

// ----------------------------------------------------------------------------
// Builds a Map<item_code, stat> covering every item that has ANY opening
// balance or movement. Items with zero activity anywhere are still included
// as long as they belong to the company (added as zero rows) so the report
// shows the full item master, not just items that moved.
// ----------------------------------------------------------------------------
async function buildItemStatsMap(company_id, financialyear_id, start_date, end_date) {
    const statsByItemCode = new Map();

    const ensure = (code) => {
        if (!statsByItemCode.has(code)) statsByItemCode.set(code, blankStat());
        return statsByItemCode.get(code);
    };

    // Every item that belongs to this company starts at zero.
    const [items] = await db.query(
        `SELECT code FROM ItemDetail WHERE company_id = ?`,
        [company_id]
    );
    items.forEach((it) => ensure(it.code));

    // ---- Opening balances (start of financial year) -------------------------
    const [openingRows] = await db.query(
        `SELECT item.code AS item_code,
                io.quantity AS quantity, io.weight AS weight, io.amount AS amount
         FROM ItemOpening io
         INNER JOIN ItemDetail item ON io.itemdetail_id = item.id
         WHERE io.company_id = ? AND io.financialyear_id = ?`,
        [company_id, financialyear_id]
    );
    openingRows.forEach((r) => {
        const s = ensure(r.item_code);
        s.opening_pieces += n(r.quantity);
        s.opening_weight += n(r.weight);
        s.opening_amount += n(r.amount);
    });

    // ---- Purchases (IN) -------------------------------------------------------
    const [purchaseRows] = await db.query(
        `SELECT pd.Item_code AS item_code,
                SUM(CASE WHEN pm.grn_date < ? THEN pd.pieces ELSE 0 END) AS open_pieces,
                SUM(CASE WHEN pm.grn_date < ? THEN pd.net_weight ELSE 0 END) AS open_weight,
                SUM(CASE WHEN pm.grn_date < ? THEN pd.amount ELSE 0 END) AS open_amount,
                SUM(CASE WHEN pm.grn_date BETWEEN ? AND ? THEN pd.pieces ELSE 0 END) AS period_pieces,
                SUM(CASE WHEN pm.grn_date BETWEEN ? AND ? THEN pd.net_weight ELSE 0 END) AS period_weight,
                SUM(CASE WHEN pm.grn_date BETWEEN ? AND ? THEN pd.amount ELSE 0 END) AS period_amount
         FROM PurchaseDetail pd
         INNER JOIN PurchaseMain pm ON pd.purchasemain_id = pm.id
         WHERE pd.company_id = ? AND pd.financialyear_id = ? AND pd.entry = 'user'
         GROUP BY pd.Item_code`,
        [start_date, start_date, start_date, start_date, end_date, start_date, end_date, start_date, end_date,
            company_id, financialyear_id]
    );
    purchaseRows.forEach((r) => {
        const s = ensure(r.item_code);
        s.opening_pieces += n(r.open_pieces);
        s.opening_weight += n(r.open_weight);
        s.opening_amount += n(r.open_amount);
        s.in_pieces += n(r.period_pieces);
        s.in_weight += n(r.period_weight);
        s.in_amount += n(r.period_amount);
    });

    // ---- Sales Returns (IN) ----------------------------------------------------
    const [salesReturnRows] = await db.query(
        `SELECT srd.Item_code AS item_code,
                SUM(CASE WHEN srm.invoice_date < ? THEN srd.pieces ELSE 0 END) AS open_pieces,
                SUM(CASE WHEN srm.invoice_date < ? THEN srd.net_weight ELSE 0 END) AS open_weight,
                SUM(CASE WHEN srm.invoice_date < ? THEN srd.amount ELSE 0 END) AS open_amount,
                SUM(CASE WHEN srm.invoice_date BETWEEN ? AND ? THEN srd.pieces ELSE 0 END) AS period_pieces,
                SUM(CASE WHEN srm.invoice_date BETWEEN ? AND ? THEN srd.net_weight ELSE 0 END) AS period_weight,
                SUM(CASE WHEN srm.invoice_date BETWEEN ? AND ? THEN srd.amount ELSE 0 END) AS period_amount
         FROM SalesReturnDetail srd
         INNER JOIN SalesReturnMain srm ON srd.sales_return_main = srm.id
         WHERE srd.company_id = ? AND srd.financialyear_id = ? AND srd.entry = 'user'
         GROUP BY srd.Item_code`,
        [start_date, start_date, start_date, start_date, end_date, start_date, end_date, start_date, end_date,
            company_id, financialyear_id]
    );
    salesReturnRows.forEach((r) => {
        const s = ensure(r.item_code);
        s.opening_pieces += n(r.open_pieces);
        s.opening_weight += n(r.open_weight);
        s.opening_amount += n(r.open_amount);
        s.in_pieces += n(r.period_pieces);
        s.in_weight += n(r.period_weight);
        s.in_amount += n(r.period_amount);
    });

    // ---- Sales (OUT) ------------------------------------------------------------
    const [salesRows] = await db.query(
        `SELECT sd.Item_code AS item_code,
                SUM(CASE WHEN sm.invoice_date < ? THEN sd.pieces ELSE 0 END) AS open_pieces,
                SUM(CASE WHEN sm.invoice_date < ? THEN sd.net_weight ELSE 0 END) AS open_weight,
                SUM(CASE WHEN sm.invoice_date < ? THEN sd.amount ELSE 0 END) AS open_amount,
                SUM(CASE WHEN sm.invoice_date BETWEEN ? AND ? THEN sd.pieces ELSE 0 END) AS period_pieces,
                SUM(CASE WHEN sm.invoice_date BETWEEN ? AND ? THEN sd.net_weight ELSE 0 END) AS period_weight,
                SUM(CASE WHEN sm.invoice_date BETWEEN ? AND ? THEN sd.amount ELSE 0 END) AS period_amount
         FROM SalesDetail sd
         INNER JOIN SalesMain sm ON sd.sale_main = sm.id
         WHERE sd.company_id = ? AND sd.financialyear_id = ? AND sd.entry = 'user'
         GROUP BY sd.Item_code`,
        [start_date, start_date, start_date, start_date, end_date, start_date, end_date, start_date, end_date,
            company_id, financialyear_id]
    );
    salesRows.forEach((r) => {
        const s = ensure(r.item_code);
        s.opening_pieces -= n(r.open_pieces);
        s.opening_weight -= n(r.open_weight);
        s.opening_amount -= n(r.open_amount);
        s.out_pieces += n(r.period_pieces);
        s.out_weight += n(r.period_weight);
        s.out_amount += n(r.period_amount);
    });

    // ---- Purchase Returns (OUT) --------------------------------------------------
    const [purchaseReturnRows] = await db.query(
        `SELECT prd.Item_code AS item_code,
                SUM(CASE WHEN prm.return_date < ? THEN prd.pieces ELSE 0 END) AS open_pieces,
                SUM(CASE WHEN prm.return_date < ? THEN prd.net_weight ELSE 0 END) AS open_weight,
                SUM(CASE WHEN prm.return_date < ? THEN prd.amount ELSE 0 END) AS open_amount,
                SUM(CASE WHEN prm.return_date BETWEEN ? AND ? THEN prd.pieces ELSE 0 END) AS period_pieces,
                SUM(CASE WHEN prm.return_date BETWEEN ? AND ? THEN prd.net_weight ELSE 0 END) AS period_weight,
                SUM(CASE WHEN prm.return_date BETWEEN ? AND ? THEN prd.amount ELSE 0 END) AS period_amount
         FROM PurchaseReturnDetail prd
         INNER JOIN PurchaseReturnMain prm ON prd.purchasereturnmain_id = prm.id
         WHERE prd.company_id = ? AND prd.financialyear_id = ? AND prd.entry = 'user'
         GROUP BY prd.Item_code`,
        [start_date, start_date, start_date, start_date, end_date, start_date, end_date, start_date, end_date,
            company_id, financialyear_id]
    );
    purchaseReturnRows.forEach((r) => {
        const s = ensure(r.item_code);
        s.opening_pieces -= n(r.open_pieces);
        s.opening_weight -= n(r.open_weight);
        s.opening_amount -= n(r.open_amount);
        s.out_pieces += n(r.period_pieces);
        s.out_weight += n(r.period_weight);
        s.out_amount += n(r.period_amount);
    });

    statsByItemCode.forEach((s) => finalizeStat(s));
    return statsByItemCode;
}

// ----------------------------------------------------------------------------
// Loads the item hierarchy (MainItem -> SubItem -> ItemDetail) plus, for
// each ItemDetail, the SubItem's GL_purchase code and its ChartOfAccount
// name (used by the account-wise report).
// ----------------------------------------------------------------------------
async function loadItemHierarchy(company_id) {
    const [mainItems] = await db.query(
        `SELECT id, code, details FROM MainItem WHERE company_id = ? ORDER BY code`,
        [company_id]
    );
    const [subItems] = await db.query(
        `SELECT id, mainitem_id, code, details, GL_purchase FROM SubItem WHERE company_id = ? ORDER BY code`,
        [company_id]
    );
    const [detailItems] = await db.query(
        `SELECT id, subitem_id, code, details FROM ItemDetail WHERE company_id = ? ORDER BY code`,
        [company_id]
    );
    const [glAccounts] = await db.query(
        `SELECT code, account_name FROM ChartOfAccount WHERE company_id = ?`,
        [company_id]
    );
    const glNameByCode = new Map(glAccounts.map((a) => [a.code, a.account_name]));

    return { mainItems, subItems, detailItems, glNameByCode };
}

function emptyTotals() {
    return blankStat();
}

// ============================================================================
// 1) ITEM-WISE STOCK REPORT (flat list)
// ============================================================================
exports.getItemWiseReport = async (req, res) => {
    try {
        const { company_id, financialyear_id, start_date, end_date } = req.query;
        if (!company_id || !financialyear_id || !start_date || !end_date) {
            return res.status(400).json({
                success: false,
                message: "company_id, financialyear_id, start_date and end_date are all required."
            });
        }

        const { mainItems, subItems, detailItems } = await loadItemHierarchy(company_id);
        const mainItemById = new Map(mainItems.map((m) => [m.id, m]));
        const subItemById = new Map(subItems.map((s) => [s.id, s]));

        const stats = await buildItemStatsMap(company_id, financialyear_id, start_date, end_date);

        const rows = detailItems.map((item) => {
            const subitem = subItemById.get(item.subitem_id);
            const mainitem = subitem ? mainItemById.get(subitem.mainitem_id) : null;
            const stat = stats.get(item.code) || blankStat();
            return {
                item_id: item.id,
                item_code: item.code,
                item_name: item.details,
                subitem_code: subitem ? subitem.code : null,
                subitem_name: subitem ? subitem.details : null,
                mainitem_code: mainitem ? mainitem.code : null,
                mainitem_name: mainitem ? mainitem.details : null,
                ...stat
            };
        });

        const grand_total = emptyTotals();
        rows.forEach((r) => addStat(grand_total, r));

        res.status(200).json({
            success: true,
            data: {
                start_date, end_date,
                rows,
                grand_total
            }
        });
    } catch (error) {
        console.error("Error generating item-wise stock report:", error);
        res.status(500).json({ success: false, message: "Failed to generate item-wise stock report.", error: error.message });
    }
};

// ============================================================================
// 2) ACCOUNT-WISE REMAINING STOCK REPORT
//    Groups every item's stock under the GL (Chart of Account) code recorded
//    against its SubItem as GL_purchase - i.e. the inventory/asset ledger
//    account that category of stock is carried under. Items whose SubItem
//    has no GL_purchase set are grouped under "Unassigned".
// ============================================================================
exports.getAccountWiseReport = async (req, res) => {
    try {
        const { company_id, financialyear_id, start_date, end_date } = req.query;
        if (!company_id || !financialyear_id || !start_date || !end_date) {
            return res.status(400).json({
                success: false,
                message: "company_id, financialyear_id, start_date and end_date are all required."
            });
        }

        const { subItems, detailItems, glNameByCode } = await loadItemHierarchy(company_id);
        const subItemById = new Map(subItems.map((s) => [s.id, s]));
        const stats = await buildItemStatsMap(company_id, financialyear_id, start_date, end_date);

        const accountsByCode = new Map();
        const getAccountBucket = (code) => {
            const key = code || "UNASSIGNED";
            if (!accountsByCode.has(key)) {
                accountsByCode.set(key, {
                    account_code: code || null,
                    account_name: code ? (glNameByCode.get(code) || code) : "Unassigned",
                    items: [],
                    totals: emptyTotals()
                });
            }
            return accountsByCode.get(key);
        };

        detailItems.forEach((item) => {
            const subitem = subItemById.get(item.subitem_id);
            const glCode = subitem ? subitem.GL_purchase : null;
            const stat = stats.get(item.code) || blankStat();
            const bucket = getAccountBucket(glCode);
            bucket.items.push({
                item_id: item.id,
                item_code: item.code,
                item_name: item.details,
                ...stat
            });
            addStat(bucket.totals, stat);
        });

        const accounts = Array.from(accountsByCode.values())
            .filter((a) => a.items.length > 0)
            .sort((a, b) => (a.account_code || "zzz").localeCompare(b.account_code || "zzz"));

        const grand_total = emptyTotals();
        accounts.forEach((a) => addStat(grand_total, a.totals));

        res.status(200).json({
            success: true,
            data: { start_date, end_date, accounts, grand_total }
        });
    } catch (error) {
        console.error("Error generating account-wise stock report:", error);
        res.status(500).json({ success: false, message: "Failed to generate account-wise stock report.", error: error.message });
    }
};

// ============================================================================
// 3) STOCK MANAGEMENT REPORT (hierarchical: MainItem -> SubItem -> ItemDetail)
//    Same opening / current-period / closing pattern as Trial Balance's
//    BalanceSheet -> MainCode -> SubCode -> ChartOfAccount drill-down, but for
//    physical stock instead of GL balances.
// ============================================================================
exports.getManagementReport = async (req, res) => {
    try {
        const { company_id, financialyear_id, start_date, end_date } = req.query;
        if (!company_id || !financialyear_id || !start_date || !end_date) {
            return res.status(400).json({
                success: false,
                message: "company_id, financialyear_id, start_date and end_date are all required."
            });
        }

        const { mainItems, subItems, detailItems } = await loadItemHierarchy(company_id);
        const stats = await buildItemStatsMap(company_id, financialyear_id, start_date, end_date);

        const subItemsByMain = new Map();
        subItems.forEach((s) => {
            if (!subItemsByMain.has(s.mainitem_id)) subItemsByMain.set(s.mainitem_id, []);
            subItemsByMain.get(s.mainitem_id).push(s);
        });

        const detailsBySub = new Map();
        detailItems.forEach((d) => {
            if (!detailsBySub.has(d.subitem_id)) detailsBySub.set(d.subitem_id, []);
            detailsBySub.get(d.subitem_id).push(d);
        });

        const mainItemNodes = mainItems.map((mi) => {
            const subNodes = (subItemsByMain.get(mi.id) || []).map((si) => {
                const itemNodes = (detailsBySub.get(si.id) || []).map((it) => ({
                    id: it.id,
                    code: it.code,
                    details: it.details,
                    ...(stats.get(it.code) || blankStat())
                }));

                const subTotals = emptyTotals();
                itemNodes.forEach((it) => addStat(subTotals, it));

                return {
                    id: si.id,
                    code: si.code,
                    details: si.details,
                    items: itemNodes,
                    totals: subTotals
                };
            }).filter((si) => si.items.length > 0);

            const mainTotals = emptyTotals();
            subNodes.forEach((si) => addStat(mainTotals, si.totals));

            return {
                id: mi.id,
                code: mi.code,
                details: mi.details,
                subitems: subNodes,
                totals: mainTotals
            };
        }).filter((mi) => mi.subitems.length > 0);

        const grand_total = emptyTotals();
        mainItemNodes.forEach((mi) => addStat(grand_total, mi.totals));

        res.status(200).json({
            success: true,
            data: { start_date, end_date, mainitems: mainItemNodes, grand_total }
        });
    } catch (error) {
        console.error("Error generating stock management report:", error);
        res.status(500).json({ success: false, message: "Failed to generate stock management report.", error: error.message });
    }
};

// ============================================================================
// Financial-year lookup, used only to pre-fill Start date / End date the
// same way TrialBalance's /financial-year endpoint does.
// ============================================================================
exports.getFinancialYearDates = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.query;
        if (!company_id || !financialyear_id) {
            return res.status(400).json({ success: false, message: "company_id and financialyear_id are required." });
        }
        const [rows] = await db.query(
            `SELECT start_date, end_date FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: "Financial year not found." });
        }
        res.status(200).json({ success: true, data: rows[0] });
    } catch (error) {
        console.error("Error fetching financial year dates:", error);
        res.status(500).json({ success: false, message: "Failed to fetch financial year dates.", error: error.message });
    }
};