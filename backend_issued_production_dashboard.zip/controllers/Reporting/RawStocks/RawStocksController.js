const db = require("../../../config/db");

/**
 * ============================================================================
 * RAW STOCK REPORT CONTROLLER
 * ============================================================================
 * "Raw stock" = stock brought in via Purchase (PurchaseDetail, entry='user').
 * A purchase lot is drawn down by THREE different things, each tracked in
 * its own detail table (see the uploaded StockAllocation helpers):
 *
 *   - IssuedDetail        where source_type = 'purchase'   (sent to Production)
 *   - PurchaseReturnDetail where entry = 'user'             (sent back to supplier)
 *   - SalesDetail          where source_type = 'purchase'   (sold directly,
 *                                                             without going
 *                                                             through Issued/
 *                                                             Production first)
 *
 * PurchaseDetail.stocks is only ever recomputed by ONE of these at a time
 * (syncPurchaseDetailStockFlag only looks at Issued+Return; Sales'
 * revertStockIfNeeded only looks at Sales) - so the stored flag can't be
 * trusted alone as "is this lot fully consumed". This report recomputes the
 * true remaining quantity per lot by summing all three consumers directly,
 * the same way the FIFO allocators do it, and reports that.
 *
 * Built the same way as the Ledger / Issued / Production reports:
 *   1. financialyear_id is sent straight from the frontend (Redux) and is
 *      looked up by PK.
 *   2. "Opening" = the CURRENT remaining quantity of every lot of this item
 *      dated (by grn_date) before `start_date`, within the FY. This is a
 *      live snapshot, not a historical reconstruction - Claude has no way to
 *      know how much of a lot was left on any past date, only how much of
 *      it is left right now.
 *   3. Display rows = one row per purchase lot (GRN line) for this item
 *      dated between `start_date` and `end_date` (inclusive), each showing
 *      its original quantity, everything consumed against it, and what's
 *      left, with a running total of remaining net weight across rows.
 *   4. Closing = opening + sum of period rows' remaining net weight.
 * ============================================================================
 */

const ITEMS_TABLE = {
  table: "ItemDetail",
  code: "code",
  name: "details",
  company_id: "company_id",
};

// -----------------------------------------------------------------------------
// Recommended indexes (create once):
//   ALTER TABLE PurchaseDetail       ADD INDEX idx_pd_item (company_id, Item_code, purchasemain_id);
//   ALTER TABLE IssuedDetail         ADD INDEX idx_id_source (source_type, source_detail_id);
//   ALTER TABLE PurchaseReturnDetail ADD INDEX idx_prd_source (source_detail_id, entry);
//   ALTER TABLE SalesDetail          ADD INDEX idx_sd_source (source_type, source_detail_id);
// -----------------------------------------------------------------------------

function toSqlDate(d) {
  if (d instanceof Date) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function clampNonNegative(n) {
  return n > 0 ? n : 0;
}

// ============================================================================
// GET /raw-stock/items/search?company_id=&q=
// ============================================================================
async function searchItems(req, res) {
  try {
    const { company_id, q = "" } = req.query;
    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }
    const like = `%${q.trim()}%`;
    const sql = `
      SELECT ${ITEMS_TABLE.code} AS code,
             ${ITEMS_TABLE.name} AS name,
             Unit AS unit
      FROM ${ITEMS_TABLE.table}
      WHERE ${ITEMS_TABLE.company_id} = ?
        AND (${ITEMS_TABLE.name} LIKE ? OR ${ITEMS_TABLE.code} LIKE ?)
      ORDER BY ${ITEMS_TABLE.name} ASC
      LIMIT 20
    `;
    const [rows] = await db.query(sql, [company_id, like, like]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("searchItems (raw stock) error:", err);
    return res.status(500).json({ success: false, message: "Failed to search items" });
  }
}

// ============================================================================
// GET /raw-stock/departments?company_id=
// ============================================================================
async function getDepartments(req, res) {
  try {
    const { company_id } = req.query;
    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }
    const sql = `
      SELECT id, department_name
      FROM Department
      WHERE company_id = ?
      ORDER BY department_name ASC
    `;
    const [rows] = await db.query(sql, [company_id]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("getDepartments (raw stock) error:", err);
    return res.status(500).json({ success: false, message: "Failed to load departments" });
  }
}

// ============================================================================
// GET /raw-stock/items/stock?company_id=&financialyear_id=&department_id=
//   "Show All Items" — one row per item that still has raw (purchased)
//   stock on hand right now, computed the same way as the report rows
//   (net_weight - issued - returned - sold), zero/negative remainder items
//   excluded via HAVING.
// ============================================================================
async function getStockSummary(req, res) {
  try {
    const { company_id, financialyear_id, department_id } = req.query;
    if (!company_id || !financialyear_id) {
      return res.status(400).json({ success: false, message: "company_id and financialyear_id are required" });
    }

    const params = [company_id, financialyear_id];
    let departmentClause = "";
    if (department_id) {
      departmentClause = " AND pm.department_id = ? ";
      params.push(department_id);
    }

    const sql = `
      SELECT
        pd.Item_code AS code,
        it.details    AS name,
        it.Unit        AS unit,
        COALESCE(SUM(pd.pieces), 0)     AS total_pieces,
        COALESCE(SUM(pd.net_weight), 0)  AS total_net_weight,
        COALESCE(SUM(iss.consumed_weight), 0)  AS issued_weight,
        COALESCE(SUM(ret.returned_weight), 0)   AS returned_weight,
        COALESCE(SUM(sal.sold_weight), 0)        AS sold_weight
      FROM PurchaseDetail pd
      INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
      LEFT JOIN ${ITEMS_TABLE.table} it
        ON it.${ITEMS_TABLE.code} = pd.Item_code AND it.${ITEMS_TABLE.company_id} = pd.company_id
      LEFT JOIN (
        SELECT source_detail_id, SUM(net_weight) AS consumed_weight
        FROM IssuedDetail
        WHERE source_type = 'purchase'
        GROUP BY source_detail_id
      ) iss ON iss.source_detail_id = pd.id
      LEFT JOIN (
        SELECT source_detail_id, SUM(net_weight) AS returned_weight
        FROM PurchaseReturnDetail
        WHERE entry = 'user'
        GROUP BY source_detail_id
      ) ret ON ret.source_detail_id = pd.id
      LEFT JOIN (
        SELECT source_detail_id, SUM(net_weight) AS sold_weight
        FROM SalesDetail
        WHERE source_type = 'purchase'
        GROUP BY source_detail_id
      ) sal ON sal.source_detail_id = pd.id
      WHERE pd.company_id = ?
        AND pd.entry = 'user'
        AND pm.financialyear_id = ?
        ${departmentClause}
      GROUP BY pd.Item_code, it.details, it.Unit
      HAVING SUM(pd.net_weight) - SUM(COALESCE(iss.consumed_weight,0))
             - SUM(COALESCE(ret.returned_weight,0)) - SUM(COALESCE(sal.sold_weight,0)) > 0
      ORDER BY it.details ASC
    `;
    const [rows] = await db.query(sql, params);

    return res.json({
      success: true,
      data: rows.map((r) => ({
        code: r.code,
        name: r.name || r.code,
        unit: r.unit,
        pieces: toNumber(r.total_pieces),
        net_weight: clampNonNegative(
          toNumber(r.total_net_weight) - toNumber(r.issued_weight) - toNumber(r.returned_weight) - toNumber(r.sold_weight)
        ),
      })),
    });
  } catch (err) {
    console.error("getStockSummary (raw stock) error:", err);
    return res.status(500).json({ success: false, message: "Failed to load stock summary" });
  }
}

// ============================================================================
// Financial year lookup
// ============================================================================
async function fetchFinancialYearById(companyId, financialYearId) {
  const sql = `
    SELECT id, start_date, end_date
    FROM FinancialYear
    WHERE company_id = ?
      AND id = ?
    LIMIT 1
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  if (!rows.length) return null;
  return {
    id: rows[0].id,
    start_date: normalizeDbDate(rows[0].start_date),
    end_date: normalizeDbDate(rows[0].end_date),
  };
}

// ============================================================================
// Purchase lots for an item, with everything consumed against each lot,
// optionally bounded by a grn_date range. Shared by the opening-totals
// query (range = [fyStartDate, startDate)) and the period-rows query
// (range = [startDate, endDate]).
// ============================================================================
async function fetchPurchaseLots(companyId, itemCode, departmentId, rangeStart, rangeEndExclusiveOrInclusive, inclusive) {
  const params = [companyId, itemCode, rangeStart, rangeEndExclusiveOrInclusive];
  let departmentClause = "";
  if (departmentId) {
    departmentClause = " AND pm.department_id = ? ";
    params.push(departmentId);
  }
  const dateOp = inclusive ? "BETWEEN ? AND ?" : ">= ? AND pm.grn_date < ?";
  const sql = `
    SELECT
      pm.grn_no          AS doc_no,
      pm.grn_date         AS txn_date,
      d.department_name    AS department_name,
      pd.id                 AS lot_id,
      pd.entry_no             AS entry_no,
      pd.stocks                AS stocks,
      pd.pieces                 AS pieces,
      pd.gross_weight             AS gross_weight,
      pd.tear_weight                AS tear_weight,
      pd.net_weight                  AS net_weight,
      COALESCE(iss.consumed_weight, 0)  AS issued_weight,
      COALESCE(iss.consumed_pieces, 0)   AS issued_pieces,
      COALESCE(ret.returned_weight, 0)    AS returned_weight,
      COALESCE(ret.returned_pieces, 0)     AS returned_pieces,
      COALESCE(sal.sold_weight, 0)          AS sold_weight,
      COALESCE(sal.sold_pieces, 0)           AS sold_pieces
    FROM PurchaseDetail pd
    INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
    LEFT JOIN Department d ON d.id = pm.department_id
    LEFT JOIN (
      SELECT source_detail_id, SUM(net_weight) AS consumed_weight, SUM(pieces) AS consumed_pieces
      FROM IssuedDetail
      WHERE source_type = 'purchase'
      GROUP BY source_detail_id
    ) iss ON iss.source_detail_id = pd.id
    LEFT JOIN (
      SELECT source_detail_id, SUM(net_weight) AS returned_weight, SUM(pieces) AS returned_pieces
      FROM PurchaseReturnDetail
      WHERE entry = 'user'
      GROUP BY source_detail_id
    ) ret ON ret.source_detail_id = pd.id
    LEFT JOIN (
      SELECT source_detail_id, SUM(net_weight) AS sold_weight, SUM(pieces) AS sold_pieces
      FROM SalesDetail
      WHERE source_type = 'purchase'
      GROUP BY source_detail_id
    ) sal ON sal.source_detail_id = pd.id
    WHERE pd.company_id = ?
      AND pd.Item_code = ?
      AND pd.entry = 'user'
      AND pm.grn_date ${dateOp}
      ${departmentClause}
    ORDER BY pm.grn_date, pm.id, pd.entry_no
  `;
  const [rows] = await db.query(sql, params);
  return rows.map((r) => {
    const remaining_pieces = clampNonNegative(toNumber(r.pieces) - toNumber(r.issued_pieces) - toNumber(r.returned_pieces) - toNumber(r.sold_pieces));
    const remaining_net_weight = clampNonNegative(
      toNumber(r.net_weight) - toNumber(r.issued_weight) - toNumber(r.returned_weight) - toNumber(r.sold_weight)
    );
    return {
      txn_date: normalizeDbDate(r.txn_date),
      doc_no: r.doc_no,
      department_name: r.department_name || "",
      stocks: r.stocks,
      pieces: toNumber(r.pieces),
      gross_weight: toNumber(r.gross_weight),
      tear_weight: toNumber(r.tear_weight),
      net_weight: toNumber(r.net_weight),
      issued_weight: toNumber(r.issued_weight),
      returned_weight: toNumber(r.returned_weight),
      sold_weight: toNumber(r.sold_weight),
      remaining_pieces,
      remaining_net_weight,
    };
  });
}

// ============================================================================
// GET /raw-stock/report
//   query params: company_id, financialyear_id, item_code, department_id
//                 (optional), start_date, end_date
// ============================================================================
async function getRawStockReport(req, res) {
  try {
    const { company_id, financialyear_id, item_code, department_id, start_date, end_date } = req.query;

    if (!company_id || !financialyear_id || !item_code || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: "company_id, financialyear_id, item_code, start_date and end_date are required",
      });
    }

    const startDate = toSqlDate(start_date);
    const endDate = toSqlDate(end_date);
    const departmentId = department_id ? Number(department_id) : null;

    const financialYear = await fetchFinancialYearById(company_id, financialyear_id);
    if (!financialYear) {
      return res.status(400).json({
        success: false,
        message: `Financial year ${financialyear_id} was not found for this company.`,
      });
    }
    const fyStartDate = financialYear.start_date;

    const openingLots = await fetchPurchaseLots(company_id, item_code, departmentId, fyStartDate, startDate, false);
    const periodLots = await fetchPurchaseLots(company_id, item_code, departmentId, startDate, endDate, true);

    const opening = openingLots.reduce(
      (acc, l) => {
        acc.pieces += l.remaining_pieces;
        acc.net_weight += l.remaining_net_weight;
        return acc;
      },
      { pieces: 0, net_weight: 0 }
    );

    let runningPieces = opening.pieces;
    let runningNetWeight = opening.net_weight;

    const outRows = periodLots.map((l, idx) => {
      runningPieces += l.remaining_pieces;
      runningNetWeight += l.remaining_net_weight;
      return {
        s_no: idx + 1,
        date: l.txn_date,
        doc_no: l.doc_no,
        department_name: l.department_name,
        stocks: l.stocks,
        pieces: l.pieces,
        net_weight: l.net_weight,
        issued_weight: Number(l.issued_weight.toFixed(2)),
        returned_weight: Number(l.returned_weight.toFixed(2)),
        sold_weight: Number(l.sold_weight.toFixed(2)),
        remaining_pieces: l.remaining_pieces,
        remaining_net_weight: Number(l.remaining_net_weight.toFixed(2)),
        running_pieces: runningPieces,
        running_net_weight: Number(runningNetWeight.toFixed(2)),
      };
    });

    const totals = outRows.reduce(
      (acc, r) => {
        acc.pieces += r.remaining_pieces;
        acc.net_weight += r.remaining_net_weight;
        return acc;
      },
      { pieces: 0, net_weight: 0 }
    );

    return res.json({
      success: true,
      data: {
        opening_pieces: opening.pieces,
        opening_net_weight: Number(opening.net_weight.toFixed(2)),
        rows: outRows,
        total_pieces: totals.pieces,
        total_net_weight: Number(totals.net_weight.toFixed(2)),
        closing_pieces: outRows.length ? outRows[outRows.length - 1].running_pieces : opening.pieces,
        closing_net_weight: outRows.length
          ? outRows[outRows.length - 1].running_net_weight
          : Number(opening.net_weight.toFixed(2)),
        start_date: startDate,
        end_date: endDate,
      },
    });
  } catch (err) {
    console.error("getRawStockReport error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate raw stock report" });
  }
}

module.exports = {
  searchItems,
  getDepartments,
  getStockSummary,
  getRawStockReport,
};