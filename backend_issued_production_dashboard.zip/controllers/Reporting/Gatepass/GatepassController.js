const db = require("../../../config/db");

/**
 * ============================================================================
 * GATE PASS REPORT CONTROLLER
 * ============================================================================
 * Produces two reports over InwardGatePassMain/Detail and
 * OutwardGatePassMain/Detail, scoped to one company (+ optional department),
 * between a start and end date. Mirrors the structure/helpers of
 * ledgerController.js exactly, so the two report families stay consistent.
 *
 * REPORT 1 — Item movement (getItemMovementReport)
 *   For one Item_code: every Inward + Outward gate pass line dated between
 *   start_date and end_date, merged and sorted chronologically, with a
 *   running net-weight balance (Inward adds, Outward subtracts) — the same
 *   idea as the ledger's running debit/credit balance.
 *
 * REPORT 2 — All items summary (getItemsSummaryReport)
 *   One row per item that had any Inward or Outward movement in the date
 *   range: total inward pieces/weight, total outward pieces/weight, and the
 *   net (in - out) for both. No running balance — just period totals.
 *
 * Table mapping used:
 *   - InwardGatePassMain(id, company_id, department_id, inward_no,
 *       inward_date, challan_no, vehicle_no, account_code, driver_name,
 *       freight)
 *   - InwardGatePassDetail(inwardgatepassmain_id, Item_code, entry_no,
 *       pieces, gross_weight, tear_weight, net_weight, amount, freight, total)
 *   - OutwardGatePassMain(id, company_id, department_id, outward_no,
 *       outward_date, account_code, vehicle_no, vehicle_type, driver_name,
 *       freight, contract_no, production_no)
 *   - OutwardGatePassDetail(outwardgatepassmain_id, Item_code, entry_no,
 *       pieces, gross_weight, tear_weight, net_weight)
 *       -- amount/gst/freight/total were dropped from this table; freight
 *          lives only on OutwardGatePassMain (header-level), same pattern
 *          as InwardGatePassMain.
 *   - ItemDetail(code, details) -> item display name, same as ledger's
 *     ITEMS_TABLE usage
 *   - ChartOfAccount(code, account_name) -> party name for account_code
 *   - Department(id, department_name)
 * ============================================================================
 */

const ITEMS_TABLE = {
  table: "ItemDetail",
  code: "code",
  name: "details",
};

const ACCOUNTS_TABLE = {
  table: "ChartOfAccount",
  code: "code",
  name: "account_name",
};

/**
 * Recommended indexes (create once):
 *
 *   ALTER TABLE InwardGatePassMain    ADD INDEX idx_igpm_date (company_id, department_id, inward_date);
 *   ALTER TABLE InwardGatePassDetail  ADD INDEX idx_igpd_main (inwardgatepassmain_id);
 *   ALTER TABLE InwardGatePassDetail  ADD INDEX idx_igpd_item (company_id, Item_code);
 *   ALTER TABLE OutwardGatePassMain   ADD INDEX idx_ogpm_date (company_id, department_id, outward_date);
 *   ALTER TABLE OutwardGatePassDetail ADD INDEX idx_ogpd_main (outwardgatepassmain_id);
 *   ALTER TABLE OutwardGatePassDetail ADD INDEX idx_ogpd_item (company_id, Item_code);
 */

// ============================================================================
// Helpers (same behaviour as ledgerController.js)
// ============================================================================

function toSqlDate(d) {
  if (d instanceof Date) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

// ============================================================================
// GET /gatepass/items/search?company_id=&q=
//   Same fetch-then-filter contract as searchAccounts in ledgerController.js.
// ============================================================================
async function searchItems(req, res) {
  try {
    const { company_id, q = "" } = req.query;
    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }
    const like = `%${q.trim()}%`;
    const sql = `
      SELECT id.${ITEMS_TABLE.code}   AS code,
             id.${ITEMS_TABLE.name}   AS name,
             id.Unit                  AS unit
      FROM ${ITEMS_TABLE.table} id
      WHERE id.company_id = ?
        AND (id.${ITEMS_TABLE.name} LIKE ? OR id.${ITEMS_TABLE.code} LIKE ?)
      ORDER BY id.${ITEMS_TABLE.name} ASC
      LIMIT 20
    `;
    const [rows] = await db.query(sql, [company_id, like, like]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("searchItems error:", err);
    return res.status(500).json({ success: false, message: "Failed to search items" });
  }
}

// ============================================================================
// Internal query builders — Report 1 (single item, merged & chronological)
// ============================================================================

async function fetchInwardMovement(companyId, departmentId, itemCode, startDate, endDate) {
  const params = [companyId, itemCode, startDate, endDate];
  let deptClause = "";
  if (departmentId) {
    deptClause = " AND igpm.department_id = ? ";
    params.push(departmentId);
  }
  const sql = `
    SELECT
      igpm.inward_date   AS txn_date,
      igpm.inward_no     AS voucher_no,
      igpm.challan_no    AS challan_no,
      igpm.vehicle_no    AS vehicle_no,
      igpm.driver_name   AS driver_name,
      igpm.account_code  AS account_code,
      COALESCE(coa.${ACCOUNTS_TABLE.name}, igpm.account_code) AS party_name,
      igpd.entry_no       AS entry_no,
      igpd.pieces          AS pieces,
      igpd.net_weight      AS net_weight
    FROM InwardGatePassDetail igpd
    INNER JOIN InwardGatePassMain igpm ON igpm.id = igpd.inwardgatepassmain_id
    LEFT JOIN ${ACCOUNTS_TABLE.table} coa ON coa.${ACCOUNTS_TABLE.code} = igpm.account_code
    WHERE igpd.company_id = ?
      AND igpd.Item_code = ?
      AND igpm.inward_date BETWEEN ? AND ?
      ${deptClause}
    ORDER BY igpm.inward_date, igpm.id, igpd.entry_no
  `;
  const [rows] = await db.query(sql, params);
  return rows.map((r) => ({
    txn_date: normalizeDbDate(r.txn_date),
    movement_type: "IN",
    voucher_no: r.voucher_no,
    narration: [
      r.challan_no ? `Challan(${r.challan_no})` : "",
      r.vehicle_no ? `Vehicle(${r.vehicle_no})` : "",
      r.driver_name ? `Driver(${r.driver_name})` : "",
    ]
      .filter(Boolean)
      .join(" "),
    party_name: r.party_name,
    pieces_in: toNumber(r.pieces),
    pieces_out: 0,
    weight_in: toNumber(r.net_weight),
    weight_out: 0,
  }));
}

async function fetchOutwardMovement(companyId, departmentId, itemCode, startDate, endDate) {
  const params = [companyId, itemCode, startDate, endDate];
  let deptClause = "";
  if (departmentId) {
    deptClause = " AND ogpm.department_id = ? ";
    params.push(departmentId);
  }
  const sql = `
    SELECT
      ogpm.outward_date  AS txn_date,
      ogpm.outward_no    AS voucher_no,
      ogpm.vehicle_no    AS vehicle_no,
      ogpm.driver_name   AS driver_name,
      ogpm.contract_no   AS contract_no,
      ogpm.production_no AS production_no,
      ogpm.account_code  AS account_code,
      COALESCE(coa.${ACCOUNTS_TABLE.name}, ogpm.account_code) AS party_name,
      ogpd.entry_no        AS entry_no,
      ogpd.pieces           AS pieces,
      ogpd.net_weight       AS net_weight
    FROM OutwardGatePassDetail ogpd
    INNER JOIN OutwardGatePassMain ogpm ON ogpm.id = ogpd.outwardgatepassmain_id
    LEFT JOIN ${ACCOUNTS_TABLE.table} coa ON coa.${ACCOUNTS_TABLE.code} = ogpm.account_code
    WHERE ogpd.company_id = ?
      AND ogpd.Item_code = ?
      AND ogpm.outward_date BETWEEN ? AND ?
      ${deptClause}
    ORDER BY ogpm.outward_date, ogpm.id, ogpd.entry_no
  `;
  const [rows] = await db.query(sql, params);
  return rows.map((r) => ({
    txn_date: normalizeDbDate(r.txn_date),
    movement_type: "OUT",
    voucher_no: r.voucher_no,
    narration: [
      r.contract_no ? `Contract(${r.contract_no})` : "",
      r.production_no ? `Production(${r.production_no})` : "",
      r.vehicle_no ? `Vehicle(${r.vehicle_no})` : "",
      r.driver_name ? `Driver(${r.driver_name})` : "",
    ]
      .filter(Boolean)
      .join(" "),
    party_name: r.party_name,
    pieces_in: 0,
    pieces_out: toNumber(r.pieces),
    weight_in: 0,
    weight_out: toNumber(r.net_weight),
  }));
}

// ============================================================================
// GET /gatepass/item-report
//   query: company_id, item_code, department_id (optional), start_date, end_date
// ============================================================================
async function getItemMovementReport(req, res) {
  try {
    const { company_id, item_code, department_id, start_date, end_date } = req.query;

    if (!company_id || !item_code || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: "company_id, item_code, start_date and end_date are required",
      });
    }

    const startDate = toSqlDate(start_date);
    const endDate = toSqlDate(end_date);
    const deptId = department_id || null;

    const [inRows, outRows] = await Promise.all([
      fetchInwardMovement(company_id, deptId, item_code, startDate, endDate),
      fetchOutwardMovement(company_id, deptId, item_code, startDate, endDate),
    ]);

    const merged = [...inRows, ...outRows].sort((a, b) => {
      if (a.txn_date < b.txn_date) return -1;
      if (a.txn_date > b.txn_date) return 1;
      return 0;
    });

    let runningWeight = 0;
    let runningPieces = 0;
    const rows = merged.map((r, idx) => {
      runningWeight = runningWeight + r.weight_in - r.weight_out;
      runningPieces = runningPieces + r.pieces_in - r.pieces_out;
      return {
        s_no: idx + 1,
        date: r.txn_date,
        movement_type: r.movement_type,
        voucher_no: r.voucher_no,
        party_name: r.party_name,
        narration: r.narration,
        pieces: r.movement_type === "IN" ? r.pieces_in : r.pieces_out,
        weight: r.movement_type === "IN" ? r.weight_in : r.weight_out,
        weight_balance: Number(runningWeight.toFixed(2)),
        pieces_balance: runningPieces,
      };
    });

    const totals = rows.reduce(
      (acc, r) => {
        if (r.movement_type === "IN") {
          acc.pieces_in += r.pieces;
          acc.weight_in += r.weight;
        } else {
          acc.pieces_out += r.pieces;
          acc.weight_out += r.weight;
        }
        return acc;
      },
      { pieces_in: 0, weight_in: 0, pieces_out: 0, weight_out: 0 }
    );

    // Item display name
    const [itemRows] = await db.query(
      `SELECT ${ITEMS_TABLE.code} AS code, ${ITEMS_TABLE.name} AS name FROM ${ITEMS_TABLE.table} WHERE company_id = ? AND ${ITEMS_TABLE.code} = ? LIMIT 1`,
      [company_id, item_code]
    );

    return res.json({
      success: true,
      data: {
        item_code,
        item_name: itemRows[0]?.name || item_code,
        rows,
        total_pieces_in: totals.pieces_in,
        total_weight_in: Number(totals.weight_in.toFixed(2)),
        total_pieces_out: totals.pieces_out,
        total_weight_out: Number(totals.weight_out.toFixed(2)),
        net_weight: Number((totals.weight_in - totals.weight_out).toFixed(2)),
        net_pieces: totals.pieces_in - totals.pieces_out,
        start_date: startDate,
        end_date: endDate,
      },
    });
  } catch (err) {
    console.error("getItemMovementReport error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate item movement report" });
  }
}

// ============================================================================
// Internal query builders — Report 2 (all items, aggregated totals)
// ============================================================================

async function fetchInwardTotalsByItem(companyId, departmentId, startDate, endDate) {
  const params = [companyId, startDate, endDate];
  let deptClause = "";
  if (departmentId) {
    deptClause = " AND igpm.department_id = ? ";
    params.push(departmentId);
  }
  const sql = `
    SELECT igpd.Item_code AS item_code,
           COALESCE(SUM(igpd.pieces), 0)     AS pieces_in,
           COALESCE(SUM(igpd.net_weight), 0) AS weight_in
    FROM InwardGatePassDetail igpd
    INNER JOIN InwardGatePassMain igpm ON igpm.id = igpd.inwardgatepassmain_id
    WHERE igpd.company_id = ?
      AND igpm.inward_date BETWEEN ? AND ?
      ${deptClause}
    GROUP BY igpd.Item_code
  `;
  const [rows] = await db.query(sql, params);
  return rows;
}

async function fetchOutwardTotalsByItem(companyId, departmentId, startDate, endDate) {
  const params = [companyId, startDate, endDate];
  let deptClause = "";
  if (departmentId) {
    deptClause = " AND ogpm.department_id = ? ";
    params.push(departmentId);
  }
  const sql = `
    SELECT ogpd.Item_code AS item_code,
           COALESCE(SUM(ogpd.pieces), 0)     AS pieces_out,
           COALESCE(SUM(ogpd.net_weight), 0) AS weight_out
    FROM OutwardGatePassDetail ogpd
    INNER JOIN OutwardGatePassMain ogpm ON ogpm.id = ogpd.outwardgatepassmain_id
    WHERE ogpd.company_id = ?
      AND ogpm.outward_date BETWEEN ? AND ?
      ${deptClause}
    GROUP BY ogpd.Item_code
  `;
  const [rows] = await db.query(sql, params);
  return rows;
}

// ============================================================================
// GET /gatepass/summary-report
//   query: company_id, department_id (optional), start_date, end_date
// ============================================================================
async function getItemsSummaryReport(req, res) {
  try {
    const { company_id, department_id, start_date, end_date } = req.query;

    if (!company_id || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: "company_id, start_date and end_date are required",
      });
    }

    const startDate = toSqlDate(start_date);
    const endDate = toSqlDate(end_date);
    const deptId = department_id || null;

    const [inTotals, outTotals] = await Promise.all([
      fetchInwardTotalsByItem(company_id, deptId, startDate, endDate),
      fetchOutwardTotalsByItem(company_id, deptId, startDate, endDate),
    ]);

    const byItem = new Map();
    for (const r of inTotals) {
      byItem.set(r.item_code, {
        item_code: r.item_code,
        pieces_in: toNumber(r.pieces_in),
        weight_in: toNumber(r.weight_in),
        pieces_out: 0,
        weight_out: 0,
      });
    }
    for (const r of outTotals) {
      const existing = byItem.get(r.item_code) || {
        item_code: r.item_code,
        pieces_in: 0,
        weight_in: 0,
        pieces_out: 0,
        weight_out: 0,
      };
      existing.pieces_out = toNumber(r.pieces_out);
      existing.weight_out = toNumber(r.weight_out);
      byItem.set(r.item_code, existing);
    }

    const itemCodes = Array.from(byItem.keys());
    let namesByCode = {};
    if (itemCodes.length) {
      const [nameRows] = await db.query(
        `SELECT ${ITEMS_TABLE.code} AS code, ${ITEMS_TABLE.name} AS name
         FROM ${ITEMS_TABLE.table}
         WHERE company_id = ? AND ${ITEMS_TABLE.code} IN (?)`,
        [company_id, itemCodes]
      );
      namesByCode = Object.fromEntries(nameRows.map((n) => [n.code, n.name]));
    }

    const rows = itemCodes
      .map((code) => {
        const r = byItem.get(code);
        return {
          item_code: code,
          item_name: namesByCode[code] || code,
          pieces_in: r.pieces_in,
          weight_in: Number(r.weight_in.toFixed(2)),
          pieces_out: r.pieces_out,
          weight_out: Number(r.weight_out.toFixed(2)),
          net_pieces: r.pieces_in - r.pieces_out,
          net_weight: Number((r.weight_in - r.weight_out).toFixed(2)),
        };
      })
      .sort((a, b) => a.item_name.localeCompare(b.item_name));

    const totals = rows.reduce(
      (acc, r) => {
        acc.pieces_in += r.pieces_in;
        acc.weight_in += r.weight_in;
        acc.pieces_out += r.pieces_out;
        acc.weight_out += r.weight_out;
        return acc;
      },
      { pieces_in: 0, weight_in: 0, pieces_out: 0, weight_out: 0 }
    );

    return res.json({
      success: true,
      data: {
        rows,
        total_pieces_in: totals.pieces_in,
        total_weight_in: Number(totals.weight_in.toFixed(2)),
        total_pieces_out: totals.pieces_out,
        total_weight_out: Number(totals.weight_out.toFixed(2)),
        net_weight: Number((totals.weight_in - totals.weight_out).toFixed(2)),
        net_pieces: totals.pieces_in - totals.pieces_out,
        start_date: startDate,
        end_date: endDate,
      },
    });
  } catch (err) {
    console.error("getItemsSummaryReport error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate items summary report" });
  }
}

module.exports = {
  searchItems,
  getItemMovementReport,
  getItemsSummaryReport,
};