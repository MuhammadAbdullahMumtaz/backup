const db = require("../../../config/db");

/**
 * ============================================================================
 * PROFIT & LOSS CONTROLLER
 * ============================================================================
 * Produces a 4-level Profit & Loss statement for one company / financial
 * year, over a start/end date window:
 *
 *   Level 1 -> BalanceSheet   (only groups whose `nature` is Income/Expense)
 *   Level 2 -> MainCode
 *   Level 3 -> SubCode
 *   Level 4 -> ChartOfAccount (the actual ledger account — the leaf)
 *
 * Unlike the Trial Balance, P&L is a PERIOD statement, not a running
 * balance — Income/Expense accounts don't carry an opening balance forward
 * from before the report's start date the way Asset/Liability/Equity
 * accounts do. So this controller only computes movement WITHIN
 * [start_date, end_date] (inclusive) for every account, using the exact
 * same 5-source aggregation (Voucher + Purchase + Purchase Return + Sales
 * + Sales Return) and debit/credit convention as the Trial Balance and
 * Ledger controllers.
 *
 * Per-account presentation amount:
 *   - Income  accounts: credit - debit   (Income has a natural credit balance)
 *   - Expense accounts: debit - credit   (Expense has a natural debit balance)
 *
 * Net Profit = Total Income - Total Expense.
 *
 * Classification: BalanceSheet.nature ('Asset'|'Liability'|'Equity'|
 * 'Income'|'Expense') — only groups tagged Income or Expense are included
 * here; everything else (Capital, Current Assets, Current Liabilities...)
 * belongs on the Balance Sheet / Trial Balance, not here.
 *
 * Debit/Credit convention (same as Ledger & Trial Balance, confirmed):
 *   - Purchase:        entry='user' -> credit | entry='auto' -> debit
 *   - Purchase Return:  entry='user' -> debit  | entry='auto' -> credit
 *   - Sales:            entry='user' -> debit  | entry='auto' -> credit
 *   - Sales Return:      entry='user' -> credit | entry='auto' -> debit
 *
 * Table mapping:
 *   - ChartOfAccount.id   -> VoucherDetail.accountcode
 *   - ChartOfAccount.code -> PurchaseMain.supplier_code / PurchaseReturnMain.supplier_code
 *                            / SalesMain.customer_code / SalesReturnMain.customer_code
 *   - ChartOfAccount.subcode_id -> SubCode.id
 *   - SubCode.maincode_id       -> MainCode.id
 *   - MainCode.balancesheet_id  -> BalanceSheet.id
 * ============================================================================
 */

// ============================================================================
// Helpers (same conventions as the ledger / trial balance controllers)
// ============================================================================

function toSqlDate(d) {
  if (d instanceof Date) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function round2(n) {
  return Number((Math.round((n + Number.EPSILON) * 100) / 100).toFixed(2));
}

// ============================================================================
// GET /api/profit-loss/financial-year?company_id=&financialyear_id=
// Prefills the Start date / End date inputs, same as Trial Balance's.
// ============================================================================
async function getFinancialYearRange(req, res) {
  try {
    const { company_id, financialyear_id } = req.query;
    if (!company_id || !financialyear_id) {
      return res.status(400).json({ success: false, message: "company_id and financialyear_id are required" });
    }

    const [rows] = await db.query(
      `SELECT id, start_date, end_date FROM FinancialYear WHERE company_id = ? AND id = ? LIMIT 1`,
      [company_id, financialyear_id]
    );
    if (!rows.length) {
      return res.status(404).json({ success: false, message: "Financial year not found" });
    }

    return res.json({
      success: true,
      data: {
        id: rows[0].id,
        start_date: normalizeDbDate(rows[0].start_date),
        end_date: normalizeDbDate(rows[0].end_date),
      },
    });
  } catch (err) {
    console.error("getFinancialYearRange error:", err);
    return res.status(500).json({ success: false, message: "Failed to fetch financial year" });
  }
}

async function fetchFinancialYearById(companyId, financialYearId) {
  const [rows] = await db.query(
    `SELECT id, start_date, end_date FROM FinancialYear WHERE company_id = ? AND id = ? LIMIT 1`,
    [companyId, financialYearId]
  );
  if (!rows.length) return null;
  return {
    id: rows[0].id,
    start_date: normalizeDbDate(rows[0].start_date),
    end_date: normalizeDbDate(rows[0].end_date),
  };
}

// ============================================================================
// Chart-of-account hierarchy, scoped to Income/Expense BalanceSheet groups
// only — everything else (Assets, Liabilities, Equity) has no place on a
// Profit & Loss statement.
// ============================================================================
async function fetchCoaHierarchy(companyId, financialYearId) {
  const sql = `
    SELECT
      bs.id      AS bs_id,
      bs.details AS bs_details,
      bs.nature  AS bs_nature,
      mc.id      AS mc_id,
      mc.code    AS mc_code,
      mc.details AS mc_details,
      sc.id      AS sc_id,
      sc.code    AS sc_code,
      sc.details AS sc_details,
      coa.id           AS coa_id,
      coa.code         AS coa_code,
      coa.account_name AS coa_name
    FROM ChartOfAccount coa
    INNER JOIN SubCode sc ON sc.id = coa.subcode_id
    INNER JOIN MainCode mc ON mc.id = sc.maincode_id
    INNER JOIN BalanceSheet bs ON bs.id = mc.balancesheet_id
    WHERE coa.company_id = ?
      AND coa.financialyear_id = ?
      AND bs.nature IN ('Income', 'Expense')
    ORDER BY bs.nature DESC, bs.id, mc.code, sc.code, coa.code
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  return rows;
}

// ============================================================================
// Period-only bulk fetchers (no opening replay — P&L doesn't carry forward).
// Same table/column mapping as Trial Balance's fetch*Map functions.
// ============================================================================

async function fetchVoucherMap(companyId, fromDate, toDate) {
  const sql = `
    SELECT vd.accountcode AS acc,
           COALESCE(SUM(vd.debit), 0)  AS debit,
           COALESCE(SUM(vd.credit), 0) AS credit
    FROM VoucherDetail vd
    INNER JOIN VoucherMain vm ON vm.id = vd.vouchermain_id
    WHERE vd.company_id = ?
      AND vm.voucher_date BETWEEN ? AND ?
    GROUP BY vd.accountcode
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.acc, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

async function fetchPurchaseMap(companyId, fromDate, toDate) {
  const sql = `
    SELECT pm.supplier_code AS code,
           COALESCE(SUM(CASE WHEN pm.entry = 'auto' THEN pd.total ELSE 0 END), 0) AS debit,
           COALESCE(SUM(CASE WHEN pm.entry = 'user' THEN pd.total ELSE 0 END), 0) AS credit
    FROM PurchaseDetail pd
    INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
    WHERE pd.company_id = ?
      AND pm.grn_date BETWEEN ? AND ?
    GROUP BY pm.supplier_code
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.code, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

async function fetchPurchaseReturnMap(companyId, fromDate, toDate) {
  const sql = `
    SELECT prm.supplier_code AS code,
           COALESCE(SUM(CASE WHEN prm.entry = 'user' THEN prd.total ELSE 0 END), 0) AS debit,
           COALESCE(SUM(CASE WHEN prm.entry = 'auto' THEN prd.total ELSE 0 END), 0) AS credit
    FROM PurchaseReturnDetail prd
    INNER JOIN PurchaseReturnMain prm ON prm.id = prd.purchasereturnmain_id
    WHERE prd.company_id = ?
      AND prm.return_date BETWEEN ? AND ?
    GROUP BY prm.supplier_code
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.code, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

async function fetchSalesMap(companyId, fromDate, toDate) {
  const sql = `
    SELECT sm.customer_code AS code,
           COALESCE(SUM(CASE WHEN sm.entry = 'user' THEN sm.total ELSE 0 END), 0) AS debit,
           COALESCE(SUM(CASE WHEN sm.entry = 'auto' THEN sm.total ELSE 0 END), 0) AS credit
    FROM SalesMain sm
    WHERE sm.company_id = ?
      AND sm.invoice_date BETWEEN ? AND ?
    GROUP BY sm.customer_code
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.code, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

async function fetchSalesReturnMap(companyId, fromDate, toDate) {
  const sql = `
    SELECT srm.customer_code AS code,
           COALESCE(SUM(CASE WHEN srm.entry = 'auto' THEN srm.total ELSE 0 END), 0) AS debit,
           COALESCE(SUM(CASE WHEN srm.entry = 'user' THEN srm.total ELSE 0 END), 0) AS credit
    FROM SalesReturnMain srm
    WHERE srm.company_id = ?
      AND srm.invoice_date BETWEEN ? AND ?
    GROUP BY srm.customer_code
  `;
  const [rows] = await db.query(sql, [companyId, fromDate, toDate]);
  const map = new Map();
  for (const r of rows) map.set(r.code, { debit: toNumber(r.debit), credit: toNumber(r.credit) });
  return map;
}

// Flattens the Map-based hierarchy into plain arrays for the JSON response.
function flattenBalanceSheets(bsMap) {
  return Array.from(bsMap.values()).map((bs) => ({
    id: bs.id,
    details: bs.details,
    total: round2(bs.total),
    maincodes: Array.from(bs.maincodes.values()).map((mc) => ({
      id: mc.id,
      code: mc.code,
      details: mc.details,
      total: round2(mc.total),
      subcodes: Array.from(mc.subcodes.values()).map((sc) => ({
        id: sc.id,
        code: sc.code,
        details: sc.details,
        total: round2(sc.total),
        accounts: sc.accounts,
      })),
    })),
  }));
}

// ============================================================================
// GET /api/profit-loss/report
//   query params: company_id, financialyear_id, start_date (YYYY-MM-DD),
//                 end_date (YYYY-MM-DD)
// ============================================================================
async function getProfitAndLoss(req, res) {
  try {
    const { company_id, financialyear_id, start_date, end_date } = req.query;

    if (!company_id || !financialyear_id || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: "company_id, financialyear_id, start_date and end_date are required",
      });
    }

    const startDate = toSqlDate(start_date);
    const endDate = toSqlDate(end_date);

    const financialYear = await fetchFinancialYearById(company_id, financialyear_id);
    if (!financialYear) {
      return res.status(400).json({
        success: false,
        message: `Financial year ${financialyear_id} was not found for this company.`,
      });
    }

    const [coaRows, voucherMap, purchaseMap, purchaseReturnMap, salesMap, salesReturnMap] = await Promise.all([
      fetchCoaHierarchy(company_id, financialyear_id),
      fetchVoucherMap(company_id, startDate, endDate),
      fetchPurchaseMap(company_id, startDate, endDate),
      fetchPurchaseReturnMap(company_id, startDate, endDate),
      fetchSalesMap(company_id, startDate, endDate),
      fetchSalesReturnMap(company_id, startDate, endDate),
    ]);

    const sections = { Income: new Map(), Expense: new Map() };
    const sectionTotals = { Income: 0, Expense: 0 };

    for (const row of coaRows) {
      const vp = voucherMap.get(row.coa_id) || { debit: 0, credit: 0 };
      const pp = purchaseMap.get(row.coa_code) || { debit: 0, credit: 0 };
      const prp = purchaseReturnMap.get(row.coa_code) || { debit: 0, credit: 0 };
      const zp = salesMap.get(row.coa_code) || { debit: 0, credit: 0 };
      const zrp = salesReturnMap.get(row.coa_code) || { debit: 0, credit: 0 };

      const debit = vp.debit + pp.debit + prp.debit + zp.debit + zrp.debit;
      const credit = vp.credit + pp.credit + prp.credit + zp.credit + zrp.credit;

      // Skip accounts with zero movement in the window entirely - an empty
      // P&L line is just noise.
      if (debit === 0 && credit === 0) continue;

      const nature = row.bs_nature; // 'Income' | 'Expense'
      const amount = nature === "Income" ? credit - debit : debit - credit;

      const account = {
        id: row.coa_id,
        code: row.coa_code,
        account_name: row.coa_name,
        debit: round2(debit),
        credit: round2(credit),
        amount: round2(amount),
      };

      const bsMap = sections[nature];
      if (!bsMap.has(row.bs_id)) {
        bsMap.set(row.bs_id, { id: row.bs_id, details: row.bs_details, maincodes: new Map(), total: 0 });
      }
      const bsNode = bsMap.get(row.bs_id);

      if (!bsNode.maincodes.has(row.mc_id)) {
        bsNode.maincodes.set(row.mc_id, { id: row.mc_id, code: row.mc_code, details: row.mc_details, subcodes: new Map(), total: 0 });
      }
      const mcNode = bsNode.maincodes.get(row.mc_id);

      if (!mcNode.subcodes.has(row.sc_id)) {
        mcNode.subcodes.set(row.sc_id, { id: row.sc_id, code: row.sc_code, details: row.sc_details, accounts: [], total: 0 });
      }
      const scNode = mcNode.subcodes.get(row.sc_id);

      scNode.accounts.push(account);
      scNode.total += amount;
      mcNode.total += amount;
      bsNode.total += amount;
      sectionTotals[nature] += amount;
    }

    const totalIncome = round2(sectionTotals.Income);
    const totalExpense = round2(sectionTotals.Expense);

    return res.json({
      success: true,
      data: {
        start_date: startDate,
        end_date: endDate,
        financial_year: financialYear,
        income: { total: totalIncome, balancesheets: flattenBalanceSheets(sections.Income) },
        expenses: { total: totalExpense, balancesheets: flattenBalanceSheets(sections.Expense) },
        net_profit: round2(totalIncome - totalExpense),
      },
    });
  } catch (err) {
    console.error("getProfitAndLoss error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate profit & loss report" });
  }
}

module.exports = {
  getFinancialYearRange,
  getProfitAndLoss,
};