const db = require("../../../config/db");

const VALID_DOC_TYPES = ['voucher', 'purchase', 'purchasereturn', 'sales', 'salesreturn'];

// ======================================================
// Get Company Users (for the User-select dropdown)
// ======================================================
exports.getCompanyUsers = async (req, res) => {
    try {
        const { company_id } = req.params;
        if (!company_id) {
            return res.status(400).json({ message: "Company ID is required." });
        }

        const [rows] = await db.query(
            `SELECT id, username, role FROM Logins WHERE company_id = ? ORDER BY username ASC`,
            [company_id]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching company users:", error);
        res.status(500).json({ message: "Failed to fetch users.", error: error.message });
    }
};

// ======================================================
// Get User Entries Report
// ======================================================
// Body: { company_id, financialyear_id, requested_by, role, usernames: [],
//         start_date (yyyy-mm-dd), end_date (yyyy-mm-dd), doc_types: [] }
exports.getUserEntriesReport = async (req, res) => {
    try {
        const {
            company_id,
            financialyear_id,
            requested_by,
            role,
            usernames,
            start_date,
            end_date,
            doc_types
        } = req.body;

        if (!company_id || !start_date || !end_date) {
            return res.status(400).json({
                message: "Company, start date, and end date are required."
            });
        }
        if (!Array.isArray(doc_types) || doc_types.length === 0) {
            return res.status(400).json({ message: "Select at least one document type." });
        }
        const invalidType = doc_types.find((t) => !VALID_DOC_TYPES.includes(t));
        if (invalidType) {
            return res.status(400).json({ message: `Invalid document type: ${invalidType}` });
        }

        // SECURITY: non-admins can only ever see their own entries, no matter
        // what the client sent in `usernames`. See flag in the covering note
        // about trusting `role` from the client the same way this app
        // already trusts `performed_by` for logging.
        let targetUsernames;
        if (role === 'Admin') {
            if (!Array.isArray(usernames) || usernames.length === 0) {
                return res.status(400).json({ message: "Select at least one user." });
            }
            targetUsernames = usernames;
        } else {
            if (!requested_by) {
                return res.status(400).json({ message: "requested_by is required." });
            }
            targetUsernames = [requested_by];
        }

        const entries = [];

        const userPlaceholders = targetUsernames.map(() => '?').join(',');

        if (doc_types.includes('voucher')) {
            const [rows] = await db.query(
                `SELECT vm.id, vm.voucher_no AS document_no,
                        DATE_FORMAT(vm.voucher_date, '%Y-%m-%d') AS document_date,
                        vt.details AS party_name,
                        vm.created_by,
                        NULL AS amount
                 FROM VoucherMain vm
                 INNER JOIN VoucherType vt ON vm.vouchertype_id = vt.id
                 WHERE vm.company_id = ?
                   ${financialyear_id ? 'AND vm.financialyear_id = ?' : ''}
                   AND vm.voucher_date BETWEEN ? AND ?
                   AND vm.created_by IN (${userPlaceholders})`,
                [
                    company_id,
                    ...(financialyear_id ? [financialyear_id] : []),
                    start_date, end_date,
                    ...targetUsernames
                ]
            );
            rows.forEach((r) => entries.push({ doc_type: 'voucher', ...r }));
        }

        if (doc_types.includes('purchase')) {
            const [rows] = await db.query(
                `SELECT pm.id, pm.grn_no AS document_no,
                        DATE_FORMAT(pm.grn_date, '%Y-%m-%d') AS document_date,
                        coa.account_name AS party_name,
                        pm.created_by,
                        (SELECT COALESCE(SUM(pd.total),0) FROM PurchaseDetail pd
                            WHERE pd.purchasemain_id = pm.id AND pd.entry = 'user') AS amount
                 FROM PurchaseMain pm
                 LEFT JOIN ChartOfAccount coa ON pm.supplier_code = coa.code AND coa.company_id = pm.company_id
                 WHERE pm.company_id = ?
                   AND pm.entry = 'user'
                   ${financialyear_id ? 'AND pm.financialyear_id = ?' : ''}
                   AND pm.grn_date BETWEEN ? AND ?
                   AND pm.created_by IN (${userPlaceholders})`,
                [
                    company_id,
                    ...(financialyear_id ? [financialyear_id] : []),
                    start_date, end_date,
                    ...targetUsernames
                ]
            );
            rows.forEach((r) => entries.push({ doc_type: 'purchase', ...r }));
        }

        if (doc_types.includes('purchasereturn')) {
            const [rows] = await db.query(
                `SELECT prm.id, prm.return_no AS document_no,
                        DATE_FORMAT(prm.return_date, '%Y-%m-%d') AS document_date,
                        coa.account_name AS party_name,
                        prm.created_by,
                        (SELECT COALESCE(SUM(prd.total),0) FROM PurchaseReturnDetail prd
                            WHERE prd.purchasereturnmain_id = prm.id AND prd.entry = 'user') AS amount
                 FROM PurchaseReturnMain prm
                 LEFT JOIN ChartOfAccount coa ON prm.supplier_code = coa.code AND coa.company_id = prm.company_id
                 WHERE prm.company_id = ?
                   AND prm.entry = 'user'
                   ${financialyear_id ? 'AND prm.financialyear_id = ?' : ''}
                   AND prm.return_date BETWEEN ? AND ?
                   AND prm.created_by IN (${userPlaceholders})`,
                [
                    company_id,
                    ...(financialyear_id ? [financialyear_id] : []),
                    start_date, end_date,
                    ...targetUsernames
                ]
            );
            rows.forEach((r) => entries.push({ doc_type: 'purchasereturn', ...r }));
        }

        if (doc_types.includes('sales')) {
            const [rows] = await db.query(
                `SELECT sm.id, sm.invoice_no AS document_no,
                        DATE_FORMAT(sm.invoice_date, '%Y-%m-%d') AS document_date,
                        coa.account_name AS party_name,
                        sm.created_by,
                        sm.total AS amount
                 FROM SalesMain sm
                 LEFT JOIN ChartOfAccount coa ON sm.customer_code = coa.code AND coa.company_id = sm.company_id
                 WHERE sm.company_id = ?
                   AND sm.entry = 'user'
                   ${financialyear_id ? 'AND sm.financialyear_id = ?' : ''}
                   AND sm.invoice_date BETWEEN ? AND ?
                   AND sm.created_by IN (${userPlaceholders})`,
                [
                    company_id,
                    ...(financialyear_id ? [financialyear_id] : []),
                    start_date, end_date,
                    ...targetUsernames
                ]
            );
            rows.forEach((r) => entries.push({ doc_type: 'sales', ...r }));
        }

        if (doc_types.includes('salesreturn')) {
            const [rows] = await db.query(
                `SELECT srm.id, srm.invoice_no AS document_no,
                        DATE_FORMAT(srm.invoice_date, '%Y-%m-%d') AS document_date,
                        coa.account_name AS party_name,
                        srm.created_by,
                        srm.total AS amount
                 FROM SalesReturnMain srm
                 LEFT JOIN ChartOfAccount coa ON srm.customer_code = coa.code AND coa.company_id = srm.company_id
                 WHERE srm.company_id = ?
                   AND srm.entry = 'user'
                   ${financialyear_id ? 'AND srm.financialyear_id = ?' : ''}
                   AND srm.invoice_date BETWEEN ? AND ?
                   AND srm.created_by IN (${userPlaceholders})`,
                [
                    company_id,
                    ...(financialyear_id ? [financialyear_id] : []),
                    start_date, end_date,
                    ...targetUsernames
                ]
            );
            rows.forEach((r) => entries.push({ doc_type: 'salesreturn', ...r }));
        }

        // Summary: count per (username, doc_type)
        const summaryMap = new Map();
        for (const e of entries) {
            const key = `${e.created_by || 'Unknown'}|${e.doc_type}`;
            summaryMap.set(key, (summaryMap.get(key) || 0) + 1);
        }
        const summary = [...summaryMap.entries()].map(([key, count]) => {
            const [username, doc_type] = key.split('|');
            return { username, doc_type, count };
        });

        entries.sort((a, b) => new Date(b.document_date) - new Date(a.document_date));

        res.status(200).json({ summary, entries });
    } catch (error) {
        console.error("Error generating user entries report:", error);
        res.status(500).json({ message: "Failed to generate report.", error: error.message });
    }
};