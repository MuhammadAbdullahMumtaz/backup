const db = require("../../../config/db");

/**
 * ============================================================================
 * PRODUCTION REPORT CONTROLLER
 * ============================================================================
 * Produces an item-wise production report (ProductionMain + ProductionDetail)
 * for one finished-goods item, between a start and end date. Built the same
 * way as the Ledger report (LedgerController.js) and the Issued report:
 *
 *   1. financialyear_id is sent straight from the frontend (Redux) and is
 *      looked up by PK — no date-range scanning.
 *   2. "Opening" = sum of pieces / net_weight / amount for this item (and,
 *      if given, this department) produced between the FY's start_date and
 *      (but excluding) `start_date`.
 *   3. Display rows = every ProductionDetail line for this item dated
 *      between `start_date` and `end_date` (inclusive), one row per detail
 *      line. Unlike IssuedDetail, ProductionDetail keeps rate/amount/total
 *      (production carries a valuation), but the link back to the source
 *      Issued batch lives on ProductionMain.issued_no (header-level only —
 *      ProductionDetail itself carries no per-line source_detail_id).
 *   4. Running net weight / amount start at the opening totals and are
 *      carried forward row by row; the last row's running value is the
 *      closing total.
 *
 * Table mapping used (matches schema v2):
 *   - ItemDetail(code, details, Unit, company_id)  -> item search + display
 *   - Department(id, company_id, department_name)  -> department filter
 *   - ProductionMain(id, company_id, department_id, financialyear_id,
 *                     production_no, production_date, issued_no, remarks)
 *   - ProductionDetail(productionmain_id, Item_code, entry_no, stocks,
 *                       pieces, gross_weight, tear_weight, net_weight,
 *                       rate, amount, total)
 * ============================================================================
 */

const ITEMS_TABLE = {
  table: "ItemDetail",
  code: "code",
  name: "details",
  company_id: "company_id",
};

// -----------------------------------------------------------------------------
// Recommended indexes (create once):
//   ALTER TABLE ProductionMain   ADD INDEX idx_pm_ledger (company_id, financialyear_id, department_id, production_date);
//   ALTER TABLE ProductionDetail ADD INDEX idx_pd_item (company_id, Item_code, productionmain_id);
// -----------------------------------------------------------------------------

function toSqlDate(d) {
  if (d instanceof Date) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

// ============================================================================
// GET /production/items/search?company_id=&q=
// ============================================================================
async function searchItems(req, res) {
  try {
    const { company_id, q = "" } = req.query;
    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }
    const like = `%${q.trim()}%`;
    const sql = `
      SELECT ${ITEMS_TABLE.code} AS code,
             ${ITEMS_TABLE.name} AS name,
             Unit AS unit
      FROM ${ITEMS_TABLE.table}
      WHERE ${ITEMS_TABLE.company_id} = ?
        AND (${ITEMS_TABLE.name} LIKE ? OR ${ITEMS_TABLE.code} LIKE ?)
      ORDER BY ${ITEMS_TABLE.name} ASC
      LIMIT 20
    `;
    const [rows] = await db.query(sql, [company_id, like, like]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("searchItems (production) error:", err);
    return res.status(500).json({ success: false, message: "Failed to search items" });
  }
}

// ============================================================================
// GET /production/departments?company_id=
// ============================================================================
async function getDepartments(req, res) {
  try {
    const { company_id } = req.query;
    if (!company_id) {
      return res.status(400).json({ success: false, message: "company_id is required" });
    }
    const sql = `
      SELECT id, department_name
      FROM Department
      WHERE company_id = ?
      ORDER BY department_name ASC
    `;
    const [rows] = await db.query(sql, [company_id]);
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("getDepartments (production) error:", err);
    return res.status(500).json({ success: false, message: "Failed to load departments" });
  }
}

// ============================================================================
// GET /production/items/stock?company_id=&financialyear_id=&department_id=
//   "Show All Items" — one row per finished-goods item currently in stock
//   (stocks = 'available', i.e. not yet consumed by Sales), for the whole
//   financial year to date. Items whose available quantity nets to zero
//   (or less) are dropped via HAVING, so this never lists an item that has
//   nothing left in stock.
// ============================================================================
async function getStockSummary(req, res) {
  try {
    const { company_id, financialyear_id, department_id } = req.query;
    if (!company_id || !financialyear_id) {
      return res.status(400).json({ success: false, message: "company_id and financialyear_id are required" });
    }

    const params = [company_id, financialyear_id];
    let departmentClause = "";
    if (department_id) {
      departmentClause = " AND pm.department_id = ? ";
      params.push(department_id);
    }

    const sql = `
      SELECT
        pd.Item_code                       AS code,
        it.details                          AS name,
        it.Unit                              AS unit,
        COALESCE(SUM(pd.pieces), 0)           AS pieces,
        COALESCE(SUM(pd.net_weight), 0)        AS net_weight,
        COALESCE(SUM(pd.total), 0)              AS amount
      FROM ProductionDetail pd
      INNER JOIN ProductionMain pm ON pm.id = pd.productionmain_id
      LEFT JOIN ${ITEMS_TABLE.table} it
        ON it.${ITEMS_TABLE.code} = pd.Item_code AND it.${ITEMS_TABLE.company_id} = pd.company_id
      WHERE pd.company_id = ?
        AND pm.financialyear_id = ?
        AND pd.stocks = 'available'
        ${departmentClause}
      GROUP BY pd.Item_code, it.details, it.Unit
      HAVING SUM(pd.net_weight) > 0
      ORDER BY it.details ASC
    `;
    const [rows] = await db.query(sql, params);

    return res.json({
      success: true,
      data: rows.map((r) => ({
        code: r.code,
        name: r.name || r.code,
        unit: r.unit,
        pieces: toNumber(r.pieces),
        net_weight: toNumber(r.net_weight),
        amount: toNumber(r.amount),
      })),
    });
  } catch (err) {
    console.error("getStockSummary (production) error:", err);
    return res.status(500).json({ success: false, message: "Failed to load stock summary" });
  }
}

// ============================================================================
// Financial year lookup
// ============================================================================
async function fetchFinancialYearById(companyId, financialYearId) {
  const sql = `
    SELECT id, start_date, end_date
    FROM FinancialYear
    WHERE company_id = ?
      AND id = ?
    LIMIT 1
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  if (!rows.length) return null;
  return {
    id: rows[0].id,
    start_date: normalizeDbDate(rows[0].start_date),
    end_date: normalizeDbDate(rows[0].end_date),
  };
}

// ============================================================================
// Opening totals (before start_date, within the FY)
// ============================================================================
async function fetchProductionOpeningTotals(companyId, itemCode, departmentId, fyStartDate, startDate) {
  const params = [companyId, itemCode, fyStartDate, startDate];
  let departmentClause = "";
  if (departmentId) {
    departmentClause = " AND pm.department_id = ? ";
    params.push(departmentId);
  }
  const sql = `
    SELECT
      COALESCE(SUM(pd.pieces), 0)      AS total_pieces,
      COALESCE(SUM(pd.net_weight), 0)  AS total_net_weight,
      COALESCE(SUM(pd.total), 0)       AS total_amount
    FROM ProductionDetail pd
    INNER JOIN ProductionMain pm ON pm.id = pd.productionmain_id
    WHERE pd.company_id = ?
      AND pd.Item_code = ?
      AND pm.production_date >= ?
      AND pm.production_date <  ?
      ${departmentClause}
  `;
  const [rows] = await db.query(sql, params);
  return {
    pieces: toNumber(rows[0]?.total_pieces),
    net_weight: toNumber(rows[0]?.total_net_weight),
    amount: toNumber(rows[0]?.total_amount),
  };
}

// ============================================================================
// Period rows (start_date..end_date inclusive), one row per detail line
// ============================================================================
async function fetchProductionRows(companyId, itemCode, departmentId, startDate, endDate) {
  const params = [companyId, itemCode, startDate, endDate];
  let departmentClause = "";
  if (departmentId) {
    departmentClause = " AND pm.department_id = ? ";
    params.push(departmentId);
  }
  const sql = `
    SELECT
      pm.production_no      AS doc_no,
      pm.production_date    AS txn_date,
      pm.issued_no          AS source_issued_no,
      pm.remarks            AS header_remarks,
      d.department_name     AS department_name,
      pd.entry_no             AS entry_no,
      pd.stocks                AS stocks,
      pd.pieces                  AS pieces,
      pd.gross_weight             AS gross_weight,
      pd.tear_weight               AS tear_weight,
      pd.net_weight                 AS net_weight,
      pd.rate                        AS rate,
      pd.amount                       AS amount,
      pd.total                         AS total
    FROM ProductionDetail pd
    INNER JOIN ProductionMain pm ON pm.id = pd.productionmain_id
    LEFT JOIN Department d ON d.id = pm.department_id
    WHERE pd.company_id = ?
      AND pd.Item_code = ?
      AND pm.production_date BETWEEN ? AND ?
      ${departmentClause}
    ORDER BY pm.production_date, pm.id, pd.entry_no
  `;
  const [rows] = await db.query(sql, params);
  return rows.map((r) => ({
    txn_date: normalizeDbDate(r.txn_date),
    doc_no: r.doc_no,
    department_name: r.department_name || "",
    stocks: r.stocks,
    pieces: toNumber(r.pieces),
    gross_weight: toNumber(r.gross_weight),
    tear_weight: toNumber(r.tear_weight),
    net_weight: toNumber(r.net_weight),
    rate: toNumber(r.rate),
    amount: toNumber(r.amount),
    total: toNumber(r.total),
    source_ref: r.source_issued_no ? `Issued #${r.source_issued_no}` : "",
    remarks: r.header_remarks || "",
  }));
}

// ============================================================================
// GET /production/report
//   query params: company_id, financialyear_id, item_code, department_id
//                 (optional), start_date, end_date
// ============================================================================
async function getProductionReport(req, res) {
  try {
    const { company_id, financialyear_id, item_code, department_id, start_date, end_date } = req.query;

    if (!company_id || !financialyear_id || !item_code || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: "company_id, financialyear_id, item_code, start_date and end_date are required",
      });
    }

    const startDate = toSqlDate(start_date);
    const endDate = toSqlDate(end_date);
    const departmentId = department_id ? Number(department_id) : null;

    const financialYear = await fetchFinancialYearById(company_id, financialyear_id);
    if (!financialYear) {
      return res.status(400).json({
        success: false,
        message: `Financial year ${financialyear_id} was not found for this company.`,
      });
    }
    const fyStartDate = financialYear.start_date;

    const opening = await fetchProductionOpeningTotals(company_id, item_code, departmentId, fyStartDate, startDate);
    const rows = await fetchProductionRows(company_id, item_code, departmentId, startDate, endDate);

    let runningPieces = opening.pieces;
    let runningNetWeight = opening.net_weight;
    let runningAmount = opening.amount;

    const outRows = rows.map((r, idx) => {
      runningPieces += r.pieces;
      runningNetWeight += r.net_weight;
      runningAmount += r.total;
      return {
        s_no: idx + 1,
        date: r.txn_date,
        doc_no: r.doc_no,
        department_name: r.department_name,
        stocks: r.stocks,
        pieces: r.pieces,
        gross_weight: r.gross_weight,
        tear_weight: r.tear_weight,
        net_weight: r.net_weight,
        rate: r.rate,
        amount: r.amount,
        total: r.total,
        running_pieces: runningPieces,
        running_net_weight: Number(runningNetWeight.toFixed(2)),
        running_amount: Number(runningAmount.toFixed(2)),
        source_ref: r.source_ref,
        remarks: r.remarks,
      };
    });

    const totals = outRows.reduce(
      (acc, r) => {
        acc.pieces += r.pieces;
        acc.net_weight += r.net_weight;
        acc.amount += r.total;
        return acc;
      },
      { pieces: 0, net_weight: 0, amount: 0 }
    );

    return res.json({
      success: true,
      data: {
        opening_pieces: opening.pieces,
        opening_net_weight: Number(opening.net_weight.toFixed(2)),
        opening_amount: Number(opening.amount.toFixed(2)),
        rows: outRows,
        total_pieces: totals.pieces,
        total_net_weight: Number(totals.net_weight.toFixed(2)),
        total_amount: Number(totals.amount.toFixed(2)),
        closing_pieces: outRows.length ? outRows[outRows.length - 1].running_pieces : opening.pieces,
        closing_net_weight: outRows.length
          ? outRows[outRows.length - 1].running_net_weight
          : Number(opening.net_weight.toFixed(2)),
        closing_amount: outRows.length
          ? outRows[outRows.length - 1].running_amount
          : Number(opening.amount.toFixed(2)),
        start_date: startDate,
        end_date: endDate,
      },
    });
  } catch (err) {
    console.error("getProductionReport error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate production report" });
  }
}

module.exports = {
  searchItems,
  getDepartments,
  getStockSummary,
  getProductionReport,
};