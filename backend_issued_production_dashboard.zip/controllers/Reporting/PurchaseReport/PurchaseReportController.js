const db = require("../../../config/db");

function toSqlDate(d) {
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function requireCommon(query) {
  const { company_id, financialyear_id, start_date, end_date } = query;
  if (!company_id || !financialyear_id || !start_date || !end_date) {
    return {
      ok: false,
      message: "company_id, financialyear_id, start_date and end_date are required",
    };
  }
  return {
    ok: true,
    companyId: company_id,
    financialyearId: financialyear_id,
    startDate: toSqlDate(start_date),
    endDate: toSqlDate(end_date),
  };
}

// ============================================================================
// Shared building block.
//
// Every summary report (date/account/item/item-group) needs the SAME thing:
// purchases counted as +ve and purchase-returns counted as -ve, over the same
// date range, so a fully-returned GRN nets to zero instead of still showing
// up as a "top" purchase.
//
// `base`  = one row per PurchaseDetail / PurchaseReturnDetail line, signed.
// `alloc` = same rows + a window-function flag (rn = 1) marking exactly one
//           row per document, used to add that document's header-level
//           freight into a SUM() exactly once (freight lives on
//           PurchaseMain/PurchaseReturnMain, not on the detail line, so
//           summing it per-detail-row would multiply it by the item count).
// ============================================================================
const BASE_CTE = `
WITH base AS (
  SELECT
    pm.id               AS doc_id,
    pm.grn_no            AS doc_no,
    pm.grn_date           AS doc_date,
    pm.supplier_code       AS supplier_code,
    pm.freight            AS main_freight,
    sd.entry_no           AS entry_no,
    sd.Item_code          AS item_code,
    sd.pieces            AS pieces,
    sd.gross_weight        AS gross_weight,
    sd.tear_weight         AS tear_weight,
    sd.net_weight         AS net_weight,
    sd.rate              AS rate,
    sd.amount            AS amount,
    sd.total             AS total,
    'purchase'           AS type
  FROM PurchaseDetail sd
  INNER JOIN PurchaseMain pm ON pm.id = sd.purchasemain_id
  WHERE sd.company_id = ?
    AND pm.financialyear_id = ?
    AND pm.entry = 'user'
    AND pm.grn_date BETWEEN ? AND ?

  UNION ALL

  SELECT
    prm.id, prm.return_no, prm.return_date, prm.supplier_code, prm.freight,
    prd.entry_no, prd.Item_code,
    -prd.pieces, -prd.gross_weight, -prd.tear_weight, -prd.net_weight,
    prd.rate, -prd.amount, -prd.total,
    'return'
  FROM PurchaseReturnDetail prd
  INNER JOIN PurchaseReturnMain prm ON prm.id = prd.purchasereturnmain_id
  WHERE prd.company_id = ?
    AND prm.financialyear_id = ?
    AND prm.entry = 'user'
    AND prm.return_date BETWEEN ? AND ?
),
alloc AS (
  SELECT
    base.*,
    ROW_NUMBER() OVER (PARTITION BY type, doc_id ORDER BY entry_no) AS rn,
    CASE WHEN type = 'purchase' THEN main_freight ELSE -main_freight END AS freight_signed
  FROM base
)
`;

// four placeholders used twice (purchase leg + return leg) inside BASE_CTE
function baseCteParams(companyId, financialyearId, startDate, endDate) {
  return [companyId, financialyearId, startDate, endDate, companyId, financialyearId, startDate, endDate];
}

// ============================================================================
// GET /purchase-report/date-wise
//   Purchases minus returns, grouped by GRN / return date.
// ============================================================================
async function getDateWiseSummary(req, res) {
  try {
    const common = requireCommon(req.query);
    if (!common.ok) return res.status(400).json({ success: false, message: common.message });
    const { companyId, financialyearId, startDate, endDate } = common;

    const sql = `
      ${BASE_CTE}
      SELECT
        doc_date AS date,
        COUNT(DISTINCT CASE WHEN type = 'purchase' THEN doc_id END) AS purchase_count,
        COUNT(DISTINCT CASE WHEN type = 'return' THEN doc_id END)   AS return_count,
        COALESCE(SUM(pieces), 0)     AS total_pieces,
        COALESCE(SUM(net_weight), 0) AS total_net_weight,
        COALESCE(SUM(amount), 0)     AS total_amount,
        COALESCE(SUM(CASE WHEN rn = 1 THEN freight_signed ELSE 0 END), 0) AS total_freight,
        COALESCE(SUM(total), 0)      AS total_value
      FROM alloc
      GROUP BY doc_date
      ORDER BY doc_date
    `;
    const [rows] = await db.query(sql, baseCteParams(companyId, financialyearId, startDate, endDate));

    const data = rows.map((r, idx) => ({
      s_no: idx + 1,
      date: normalizeDbDate(r.date),
      purchase_count: toNumber(r.purchase_count),
      return_count: toNumber(r.return_count),
      total_pieces: toNumber(r.total_pieces),
      total_net_weight: toNumber(r.total_net_weight),
      total_amount: toNumber(r.total_amount),
      total_freight: toNumber(r.total_freight),
      total_value: toNumber(r.total_value),
    }));

    return res.json({ success: true, data, start_date: startDate, end_date: endDate });
  } catch (err) {
    console.error("getDateWiseSummary error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate date-wise purchase report" });
  }
}

// ============================================================================
// GET /purchase-report/account-wise
//   optional: limit (default 20)
// ============================================================================
async function getAccountWiseSummary(req, res) {
  try {
    const common = requireCommon(req.query);
    if (!common.ok) return res.status(400).json({ success: false, message: common.message });
    const { companyId, financialyearId, startDate, endDate } = common;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 500);

    const sql = `
      ${BASE_CTE}
      SELECT
        coa.id              AS supplier_id,
        coa.code             AS supplier_code,
        coa.account_name       AS supplier_name,
        cd.city              AS city,
        COUNT(DISTINCT CASE WHEN alloc.type = 'purchase' THEN alloc.doc_id END) AS purchase_count,
        COUNT(DISTINCT CASE WHEN alloc.type = 'return' THEN alloc.doc_id END)   AS return_count,
        COALESCE(SUM(alloc.pieces), 0)     AS total_pieces,
        COALESCE(SUM(alloc.net_weight), 0) AS total_net_weight,
        COALESCE(SUM(alloc.amount), 0)     AS total_amount,
        COALESCE(SUM(CASE WHEN alloc.rn = 1 THEN alloc.freight_signed ELSE 0 END), 0) AS total_freight,
        COALESCE(SUM(alloc.total), 0)      AS total_value
      FROM alloc
      INNER JOIN ChartOfAccount coa ON coa.code = alloc.supplier_code AND coa.company_id = ?
      LEFT JOIN ChartDetail cd ON cd.chartofaccount_id = coa.id
      GROUP BY coa.id, coa.code, coa.account_name, cd.city
      ORDER BY total_value DESC
      LIMIT ?
    `;
    const params = [...baseCteParams(companyId, financialyearId, startDate, endDate), companyId, limit];
    const [rows] = await db.query(sql, params);

    const data = rows.map((r, idx) => ({
      s_no: idx + 1,
      supplier_id: r.supplier_id,
      supplier_code: r.supplier_code,
      supplier_name: r.supplier_name,
      city: r.city || "—",
      purchase_count: toNumber(r.purchase_count),
      return_count: toNumber(r.return_count),
      total_pieces: toNumber(r.total_pieces),
      total_net_weight: toNumber(r.total_net_weight),
      total_amount: toNumber(r.total_amount),
      total_freight: toNumber(r.total_freight),
      total_value: toNumber(r.total_value),
    }));

    return res.json({ success: true, data, start_date: startDate, end_date: endDate });
  } catch (err) {
    console.error("getAccountWiseSummary error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate account-wise purchase report" });
  }
}

// ============================================================================
// GET /purchase-report/item-wise
//   Raw ItemDetail level. optional: limit (default 20)
// ============================================================================
async function getItemWiseSummary(req, res) {
  try {
    const common = requireCommon(req.query);
    if (!common.ok) return res.status(400).json({ success: false, message: common.message });
    const { companyId, financialyearId, startDate, endDate } = common;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 500);

    const sql = `
      ${BASE_CTE}
      SELECT
        itd.code               AS item_code,
        itd.details             AS item_name,
        COUNT(DISTINCT CASE WHEN alloc.type = 'purchase' THEN alloc.doc_id END) AS purchase_count,
        COALESCE(SUM(alloc.pieces), 0)     AS total_pieces,
        COALESCE(SUM(alloc.net_weight), 0) AS total_net_weight,
        COALESCE(SUM(alloc.amount), 0)     AS total_amount,
        COALESCE(SUM(alloc.total), 0)      AS total_value
      FROM alloc
      INNER JOIN ItemDetail itd ON itd.code = alloc.item_code AND itd.company_id = ?
      GROUP BY itd.id, itd.code, itd.details
      ORDER BY total_value DESC
      LIMIT ?
    `;
    const params = [...baseCteParams(companyId, financialyearId, startDate, endDate), companyId, limit];
    const [rows] = await db.query(sql, params);

    const data = rows.map((r, idx) => {
      const pieces = toNumber(r.total_pieces);
      const amount = toNumber(r.total_amount);
      return {
        s_no: idx + 1,
        item_code: r.item_code,
        item_name: r.item_name,
        purchase_count: toNumber(r.purchase_count),
        total_pieces: pieces,
        total_net_weight: toNumber(r.total_net_weight),
        avg_rate: pieces !== 0 ? Number((amount / pieces).toFixed(2)) : 0,
        total_amount: amount,
        total_value: toNumber(r.total_value),
      };
    });

    return res.json({ success: true, data, start_date: startDate, end_date: endDate });
  } catch (err) {
    console.error("getItemWiseSummary error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate item-wise purchase report" });
  }
}

// ============================================================================
// GET /purchase-report/item-group-wise
//   optional: limit (default 20), group_by = 'subitem' | 'mainitem' (default subitem)
// ============================================================================
async function getItemGroupWiseSummary(req, res) {
  try {
    const common = requireCommon(req.query);
    if (!common.ok) return res.status(400).json({ success: false, message: common.message });
    const { companyId, financialyearId, startDate, endDate } = common;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 500);
    const groupBy = ["subitem", "mainitem"].includes(req.query.group_by) ? req.query.group_by : "subitem";

    let groupSelect, groupJoin, groupByClause;
    if (groupBy === "mainitem") {
      groupSelect = `mi.code AS group_code, mi.details AS group_name`;
      groupJoin = `
        INNER JOIN ItemDetail itd ON itd.code = alloc.item_code AND itd.company_id = ?
        INNER JOIN SubItem si ON si.id = itd.subitem_id
        INNER JOIN MainItem mi ON mi.id = si.mainitem_id`;
      groupByClause = `mi.id`;
    } else {
      groupSelect = `si.code AS group_code, si.details AS group_name`;
      groupJoin = `
        INNER JOIN ItemDetail itd ON itd.code = alloc.item_code AND itd.company_id = ?
        INNER JOIN SubItem si ON si.id = itd.subitem_id`;
      groupByClause = `si.id`;
    }

    const sql = `
      ${BASE_CTE}
      SELECT
        ${groupSelect},
        COUNT(DISTINCT CASE WHEN alloc.type = 'purchase' THEN alloc.doc_id END) AS purchase_count,
        COALESCE(SUM(alloc.pieces), 0)     AS total_pieces,
        COALESCE(SUM(alloc.net_weight), 0) AS total_net_weight,
        COALESCE(SUM(alloc.amount), 0)     AS total_amount,
        COALESCE(SUM(alloc.total), 0)      AS total_value
      FROM alloc
      ${groupJoin}
      GROUP BY ${groupByClause}
      ORDER BY total_value DESC
      LIMIT ?
    `;
    const params = [...baseCteParams(companyId, financialyearId, startDate, endDate), companyId, limit];
    const [rows] = await db.query(sql, params);

    const data = rows.map((r, idx) => {
      const pieces = toNumber(r.total_pieces);
      const amount = toNumber(r.total_amount);
      return {
        s_no: idx + 1,
        group_code: r.group_code,
        group_name: r.group_name,
        purchase_count: toNumber(r.purchase_count),
        total_pieces: pieces,
        total_net_weight: toNumber(r.total_net_weight),
        avg_rate: pieces !== 0 ? Number((amount / pieces).toFixed(2)) : 0,
        total_amount: amount,
        total_value: toNumber(r.total_value),
      };
    });

    return res.json({ success: true, data, group_by: groupBy, start_date: startDate, end_date: endDate });
  } catch (err) {
    console.error("getItemGroupWiseSummary error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate item-group-wise purchase report" });
  }
}

// ============================================================================
// GET /purchase-report/detailed
//   Row-level register: every PurchaseDetail line AND every
//   PurchaseReturnDetail line (marked by `type`), for the column picker on
//   the frontend to show/hide. Unlike the summary reports this does NOT net
//   the numbers per row — each row is shown exactly as it was entered, with
//   a Type column so the user can see which rows are returns. Only the
//   footer totals are netted (purchases - returns).
//   optional: supplier_code, item_code, type ('purchase' | 'return'), limit
// ============================================================================
async function getDetailedPurchases(req, res) {
  try {
    const common = requireCommon(req.query);
    if (!common.ok) return res.status(400).json({ success: false, message: common.message });
    const { companyId, financialyearId, startDate, endDate } = common;
    const { supplier_code, item_code, type } = req.query;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 2000, 1), 20000);

    let purchaseWhere = "";
    let returnWhere = "";
    const purchaseParams = [companyId, financialyearId, startDate, endDate];
    const returnParams = [companyId, financialyearId, startDate, endDate];

    if (supplier_code) {
      purchaseWhere += " AND pm.supplier_code = ? ";
      returnWhere += " AND prm.supplier_code = ? ";
      purchaseParams.push(supplier_code);
      returnParams.push(supplier_code);
    }
    if (item_code) {
      purchaseWhere += " AND sd.Item_code = ? ";
      returnWhere += " AND prd.Item_code = ? ";
      purchaseParams.push(item_code);
      returnParams.push(item_code);
    }

    const includePurchase = type !== "return";
    const includeReturn = type !== "purchase";

    const unionParts = [];
    const params = [];

    if (includePurchase) {
      unionParts.push(`
        SELECT
          pm.id AS doc_id, 'purchase' AS type, pm.grn_no AS doc_no, pm.grn_date AS doc_date,
          pm.gp_no AS gp_no, pm.gp_date AS gp_date, pm.invoice_no AS invoice_no, pm.invoice_date AS invoice_date,
          pm.supplier_code AS supplier_code, pm.freight AS main_freight,
          sd.entry_no AS entry_no, sd.Item_code AS item_code, sd.stocks AS stocks,
          sd.pieces AS pieces, sd.gross_weight AS gross_weight, sd.tear_weight AS tear_weight,
          sd.net_weight AS net_weight, sd.rate AS rate, sd.amount AS amount,
          sd.freight AS detail_freight, sd.total AS total
        FROM PurchaseDetail sd
        INNER JOIN PurchaseMain pm ON pm.id = sd.purchasemain_id
        WHERE sd.company_id = ? AND pm.financialyear_id = ? AND pm.entry = 'user'
          AND pm.grn_date BETWEEN ? AND ?
          ${purchaseWhere}
      `);
      params.push(...purchaseParams);
    }

    if (includeReturn) {
      unionParts.push(`
        SELECT
          prm.id, 'return', prm.return_no, prm.return_date,
          prm.gp_no, prm.gp_date, prm.invoice_no, prm.invoice_date,
          prm.supplier_code, prm.freight,
          prd.entry_no, prd.Item_code, NULL,
          prd.pieces, prd.gross_weight, prd.tear_weight,
          prd.net_weight, prd.rate, prd.amount,
          prd.freight, prd.total
        FROM PurchaseReturnDetail prd
        INNER JOIN PurchaseReturnMain prm ON prm.id = prd.purchasereturnmain_id
        WHERE prd.company_id = ? AND prm.financialyear_id = ? AND prm.entry = 'user'
          AND prm.return_date BETWEEN ? AND ?
          ${returnWhere}
      `);
      params.push(...returnParams);
    }

    if (unionParts.length === 0) {
      return res.json({ success: true, data: [], totals: null, start_date: startDate, end_date: endDate });
    }

    params.push(companyId, companyId, limit);

    const sql = `
      SELECT
        d.doc_id, d.type, d.doc_no, d.doc_date,
        d.gp_no, d.gp_date, d.invoice_no, d.invoice_date,
        d.main_freight,
        d.entry_no, d.item_code, d.stocks,
        d.pieces, d.gross_weight, d.tear_weight, d.net_weight,
        d.rate, d.amount, d.detail_freight, d.total,
        coa.code AS supplier_code, coa.account_name AS supplier_name,
        cd.city AS city, cd.province AS province,
        itd.details AS item_name, si.details AS item_sub
      FROM (
        ${unionParts.join(" UNION ALL ")}
      ) d
      INNER JOIN ChartOfAccount coa ON coa.code = d.supplier_code AND coa.company_id = ?
      LEFT JOIN ChartDetail cd ON cd.chartofaccount_id = coa.id
      LEFT JOIN ItemDetail itd ON itd.code = d.item_code AND itd.company_id = ?
      LEFT JOIN SubItem si ON si.id = itd.subitem_id
      ORDER BY d.doc_date, d.doc_id, d.entry_no
      LIMIT ?
    `;
    const [rows] = await db.query(sql, params);

    let totalPieces = 0;
    let totalNetWeight = 0;
    let totalAmount = 0;
    let totalValue = 0;

    const data = rows.map((r, idx) => {
      const sign = r.type === "return" ? -1 : 1;
      totalPieces += sign * toNumber(r.pieces);
      totalNetWeight += sign * toNumber(r.net_weight);
      totalAmount += sign * toNumber(r.amount);
      totalValue += sign * toNumber(r.total);

      return {
        s_no: idx + 1,
        doc_id: r.doc_id,
        type: r.type === "return" ? "Return" : "Purchase",
        doc_no: r.doc_no,
        doc_date: normalizeDbDate(r.doc_date),
        gp_no: r.gp_no,
        gp_date: normalizeDbDate(r.gp_date),
        invoice_no: r.invoice_no,
        invoice_date: normalizeDbDate(r.invoice_date),

        supplier_code: r.supplier_code,
        supplier_name: r.supplier_name,
        city: r.city || "—",
        province: r.province || "—",

        entry_no: r.entry_no,
        item_code: r.item_code,
        item_name: r.item_name || r.item_code,
        item_sub: r.item_sub || "—",
        stocks: r.stocks || "—",

        pieces: toNumber(r.pieces),
        gross_weight: toNumber(r.gross_weight),
        tear_weight: toNumber(r.tear_weight),
        net_weight: toNumber(r.net_weight),
        rate: toNumber(r.rate),
        amount: toNumber(r.amount),
        detail_freight: toNumber(r.detail_freight),
        total: toNumber(r.total),
      };
    });

    return res.json({
      success: true,
      data,
      totals: {
        pieces: totalPieces,
        net_weight: Number(totalNetWeight.toFixed(2)),
        amount: Number(totalAmount.toFixed(2)),
        total: Number(totalValue.toFixed(2)),
      },
      start_date: startDate,
      end_date: endDate,
    });
  } catch (err) {
    console.error("getDetailedPurchases error:", err);
    return res.status(500).json({ success: false, message: "Failed to generate detailed purchase report" });
  }
}

module.exports = {
  getDateWiseSummary,
  getAccountWiseSummary,
  getItemWiseSummary,
  getItemGroupWiseSummary,
  getDetailedPurchases,
};