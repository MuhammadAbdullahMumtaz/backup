const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Outward Gate Pass Details
// ======================================================
exports.getAllOutwardGatePassDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                ogd.id,
                ogd.company_id,
                c.company_name,
                ogd.department_id,
                d.department_name,
                ogd.outwardgatepassmain_id,
                ogm.outward_no,
                ogd.financialyear_id,
                fy.year_detail,
                ogd.Item_code,
                item.details AS item_name,
                ogd.entry_no,
                ogd.pieces,
                ogd.gross_weight,
                ogd.tear_weight,
                ogd.net_weight,
                ogd.add_date,
                ogd.update_date
            FROM OutwardGatePassDetail ogd
            INNER JOIN CompanyName c
                ON ogd.company_id = c.id
            INNER JOIN Department d
                ON ogd.department_id = d.id
            INNER JOIN OutwardGatePassMain ogm
                ON ogd.outwardgatepassmain_id = ogm.id
            INNER JOIN FinancialYear fy
                ON ogd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON ogd.Item_code = item.code AND ogd.company_id = item.company_id
            ORDER BY
                ogm.outward_no,
                ogd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching outward gate pass details:", error);
        res.status(500).json({
            message: "Failed to fetch outward gate pass details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Outward Gate Pass Details By Main ID
// ======================================================
exports.getOutwardGatePassDetailsByMain = async (req, res) => {
    try {
        const { outwardgatepassmain_id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                ogd.id,
                ogd.company_id,
                c.company_name,
                ogd.department_id,
                d.department_name,
                ogd.outwardgatepassmain_id,
                ogm.outward_no,
                ogd.financialyear_id,
                fy.year_detail,
                ogd.Item_code,
                item.details AS item_name,
                ogd.entry_no,
                ogd.pieces,
                ogd.gross_weight,
                ogd.tear_weight,
                ogd.net_weight,
                ogd.add_date,
                ogd.update_date
            FROM OutwardGatePassDetail ogd
            INNER JOIN CompanyName c
                ON ogd.company_id = c.id
            INNER JOIN Department d
                ON ogd.department_id = d.id
            INNER JOIN OutwardGatePassMain ogm
                ON ogd.outwardgatepassmain_id = ogm.id
            INNER JOIN FinancialYear fy
                ON ogd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON ogd.Item_code = item.code AND ogd.company_id = item.company_id
            WHERE ogd.outwardgatepassmain_id = ?
            ORDER BY ogd.entry_no ASC
            `,
            [outwardgatepassmain_id]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching outward gate pass details by main:", error);
        res.status(500).json({
            message: "Failed to fetch outward gate pass details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Outward Gate Pass Detail By ID
// ======================================================
exports.getOutwardGatePassDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                ogd.id,
                ogd.company_id,
                c.company_name,
                ogd.department_id,
                d.department_name,
                ogd.outwardgatepassmain_id,
                ogm.outward_no,
                ogd.financialyear_id,
                fy.year_detail,
                ogd.Item_code,
                item.details AS item_name,
                ogd.entry_no,
                ogd.pieces,
                ogd.gross_weight,
                ogd.tear_weight,
                ogd.net_weight,
                ogd.add_date,
                ogd.update_date
            FROM OutwardGatePassDetail ogd
            INNER JOIN CompanyName c
                ON ogd.company_id = c.id
            INNER JOIN Department d
                ON ogd.department_id = d.id
            INNER JOIN OutwardGatePassMain ogm
                ON ogd.outwardgatepassmain_id = ogm.id
            INNER JOIN FinancialYear fy
                ON ogd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON ogd.Item_code = item.code AND ogd.company_id = item.company_id
            WHERE ogd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "Outward gate pass detail not found." });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching outward gate pass detail:", error);
        res.status(500).json({
            message: "Failed to fetch outward gate pass detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Outward Gate Pass Detail
// ======================================================
// OutwardGatePassDetail is now a pure stock-movement record (like
// IssuedDetail) - no rate, amount, GST, or total. Valuation, if needed,
// lives on the Sales/Contract document this dispatch is against.
exports.addOutwardGatePassDetail = async (req, res) => {
    try {
        const {
            company_id,
            outwardgatepassmain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            performed_by,
            system_name_ip
        } = req.body;

        // department_id and financialyear_id are NOT taken from req.body -
        // they're always derived from the parent OutwardGatePassMain row below.
        if (!company_id || !outwardgatepassmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Outward Gate Pass Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({ message: "Entry number must be a positive integer." });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({ message: "Item code cannot be more than 8 characters." });
        }

        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;

        if (piecesValue < 0) return res.status(400).json({ message: "Pieces cannot be negative." });
        if (netWeightValue < 0) return res.status(400).json({ message: "Net weight cannot be negative." });

        const [mainCheck] = await db.query(
            `SELECT id, department_id, financialyear_id, outward_no FROM OutwardGatePassMain WHERE id = ? AND company_id = ?`,
            [outwardgatepassmain_id, company_id]
        );
        if (mainCheck.length === 0) {
            return res.status(400).json({ message: "Invalid outward gate pass for this company." });
        }
        const { department_id, financialyear_id, outward_no } = mainCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({ message: "Invalid item code for this company." });
        }

        const [result] = await db.query(
            `
            INSERT INTO OutwardGatePassDetail
            (
                company_id, department_id, outwardgatepassmain_id, financialyear_id,
                Item_code, entry_no, pieces, gross_weight, tear_weight, net_weight
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
                company_id, department_id, outwardgatepassmain_id, financialyear_id,
                Item_code, entry_no, piecesValue, grossWeightValue, tearWeightValue, netWeightValue
            ]
        );

        await logActivity({
            document_type: "OutwardGatePassDetail",
            document_no: `${outward_no}-${entry_no}`,
            status: "New",
            remarks: `Outward gate pass line added (Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            message: "Outward gate pass detail added successfully.",
            id: result.insertId
        });
    } catch (error) {
        console.error("Error adding outward gate pass detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({ message: "Entry number already exists for this outward gate pass." });
        }
        res.status(500).json({ message: "Failed to add outward gate pass detail.", error: error.message });
    }
};

// ======================================================
// Update Outward Gate Pass Detail
// ======================================================
exports.updateOutwardGatePassDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            outwardgatepassmain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            performed_by,
            system_name_ip
        } = req.body;

        const [existingRow] = await db.query(`SELECT id FROM OutwardGatePassDetail WHERE id = ?`, [id]);
        if (existingRow.length === 0) {
            return res.status(404).json({ message: "Outward gate pass detail not found." });
        }

        if (!company_id || !outwardgatepassmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Outward Gate Pass Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({ message: "Entry number must be a positive integer." });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({ message: "Item code cannot be more than 8 characters." });
        }

        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;

        if (piecesValue < 0) return res.status(400).json({ message: "Pieces cannot be negative." });
        if (netWeightValue < 0) return res.status(400).json({ message: "Net weight cannot be negative." });

        // Re-derive department_id/financialyear_id from the (possibly new) parent main.
        const [mainCheck] = await db.query(
            `SELECT id, department_id, financialyear_id, outward_no FROM OutwardGatePassMain WHERE id = ? AND company_id = ?`,
            [outwardgatepassmain_id, company_id]
        );
        if (mainCheck.length === 0) {
            return res.status(400).json({ message: "Invalid outward gate pass for this company." });
        }
        const { department_id, financialyear_id, outward_no } = mainCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({ message: "Invalid item code for this company." });
        }

        await db.query(
            `
            UPDATE OutwardGatePassDetail
            SET
                company_id = ?,
                department_id = ?,
                outwardgatepassmain_id = ?,
                financialyear_id = ?,
                Item_code = ?,
                entry_no = ?,
                pieces = ?,
                gross_weight = ?,
                tear_weight = ?,
                net_weight = ?
            WHERE id = ?
            `,
            [
                company_id, department_id, outwardgatepassmain_id, financialyear_id,
                Item_code, entry_no, piecesValue, grossWeightValue, tearWeightValue, netWeightValue,
                id
            ]
        );

        await logActivity({
            document_type: "OutwardGatePassDetail",
            document_no: `${outward_no}-${entry_no}`,
            status: "Edit",
            remarks: `Outward gate pass line updated (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Outward gate pass detail updated successfully." });
    } catch (error) {
        console.error("Error updating outward gate pass detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({ message: "Entry number already exists for this outward gate pass." });
        }
        res.status(500).json({ message: "Failed to update outward gate pass detail.", error: error.message });
    }
};

// ======================================================
// Delete Outward Gate Pass Detail
// ======================================================
exports.deleteOutwardGatePassDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [rows] = await db.query(
            `SELECT ogd.entry_no, ogd.Item_code, ogm.outward_no
             FROM OutwardGatePassDetail ogd
             INNER JOIN OutwardGatePassMain ogm ON ogd.outwardgatepassmain_id = ogm.id
             WHERE ogd.id = ?`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Outward gate pass detail not found." });
        }
        const { entry_no, Item_code, outward_no } = rows[0];

        const [result] = await db.query(`DELETE FROM OutwardGatePassDetail WHERE id = ?`, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Outward gate pass detail not found." });
        }

        await logActivity({
            document_type: "OutwardGatePassDetail",
            document_no: `${outward_no}-${entry_no}`,
            status: "Delete",
            remarks: `Outward gate pass line deleted (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Outward gate pass detail deleted successfully." });
    } catch (error) {
        console.error("Error deleting outward gate pass detail:", error);
        res.status(500).json({
            message: "Failed to delete outward gate pass detail.",
            error: error.message
        });
    }
};