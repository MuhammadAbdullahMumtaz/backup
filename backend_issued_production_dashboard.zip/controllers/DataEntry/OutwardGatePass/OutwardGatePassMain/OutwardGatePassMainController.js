const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Outward Gate Pass Mains
// ======================================================
exports.getAllOutwardGatePassMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                ogm.id,
                ogm.company_id,
                c.company_name,

                ogm.department_id,
                d.department_name,

                ogm.financialyear_id,
                fy.year_detail,

                ogm.outward_no,
                ogm.outward_date,

                ogm.account_code,
                coa.account_name,

                ogm.vehicle_no,
                ogm.vehicle_type,
                ogm.driver_name,
                ogm.driver_phone_no,

                ogm.contract_no,
                ogm.production_no,

                ogm.freight,
                ogm.remarks,

                ogm.created_by,
                ogm.add_date,
                ogm.update_date

            FROM OutwardGatePassMain ogm

            INNER JOIN CompanyName c
                ON ogm.company_id = c.id

            INNER JOIN Department d
                ON ogm.department_id = d.id

            INNER JOIN FinancialYear fy
                ON ogm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON ogm.account_code = coa.code AND coa.company_id = ogm.company_id

            ORDER BY ogm.outward_no ASC
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching outward gate passes:", error);
        res.status(500).json({
            message: "Failed to fetch outward gate passes.",
            error: error.message
        });
    }
};

// ======================================================
// Get Next Outward Number (preview only - real number assigned in add())
// ======================================================
exports.getNextOutwardNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.params;

        if (!company_id || !financialyear_id) {
            return res.status(400).json({
                message: "Company ID and Financial Year ID are required."
            });
        }

        const [rows] = await db.query(
            `
            SELECT MAX(CAST(SUBSTRING_INDEX(outward_no, '-', -1) AS UNSIGNED)) as max_outward_no
            FROM OutwardGatePassMain
            WHERE company_id = ?
              AND financialyear_id = ?
            `,
            [company_id, financialyear_id]
        );

        const maxOutwardNo = rows[0].max_outward_no || 0;
        const nextNumber = maxOutwardNo + 1;

        res.status(200).json({ next_outward_number: nextNumber });
    } catch (error) {
        console.error("Error generating next outward number:", error);
        res.status(500).json({
            message: "Failed to generate next outward number.",
            error: error.message
        });
    }
};

// ======================================================
// Get Outward Gate Pass Main By ID
// ======================================================
exports.getOutwardGatePassMainById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                ogm.id,
                ogm.company_id,
                c.company_name,

                ogm.department_id,
                d.department_name,

                ogm.financialyear_id,
                fy.year_detail,

                ogm.outward_no,
                ogm.outward_date,

                ogm.account_code,
                coa.account_name,

                ogm.vehicle_no,
                ogm.vehicle_type,
                ogm.driver_name,
                ogm.driver_phone_no,

                ogm.contract_no,
                ogm.production_no,

                ogm.freight,
                ogm.remarks,

                ogm.created_by,
                ogm.add_date,
                ogm.update_date

            FROM OutwardGatePassMain ogm

            INNER JOIN CompanyName c
                ON ogm.company_id = c.id

            INNER JOIN Department d
                ON ogm.department_id = d.id

            INNER JOIN FinancialYear fy
                ON ogm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON ogm.account_code = coa.code AND coa.company_id = ogm.company_id

            WHERE ogm.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "Outward gate pass not found." });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching outward gate pass:", error);
        res.status(500).json({
            message: "Failed to fetch outward gate pass.",
            error: error.message
        });
    }
};

// ======================================================
// Add Outward Gate Pass Main
// ======================================================
exports.addOutwardGatePassMain = async (req, res) => {
    const {
        company_id,
        department_id,
        financialyear_id,
        outward_date,
        account_code,
        vehicle_no,
        vehicle_type,
        driver_name,
        driver_phone_no,
        contract_no,
        production_no,
        freight,
        remarks,
        performed_by,
        system_name_ip
    } = req.body;

    const freightValue = parseFloat(freight) || 0;

    // outward_no is not accepted from the client - it's generated atomically below
    if (!company_id || !department_id || !financialyear_id || !outward_date ||
        !account_code || !vehicle_no) {
        return res.status(400).json({
            message: "Company, department, financial year, outward date, account, and vehicle no are all required."
        });
    }

    if (!String(vehicle_no).trim()) {
        return res.status(400).json({ message: "Vehicle number cannot be empty." });
    }

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        const [departmentCheck] = await conn.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [accountCheck] = await conn.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [account_code, company_id]
        );
        if (accountCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid account code for this company." });
        }

        const [financialYearCheck] = await conn.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        // contract_no / production_no are optional free-text references (not FKs)
        // but if supplied, they must point at a real document for this company.
        if (contract_no) {
            const [contractCheck] = await conn.query(
                `SELECT id FROM SalesContractMain WHERE contract_no = ? AND company_id = ?`,
                [contract_no, company_id]
            );
            if (contractCheck.length === 0) {
                await conn.rollback();
                return res.status(400).json({ message: "Invalid contract number for this company." });
            }
        }

        if (production_no) {
            const [productionCheck] = await conn.query(
                `SELECT id FROM ProductionMain WHERE production_no = ? AND company_id = ?`,
                [production_no, company_id]
            );
            if (productionCheck.length === 0) {
                await conn.rollback();
                return res.status(400).json({ message: "Invalid production number for this company." });
            }
        }

        // Atomic increment, scoped to (company, financial year) - matches
        // OutwardGatePassSequence's primary key and the compound unique key
        // (company_id, financialyear_id, outward_no) on OutwardGatePassMain.
        await conn.query(
            `INSERT INTO OutwardGatePassSequence (company_id, financialyear_id, last_no)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE last_no = last_no + 1`,
            [company_id, financialyear_id]
        );

        const [seqRow] = await conn.query(
            `SELECT last_no FROM OutwardGatePassSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const nextNumber = seqRow[0].last_no;
        const outwardNo = String(nextNumber);

        const [result] = await conn.query(
            `INSERT INTO OutwardGatePassMain
                (company_id, department_id, financialyear_id, outward_no, outward_date,
                 account_code, vehicle_no, vehicle_type, driver_name, driver_phone_no,
                 contract_no, production_no, freight, remarks, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                company_id, department_id, financialyear_id, outwardNo, outward_date,
                account_code, vehicle_no.trim(), vehicle_type ? vehicle_type.trim() : null,
                driver_name ? driver_name.trim() : null,
                driver_phone_no ? driver_phone_no.trim() : null,
                contract_no || null,
                production_no || null,
                freightValue,
                remarks ? remarks.trim() : null,
                performed_by || 'Unknown'
            ]
        );

        await conn.commit();
        await logActivity({
            document_type: "OutwardGatePassMain",
            document_no: outwardNo,
            status: "New",
            remarks: `Outward gate pass created (Vehicle: ${vehicle_no}, Account: ${account_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            message: "Outward gate pass created successfully.",
            id: result.insertId,
            outward_no: outwardNo
        });
    } catch (error) {
        await conn.rollback();
        console.error("Error adding outward gate pass:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This outward number already exists for the selected company and financial year."
            });
        }
        res.status(500).json({ message: "Failed to create outward gate pass.", error: error.message });
    } finally {
        conn.release();
    }
};

// ======================================================
// Update Outward Gate Pass Main
// ======================================================
exports.updateOutwardGatePassMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            department_id,
            financialyear_id,
            outward_no,
            outward_date,
            account_code,
            vehicle_no,
            vehicle_type,
            driver_name,
            driver_phone_no,
            contract_no,
            production_no,
            freight,
            remarks,
            performed_by,
            system_name_ip
        } = req.body;

        const freightValue = parseFloat(freight) || 0;

        const [existingMain] = await db.query(
            `SELECT id FROM OutwardGatePassMain WHERE id = ?`,
            [id]
        );
        if (existingMain.length === 0) {
            return res.status(404).json({ message: "Outward gate pass not found." });
        }

        if (!company_id || !department_id || !financialyear_id || !outward_no || !outward_date ||
            !account_code || !vehicle_no) {
            return res.status(400).json({
                message: "Company, department, financial year, outward number, outward date, account, and vehicle no are all required."
            });
        }

        if (!String(outward_no).trim()) {
            return res.status(400).json({ message: "Outward number cannot be empty." });
        }
        if (!String(vehicle_no).trim()) {
            return res.status(400).json({ message: "Vehicle number cannot be empty." });
        }

        const [departmentCheck] = await db.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [accountCheck] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [account_code, company_id]
        );
        if (accountCheck.length === 0) {
            return res.status(400).json({ message: "Invalid account code for this company." });
        }

        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        if (contract_no) {
            const [contractCheck] = await db.query(
                `SELECT id FROM SalesContractMain WHERE contract_no = ? AND company_id = ?`,
                [contract_no, company_id]
            );
            if (contractCheck.length === 0) {
                return res.status(400).json({ message: "Invalid contract number for this company." });
            }
        }

        if (production_no) {
            const [productionCheck] = await db.query(
                `SELECT id FROM ProductionMain WHERE production_no = ? AND company_id = ?`,
                [production_no, company_id]
            );
            if (productionCheck.length === 0) {
                return res.status(400).json({ message: "Invalid production number for this company." });
            }
        }

        await db.query(
            `
            UPDATE OutwardGatePassMain
            SET
                company_id = ?,
                department_id = ?,
                financialyear_id = ?,
                outward_no = ?,
                outward_date = ?,
                account_code = ?,
                vehicle_no = ?,
                vehicle_type = ?,
                driver_name = ?,
                driver_phone_no = ?,
                contract_no = ?,
                production_no = ?,
                freight = ?,
                remarks = ?
            WHERE id = ?
            `,
            [
                company_id,
                department_id,
                financialyear_id,
                outward_no.trim(),
                outward_date,
                account_code,
                vehicle_no.trim(),
                vehicle_type ? vehicle_type.trim() : null,
                driver_name ? driver_name.trim() : null,
                driver_phone_no ? driver_phone_no.trim() : null,
                contract_no || null,
                production_no || null,
                freightValue,
                remarks ? remarks.trim() : null,
                id
            ]
        );

        await logActivity({
            document_type: "OutwardGatePassMain",
            document_no: outward_no.trim(),
            status: "Edit",
            remarks: `Outward gate pass updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Outward gate pass updated successfully." });
    } catch (error) {
        console.error("Error updating outward gate pass:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This outward number already exists for the selected company and financial year."
            });
        }

        res.status(500).json({
            message: "Failed to update outward gate pass.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Outward Gate Pass Main
// ======================================================
exports.deleteOutwardGatePassMain = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [mainRows] = await db.query(
            `SELECT outward_no FROM OutwardGatePassMain WHERE id = ?`,
            [id]
        );
        if (mainRows.length === 0) {
            return res.status(404).json({ message: "Outward gate pass not found." });
        }
        const mainRow = mainRows[0];

        const [detailCheck] = await db.query(
            `SELECT COUNT(*) as count FROM OutwardGatePassDetail WHERE outwardgatepassmain_id = ?`,
            [id]
        );
        if (detailCheck[0].count > 0) {
            return res.status(409).json({
                message: "Cannot delete outward gate pass as it has associated details. Please delete the details first."
            });
        }

        const [result] = await db.query(`DELETE FROM OutwardGatePassMain WHERE id = ?`, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Outward gate pass not found." });
        }

        await logActivity({
            document_type: "OutwardGatePassMain",
            document_no: mainRow.outward_no,
            status: "Delete",
            remarks: `Outward gate pass deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Outward gate pass deleted successfully." });
    } catch (error) {
        console.error("Error deleting outward gate pass:", error);
        res.status(500).json({ message: "Failed to delete outward gate pass.", error: error.message });
    }
};

// ======================================================
// Get Outward Gate Pass with Details
// ======================================================
exports.getOutwardGatePassWithDetails = async (req, res) => {
    try {
        const { id } = req.params;

        const [mainRows] = await db.query(
            `
            SELECT
                ogm.id,
                ogm.company_id,
                c.company_name,

                ogm.department_id,
                d.department_name,

                ogm.financialyear_id,
                fy.year_detail,

                ogm.outward_no,
                ogm.outward_date,

                ogm.account_code,
                coa.account_name,

                ogm.vehicle_no,
                ogm.vehicle_type,
                ogm.driver_name,
                ogm.driver_phone_no,

                ogm.contract_no,
                ogm.production_no,

                ogm.freight,
                ogm.remarks,

                ogm.created_by,
                ogm.add_date,
                ogm.update_date

            FROM OutwardGatePassMain ogm

            INNER JOIN CompanyName c
                ON ogm.company_id = c.id

            INNER JOIN Department d
                ON ogm.department_id = d.id

            INNER JOIN FinancialYear fy
                ON ogm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON ogm.account_code = coa.code AND coa.company_id = ogm.company_id

            WHERE ogm.id = ?
            `,
            [id]
        );

        if (mainRows.length === 0) {
            return res.status(404).json({ message: "Outward gate pass not found." });
        }

        const [detailRows] = await db.query(
            `
            SELECT
                ogd.id,
                ogd.company_id,
                ogd.department_id,
                ogd.outwardgatepassmain_id,
                ogd.financialyear_id,
                ogd.Item_code,
                item.details AS item_name,
                ogd.entry_no,
                ogd.pieces,
                ogd.gross_weight,
                ogd.tear_weight,
                ogd.net_weight,
                ogd.amount,
                ogd.gst_percent,
                ogd.gst_amount,
                ogd.further_percent,
                ogd.further_amount,
                ogd.other_tax,
                ogd.total,
                ogd.add_date,
                ogd.update_date
            FROM OutwardGatePassDetail ogd
            INNER JOIN ItemDetail item
                ON ogd.Item_code = item.code AND ogd.company_id = item.company_id
            WHERE ogd.outwardgatepassmain_id = ?
            ORDER BY ogd.entry_no ASC
            `,
            [id]
        );

        res.status(200).json({
            ...mainRows[0],
            details: detailRows
        });
    } catch (error) {
        console.error("Error fetching outward gate pass with details:", error);
        res.status(500).json({
            message: "Failed to fetch outward gate pass with details.",
            error: error.message
        });
    }
};