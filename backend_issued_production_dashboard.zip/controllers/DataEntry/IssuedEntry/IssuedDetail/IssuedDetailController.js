// controllers/DataEntry/IssuedEntry/IssuedDetail/IssuedDetailController.js
const db = require("../../../../config/db");
const {
    getAvailablePurchaseLots,
    allocateFifo,
    revertPurchaseStockIfNeeded,
    syncPurchaseDetailStockFlag
} = require("../IssuedStockAllocation");
const { logActivity } = require("../../../../utils/ActivityLogger");

exports.getAvailableStockForIssue = async (req, res) => {
    try {
        const { company_id, item_code } = req.query;
        const lots = await getAvailablePurchaseLots(company_id, item_code);
        res.status(200).json(lots);
    } catch (error) {
        res.status(500).json({ message: "Failed to fetch stock lots.", error: error.message });
    }
};

// ======================================================
// Get All Issued Details
// ======================================================
exports.getAllIssuedDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                idt.id, idt.company_id, c.company_name,
                idt.department_id, d.department_name,
                idt.issuedmain_id, im.issued_no,
                idt.financialyear_id, fy.year_detail,
                idt.Item_code, item.details AS item_name,
                idt.entry_no, idt.stocks, idt.grn_no, idt.purchase_entry_no,
                idt.pieces, idt.net_weight,
                idt.add_date, idt.update_date
            FROM IssuedDetail idt
            INNER JOIN CompanyName c ON idt.company_id = c.id
            INNER JOIN Department d ON idt.department_id = d.id
            INNER JOIN IssuedMain im ON idt.issuedmain_id = im.id
            INNER JOIN FinancialYear fy ON idt.financialyear_id = fy.id
            INNER JOIN ItemDetail item ON idt.Item_code = item.code AND idt.company_id = item.company_id
            ORDER BY im.issued_no, idt.entry_no
        `);
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching issued details:", error);
        res.status(500).json({ message: "Failed to fetch issued details.", error: error.message });
    }
};

// ======================================================
// Get Issued Details By Issued Main ID
// ======================================================
exports.getIssuedDetailsByIssuedMain = async (req, res) => {
    try {
        const { issuedmain_id } = req.params;
        const [rows] = await db.query(
            `
            SELECT
                idt.id, idt.company_id, c.company_name,
                idt.department_id, d.department_name,
                idt.issuedmain_id, im.issued_no,
                idt.financialyear_id, fy.year_detail,
                idt.Item_code, item.details AS item_name,
                idt.entry_no, idt.stocks, idt.grn_no, idt.purchase_entry_no,
                idt.pieces, idt.net_weight,
                idt.add_date, idt.update_date
            FROM IssuedDetail idt
            INNER JOIN CompanyName c ON idt.company_id = c.id
            INNER JOIN Department d ON idt.department_id = d.id
            INNER JOIN IssuedMain im ON idt.issuedmain_id = im.id
            INNER JOIN FinancialYear fy ON idt.financialyear_id = fy.id
            INNER JOIN ItemDetail item ON idt.Item_code = item.code AND idt.company_id = item.company_id
            WHERE idt.issuedmain_id = ?
            ORDER BY idt.entry_no ASC
            `,
            [issuedmain_id]
        );
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching issued details by main:", error);
        res.status(500).json({ message: "Failed to fetch issued details.", error: error.message });
    }
};

// ======================================================
// Get Issued Detail By ID
// ======================================================
exports.getIssuedDetailById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query(
            `
            SELECT
                idt.id, idt.company_id, c.company_name,
                idt.department_id, d.department_name,
                idt.issuedmain_id, im.issued_no,
                idt.financialyear_id, fy.year_detail,
                idt.Item_code, item.details AS item_name,
                idt.entry_no, idt.stocks, idt.grn_no, idt.purchase_entry_no,
                idt.pieces, idt.net_weight,
                idt.add_date, idt.update_date
            FROM IssuedDetail idt
            INNER JOIN CompanyName c ON idt.company_id = c.id
            INNER JOIN Department d ON idt.department_id = d.id
            INNER JOIN IssuedMain im ON idt.issuedmain_id = im.id
            INNER JOIN FinancialYear fy ON idt.financialyear_id = fy.id
            INNER JOIN ItemDetail item ON idt.Item_code = item.code AND idt.company_id = item.company_id
            WHERE idt.id = ?
            `,
            [id]
        );
        if (rows.length === 0) return res.status(404).json({ message: "Issued detail not found." });
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching issued detail:", error);
        res.status(500).json({ message: "Failed to fetch issued detail.", error: error.message });
    }
};

// ======================================================
// Add Issued Detail (FIFO-allocates against available purchase stock)
// ======================================================
exports.addIssuedDetail = async (req, res) => {
    try {
        const {
            company_id, issuedmain_id, Item_code,
            pieces, net_weight, performed_by, system_name_ip
        } = req.body;

        // department_id and financialyear_id are NOT taken from req.body -
        // they're always derived from the parent IssuedMain row below, so a
        // detail line can never drift out of sync with its header.
        if (!company_id || !issuedmain_id || !Item_code) {
            return res.status(400).json({ message: "Company, Issued Main, and Item Code are required." });
        }
        if (!net_weight || parseFloat(net_weight) <= 0) {
            return res.status(400).json({ message: "Net weight must be greater than zero." });
        }
        if (String(Item_code).length > 8) {
            return res.status(400).json({ message: "Item code cannot be more than 8 characters." });
        }

        const netWeightValue = parseFloat(net_weight) || 0;
        const piecesValue = parseInt(pieces) || 0;

        const lots = await getAvailablePurchaseLots(company_id, Item_code);
        let allocations;
        try {
            allocations = allocateFifo(lots, netWeightValue, piecesValue);
        } catch (e) {
            if (e.code === "INSUFFICIENT_STOCK") {
                return res.status(400).json({ message: e.message });
            }
            throw e;
        }

        const [mainCheck] = await db.query(
            `SELECT id, department_id, financialyear_id, issued_no FROM IssuedMain WHERE id = ? AND company_id = ?`,
            [issuedmain_id, company_id]
        );
        if (mainCheck.length === 0) {
            return res.status(400).json({ message: "Invalid issued entry for this company." });
        }
        const { department_id, financialyear_id, issued_no } = mainCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({ message: "Invalid item code for this company." });
        }

        const [existing] = await db.query(
            `SELECT COALESCE(MAX(entry_no),0) AS maxNo FROM IssuedDetail WHERE issuedmain_id = ?`,
            [issuedmain_id]
        );
        let nextEntryNo = existing[0].maxNo + 1;

        const insertedIds = [];
        for (let i = 0; i < allocations.length; i++) {
            const alloc = allocations[i];
            const thisEntryNo = nextEntryNo;

            const [result] = await db.query(
                `INSERT INTO IssuedDetail
                    (company_id, department_id, issuedmain_id, financialyear_id, Item_code, entry_no,
                     source_type, source_detail_id, grn_no, purchase_entry_no, pieces, net_weight)
                 VALUES (?,?,?,?,?,?, ?,?,?,?, ?,?)`,
                [
                    company_id, department_id, issuedmain_id, financialyear_id, Item_code, nextEntryNo++,
                    alloc.source_type, alloc.source_detail_id, alloc.grn_no, alloc.purchase_entry_no,
                    alloc.pieces, alloc.net_weight
                ]
            );
            insertedIds.push(result.insertId);

            await logActivity({
                document_type: "IssuedDetail",
                document_no: `${issued_no}-${thisEntryNo}`,
                status: "New",
                remarks: allocations.length > 1
                    ? `Issued line added (Item: ${Item_code}, lot ${i + 1}/${allocations.length})`
                    : `Issued line added (Item: ${Item_code})`,
                username: performed_by || "Unknown",
                system_name_ip
            });

            // FIXED: was referencing an undefined `existingRow` (copy-pasted
            // from updateIssuedDetail) and calling both 'out' then
            // 'available' back-to-back. Use this allocation's own lot id and
            // let the shared helper decide the correct flag (it accounts
            // for both Issued consumption AND Purchase Return consumption).
            await syncPurchaseDetailStockFlag(alloc.source_detail_id);
        }

        res.status(201).json({
            message: allocations.length > 1
                ? `Issued entry split across ${allocations.length} purchase lots and saved.`
                : "Issued detail added successfully.",
            ids: insertedIds,
            entriesCreated: allocations.length
        });
    } catch (error) {
        console.error("Error adding issued detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({ message: "Entry number already exists for this issued entry." });
        }
        res.status(500).json({ message: "Failed to add issued detail.", error: error.message });
    }
};

// ======================================================
// Update Issued Detail
// ======================================================
// NOTE: updates a single existing row in place (same simplification used by
// Sales Detail's update) - it does not re-run FIFO splitting. If the
// requested net_weight exceeds what's left on this row's own source lot,
// the update is rejected; reduce it or delete + re-add instead.
exports.updateIssuedDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id, issuedmain_id, Item_code, entry_no,
            pieces, net_weight, performed_by, system_name_ip
        } = req.body;

        const [existingRow] = await db.query(
            `SELECT issuedmain_id, source_detail_id, net_weight AS old_net_weight, stocks
             FROM IssuedDetail WHERE id = ?`,
            [id]
        );
        if (existingRow.length === 0) return res.status(404).json({ message: "Issued detail not found." });

        if (existingRow[0].stocks === 'out') {
            return res.status(409).json({
                message: "This issued stock has already been consumed downstream and cannot be edited. Delete the downstream entry first."
            });
        }

        if (!company_id || !issuedmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({ message: "Company, Issued Main, Item Code, and Entry No are required." });
        }
        if (entry_no <= 0) {
            return res.status(400).json({ message: "Entry number must be a positive integer." });
        }
        if (String(Item_code).length > 8) {
            return res.status(400).json({ message: "Item code cannot be more than 8 characters." });
        }

        const piecesValue = parseInt(pieces) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        if (piecesValue < 0) return res.status(400).json({ message: "Pieces cannot be negative." });
        if (netWeightValue <= 0) return res.status(400).json({ message: "Net weight must be greater than zero." });

        // Confirm the requested net weight still fits this row's own source
        // purchase lot (lot total minus whatever OTHER Issued rows draw
        // from it - Purchase Return consumption is checked separately
        // below via the shared sync helper, since a return doesn't block
        // an Issued edit the way another Issued row does; it just narrows
        // how much room is left overall).
        const [[lotRow]] = await db.query(
            `SELECT net_weight FROM PurchaseDetail WHERE id = ?`,
            [existingRow[0].source_detail_id]
        );
        const [[{ consumedElsewhere }]] = await db.query(
            `SELECT COALESCE(SUM(net_weight),0) AS consumedElsewhere
             FROM IssuedDetail WHERE source_type = 'purchase' AND source_detail_id = ? AND id != ?`,
            [existingRow[0].source_detail_id, id]
        );
        const [[{ returnedOnLot }]] = await db.query(
            `SELECT COALESCE(SUM(net_weight),0) AS returnedOnLot
             FROM PurchaseReturnDetail WHERE source_detail_id = ? AND entry = 'user'`,
            [existingRow[0].source_detail_id]
        );
        const availableForThisRow = Number(lotRow.net_weight) - Number(consumedElsewhere) - Number(returnedOnLot);
        if (netWeightValue > availableForThisRow + 0.0001) {
            return res.status(400).json({
                message: `Requested net weight exceeds what's left on this row's source lot (${availableForThisRow}).`
            });
        }

        const [mainCheck] = await db.query(
            `SELECT id, department_id, financialyear_id, issued_no FROM IssuedMain WHERE id = ? AND company_id = ?`,
            [issuedmain_id, company_id]
        );
        if (mainCheck.length === 0) return res.status(400).json({ message: "Invalid issued entry for this company." });
        const { department_id, financialyear_id, issued_no } = mainCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) return res.status(400).json({ message: "Invalid item code for this company." });

        await db.query(
            `
            UPDATE IssuedDetail
            SET company_id = ?, department_id = ?, issuedmain_id = ?, financialyear_id = ?,
                Item_code = ?, entry_no = ?, pieces = ?, net_weight = ?
            WHERE id = ?
            `,
            [company_id, department_id, issuedmain_id, financialyear_id, Item_code, entry_no,
                piecesValue, netWeightValue, id]
        );

        // FIXED: was hand-computing the flag from Issued rows only, which
        // ignores Purchase Return consumption on the same lot. Delegate to
        // the shared helper so the flag always reflects issued + returned.
        await syncPurchaseDetailStockFlag(existingRow[0].source_detail_id);

        await logActivity({
            document_type: "IssuedDetail",
            document_no: `${issued_no}-${entry_no}`,
            status: "Edit",
            remarks: `Issued line updated (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Issued detail updated successfully." });
    } catch (error) {
        console.error("Error updating issued detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({ message: "Entry number already exists for this issued entry." });
        }
        res.status(500).json({ message: "Failed to update issued detail.", error: error.message });
    }
};

// ======================================================
// Delete Issued Detail
// ======================================================
exports.deleteIssuedDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [rows] = await db.query(
            `SELECT idt.source_detail_id, idt.entry_no, idt.Item_code, idt.stocks, im.issued_no
             FROM IssuedDetail idt
             INNER JOIN IssuedMain im ON idt.issuedmain_id = im.id
             WHERE idt.id = ?`,
            [id]
        );
        if (rows.length === 0) return res.status(404).json({ message: "Issued detail not found." });
        const { source_detail_id, entry_no, Item_code, stocks, issued_no } = rows[0];

        if (stocks === 'out') {
            return res.status(409).json({
                message: "This issued stock has already been consumed downstream (e.g. by Production). Delete that entry first."
            });
        }

        const [result] = await db.query(`DELETE FROM IssuedDetail WHERE id = ?`, [id]);
        if (result.affectedRows === 0) return res.status(404).json({ message: "Issued detail not found." });

        await logActivity({
            document_type: "IssuedDetail",
            document_no: `${issued_no}-${entry_no}`,
            status: "Delete",
            remarks: `Issued line deleted (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        // Give the consumed purchase stock back if nothing else (Issued or
        // Purchase Return) still draws from it.
        await revertPurchaseStockIfNeeded(source_detail_id);

        res.status(200).json({ message: "Issued detail deleted successfully." });
    } catch (error) {
        console.error("Error deleting issued detail:", error);
        res.status(500).json({ message: "Failed to delete issued detail.", error: error.message });
    }
};