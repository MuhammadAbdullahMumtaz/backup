// controllers/DataEntry/IssuedEntry/IssuedMain/IssuedMainController.js
const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Issued Mains
// ======================================================
exports.getAllIssuedMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                im.id,
                im.company_id,
                c.company_name,

                im.department_id,
                d.department_name,

                im.financialyear_id,
                fy.year_detail,

                im.issued_no,
                im.issued_date,
                im.remarks,

                im.created_by,
                im.add_date,
                im.update_date

            FROM IssuedMain im
            INNER JOIN CompanyName c ON im.company_id = c.id
            INNER JOIN Department d ON im.department_id = d.id
            INNER JOIN FinancialYear fy ON im.financialyear_id = fy.id
            ORDER BY im.issued_no ASC
        `);
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching issued entries:", error);
        res.status(500).json({ message: "Failed to fetch issued entries.", error: error.message });
    }
};

// ======================================================
// Get Next Issued Number (preview only - not reserved)
// ======================================================
exports.getNextIssuedNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.params;
        if (!company_id || !financialyear_id) {
            return res.status(400).json({ message: "Company ID and Financial Year ID are required." });
        }
        const [rows] = await db.query(
            `SELECT last_no FROM IssuedSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const lastNo = rows.length > 0 ? rows[0].last_no : 0;
        res.status(200).json({ next_issued_number: lastNo + 1 });
    } catch (error) {
        console.error("Error generating next issued number:", error);
        res.status(500).json({ message: "Failed to generate next issued number.", error: error.message });
    }
};

// ======================================================
// Get Issued Main By ID
// ======================================================
exports.getIssuedMainById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query(
            `
            SELECT
                im.id, im.company_id, c.company_name,
                im.department_id, d.department_name,
                im.financialyear_id, fy.year_detail,
                im.issued_no, im.issued_date, im.remarks,
                im.created_by, im.add_date, im.update_date
            FROM IssuedMain im
            INNER JOIN CompanyName c ON im.company_id = c.id
            INNER JOIN Department d ON im.department_id = d.id
            INNER JOIN FinancialYear fy ON im.financialyear_id = fy.id
            WHERE im.id = ?
            `,
            [id]
        );
        if (rows.length === 0) return res.status(404).json({ message: "Issued entry not found." });
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching issued entry:", error);
        res.status(500).json({ message: "Failed to fetch issued entry.", error: error.message });
    }
};

// ======================================================
// Add Issued Main
// ======================================================
exports.addIssuedMain = async (req, res) => {
    const {
        company_id,
        department_id,
        financialyear_id,
        issued_date,
        remarks,
        performed_by,
        system_name_ip
    } = req.body;

    // issued_no is not accepted from the client - it's generated atomically
    // below via IssuedSequence.
    if (!company_id || !department_id || !financialyear_id || !issued_date) {
        return res.status(400).json({
            message: "Company, department, financial year, and issued date are all required."
        });
    }

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        const [departmentCheck] = await conn.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [financialYearCheck] = await conn.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        await conn.query(
            `INSERT INTO IssuedSequence (company_id, financialyear_id, last_no)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE last_no = last_no + 1`,
            [company_id, financialyear_id]
        );
        const [seqRow] = await conn.query(
            `SELECT last_no FROM IssuedSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const issuedNo = String(seqRow[0].last_no);

        const [result] = await conn.query(
            `INSERT INTO IssuedMain
                (company_id, department_id, financialyear_id, issued_no, issued_date, remarks, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [company_id, department_id, financialyear_id, issuedNo, issued_date,
                remarks ? remarks.trim() : null, performed_by || 'Unknown']
        );

        await conn.commit();
        await logActivity({
            document_type: "IssuedMain",
            document_no: issuedNo,
            status: "New",
            remarks: `Issued entry created (Department: ${department_id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            message: "Issued entry created successfully.",
            id: result.insertId,
            issued_no: issuedNo
        });
    } catch (error) {
        await conn.rollback();
        console.error("Error adding issued entry:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This issued number already exists for the selected company and financial year."
            });
        }
        res.status(500).json({ message: "Failed to create issued entry.", error: error.message });
    } finally {
        conn.release();
    }
};

// ======================================================
// Update Issued Main
// ======================================================
exports.updateIssuedMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            department_id,
            financialyear_id,
            issued_date,
            remarks,
            performed_by,
            system_name_ip
        } = req.body;

        const [existing] = await db.query(`SELECT issued_no FROM IssuedMain WHERE id = ?`, [id]);
        if (existing.length === 0) return res.status(404).json({ message: "Issued entry not found." });

        if (!company_id || !department_id || !financialyear_id || !issued_date) {
            return res.status(400).json({
                message: "Company, department, financial year, and issued date are all required."
            });
        }

        const [departmentCheck] = await db.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        await db.query(
            `
            UPDATE IssuedMain
            SET company_id = ?, department_id = ?, financialyear_id = ?, issued_date = ?, remarks = ?
            WHERE id = ?
            `,
            [company_id, department_id, financialyear_id, issued_date,
                remarks ? remarks.trim() : null, id]
        );

        await logActivity({
            document_type: "IssuedMain",
            document_no: existing[0].issued_no,
            status: "Edit",
            remarks: `Issued entry updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Issued entry updated successfully." });
    } catch (error) {
        console.error("Error updating issued entry:", error);
        res.status(500).json({ message: "Failed to update issued entry.", error: error.message });
    }
};

// ======================================================
// Delete Issued Main
// ======================================================
exports.deleteIssuedMain = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [mainRows] = await db.query(`SELECT issued_no FROM IssuedMain WHERE id = ?`, [id]);
        if (mainRows.length === 0) return res.status(404).json({ message: "Issued entry not found." });

        const [detailCheck] = await db.query(
            `SELECT COUNT(*) as count FROM IssuedDetail WHERE issuedmain_id = ?`,
            [id]
        );
        if (detailCheck[0].count > 0) {
            return res.status(409).json({
                message: "Cannot delete issued entry as it has associated details. Please delete the details first."
            });
        }

        const [result] = await db.query(`DELETE FROM IssuedMain WHERE id = ?`, [id]);
        if (result.affectedRows === 0) return res.status(404).json({ message: "Issued entry not found." });

        await logActivity({
            document_type: "IssuedMain",
            document_no: mainRows[0].issued_no,
            status: "Delete",
            remarks: `Issued entry deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Issued entry deleted successfully." });
    } catch (error) {
        console.error("Error deleting issued entry:", error);
        res.status(500).json({ message: "Failed to delete issued entry.", error: error.message });
    }
};

// ======================================================
// Get Issued with Details
// ======================================================
exports.getIssuedWithDetails = async (req, res) => {
    try {
        const { id } = req.params;
        const [mainRows] = await db.query(
            `
            SELECT
                im.id, im.company_id, c.company_name,
                im.department_id, d.department_name,
                im.financialyear_id, fy.year_detail,
                im.issued_no, im.issued_date, im.remarks,
                im.created_by, im.add_date, im.update_date
            FROM IssuedMain im
            INNER JOIN CompanyName c ON im.company_id = c.id
            INNER JOIN Department d ON im.department_id = d.id
            INNER JOIN FinancialYear fy ON im.financialyear_id = fy.id
            WHERE im.id = ?
            `,
            [id]
        );
        if (mainRows.length === 0) return res.status(404).json({ message: "Issued entry not found." });

        const [detailRows] = await db.query(
            `
            SELECT
                idt.id, idt.company_id, idt.department_id, idt.issuedmain_id,
                idt.financialyear_id, idt.Item_code, item.details AS item_name,
                idt.entry_no, idt.stocks, idt.source_type, idt.source_detail_id,
                idt.grn_no, idt.purchase_entry_no,
                idt.pieces, idt.net_weight,
                idt.add_date, idt.update_date
            FROM IssuedDetail idt
            INNER JOIN ItemDetail item ON idt.Item_code = item.code AND idt.company_id = item.company_id
            WHERE idt.issuedmain_id = ?
            ORDER BY idt.entry_no ASC
            `,
            [id]
        );

        res.status(200).json({ ...mainRows[0], details: detailRows });
    } catch (error) {
        console.error("Error fetching issued entry with details:", error);
        res.status(500).json({ message: "Failed to fetch issued entry with details.", error: error.message });
    }
};