const db = require("../../../config/db");

// ======================================================
// Consumption helpers
// ======================================================

// Total net_weight already drawn from a purchase lot via Issued entries.
async function getIssuedConsumedWeight(purchase_detail_id) {
    const [[{ consumed }]] = await db.query(
        `SELECT COALESCE(SUM(net_weight),0) AS consumed
         FROM IssuedDetail
         WHERE source_type = 'purchase' AND source_detail_id = ?`,
        [purchase_detail_id]
    );
    return Number(consumed);
}

// Total net_weight already sent back to the supplier via Purchase Return
// entries against a purchase lot. Only 'user' rows count - 'auto' rows are
// GL-sync mirrors, not physical stock movements.
async function getReturnedWeight(purchase_detail_id) {
    const [[{ returned }]] = await db.query(
        `SELECT COALESCE(SUM(net_weight),0) AS returned
         FROM PurchaseReturnDetail
         WHERE source_detail_id = ? AND entry = 'user'`,
        [purchase_detail_id]
    );
    return Number(returned);
}

// ======================================================
// FIFO-ordered purchase lots for an item with their REMAINING net_weight,
// i.e. lot net_weight minus whatever has already been issued out AND
// minus whatever has already been sent back via a purchase return.
// Mirrors StockAllocation.js's getAvailableLots, but scoped to
// PurchaseDetail only - Issued never draws from sales returns.
// ======================================================
async function getAvailablePurchaseLots(company_id, Item_code) {
    const [lots] = await db.query(
        `SELECT pd.id AS source_detail_id, pm.grn_no AS label, pd.entry_no,
                pd.pieces, pd.net_weight, pm.grn_date AS lot_date, pd.stocks
         FROM PurchaseDetail pd
         JOIN PurchaseMain pm ON pd.purchasemain_id = pm.id
         WHERE pd.company_id = ? AND pd.Item_code = ?
           AND pd.stocks = 'available'
           AND pd.entry = 'user'
         ORDER BY pm.grn_date ASC, pd.id ASC`,
        [company_id, Item_code]
    );

    for (const lot of lots) {
        const consumed = await getIssuedConsumedWeight(lot.source_detail_id);
        const returned = await getReturnedWeight(lot.source_detail_id);
        lot.remaining_net_weight = Math.max(0, Number(lot.net_weight) - consumed - returned);
    }

    return lots.filter((l) => l.remaining_net_weight > 0);
}

// Same FIFO-split logic as StockAllocation.js's allocateFifo - splits the
// requested net_weight across lots in order, then distributes pieces
// proportionally to each lot's weight share.
function allocateFifo(lots, requestedNetWeight, requestedPieces) {
    let remainingWeight = Number(requestedNetWeight);
    const allocations = [];

    for (const lot of lots) {
        if (remainingWeight <= 0) break;
        const take = Math.min(lot.remaining_net_weight, remainingWeight);
        if (take <= 0) continue;

        allocations.push({
            source_type: 'purchase',
            source_detail_id: lot.source_detail_id,
            grn_no: lot.label,
            purchase_entry_no: lot.entry_no,
            net_weight: take,
            will_exhaust_lot: take >= lot.remaining_net_weight,
        });

        remainingWeight -= take;
    }

    if (remainingWeight > 0.0001) {
        const err = new Error("Insufficient purchase stock for this item.");
        err.code = "INSUFFICIENT_STOCK";
        throw err;
    }

    const piecesTotal = Number(requestedPieces) || 0;
    let piecesLeft = piecesTotal;
    allocations.forEach((alloc, i) => {
        const isLast = i === allocations.length - 1;
        const shareRatio = alloc.net_weight / Number(requestedNetWeight);
        const piecesForRow = isLast ? piecesLeft : Math.round(piecesTotal * shareRatio);
        alloc.pieces = piecesForRow;
        piecesLeft -= piecesForRow;
    });

    return allocations;
}

// ======================================================
// Single source of truth for PurchaseDetail.stocks.
// A lot flips to 'out' once (issued + returned) >= its original
// net_weight, and back to 'available' otherwise. Call this after ANY
// insert/update/delete on IssuedDetail or PurchaseReturnDetail that
// references a source_detail_id, instead of setting the flag by hand.
// ======================================================
async function syncPurchaseDetailStockFlag(source_detail_id) {
    if (!source_detail_id) return;

    const [[lot]] = await db.query(
        `SELECT net_weight FROM PurchaseDetail WHERE id = ?`,
        [source_detail_id]
    );
    if (!lot) return;

    const issued = await getIssuedConsumedWeight(source_detail_id);
    const returned = await getReturnedWeight(source_detail_id);
    const newStatus = (issued + returned) >= Number(lot.net_weight) ? 'out' : 'available';

    await db.query(`UPDATE PurchaseDetail SET stocks = ? WHERE id = ?`, [newStatus, source_detail_id]);
}

// Kept for backward compatibility with existing callers
// (IssuedDetailController.deleteIssuedDetail) that already import this name.
async function revertPurchaseStockIfNeeded(source_detail_id) {
    await syncPurchaseDetailStockFlag(source_detail_id);
}

module.exports = {
    getAvailablePurchaseLots,
    allocateFifo,
    revertPurchaseStockIfNeeded,
    syncPurchaseDetailStockFlag,
    getIssuedConsumedWeight,
    getReturnedWeight,
};