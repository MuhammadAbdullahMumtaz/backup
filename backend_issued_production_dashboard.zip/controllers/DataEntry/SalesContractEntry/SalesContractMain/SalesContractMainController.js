const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Sales Contract Mains
// ======================================================
exports.getAllSalesContractMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                scm.id, scm.company_id, c.company_name,
                scm.financialyear_id, fy.year_detail,
                scm.contract_no, scm.contract_date,
                scm.account_code, coa.account_name,
                scm.delivery_date, scm.remarks,
                scm.created_by, scm.add_date, scm.update_date
            FROM SalesContractMain scm
            INNER JOIN CompanyName c ON scm.company_id = c.id
            INNER JOIN FinancialYear fy ON scm.financialyear_id = fy.id
            INNER JOIN ChartOfAccount coa ON scm.account_code = coa.code AND scm.company_id = coa.company_id
            ORDER BY scm.contract_no ASC
        `);
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sales contracts:", error);
        res.status(500).json({ message: "Failed to fetch sales contracts.", error: error.message });
    }
};

// ======================================================
// Get Next Contract Number (preview only - not reserved)
// ======================================================
exports.getNextContractNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.params;
        if (!company_id || !financialyear_id) {
            return res.status(400).json({ message: "Company ID and Financial Year ID are required." });
        }
        const [rows] = await db.query(
            `SELECT last_no FROM SalesContractSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const lastNo = rows.length > 0 ? rows[0].last_no : 0;
        res.status(200).json({ next_contract_number: lastNo + 1 });
    } catch (error) {
        console.error("Error generating next contract number:", error);
        res.status(500).json({ message: "Failed to generate next contract number.", error: error.message });
    }
};

// ======================================================
// Get Sales Contract Main By ID
// ======================================================
exports.getSalesContractMainById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query(
            `
            SELECT
                scm.id, scm.company_id, c.company_name,
                scm.financialyear_id, fy.year_detail,
                scm.contract_no, scm.contract_date,
                scm.account_code, coa.account_name,
                scm.delivery_date, scm.remarks,
                scm.created_by, scm.add_date, scm.update_date
            FROM SalesContractMain scm
            INNER JOIN CompanyName c ON scm.company_id = c.id
            INNER JOIN FinancialYear fy ON scm.financialyear_id = fy.id
            INNER JOIN ChartOfAccount coa ON scm.account_code = coa.code AND scm.company_id = coa.company_id
            WHERE scm.id = ?
            `,
            [id]
        );
        if (rows.length === 0) return res.status(404).json({ message: "Sales contract not found." });
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching sales contract:", error);
        res.status(500).json({ message: "Failed to fetch sales contract.", error: error.message });
    }
};

// ======================================================
// Add Sales Contract Main
// ======================================================
exports.addSalesContractMain = async (req, res) => {
    const {
        company_id, financialyear_id, contract_date,
        account_code, delivery_date, remarks,
        performed_by, system_name_ip
    } = req.body;

    // contract_no is not accepted from the client - it's generated
    // atomically below via SalesContractSequence.
    if (!company_id || !financialyear_id || !contract_date || !account_code) {
        return res.status(400).json({
            message: "Company, financial year, contract date, and customer are all required."
        });
    }

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        const [financialYearCheck] = await conn.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        const [accountCheck] = await conn.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [account_code, company_id]
        );
        if (accountCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid customer account for this company." });
        }

        await conn.query(
            `INSERT INTO SalesContractSequence (company_id, financialyear_id, last_no)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE last_no = last_no + 1`,
            [company_id, financialyear_id]
        );
        const [seqRow] = await conn.query(
            `SELECT last_no FROM SalesContractSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const contractNo = String(seqRow[0].last_no);

        const [result] = await conn.query(
            `INSERT INTO SalesContractMain
                (company_id, financialyear_id, contract_no, contract_date, account_code, delivery_date, remarks, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [company_id, financialyear_id, contractNo, contract_date, account_code,
                delivery_date || null, remarks ? remarks.trim() : null, performed_by || 'Unknown']
        );

        await conn.commit();
        await logActivity({
            document_type: "SalesContractMain",
            document_no: contractNo,
            status: "New",
            remarks: `Sales contract created (Customer: ${account_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            message: "Sales contract created successfully.",
            id: result.insertId,
            contract_no: contractNo
        });
    } catch (error) {
        await conn.rollback();
        console.error("Error adding sales contract:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This contract number already exists for the selected company and financial year."
            });
        }
        res.status(500).json({ message: "Failed to create sales contract.", error: error.message });
    } finally {
        conn.release();
    }
};

// ======================================================
// Update Sales Contract Main
// ======================================================
exports.updateSalesContractMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id, financialyear_id, contract_date,
            account_code, delivery_date, remarks,
            performed_by, system_name_ip
        } = req.body;

        const [existing] = await db.query(`SELECT contract_no FROM SalesContractMain WHERE id = ?`, [id]);
        if (existing.length === 0) return res.status(404).json({ message: "Sales contract not found." });

        if (!company_id || !financialyear_id || !contract_date || !account_code) {
            return res.status(400).json({
                message: "Company, financial year, contract date, and customer are all required."
            });
        }

        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        const [accountCheck] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [account_code, company_id]
        );
        if (accountCheck.length === 0) {
            return res.status(400).json({ message: "Invalid customer account for this company." });
        }

        await db.query(
            `
            UPDATE SalesContractMain
            SET company_id = ?, financialyear_id = ?, contract_date = ?, account_code = ?,
                delivery_date = ?, remarks = ?
            WHERE id = ?
            `,
            [company_id, financialyear_id, contract_date, account_code,
                delivery_date || null, remarks ? remarks.trim() : null, id]
        );

        await logActivity({
            document_type: "SalesContractMain",
            document_no: existing[0].contract_no,
            status: "Edit",
            remarks: `Sales contract updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Sales contract updated successfully." });
    } catch (error) {
        console.error("Error updating sales contract:", error);
        res.status(500).json({ message: "Failed to update sales contract.", error: error.message });
    }
};

// ======================================================
// Delete Sales Contract Main
// ======================================================
exports.deleteSalesContractMain = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [mainRows] = await db.query(`SELECT contract_no FROM SalesContractMain WHERE id = ?`, [id]);
        if (mainRows.length === 0) return res.status(404).json({ message: "Sales contract not found." });

        const [detailCheck] = await db.query(
            `SELECT COUNT(*) as count FROM SalesContractDetail WHERE salescontractmain_id = ?`,
            [id]
        );
        if (detailCheck[0].count > 0) {
            return res.status(409).json({
                message: "Cannot delete sales contract as it has associated details. Please delete the details first."
            });
        }

        const [result] = await db.query(`DELETE FROM SalesContractMain WHERE id = ?`, [id]);
        if (result.affectedRows === 0) return res.status(404).json({ message: "Sales contract not found." });

        await logActivity({
            document_type: "SalesContractMain",
            document_no: mainRows[0].contract_no,
            status: "Delete",
            remarks: `Sales contract deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Sales contract deleted successfully." });
    } catch (error) {
        console.error("Error deleting sales contract:", error);
        res.status(500).json({ message: "Failed to delete sales contract.", error: error.message });
    }
};

// ======================================================
// Get Sales Contract with Details
// ======================================================
exports.getSalesContractWithDetails = async (req, res) => {
    try {
        const { id } = req.params;
        const [mainRows] = await db.query(
            `
            SELECT
                scm.id, scm.company_id, c.company_name,
                scm.financialyear_id, fy.year_detail,
                scm.contract_no, scm.contract_date,
                scm.account_code, coa.account_name,
                scm.delivery_date, scm.remarks,
                scm.created_by, scm.add_date, scm.update_date
            FROM SalesContractMain scm
            INNER JOIN CompanyName c ON scm.company_id = c.id
            INNER JOIN FinancialYear fy ON scm.financialyear_id = fy.id
            INNER JOIN ChartOfAccount coa ON scm.account_code = coa.code AND scm.company_id = coa.company_id
            WHERE scm.id = ?
            `,
            [id]
        );
        if (mainRows.length === 0) return res.status(404).json({ message: "Sales contract not found." });

        const [detailRows] = await db.query(
            `
            SELECT
                scd.id, scd.company_id, scd.salescontractmain_id,
                scd.financialyear_id, scd.Item_code, item.details AS item_name,
                scd.entry_no, scd.pieces, scd.net_weight, scd.rate,
                scd.amount, scd.gst_percent, scd.gst_amount,
                scd.further_percent, scd.further_amount, scd.other_tax, scd.total,
                scd.add_date, scd.update_date
            FROM SalesContractDetail scd
            INNER JOIN ItemDetail item ON scd.Item_code = item.code AND scd.company_id = item.company_id
            WHERE scd.salescontractmain_id = ?
            ORDER BY scd.entry_no ASC
            `,
            [id]
        );

        res.status(200).json({ ...mainRows[0], details: detailRows });
    } catch (error) {
        console.error("Error fetching sales contract with details:", error);
        res.status(500).json({ message: "Failed to fetch sales contract with details.", error: error.message });
    }
};