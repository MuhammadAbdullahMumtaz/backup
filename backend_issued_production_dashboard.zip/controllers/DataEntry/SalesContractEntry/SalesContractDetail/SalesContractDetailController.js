const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Sales Contract Details
// ======================================================
exports.getAllSalesContractDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                scd.id, scd.company_id, c.company_name,
                scd.salescontractmain_id, scm.contract_no,
                scd.financialyear_id, fy.year_detail,
                scd.Item_code, item.details AS item_name,
                scd.entry_no, scd.pieces, scd.net_weight, scd.rate,
                scd.amount, scd.gst_percent, scd.gst_amount,
                scd.further_percent, scd.further_amount, scd.other_tax, scd.total,
                scd.add_date, scd.update_date
            FROM SalesContractDetail scd
            INNER JOIN CompanyName c ON scd.company_id = c.id
            INNER JOIN SalesContractMain scm ON scd.salescontractmain_id = scm.id
            INNER JOIN FinancialYear fy ON scd.financialyear_id = fy.id
            INNER JOIN ItemDetail item ON scd.Item_code = item.code AND scd.company_id = item.company_id
            ORDER BY scm.contract_no, scd.entry_no
        `);
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sales contract details:", error);
        res.status(500).json({ message: "Failed to fetch sales contract details.", error: error.message });
    }
};

// ======================================================
// Get Sales Contract Details By Sales Contract Main ID
// ======================================================
exports.getSalesContractDetailsBySalesContractMain = async (req, res) => {
    try {
        const { salescontractmain_id } = req.params;
        const [rows] = await db.query(
            `
            SELECT
                scd.id, scd.company_id, c.company_name,
                scd.salescontractmain_id, scm.contract_no,
                scd.financialyear_id, fy.year_detail,
                scd.Item_code, item.details AS item_name,
                scd.entry_no, scd.pieces, scd.net_weight, scd.rate,
                scd.amount, scd.gst_percent, scd.gst_amount,
                scd.further_percent, scd.further_amount, scd.other_tax, scd.total,
                scd.add_date, scd.update_date
            FROM SalesContractDetail scd
            INNER JOIN CompanyName c ON scd.company_id = c.id
            INNER JOIN SalesContractMain scm ON scd.salescontractmain_id = scm.id
            INNER JOIN FinancialYear fy ON scd.financialyear_id = fy.id
            INNER JOIN ItemDetail item ON scd.Item_code = item.code AND scd.company_id = item.company_id
            WHERE scd.salescontractmain_id = ?
            ORDER BY scd.entry_no ASC
            `,
            [salescontractmain_id]
        );
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sales contract details by main:", error);
        res.status(500).json({ message: "Failed to fetch sales contract details.", error: error.message });
    }
};

// ======================================================
// Get Sales Contract Detail By ID
// ======================================================
exports.getSalesContractDetailById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query(
            `
            SELECT
                scd.id, scd.company_id, c.company_name,
                scd.salescontractmain_id, scm.contract_no,
                scd.financialyear_id, fy.year_detail,
                scd.Item_code, item.details AS item_name,
                scd.entry_no, scd.pieces, scd.net_weight, scd.rate,
                scd.amount, scd.gst_percent, scd.gst_amount,
                scd.further_percent, scd.further_amount, scd.other_tax, scd.total,
                scd.add_date, scd.update_date
            FROM SalesContractDetail scd
            INNER JOIN CompanyName c ON scd.company_id = c.id
            INNER JOIN SalesContractMain scm ON scd.salescontractmain_id = scm.id
            INNER JOIN FinancialYear fy ON scd.financialyear_id = fy.id
            INNER JOIN ItemDetail item ON scd.Item_code = item.code AND scd.company_id = item.company_id
            WHERE scd.id = ?
            `,
            [id]
        );
        if (rows.length === 0) return res.status(404).json({ message: "Sales contract detail not found." });
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching sales contract detail:", error);
        res.status(500).json({ message: "Failed to fetch sales contract detail.", error: error.message });
    }
};

// ======================================================
// Add Sales Contract Detail
// ======================================================
// gross_weight / tear_weight are left at their DB defaults (0.00) - only
// net_weight is entered directly, same simplification used by Production
// Entry, "for now".
exports.addSalesContractDetail = async (req, res) => {
    try {
        const {
            company_id, salescontractmain_id, Item_code,
            pieces, net_weight, rate,
            gst_percent, further_percent, other_tax,
            performed_by, system_name_ip
        } = req.body;

        // financialyear_id is NOT taken from req.body - it's always derived
        // from the parent SalesContractMain row below, so a detail line can
        // never drift out of sync with its header.
        if (!company_id || !salescontractmain_id || !Item_code) {
            return res.status(400).json({ message: "Company, Sales Contract, and Item Code are required." });
        }
        if (!net_weight || parseFloat(net_weight) <= 0) {
            return res.status(400).json({ message: "Net weight must be greater than zero." });
        }
        if (String(Item_code).length > 8) {
            return res.status(400).json({ message: "Item code cannot be more than 8 characters." });
        }

        const netWeightValue = parseFloat(net_weight) || 0;
        const piecesValue = parseInt(pieces) || 0;
        const rateValue = parseFloat(rate) || 0;
        const gstPercentValue = parseFloat(gst_percent) || 0;
        const furtherPercentValue = parseFloat(further_percent) || 0;
        const otherTaxValue = parseFloat(other_tax) || 0;

        const amountValue = netWeightValue * rateValue;
        const gstAmountValue = amountValue * gstPercentValue / 100;
        const furtherAmountValue = amountValue * furtherPercentValue / 100;
        const totalValue = amountValue + gstAmountValue + furtherAmountValue + otherTaxValue;

        const [mainCheck] = await db.query(
            `SELECT id, financialyear_id, contract_no FROM SalesContractMain WHERE id = ? AND company_id = ?`,
            [salescontractmain_id, company_id]
        );
        if (mainCheck.length === 0) {
            return res.status(400).json({ message: "Invalid sales contract for this company." });
        }
        const { financialyear_id, contract_no } = mainCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({ message: "Invalid item code for this company." });
        }

        const [existing] = await db.query(
            `SELECT COALESCE(MAX(entry_no),0) AS maxNo FROM SalesContractDetail WHERE salescontractmain_id = ?`,
            [salescontractmain_id]
        );
        const nextEntryNo = existing[0].maxNo + 1;

        const [result] = await db.query(
            `INSERT INTO SalesContractDetail
                (company_id, financialyear_id, salescontractmain_id, Item_code, entry_no,
                 pieces, net_weight, rate, amount,
                 gst_percent, gst_amount, further_percent, further_amount, other_tax, total)
             VALUES (?,?,?,?,?, ?,?,?,?, ?,?,?,?,?,?)`,
            [
                company_id, financialyear_id, salescontractmain_id, Item_code, nextEntryNo,
                piecesValue, netWeightValue, rateValue, amountValue,
                gstPercentValue, gstAmountValue, furtherPercentValue, furtherAmountValue, otherTaxValue, totalValue
            ]
        );

        await logActivity({
            document_type: "SalesContractDetail",
            document_no: `${contract_no}-${nextEntryNo}`,
            status: "New",
            remarks: `Sales contract line added (Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({ message: "Sales contract detail added successfully.", id: result.insertId });
    } catch (error) {
        console.error("Error adding sales contract detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({ message: "Entry number already exists for this sales contract." });
        }
        res.status(500).json({ message: "Failed to add sales contract detail.", error: error.message });
    }
};

// ======================================================
// Update Sales Contract Detail
// ======================================================
exports.updateSalesContractDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id, salescontractmain_id, Item_code, entry_no,
            pieces, net_weight, rate,
            gst_percent, further_percent, other_tax,
            performed_by, system_name_ip
        } = req.body;

        const [existingRow] = await db.query(`SELECT id FROM SalesContractDetail WHERE id = ?`, [id]);
        if (existingRow.length === 0) return res.status(404).json({ message: "Sales contract detail not found." });

        if (!company_id || !salescontractmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({ message: "Company, Sales Contract, Item Code, and Entry No are required." });
        }
        if (entry_no <= 0) {
            return res.status(400).json({ message: "Entry number must be a positive integer." });
        }
        if (String(Item_code).length > 8) {
            return res.status(400).json({ message: "Item code cannot be more than 8 characters." });
        }

        const piecesValue = parseInt(pieces) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const gstPercentValue = parseFloat(gst_percent) || 0;
        const furtherPercentValue = parseFloat(further_percent) || 0;
        const otherTaxValue = parseFloat(other_tax) || 0;

        if (piecesValue < 0) return res.status(400).json({ message: "Pieces cannot be negative." });
        if (netWeightValue <= 0) return res.status(400).json({ message: "Net weight must be greater than zero." });
        if (rateValue < 0) return res.status(400).json({ message: "Rate cannot be negative." });

        const amountValue = netWeightValue * rateValue;
        const gstAmountValue = amountValue * gstPercentValue / 100;
        const furtherAmountValue = amountValue * furtherPercentValue / 100;
        const totalValue = amountValue + gstAmountValue + furtherAmountValue + otherTaxValue;

        const [mainCheck] = await db.query(
            `SELECT id, financialyear_id, contract_no FROM SalesContractMain WHERE id = ? AND company_id = ?`,
            [salescontractmain_id, company_id]
        );
        if (mainCheck.length === 0) return res.status(400).json({ message: "Invalid sales contract for this company." });
        const { financialyear_id, contract_no } = mainCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) return res.status(400).json({ message: "Invalid item code for this company." });

        await db.query(
            `
            UPDATE SalesContractDetail
            SET company_id = ?, financialyear_id = ?, salescontractmain_id = ?,
                Item_code = ?, entry_no = ?, pieces = ?, net_weight = ?, rate = ?, amount = ?,
                gst_percent = ?, gst_amount = ?, further_percent = ?, further_amount = ?, other_tax = ?, total = ?
            WHERE id = ?
            `,
            [company_id, financialyear_id, salescontractmain_id, Item_code, entry_no,
                piecesValue, netWeightValue, rateValue, amountValue,
                gstPercentValue, gstAmountValue, furtherPercentValue, furtherAmountValue, otherTaxValue, totalValue, id]
        );

        await logActivity({
            document_type: "SalesContractDetail",
            document_no: `${contract_no}-${entry_no}`,
            status: "Edit",
            remarks: `Sales contract line updated (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Sales contract detail updated successfully." });
    } catch (error) {
        console.error("Error updating sales contract detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({ message: "Entry number already exists for this sales contract." });
        }
        res.status(500).json({ message: "Failed to update sales contract detail.", error: error.message });
    }
};

// ======================================================
// Delete Sales Contract Detail
// ======================================================
exports.deleteSalesContractDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [rows] = await db.query(
            `SELECT scd.entry_no, scd.Item_code, scm.contract_no
             FROM SalesContractDetail scd
             INNER JOIN SalesContractMain scm ON scd.salescontractmain_id = scm.id
             WHERE scd.id = ?`,
            [id]
        );
        if (rows.length === 0) return res.status(404).json({ message: "Sales contract detail not found." });
        const { entry_no, Item_code, contract_no } = rows[0];

        const [result] = await db.query(`DELETE FROM SalesContractDetail WHERE id = ?`, [id]);
        if (result.affectedRows === 0) return res.status(404).json({ message: "Sales contract detail not found." });

        await logActivity({
            document_type: "SalesContractDetail",
            document_no: `${contract_no}-${entry_no}`,
            status: "Delete",
            remarks: `Sales contract line deleted (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Sales contract detail deleted successfully." });
    } catch (error) {
        console.error("Error deleting sales contract detail:", error);
        res.status(500).json({ message: "Failed to delete sales contract detail.", error: error.message });
    }
};