const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Inward Gate Pass Details
// ======================================================
exports.getAllInwardGatePassDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                igd.id,
                igd.company_id,
                c.company_name,
                igd.department_id,
                d.department_name,
                igd.inwardgatepassmain_id,
                igm.inward_no,
                igd.financialyear_id,
                fy.year_detail,
                igd.Item_code,
                item.details AS item_name,
                igd.entry_no,
                igd.pieces,
                igd.gross_weight,
                igd.tear_weight,
                igd.net_weight,
                igd.amount,
                igd.freight,
                igd.total,
                igd.add_date,
                igd.update_date
            FROM InwardGatePassDetail igd
            INNER JOIN CompanyName c
                ON igd.company_id = c.id
            INNER JOIN Department d
                ON igd.department_id = d.id
            INNER JOIN InwardGatePassMain igm
                ON igd.inwardgatepassmain_id = igm.id
            INNER JOIN FinancialYear fy
                ON igd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON igd.Item_code = item.code AND igd.company_id = item.company_id
            ORDER BY
                igm.inward_no,
                igd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching inward gate pass details:", error);
        res.status(500).json({
            message: "Failed to fetch inward gate pass details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Inward Gate Pass Details By Main ID
// ======================================================
exports.getInwardGatePassDetailsByMain = async (req, res) => {
    try {
        const { inwardgatepassmain_id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                igd.id,
                igd.company_id,
                c.company_name,
                igd.department_id,
                d.department_name,
                igd.inwardgatepassmain_id,
                igm.inward_no,
                igd.financialyear_id,
                fy.year_detail,
                igd.Item_code,
                item.details AS item_name,
                igd.entry_no,
                igd.pieces,
                igd.gross_weight,
                igd.tear_weight,
                igd.net_weight,
                igd.amount,
                igd.freight,
                igd.total,
                igd.add_date,
                igd.update_date
            FROM InwardGatePassDetail igd
            INNER JOIN CompanyName c
                ON igd.company_id = c.id
            INNER JOIN Department d
                ON igd.department_id = d.id
            INNER JOIN InwardGatePassMain igm
                ON igd.inwardgatepassmain_id = igm.id
            INNER JOIN FinancialYear fy
                ON igd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON igd.Item_code = item.code AND igd.company_id = item.company_id
            WHERE igd.inwardgatepassmain_id = ?
            ORDER BY igd.entry_no ASC
            `,
            [inwardgatepassmain_id]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching inward gate pass details by main:", error);
        res.status(500).json({
            message: "Failed to fetch inward gate pass details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Inward Gate Pass Detail By ID
// ======================================================
exports.getInwardGatePassDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                igd.id,
                igd.company_id,
                c.company_name,
                igd.department_id,
                d.department_name,
                igd.inwardgatepassmain_id,
                igm.inward_no,
                igd.financialyear_id,
                fy.year_detail,
                igd.Item_code,
                item.details AS item_name,
                igd.entry_no,
                igd.pieces,
                igd.gross_weight,
                igd.tear_weight,
                igd.net_weight,
                igd.amount,
                igd.freight,
                igd.total,
                igd.add_date,
                igd.update_date
            FROM InwardGatePassDetail igd
            INNER JOIN CompanyName c
                ON igd.company_id = c.id
            INNER JOIN Department d
                ON igd.department_id = d.id
            INNER JOIN InwardGatePassMain igm
                ON igd.inwardgatepassmain_id = igm.id
            INNER JOIN FinancialYear fy
                ON igd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON igd.Item_code = item.code AND igd.company_id = item.company_id
            WHERE igd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Inward gate pass detail not found."
            });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching inward gate pass detail:", error);
        res.status(500).json({
            message: "Failed to fetch inward gate pass detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Inward Gate Pass Detail
// ======================================================
exports.addInwardGatePassDetail = async (req, res) => {
    try {
        const {
            company_id,
            inwardgatepassmain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            amount,
            freight,
            total,
            performed_by,
            system_name_ip
        } = req.body;

        // Validate required fields
        // NOTE: department_id and financialyear_id are NOT taken from req.body -
        // they're always derived from the parent InwardGatePassMain row below,
        // so a detail line can never drift out of sync with its header.
        if (!company_id || !inwardgatepassmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Inward Gate Pass Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const amountValue = parseFloat(amount) || 0;
        const freightValue = parseFloat(freight) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({ message: "Pieces cannot be negative." });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({ message: "Net weight cannot be negative." });
        }
        if (amountValue < 0) {
            return res.status(400).json({ message: "Amount cannot be negative." });
        }

        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue + freightValue;

        const [mainCheck] = await db.query(
            `SELECT id, department_id, financialyear_id, inward_no FROM InwardGatePassMain WHERE id = ? AND company_id = ?`,
            [inwardgatepassmain_id, company_id]
        );
        if (mainCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid inward gate pass for this company."
            });
        }
        const { department_id, financialyear_id, inward_no } = mainCheck[0];

        // Check if item exists in item master
        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        const [result] = await db.query(
            `
            INSERT INTO InwardGatePassDetail
            (
                company_id,
                department_id,
                inwardgatepassmain_id,
                financialyear_id,
                Item_code,
                entry_no,
                pieces,
                gross_weight,
                tear_weight,
                net_weight,
                amount,
                freight,
                total
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
                company_id,
                department_id,
                inwardgatepassmain_id,
                financialyear_id,
                Item_code,
                entry_no,
                piecesValue,
                grossWeightValue,
                tearWeightValue,
                netWeightValue,
                amountValue,
                freightValue,
                totalValue
            ]
        );

        await logActivity({
            document_type: "InwardGatePassDetail",
            document_no: `${inward_no}-${entry_no}`,
            status: "New",
            remarks: `Inward gate pass line added (Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            message: "Inward gate pass detail added successfully.",
            id: result.insertId
        });
    } catch (error) {
        console.error("Error adding inward gate pass detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this inward gate pass."
            });
        }
        res.status(500).json({
            message: "Failed to add inward gate pass detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Inward Gate Pass Detail
// ======================================================
exports.updateInwardGatePassDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            inwardgatepassmain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            amount,
            freight,
            total,
            performed_by,
            system_name_ip
        } = req.body;

        const [existingRow] = await db.query(
            `SELECT id FROM InwardGatePassDetail WHERE id = ?`,
            [id]
        );
        if (existingRow.length === 0) {
            return res.status(404).json({ message: "Inward gate pass detail not found." });
        }

        if (!company_id || !inwardgatepassmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Inward Gate Pass Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const amountValue = parseFloat(amount) || 0;
        const freightValue = parseFloat(freight) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({ message: "Pieces cannot be negative." });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({ message: "Net weight cannot be negative." });
        }
        if (amountValue < 0) {
            return res.status(400).json({ message: "Amount cannot be negative." });
        }

        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue + freightValue;

        // Re-derive department_id/financialyear_id from the (possibly new)
        // parent main, so they can never fall out of sync with it.
        const [mainCheck] = await db.query(
            `SELECT id, department_id, financialyear_id, inward_no FROM InwardGatePassMain WHERE id = ? AND company_id = ?`,
            [inwardgatepassmain_id, company_id]
        );
        if (mainCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid inward gate pass for this company."
            });
        }
        const { department_id, financialyear_id, inward_no } = mainCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        await db.query(
            `
            UPDATE InwardGatePassDetail
            SET
                company_id = ?,
                department_id = ?,
                inwardgatepassmain_id = ?,
                financialyear_id = ?,
                Item_code = ?,
                entry_no = ?,
                pieces = ?,
                gross_weight = ?,
                tear_weight = ?,
                net_weight = ?,
                amount = ?,
                freight = ?,
                total = ?
            WHERE id = ?
            `,
            [
                company_id,
                department_id,
                inwardgatepassmain_id,
                financialyear_id,
                Item_code,
                entry_no,
                piecesValue,
                grossWeightValue,
                tearWeightValue,
                netWeightValue,
                amountValue,
                freightValue,
                totalValue,
                id
            ]
        );

        await logActivity({
            document_type: "InwardGatePassDetail",
            document_no: `${inward_no}-${entry_no}`,
            status: "Edit",
            remarks: `Inward gate pass line updated (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({
            message: "Inward gate pass detail updated successfully."
        });

    } catch (error) {
        console.error("Error updating inward gate pass detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this inward gate pass."
            });
        }
        res.status(500).json({
            message: "Failed to update inward gate pass detail.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Inward Gate Pass Detail
// ======================================================
exports.deleteInwardGatePassDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [rows] = await db.query(
            `SELECT igd.entry_no, igd.Item_code, igm.inward_no
             FROM InwardGatePassDetail igd
             INNER JOIN InwardGatePassMain igm ON igd.inwardgatepassmain_id = igm.id
             WHERE igd.id = ?`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Inward gate pass detail not found." });
        }
        const { entry_no, Item_code, inward_no } = rows[0];

        const [result] = await db.query(`DELETE FROM InwardGatePassDetail WHERE id = ?`, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Inward gate pass detail not found." });
        }

        await logActivity({
            document_type: "InwardGatePassDetail",
            document_no: `${inward_no}-${entry_no}`,
            status: "Delete",
            remarks: `Inward gate pass line deleted (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Inward gate pass detail deleted successfully." });
    } catch (error) {
        console.error("Error deleting inward gate pass detail:", error);
        res.status(500).json({
            message: "Failed to delete inward gate pass detail.",
            error: error.message
        });
    }
};