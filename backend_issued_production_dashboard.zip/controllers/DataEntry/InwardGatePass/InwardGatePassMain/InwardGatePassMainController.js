const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Inward Gate Pass Mains
// ======================================================
exports.getAllInwardGatePassMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                igm.id,
                igm.company_id,
                c.company_name,

                igm.department_id,
                d.department_name,

                igm.financialyear_id,
                fy.year_detail,

                igm.inward_no,
                igm.inward_date,

                igm.challan_no,
                igm.vehicle_no,

                igm.account_code,
                coa.account_name,

                igm.driver_name,
                igm.driver_phone_no,
                igm.freight,
                igm.remarks,

                igm.created_by,
                igm.add_date,
                igm.update_date

            FROM InwardGatePassMain igm

            INNER JOIN CompanyName c
                ON igm.company_id = c.id

            INNER JOIN Department d
                ON igm.department_id = d.id

            INNER JOIN FinancialYear fy
                ON igm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON igm.account_code = coa.code AND coa.company_id = igm.company_id

            ORDER BY igm.inward_no ASC
        `);

        res.status(200).json(rows);

    } catch (error) {
        console.error("Error fetching inward gate passes:", error);
        res.status(500).json({
            message: "Failed to fetch inward gate passes.",
            error: error.message
        });
    }
};

// ======================================================
// Get Next Inward Number
// ======================================================
// Same shape as PurchaseMain's getNextGrnNumber - this is just a preview
// (the real, race-safe number is assigned inside addInwardGatePassMain via
// InwardGatePassSequence). Numbering runs continuously per (company,
// financial year) with no department split, matching the sequence table.
exports.getNextInwardNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.params;

        if (!company_id || !financialyear_id) {
            return res.status(400).json({
                message: "Company ID and Financial Year ID are required."
            });
        }

        const [rows] = await db.query(
            `
            SELECT MAX(CAST(SUBSTRING_INDEX(inward_no, '-', -1) AS UNSIGNED)) as max_inward_no
            FROM InwardGatePassMain
            WHERE company_id = ?
              AND financialyear_id = ?
            `,
            [company_id, financialyear_id]
        );

        const maxInwardNo = rows[0].max_inward_no || 0;
        const nextNumber = maxInwardNo + 1;

        res.status(200).json({
            next_inward_number: nextNumber
        });

    } catch (error) {
        console.error("Error generating next inward number:", error);
        res.status(500).json({
            message: "Failed to generate next inward number.",
            error: error.message
        });
    }
};

// ======================================================
// Get Inward Gate Pass Main By ID
// ======================================================
exports.getInwardGatePassMainById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                igm.id,
                igm.company_id,
                c.company_name,

                igm.department_id,
                d.department_name,

                igm.financialyear_id,
                fy.year_detail,

                igm.inward_no,
                igm.inward_date,

                igm.challan_no,
                igm.vehicle_no,

                igm.account_code,
                coa.account_name,

                igm.driver_name,
                igm.driver_phone_no,
                igm.freight,
                igm.remarks,

                igm.created_by,
                igm.add_date,
                igm.update_date

            FROM InwardGatePassMain igm

            INNER JOIN CompanyName c
                ON igm.company_id = c.id

            INNER JOIN Department d
                ON igm.department_id = d.id

            INNER JOIN FinancialYear fy
                ON igm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON igm.account_code = coa.code AND coa.company_id = igm.company_id

            WHERE igm.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Inward gate pass not found."
            });
        }

        res.status(200).json(rows[0]);

    } catch (error) {
        console.error("Error fetching inward gate pass:", error);
        res.status(500).json({
            message: "Failed to fetch inward gate pass.",
            error: error.message
        });
    }
};

// ======================================================
// Add Inward Gate Pass Main
// ======================================================
exports.addInwardGatePassMain = async (req, res) => {
    const {
        company_id,
        department_id,
        financialyear_id,
        inward_date,
        challan_no,
        vehicle_no,
        account_code,
        driver_name,
        driver_phone_no,
        freight,
        remarks,
        performed_by,
        system_name_ip
    } = req.body;

    const freightValue = parseFloat(freight) || 0;
    // inward_no is not accepted from the client - it's generated atomically below
    if (!company_id || !department_id || !financialyear_id || !inward_date ||
        !challan_no || !vehicle_no || !account_code) {
        return res.status(400).json({
            message: "Company, department, financial year, inward date, challan no, vehicle no, and account are all required."
        });
    }

    if (!String(challan_no).trim()) {
        return res.status(400).json({ message: "Challan number cannot be empty." });
    }
    if (!String(vehicle_no).trim()) {
        return res.status(400).json({ message: "Vehicle number cannot be empty." });
    }

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        const [departmentCheck] = await conn.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [accountCheck] = await conn.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [account_code, company_id]
        );
        if (accountCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid account code for this company." });
        }

        const [financialYearCheck] = await conn.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        // Atomic increment, scoped to (company, financial year) only - matches
        // InwardGatePassSequence's primary key and the compound unique key
        // (company_id, financialyear_id, inward_no) on InwardGatePassMain.
        // The row lock here blocks a concurrent request for the same
        // company/FY until this transaction commits, so numbers never collide.
        await conn.query(
            `INSERT INTO InwardGatePassSequence (company_id, financialyear_id, last_no)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE last_no = last_no + 1`,
            [company_id, financialyear_id]
        );

        const [seqRow] = await conn.query(
            `SELECT last_no FROM InwardGatePassSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const nextNumber = seqRow[0].last_no;
        const inwardNo = String(nextNumber);

        const [result] = await conn.query(
            `INSERT INTO InwardGatePassMain
    (company_id, department_id, financialyear_id, inward_no, inward_date,
     challan_no, vehicle_no, account_code, driver_name, driver_phone_no,
     freight, remarks, created_by)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                company_id, department_id, financialyear_id, inwardNo, inward_date,
                challan_no.trim(), vehicle_no.trim(), account_code,
                driver_name ? driver_name.trim() : null,
                driver_phone_no ? driver_phone_no.trim() : null,
                freightValue,                                   
                remarks ? remarks.trim() : null,
                performed_by || 'Unknown'
            ]
        );

        await conn.commit();
        await logActivity({
            document_type: "InwardGatePassMain",
            document_no: inwardNo,
            status: "New",
            remarks: `Inward gate pass created (Vehicle: ${vehicle_no}, Account: ${account_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            message: "Inward gate pass created successfully.",
            id: result.insertId,
            inward_no: inwardNo
        });
    } catch (error) {
        await conn.rollback();
        console.error("Error adding inward gate pass:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This inward number already exists for the selected company and financial year."
            });
        }
        res.status(500).json({ message: "Failed to create inward gate pass.", error: error.message });
    } finally {
        conn.release();
    }
};

// ======================================================
// Update Inward Gate Pass Main
// ======================================================
exports.updateInwardGatePassMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            department_id,
            financialyear_id,
            inward_no,
            inward_date,
            challan_no,
            vehicle_no,
            account_code,
            driver_name,
            driver_phone_no,
            freight,  
            remarks,
            performed_by,
            system_name_ip
        } = req.body;

        const freightValue = parseFloat(freight) || 0;

        const [existingMain] = await db.query(
            `SELECT id FROM InwardGatePassMain WHERE id = ?`,
            [id]
        );
        if (existingMain.length === 0) {
            return res.status(404).json({ message: "Inward gate pass not found." });
        }

        if (!company_id || !department_id || !financialyear_id || !inward_no || !inward_date ||
            !challan_no || !vehicle_no || !account_code) {
            return res.status(400).json({
                message: "Company, department, financial year, inward number, inward date, challan no, vehicle no, and account are all required."
            });
        }

        if (!String(inward_no).trim()) {
            return res.status(400).json({ message: "Inward number cannot be empty." });
        }
        if (!String(challan_no).trim()) {
            return res.status(400).json({ message: "Challan number cannot be empty." });
        }
        if (!String(vehicle_no).trim()) {
            return res.status(400).json({ message: "Vehicle number cannot be empty." });
        }

        const [departmentCheck] = await db.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [accountCheck] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [account_code, company_id]
        );
        if (accountCheck.length === 0) {
            return res.status(400).json({ message: "Invalid account code for this company." });
        }

        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        await db.query(
            `
            UPDATE InwardGatePassMain
            SET
                company_id = ?,
                department_id = ?,
                financialyear_id = ?,
                inward_no = ?,
                inward_date = ?,
                challan_no = ?,
                vehicle_no = ?,
                account_code = ?,
                driver_name = ?,
                driver_phone_no = ?,
                freight = ?, 
                remarks = ?
            WHERE id = ?
            `,
            [
                company_id,
                department_id,
                financialyear_id,
                inward_no.trim(),
                inward_date,
                challan_no.trim(),
                vehicle_no.trim(),
                account_code,
                driver_name ? driver_name.trim() : null,
                driver_phone_no ? driver_phone_no.trim() : null,
                freightValue,
                remarks ? remarks.trim() : null,
                id
            ]
        );

        await logActivity({
            document_type: "InwardGatePassMain",
            document_no: inward_no.trim(),
            status: "Edit",
            remarks: `Inward gate pass updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Inward gate pass updated successfully." });

    } catch (error) {
        console.error("Error updating inward gate pass:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This inward number already exists for the selected company and financial year."
            });
        }

        res.status(500).json({
            message: "Failed to update inward gate pass.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Inward Gate Pass Main
// ======================================================
exports.deleteInwardGatePassMain = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [mainRows] = await db.query(
            `SELECT inward_no FROM InwardGatePassMain WHERE id = ?`,
            [id]
        );
        if (mainRows.length === 0) {
            return res.status(404).json({ message: "Inward gate pass not found." });
        }
        const mainRow = mainRows[0];

        const [detailCheck] = await db.query(
            `SELECT COUNT(*) as count FROM InwardGatePassDetail WHERE inwardgatepassmain_id = ?`,
            [id]
        );
        if (detailCheck[0].count > 0) {
            return res.status(409).json({
                message: "Cannot delete inward gate pass as it has associated details. Please delete the details first."
            });
        }

        const [result] = await db.query(`DELETE FROM InwardGatePassMain WHERE id = ?`, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Inward gate pass not found." });
        }

        await logActivity({
            document_type: "InwardGatePassMain",
            document_no: mainRow.inward_no,
            status: "Delete",
            remarks: `Inward gate pass deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Inward gate pass deleted successfully." });
    } catch (error) {
        console.error("Error deleting inward gate pass:", error);
        res.status(500).json({ message: "Failed to delete inward gate pass.", error: error.message });
    }
};

// ======================================================
// Get Inward Gate Pass with Details
// ======================================================
exports.getInwardGatePassWithDetails = async (req, res) => {
    try {
        const { id } = req.params;

        const [mainRows] = await db.query(
            `
            SELECT
                igm.id,
                igm.company_id,
                c.company_name,

                igm.department_id,
                d.department_name,

                igm.financialyear_id,
                fy.year_detail,

                igm.inward_no,
                igm.inward_date,

                igm.challan_no,
                igm.vehicle_no,

                igm.account_code,
                coa.account_name,

                igm.driver_name,
                igm.driver_phone_no,
                igm.freight,
                igm.remarks,

                igm.created_by,
                igm.add_date,
                igm.update_date

            FROM InwardGatePassMain igm

            INNER JOIN CompanyName c
                ON igm.company_id = c.id

            INNER JOIN Department d
                ON igm.department_id = d.id

            INNER JOIN FinancialYear fy
                ON igm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON igm.account_code = coa.code AND coa.company_id = igm.company_id

            WHERE igm.id = ?
            `,
            [id]
        );

        if (mainRows.length === 0) {
            return res.status(404).json({
                message: "Inward gate pass not found."
            });
        }

        const [detailRows] = await db.query(
            `
            SELECT
                igd.id,
                igd.company_id,
                igd.department_id,
                igd.inwardgatepassmain_id,
                igd.financialyear_id,
                igd.Item_code,
                item.details AS item_name,
                igd.entry_no,
                igd.pieces,
                igd.gross_weight,
                igd.tear_weight,
                igd.net_weight,
                igd.amount,
                igd.freight,
                igd.total,
                igd.add_date,
                igd.update_date
            FROM InwardGatePassDetail igd
            INNER JOIN ItemDetail item
                ON igd.Item_code = item.code AND igd.company_id = item.company_id
            WHERE igd.inwardgatepassmain_id = ?
            ORDER BY igd.entry_no ASC
            `,
            [id]
        );

        res.status(200).json({
            ...mainRows[0],
            details: detailRows
        });

    } catch (error) {
        console.error("Error fetching inward gate pass with details:", error);
        res.status(500).json({
            message: "Failed to fetch inward gate pass with details.",
            error: error.message
        });
    }
};