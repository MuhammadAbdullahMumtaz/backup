const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");
// ======================================================
// Get All Main Items
// ======================================================
exports.getAllMainItems = async (req, res) => {
    try {
        const sql = `
            SELECT
                mi.id,
                mi.company_id,
                c.company_name,
                mi.code,
                mi.details,
                mi.add_date,
                mi.update_date
            FROM MainItem mi
            INNER JOIN CompanyName c
                ON mi.company_id = c.id
            ORDER BY mi.id DESC
        `;

        const [rows] = await db.query(sql);

        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


// ======================================================
// Get Main Item By ID
// ======================================================
exports.getMainItemById = async (req, res) => {

    try {

        const { id } = req.params;

        const sql = `
            SELECT
                mi.id,
                mi.company_id,
                c.company_name,
                mi.code,
                mi.details,
                mi.add_date,
                mi.update_date
            FROM MainItem mi
            INNER JOIN CompanyName c
                ON mi.company_id = c.id
            WHERE mi.id = ?
        `;

        const [rows] = await db.query(sql, [id]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Main Item not found."
            });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};


// ======================================================
// Add Main Item
// ======================================================
exports.addMainItem = async (req, res) => {

    try {

        const {
            company_id,
            details
        } = req.body;

        if (!company_id || !details) {
            return res.status(400).json({
                success: false,
                message: "Company and Details are required."
            });
        }

        // Duplicate Check
        const [duplicate] = await db.query(
            `
            SELECT id
            FROM MainItem
            WHERE company_id = ?
            AND details = ?
            `,
            [company_id, details]
        );

        if (duplicate.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Main Item already exists."
            });
        }

        // ==========================================
        // Generate Main Item Code (2-digit, scoped by company)
        // ==========================================
        const [codeRows] = await db.query(
            `
            SELECT
                COALESCE(MAX(CAST(RIGHT(code, 2) AS UNSIGNED)), 0) + 1 AS nextNo
            FROM MainItem
            WHERE company_id = ?
            `,
            [company_id]
        );

        const nextNo = codeRows[0].nextNo;

        // Generate 2-digit code (01, 02, ..., 99)
        const code = String(nextNo).padStart(2, "0");

        // ==========================================
        // Insert Main Item
        // ==========================================
        const sql = `
            INSERT INTO MainItem
            (
                company_id,
                code,
                details
            )
            VALUES
            (?, ?, ?)
        `;

        const { performed_by, system_name_ip } = req.body;
        await logActivity({
            document_type: "MainItem",
            document_no: code,
            status: "New",
            remarks: `Main Item "${details}" created`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        const [result] = await db.query(sql, [
            company_id,
            code,
            details
        ]);

        res.status(201).json({
            success: true,
            message: "Main Item added successfully.",
            id: result.insertId,
            code: code
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

// ======================================================
// Update Main Item
// ======================================================
exports.updateMainItem = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            company_id,
            details
        } = req.body;

        const [exist] = await db.query(
            "SELECT id, code FROM MainItem WHERE id = ?",
            [id]
        );

        if (exist.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Main Item not found."
            });
        }

        // Duplicate Check
        const [duplicate] = await db.query(
            `
            SELECT id
            FROM MainItem
            WHERE company_id = ?
            AND details = ?
            AND id <> ?
            `,
            [
                company_id,
                details,
                id
            ]
        );

        if (duplicate.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Main Item already exists."
            });
        }

        const { performed_by, system_name_ip } = req.body;

        const sql = `
            UPDATE MainItem
            SET
                company_id = ?,
                details = ?
            WHERE id = ?
        `;

        await logActivity({
            document_type: "MainItem",
            document_no: exist[0].code,
            status: "Edit",
            remarks: `Main Item updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        await db.query(sql, [
            company_id,
            details,
            id
        ]);

        res.status(200).json({
            success: true,
            message: "Main Item updated successfully."
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};


// ======================================================
// Delete Main Item
// ======================================================
exports.deleteMainItem = async (req, res) => {

    try {

        const { id } = req.params;

        const [exist] = await db.query(
            "SELECT id, code FROM MainItem WHERE id = ?",
            [id]
        );

        if (exist.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Main Item not found."
            });
        }

        const { performed_by, system_name_ip } = req.body;
        await db.query("DELETE FROM MainItem WHERE id = ?", [id]);
        await logActivity({
            document_type: "MainItem",
            document_no: exist[0].code,
            status: "Delete",
            remarks: `Main Item deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({
            success: true,
            message: "Main Item deleted successfully."
        });

    } catch (error) {

        console.error(error);

        if (error.code === "ER_ROW_IS_REFERENCED_2" || error.errno === 1451) {
            return res.status(409).json({
                success: false,
                message: "This Main Item has Sub Item(s) linked to it. Please delete those first before deleting this item."
            });
        }

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};