const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ==========================================
// Get All Item Openings
// ==========================================
exports.getAllItemOpenings = async (req, res) => {
    try {

        const [rows] = await db.query(`
            SELECT
                io.id,
                io.company_id,
                c.company_name,
                io.financialyear_id,
                fy.year_detail,
                io.itemdetail_id,
                idt.details,
                io.quantity,
                io.weight,
                io.rate,
                io.amount,
                io.add_date,
                io.update_date
            FROM ItemOpening io
            INNER JOIN CompanyName c
                ON io.company_id = c.id
            INNER JOIN FinancialYear fy
                ON io.financialyear_id = fy.id
            INNER JOIN ItemDetail idt
                ON io.itemdetail_id = idt.id
            ORDER BY io.id DESC
        `);

        res.status(200).json({
            success: true,
            data: rows
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Error fetching item openings",
            error: err.message
        });
    }
};

// ==========================================
// Get Item Opening By ID
// ==========================================
exports.getItemOpeningById = async (req, res) => {
    try {

        const { id } = req.params;

        const [rows] = await db.query(`
            SELECT
                io.id,
                io.company_id,
                c.company_name,
                io.financialyear_id,
                fy.year_detail,
                io.itemdetail_id,
                idt.item_name,
                io.quantity,
                io.weight,
                io.rate,
                io.amount,
                io.add_date,
                io.update_date
            FROM ItemOpening io
            INNER JOIN CompanyName c
                ON io.company_id = c.id
            INNER JOIN FinancialYear fy
                ON io.financialyear_id = fy.id
            INNER JOIN ItemDetail idt
                ON io.itemdetail_id = idt.id
            WHERE io.id = ?
        `, [id]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Item Opening not found"
            });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Error fetching item opening",
            error: err.message
        });
    }
};

// ==========================================
// Add Item Opening
// ==========================================
exports.addItemOpening = async (req, res) => {
    try {

        const {
            company_id,
            financialyear_id,
            itemdetail_id,
            quantity,
            weight,
            rate,
            amount
        } = req.body;

        if (
            !company_id ||
            !financialyear_id ||
            !itemdetail_id ||
            quantity === undefined
        ) {
            return res.status(400).json({
                success: false,
                message: "Company, Financial Year, Item and Quantity are required"
            });
        }

        // Check duplicate
        const [exist] = await db.query(
            `SELECT id
             FROM ItemOpening
             WHERE company_id = ?
             AND financialyear_id = ?
             AND itemdetail_id = ?`,
            [company_id, financialyear_id, itemdetail_id]
        );

        if (exist.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Opening for this Item already exists in this Financial Year."
            });
        }

        await db.query(
            `INSERT INTO ItemOpening
            (
                company_id,
                financialyear_id,
                itemdetail_id,
                quantity,
                weight,
                rate,
                amount
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                company_id,
                financialyear_id,
                itemdetail_id,
                quantity,
                weight || 0,
                rate || 0,
                amount || 0
            ]
        );

        const [itemRow] = await db.query(
            "SELECT code FROM ItemDetail WHERE id = ?",
            [itemdetail_id]
        );

        const { performed_by, system_name_ip } = req.body;
        await logActivity({
            document_type: "ItemOpening",
            document_no: itemRow[0]?.code || null,
            status: "New",
            remarks: `Item Opening added (FY ID: ${financialyear_id}, Qty: ${quantity})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            success: true,
            message: "Item Opening added successfully"
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Error adding item opening",
            error: err.message
        });
    }
};

// ==========================================
// Update Item Opening
// ==========================================
exports.updateItemOpening = async (req, res) => {
    try {

        const { id } = req.params;

        const {
            company_id,
            financialyear_id,
            itemdetail_id,
            quantity,
            weight,
            rate,
            amount
        } = req.body;

        if (
            !company_id ||
            !financialyear_id ||
            !itemdetail_id ||
            quantity === undefined
        ) {
            return res.status(400).json({
                success: false,
                message: "Company, Financial Year, Item and Quantity are required"
            });
        }

        const [opening] = await db.query(
            "SELECT id FROM ItemOpening WHERE id = ?",
            [id]
        );

        if (opening.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Item Opening not found"
            });
        }

        // Duplicate check
        const [duplicate] = await db.query(
            `SELECT id
             FROM ItemOpening
             WHERE company_id = ?
             AND financialyear_id = ?
             AND itemdetail_id = ?
             AND id != ?`,
            [company_id, financialyear_id, itemdetail_id, id]
        );

        if (duplicate.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Opening for this Item already exists in this Financial Year."
            });
        }

        await db.query(
            `UPDATE ItemOpening
             SET
                company_id = ?,
                financialyear_id = ?,
                itemdetail_id = ?,
                quantity = ?,
                weight = ?,
                rate = ?,
                amount = ?
             WHERE id = ?`,
            [
                company_id,
                financialyear_id,
                itemdetail_id,
                quantity,
                weight || 0,
                rate || 0,
                amount || 0,
                id
            ]
        );

        const [itemRow] = await db.query(
            "SELECT code FROM ItemDetail WHERE id = ?",
            [itemdetail_id]
        );
        const { performed_by, system_name_ip } = req.body;
        // ...after UPDATE...
        await logActivity({
            document_type: "ItemOpening",
            document_no: itemRow[0]?.code || null,
            status: "Edit",
            remarks: `Item Opening updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({
            success: true,
            message: "Item Opening updated successfully"
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Error updating item opening",
            error: err.message
        });
    }
};

// ==========================================
// Delete Item Opening
// ==========================================
exports.deleteItemOpening = async (req, res) => {
    try {

        const { id } = req.params;

        const [opening] = await db.query(
            "SELECT id FROM ItemOpening WHERE id = ?",
            [id]
        );

        if (opening.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Item Opening not found"
            });
        }

        const [itemRow] = await db.query(
            "SELECT code FROM ItemDetail WHERE id = ?",
            [opening[0].itemdetail_id]
        );
        const { performed_by, system_name_ip } = req.body;
        await db.query("DELETE FROM ItemOpening WHERE id = ?", [id]);
        await logActivity({
            document_type: "ItemOpening",
            document_no: itemRow[0]?.code || null,
            status: "Delete",
            remarks: `Item Opening deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({
            success: true,
            message: "Item Opening deleted successfully"
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Error deleting item opening",
            error: err.message
        });
    }
};