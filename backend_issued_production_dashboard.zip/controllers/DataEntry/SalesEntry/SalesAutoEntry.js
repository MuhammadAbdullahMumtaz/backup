const db = require("../../../config/db"); // adjust path to match your project
const { logActivity } = require("../../../utils/ActivityLogger");
/**
 * Rebuilds every "auto" GL-side SalesMain/SalesDetail row that belongs to a
 * given user-entered SalesMain (invoice), based on the current set of
 * *user* SalesDetail rows under it. Mirrors syncAutoEntriesForPurchaseMain,
 * grouped by GL_sale instead of GL_purchase, keyed by invoice_no instead of grn_no.
 */
async function syncAutoEntriesForSalesMain(userSalesMainId, meta = {}) {
    const { performed_by, system_name_ip } = meta;
    const warnings = [];
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        const [mainRows] = await connection.query(
            `SELECT id, company_id, financialyear_id, invoice_no, invoice_date,
            gp_no, gp_date, po_no, po_date, builty_no, department_id
     FROM SalesMain
     WHERE id = ? AND entry = 'user'
     FOR UPDATE`,
            [userSalesMainId]
        );

        if (mainRows.length === 0) {
            await connection.commit();
            return { warnings };
        }
        const userMain = mainRows[0];

        const [detailRows] = await connection.query(
            `SELECT sd.Item_code, sd.pieces, sd.net_weight, sd.rate, sd.amount,
                    sd.total,
                    si.details AS subitem_details, coa.code AS account_code
             FROM SalesDetail sd
             INNER JOIN ItemDetail i
                ON sd.Item_code = i.code AND sd.company_id = i.company_id
             INNER JOIN SubItem si
                ON i.subitem_id = si.id
             LEFT JOIN ChartOfAccount coa
                ON si.GL_sale = coa.code
             WHERE sd.sale_main = ? AND sd.entry = 'user'`,
            [userSalesMainId]
        );

        const groups = new Map(); // account_code -> array of detail rows
        for (const row of detailRows) {
            if (!row.account_code) {
                warnings.push(
                    `Item "${row.Item_code}" (Sub Item "${row.subitem_details}") has no GL Sale account configured - skipped in auto entry.`
                );
                continue;
            }
            if (!groups.has(row.account_code)) groups.set(row.account_code, []);
            groups.get(row.account_code).push(row);
        }

        const [existingAutoMains] = await connection.query(
            `SELECT id, customer_code
             FROM SalesMain
             WHERE company_id = ? AND financialyear_id = ? AND invoice_no = ? AND entry = 'auto'`,
            [userMain.company_id, userMain.financialyear_id, userMain.invoice_no]
        );
        const existingByCode = new Map(existingAutoMains.map((m) => [m.customer_code, m.id]));

        // Drop auto mains whose account code is no longer represented
        for (const [code, id] of existingByCode) {
            if (!groups.has(code)) {
                await connection.query(`DELETE FROM SalesDetail WHERE sale_main = ?`, [id]);
                await connection.query(`DELETE FROM SalesMain WHERE id = ?`, [id]);
                existingByCode.delete(code);

                await logActivity({
                    document_type: "SalesMain(Auto)",
                    document_no: userMain.invoice_no,
                    status: "Delete",
                    remarks: `Auto GL entry removed (GL account: ${code}) - no longer represented`,
                    username: performed_by || "Unknown",
                    system_name_ip
                });
            }
        }

        // Upsert one auto main per remaining/new account code
        for (const [code, rows] of groups) {
            let autoMainId = existingByCode.get(code);
            const isNewAutoMain = !autoMainId;
            const groupTotal = rows.reduce((s, r) => s + Number(r.total), 0);

            if (autoMainId) {
                await connection.query(
                    `UPDATE SalesMain
         SET gp_no = ?, gp_date = ?, po_no = ?, po_date = ?,
             invoice_date = ?, builty_no = ?, total = ?, department_id = ?
         WHERE id = ?`,
                    [
                        userMain.gp_no, userMain.gp_date,
                        userMain.po_no, userMain.po_date, userMain.invoice_date,
                        userMain.builty_no, groupTotal, userMain.department_id, autoMainId,
                    ]
                );
                await connection.query(`DELETE FROM SalesDetail WHERE sale_main = ?`, [autoMainId]);
            } else {
                const [insertResult] = await connection.query(
                    `INSERT INTO SalesMain
    (company_id, financialyear_id, department_id, gp_no, gp_date, po_no, po_date,
     invoice_no, invoice_date, builty_no, customer_code, freight, total, entry)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 'auto')`,
                    [
                        userMain.company_id, userMain.financialyear_id, userMain.department_id,
                        userMain.gp_no, userMain.gp_date, userMain.po_no, userMain.po_date,
                        userMain.invoice_no, userMain.invoice_date, userMain.builty_no,
                        code, groupTotal,
                    ]
                );
                autoMainId = insertResult.insertId;
            }

            let entryNo = 1;
            for (const row of rows) {
                await connection.query(
                    `INSERT INTO SalesDetail
    (company_id, sale_main, financialyear_id, Item_code, entry_no, entry,
     pieces, net_weight, rate, amount, freight, total)
VALUES (?, ?, ?, ?, ?, 'auto', ?, ?, ?, ?, 0, ?)`,
                    [
                        userMain.company_id, autoMainId, userMain.financialyear_id,
                        row.Item_code, entryNo++, row.pieces, row.net_weight, row.rate, row.amount,
                        row.total,
                    ]
                );
            }
            await logActivity({
                document_type: "SalesMain(Auto)",
                document_no: userMain.invoice_no,
                status: isNewAutoMain ? "New" : "Edit",
                remarks: `Auto GL entry ${isNewAutoMain ? "created" : "synced"} (GL account: ${code}, ${rows.length} line(s))`,
                username: performed_by || "Unknown",
                system_name_ip
            });
        }

        await connection.commit();
        return { warnings };
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
}

/**
 * Deletes every auto row belonging to a given invoice group. Used when the
 * user's SalesMain itself is deleted. Caller controls the transaction.
 */
async function deleteAutoEntriesForInvoice(connection, { company_id, financialyear_id, invoice_no }, meta = {}) {
    const { performed_by, system_name_ip } = meta;
    const [autoMains] = await connection.query(
        `SELECT id, customer_code FROM SalesMain
         WHERE company_id = ? AND financialyear_id = ? AND invoice_no = ? AND entry = 'auto'`,
        [company_id, financialyear_id, invoice_no]
    );
    for (const m of autoMains) {
        await connection.query(`DELETE FROM SalesDetail WHERE sale_main = ?`, [m.id]);
        await connection.query(`DELETE FROM SalesMain WHERE id = ?`, [m.id]);

        await logActivity({
            document_type: "SalesMain(Auto)",
            document_no: invoice_no,
            status: "Delete",
            remarks: `Auto GL entry deleted (GL account: ${m.customer_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });
    }
}

module.exports = {
    syncAutoEntriesForSalesMain,
    deleteAutoEntriesForInvoice,
};