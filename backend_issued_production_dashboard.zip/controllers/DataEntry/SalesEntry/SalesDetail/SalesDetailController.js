const db = require("../../../../config/db");
const { syncAutoEntriesForSalesMain } = require("../SalesAutoEntry");
const { getAvailableLots, allocateFifo, revertStockIfNeeded } = require("../StockAllocation");
const { logActivity } = require("../../../../utils/ActivityLogger");

exports.getAvailableStock = async (req, res) => {
    try {
        const { company_id, item_code } = req.query;
        console.log('[available-stock] company_id=', company_id, 'item_code=', JSON.stringify(item_code));
        const lots = await getAvailableLots(company_id, item_code);
        console.log('[available-stock] lots found:', lots.length);
        res.status(200).json(lots);
    } catch (error) {
        console.error('[available-stock] error:', error);
        res.status(500).json({ message: "Failed to fetch stock lots.", error: error.message });
    }
};

const recalcSalesMainTotal = async (sale_main) => {
    const [[{ totalSum }]] = await db.query(
        `SELECT COALESCE(SUM(total), 0) AS totalSum FROM SalesDetail WHERE sale_main = ?`,
        [sale_main]
    );
    await db.query(`UPDATE SalesMain SET total = ? WHERE id = ?`, [totalSum, sale_main]);
};

// ======================================================
// Get All Sales Details
// ======================================================
exports.getAllSalesDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                sd.id,
                sd.company_id,
                c.company_name,
                sd.sale_main,
                sm.invoice_no,
                sm.entry,
                sd.financialyear_id,
                fy.year_detail,
                sd.Item_code,
                item.details AS item_name,
                sd.entry_no,
                sd.grn_no,
                sd.purchase_entry_no,
                sd.source_type,
                sd.source_detail_id,
                sd.pieces,
                sd.gross_weight,
                sd.tear_weight,
                sd.net_weight,
                sd.rate,
                sd.amount,
                sd.freight,

                -- GST columns
                sd.gst_percent,
                sd.gst_amount,
                sd.further_percent,
                sd.further_amount,
                sd.other_tax,

                sd.total,
                sd.add_date,
                sd.update_date
            FROM SalesDetail sd
            INNER JOIN CompanyName c
                ON sd.company_id = c.id
            INNER JOIN SalesMain sm
                ON sd.sale_main = sm.id
            INNER JOIN FinancialYear fy
                ON sd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON sd.Item_code = item.code AND sd.company_id = item.company_id
            ORDER BY
                sm.invoice_no,
                sd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sale details:", error);
        res.status(500).json({
            message: "Failed to fetch sale details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Details By Sales Main ID
// ======================================================
exports.getSalesDetailsBySalesMain = async (req, res) => {
    try {
        const { sale_main } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                sd.id,
                sd.company_id,
                c.company_name,
                sd.sale_main,
                sm.invoice_no,
                sd.financialyear_id,
                fy.year_detail,
                sd.Item_code,
                item.details AS item_name,
                sd.entry_no,
                sd.grn_no,
                sd.purchase_entry_no,
                sd.source_type,
                sd.source_detail_id,
                sd.pieces,
                sd.gross_weight,
                sd.tear_weight,
                sd.net_weight,
                sd.rate,
                sd.amount,
                sd.freight,

                -- GST columns
                sd.gst_percent,
                sd.gst_amount,
                sd.further_percent,
                sd.further_amount,
                sd.other_tax,

                sd.total,
                sd.add_date,
                sd.update_date
            FROM SalesDetail sd
            INNER JOIN CompanyName c
                ON sd.company_id = c.id
            INNER JOIN SalesMain sm
                ON sd.sale_main = sm.id
            INNER JOIN FinancialYear fy
                ON sd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON sd.Item_code = item.code AND sd.company_id = item.company_id
            WHERE sd.sale_main = ?
            ORDER BY sd.entry_no ASC
            `,
            [sale_main]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sale details by sale:", error);
        res.status(500).json({
            message: "Failed to fetch sale details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Detail By ID
// ======================================================
exports.getSalesDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                sd.id,
                sd.company_id,
                c.company_name,
                sd.sale_main,
                sm.invoice_no,
                sd.financialyear_id,
                fy.year_detail,
                sd.Item_code,
                item.details AS item_name,
                sd.entry_no,
                sd.grn_no,
                sd.purchase_entry_no,
                sd.source_type,
                sd.source_detail_id,
                sd.pieces,
                sd.gross_weight,
                sd.tear_weight,
                sd.net_weight,
                sd.rate,
                sd.amount,
                sd.freight,

                -- GST columns
                sd.gst_percent,
                sd.gst_amount,
                sd.further_percent,
                sd.further_amount,
                sd.other_tax,

                sd.total,
                sd.add_date,
                sd.update_date
            FROM SalesDetail sd
            INNER JOIN CompanyName c
                ON sd.company_id = c.id
            INNER JOIN SalesMain sm
                ON sd.sale_main = sm.id
            INNER JOIN FinancialYear fy
                ON sd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON sd.Item_code = item.code AND sd.company_id = item.company_id
            WHERE sd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Sale detail not found."
            });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching sale detail:", error);
        res.status(500).json({
            message: "Failed to fetch sale detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Sales Detail
// ======================================================
exports.addSalesDetail = async (req, res) => {
    try {
        const {
            company_id, sale_main, Item_code,
            pieces, net_weight, rate,
            gst_percent, further_percent, other_tax,   // NEW - GST fields
            performed_by, system_name_ip
        } = req.body;

        // Validate required fields
        // NOTE: financialyear_id is NOT taken from req.body - it's always
        // derived from the parent SalesMain row below, so it can never
        // drift out of sync with the sale it belongs to.
        if (!company_id || !sale_main || !Item_code) {
            return res.status(400).json({
                message: "Company, Sales Main, and Item Code are required."
            });
        }
        if (!net_weight || parseFloat(net_weight) <= 0) {
            return res.status(400).json({
                message: "Net weight must be greater than zero."
            });
        }

        // Validate Item_code length (matches VARCHAR(8) column)
        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const piecesValue = parseInt(pieces) || 0;

        // NEW - GST inputs. gst_percent / further_percent are rates, applied
        // to each split allocation's own amount below (so a lot-split entry
        // gets its own correct proportional share); other_tax is a flat
        // rupee amount for the whole line and is split across lots
        // proportionally to each lot's net_weight share of the total.
        const gstPercentValue = parseFloat(gst_percent) || 0;
        const furtherPercentValue = parseFloat(further_percent) || 0;
        const otherTaxValue = parseFloat(other_tax) || 0;

        // getAvailableLots/allocateFifo now merge PurchaseDetail,
        // SalesReturnDetail AND ProductionDetail lots (raw stock + finished
        // goods stock) - Sales can draw FIFO against either.
        const lots = await getAvailableLots(company_id, Item_code);
        let allocations;
        try {
            allocations = allocateFifo(lots, netWeightValue, piecesValue);   // pass piecesValue now
        } catch (e) {
            if (e.code === "INSUFFICIENT_STOCK") {
                return res.status(400).json({ message: e.message });
            }
            throw e;
        }

        const [saleCheck] = await db.query(
            `SELECT id, financialyear_id, invoice_no FROM SalesMain WHERE id = ? AND company_id = ?`,
            [sale_main, company_id]
        );
        if (saleCheck.length === 0) {
            return res.status(400).json({ message: "Invalid sale for this company." });
        }
        const { financialyear_id, invoice_no } = saleCheck[0];

        const [existing] = await db.query(
            `SELECT COALESCE(MAX(entry_no),0) AS maxNo FROM SalesDetail WHERE sale_main = ?`,
            [sale_main]
        );
        let nextEntryNo = existing[0].maxNo + 1;

        // Distribute pieces proportionally to net_weight share (per your note,
        // pieces isn't the driver — just split proportionally, last row gets remainder)

        const insertedIds = [];
        for (let i = 0; i < allocations.length; i++) {
            const alloc = allocations[i];

            const amountValue = alloc.net_weight * rateValue;

            // NEW - GST/further tax computed off THIS allocation's own
            // amount, so it is automatically split correctly when an entry
            // is spread across multiple lots. other_tax (a flat amount) is
            // split by the same net_weight share this allocation covers.
            const weightShare = netWeightValue > 0 ? (alloc.net_weight / netWeightValue) : 0;
            const gstAmountValue = amountValue * gstPercentValue / 100;
            const furtherAmountValue = amountValue * furtherPercentValue / 100;
            const otherTaxShare = otherTaxValue * weightShare;

            const totalValue = amountValue + gstAmountValue + furtherAmountValue + otherTaxShare;
            const thisEntryNo = nextEntryNo;

            const [result] = await db.query(
                `INSERT INTO SalesDetail
         (company_id, sale_main, financialyear_id, Item_code, entry_no,
          grn_no, purchase_entry_no, source_type, source_detail_id,
          pieces, net_weight, rate, amount,
          gst_percent, gst_amount, further_percent, further_amount, other_tax,
          total)
         VALUES (?,?,?,?,?, ?,?,?,?, ?,?,?,?, ?,?,?,?,?, ?)`,
                [
                    company_id, sale_main, financialyear_id, Item_code, nextEntryNo++,
                    alloc.grn_no, alloc.purchase_entry_no, alloc.source_type, alloc.source_detail_id,
                    alloc.pieces, alloc.net_weight, rateValue, amountValue,   // ← alloc.pieces, not piecesForRow
                    gstPercentValue, gstAmountValue, furtherPercentValue, furtherAmountValue, otherTaxShare,
                    totalValue
                ]
            );
            insertedIds.push(result.insertId);

            await logActivity({
                document_type: "SalesDetail",
                document_no: `${invoice_no}-${thisEntryNo}`,
                status: "New",
                remarks: allocations.length > 1
                    ? `Sale line added (Item: ${Item_code}, lot ${i + 1}/${allocations.length})`
                    : `Sale line added (Item: ${Item_code})`,
                username: performed_by || "Unknown",
                system_name_ip
            });

            if (alloc.will_exhaust_lot) {
                // CHANGED - a lot can now also come from ProductionDetail
                // (finished-goods stock), in addition to purchase/return.
                const table = alloc.source_type === "purchase" ? "PurchaseDetail"
                    : alloc.source_type === "production" ? "ProductionDetail"
                    : "SalesReturnDetail";
                await db.query(`UPDATE ${table} SET stocks = 'out' WHERE id = ?`, [alloc.source_detail_id]);
            }
        }

        await recalcSalesMainTotal(sale_main);
        const { warnings } = await syncAutoEntriesForSalesMain(sale_main, { performed_by, system_name_ip });

        res.status(201).json({
            message: allocations.length > 1
                ? `Sale entry split across ${allocations.length} lots and saved.`
                : "Sale detail added successfully.",
            ids: insertedIds,
            entriesCreated: allocations.length,
            warnings
        });
    } catch (error) {
        console.error("Error adding sale detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this sale."
            });
        }
        res.status(500).json({
            message: "Failed to add sale detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Sales Detail
// ======================================================
exports.updateSalesDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            sale_main,
            Item_code,
            entry_no,
            grn_no,
            purchase_entry_no,
            pieces,
            net_weight,
            rate,
            gst_percent,        // NEW
            further_percent,    // NEW
            other_tax,          // NEW
            performed_by,
            system_name_ip
        } = req.body;

        if (!company_id || !sale_main || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Sales Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const gstPercentValue = parseFloat(gst_percent) || 0;          // NEW
        const furtherPercentValue = parseFloat(further_percent) || 0;  // NEW
        const otherTaxValue = parseFloat(other_tax) || 0;              // NEW

        if (piecesValue < 0) {
            return res.status(400).json({
                message: "Pieces cannot be negative."
            });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({
                message: "Net weight cannot be negative."
            });
        }
        if (rateValue < 0) {
            return res.status(400).json({
                message: "Rate cannot be negative."
            });
        }

        const amountValue = netWeightValue * rateValue;
        const gstAmountValue = amountValue * gstPercentValue / 100;          // NEW
        const furtherAmountValue = amountValue * furtherPercentValue / 100;  // NEW
        // CHANGED - total is always recomputed server-side now (amount + gst
        // + further tax + other tax); the frontend no longer gets to send an
        // authoritative total, same as the GST fields it never used to send.
        const totalValue = amountValue + gstAmountValue + furtherAmountValue + otherTaxValue;

        // Check if sale detail exists
        const [detailCheck] = await db.query(
            `SELECT id FROM SalesDetail WHERE id = ?`,
            [id]
        );
        if (detailCheck.length === 0) {
            return res.status(404).json({
                message: "Sale detail not found."
            });
        }

        // Check if sale exists, and re-derive financialyear_id from it -
        // covers the case where sale_main itself changed on update.
        const [saleCheck] = await db.query(
            `SELECT id, financialyear_id, invoice_no FROM SalesMain WHERE id = ? AND company_id = ?`,
            [sale_main, company_id]
        );
        if (saleCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid sale for this company."
            });
        }
        const { financialyear_id, invoice_no } = saleCheck[0];

        // Check if item exists
        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        await db.query(
            `
            UPDATE SalesDetail
            SET
                company_id = ?,
                sale_main = ?,
                financialyear_id = ?,
                Item_code = ?,
                entry_no = ?,
                grn_no = ?,
                purchase_entry_no = ?,
                pieces = ?,
                net_weight = ?,
                rate = ?,
                amount = ?,
                gst_percent = ?,
                gst_amount = ?,
                further_percent = ?,
                further_amount = ?,
                other_tax = ?,
                total = ?
            WHERE id = ?
            `,
            [
                company_id,
                sale_main,
                financialyear_id,
                Item_code,
                entry_no,
                grn_no,
                purchase_entry_no,
                piecesValue,
                netWeightValue,
                rateValue,
                amountValue,
                gstPercentValue,
                gstAmountValue,
                furtherPercentValue,
                furtherAmountValue,
                otherTaxValue,
                totalValue,
                id
            ]
        );

        await logActivity({
            document_type: "SalesDetail",
            document_no: `${invoice_no}-${entry_no}`,
            status: "Edit",
            remarks: `Sale line updated (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        await recalcSalesMainTotal(sale_main);
        const { warnings } = await syncAutoEntriesForSalesMain(sale_main, { performed_by, system_name_ip });

        res.status(200).json({
            message: "Sale detail updated successfully.",
            warnings
        });
    } catch (error) {
        console.error("Error updating sale detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this sale."
            });
        }
        res.status(500).json({
            message: "Failed to update sale detail.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Sales Detail
// ======================================================
exports.deleteSalesDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [rows] = await db.query(
            `SELECT sd.sale_main, sd.source_type, sd.source_detail_id, sd.entry_no, sd.Item_code, sm.invoice_no
             FROM SalesDetail sd
             INNER JOIN SalesMain sm ON sd.sale_main = sm.id
             WHERE sd.id = ?`,   // widened join
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Sale detail not found." });
        }
        const { sale_main, source_type, source_detail_id, entry_no, Item_code, invoice_no } = rows[0];

        const [result] = await db.query(`DELETE FROM SalesDetail WHERE id = ?`, [id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Sale detail not found." });
        }

        await logActivity({
            document_type: "SalesDetail",
            document_no: `${invoice_no}-${entry_no}`,
            status: "Delete",
            remarks: `Sale line deleted (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        // Entry-level stock management: only this row's source lot is
        // rechecked. revertStockIfNeeded now also understands 'production'
        // as a source_type.
        await revertStockIfNeeded(source_type, source_detail_id);

        await recalcSalesMainTotal(sale_main);
        const { warnings } = await syncAutoEntriesForSalesMain(sale_main, { performed_by, system_name_ip });

        res.status(200).json({ message: "Sale detail deleted successfully.", warnings });
    } catch (error) {
        console.error("Error deleting sale detail:", error);
        res.status(500).json({ message: "Failed to delete sale detail.", error: error.message });
    }
};