const db = require("../../../../config/db");
const { syncAutoEntriesForSalesMain, deleteAutoEntriesForInvoice } = require("../SalesAutoEntry");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Sales Mains
// ======================================================
exports.getAllSalesMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                sm.id,
                sm.company_id,
                c.company_name,

                sm.financialyear_id,
                sm.department_id,
                fy.year_detail,

                sm.gp_no,
                sm.gp_date,
                sm.po_no,
                sm.po_date,
                sm.invoice_no,
                sm.invoice_date,
                sm.builty_no,

                sm.customer_code,
                coa.account_name AS customer_name,

                sm.freight,
                sm.entry,
                sm.total,

                sm.created_by,
                sm.add_date,
                sm.update_date

            FROM SalesMain sm

            INNER JOIN CompanyName c
                ON sm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON sm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON sm.customer_code = coa.code

            ORDER BY sm.invoice_date DESC, sm.id DESC
        `);

        res.status(200).json(rows);

    } catch (error) {
        console.error("Error fetching sales:", error);
        res.status(500).json({
            message: "Failed to fetch sales.",
            error: error.message
        });
    }
};

// ======================================================
// Get Next Invoice Number (suggestion only - not reserved)
// ======================================================
exports.getNextInvoiceNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.params;

        if (!company_id || !financialyear_id) {
            return res.status(400).json({
                message: "Company ID and Financial Year ID are required."
            });
        }

        const [rows] = await db.query(
            `SELECT last_no FROM SalesSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );

        const lastNo = rows.length > 0 ? rows[0].last_no : 0;

        res.status(200).json({
            next_invoice_number: lastNo + 1
        });

    } catch (error) {
        console.error("Error generating next invoice number:", error);
        res.status(500).json({
            message: "Failed to generate next invoice number.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Main By ID
// ======================================================
exports.getSalesMainById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                sm.id,
                sm.company_id,
                c.company_name,

                sm.financialyear_id,
                sm.department_id,
                fy.year_detail,

                sm.gp_no,
                sm.gp_date,
                sm.po_no,
                sm.po_date,
                sm.invoice_no,
                sm.invoice_date,
                sm.builty_no,

                sm.customer_code,
                coa.account_name AS customer_name,

                sm.freight,
                sm.total,
                sm.created_by,

                sm.add_date,
                sm.update_date

            FROM SalesMain sm

            INNER JOIN CompanyName c
                ON sm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON sm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON sm.customer_code = coa.code

            WHERE sm.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Sale not found."
            });
        }

        res.status(200).json(rows[0]);

    } catch (error) {
        console.error("Error fetching sale:", error);
        res.status(500).json({
            message: "Failed to fetch sale.",
            error: error.message
        });
    }
};

// ======================================================
// Add Sales Main
// ======================================================
exports.addSalesMain = async (req, res) => {
    const {
        company_id,
        financialyear_id,
        department_id,
        gp_no,
        gp_date,
        po_no,
        po_date,
        invoice_date,
        builty_no,
        customer_code,
        freight,
        performed_by,
        system_name_ip
    } = req.body;

    if (!company_id || !financialyear_id ||
        !customer_code || !invoice_date || !department_id) {
        return res.status(400).json({
            message: "Company, financial year, department, customer and invoice date are all required."
        });
    }
    if (gp_no && !gp_date) {
        return res.status(400).json({ message: "GP date is required when GP number is provided." });
    }
    if (gp_date && !gp_no) {
        return res.status(400).json({ message: "GP number is required when GP date is provided." });
    }
    if (po_no && !po_date) {
        return res.status(400).json({ message: "PO date is required when PO number is provided." });
    }
    if (po_date && !po_no) {
        return res.status(400).json({ message: "PO number is required when PO date is provided." });
    }

    const freightValue = parseFloat(freight) || 0;

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        const [departmentCheck] = await conn.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [customerCheck] = await conn.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [customer_code, company_id]
        );
        if (customerCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid customer code for this company." });
        }

        const [financialYearCheck] = await conn.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        // Ensure the sequence row exists, then lock it. This is a mutex AND
        // a generator now: while the row is locked, no other transaction
        // for this company/financial year can read/bump last_no, so the
        // number we compute here is guaranteed unique and gap-free.
        await conn.query(
            `INSERT IGNORE INTO SalesSequence (company_id, financialyear_id, last_no) VALUES (?, ?, 0)`,
            [company_id, financialyear_id]
        );
        const [seqRows] = await conn.query(
            `SELECT last_no FROM SalesSequence WHERE company_id = ? AND financialyear_id = ? FOR UPDATE`,
            [company_id, financialyear_id]
        );
        const nextNo = seqRows[0].last_no + 1;
        const generatedInvoiceNo = String(nextNo);

        // No duplicate check needed here anymore - the invoice number is
        // system-generated from the locked sequence, so it can never
        // collide with an existing 'user' row for this company/FY.

        const [result] = await conn.query(
            `INSERT INTO SalesMain
 (company_id, financialyear_id, department_id, gp_no, gp_date, po_no, po_date,
  invoice_no, invoice_date, builty_no, customer_code, freight, created_by)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [company_id, financialyear_id, department_id,
                gp_no ? gp_no.trim() : null, gp_date || null,
                po_no ? po_no.trim() : null, po_date || null,
                generatedInvoiceNo, invoice_date,
                builty_no ? builty_no.trim() : null, customer_code, freightValue,
                performed_by || 'Unknown']
        );
        // Advance the sequence to the number we just used.
        await conn.query(
            `UPDATE SalesSequence SET last_no = ? WHERE company_id = ? AND financialyear_id = ?`,
            [nextNo, company_id, financialyear_id]
        );

        await conn.commit();
        await logActivity({
            document_type: "SalesMain",
            document_no: generatedInvoiceNo,
            status: "New",
            remarks: `Sale created (Customer: ${customer_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });
        res.status(201).json({
            message: "Sale created successfully.",
            id: result.insertId,
            invoice_no: generatedInvoiceNo
        });
    } catch (error) {
        await conn.rollback();
        console.error("Error adding sale:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This invoice number already exists for the selected company, financial year, and customer."
            });
        }
        res.status(500).json({ message: "Failed to create sale.", error: error.message });
    } finally {
        conn.release();
    }
};

// ======================================================
// Update Sales Main
// ======================================================
exports.updateSalesMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            financialyear_id,
            department_id,
            gp_no,
            gp_date,
            po_no,
            po_date,
            invoice_date,
            builty_no,
            customer_code,
            freight,
            performed_by,
            system_name_ip
        } = req.body;

        if (!company_id || !financialyear_id || !customer_code || !invoice_date || !department_id) {
            return res.status(400).json({
                message: "Company, financial year, department, customer and invoice date are all required."
            });
        }
        if (gp_no && !gp_date) {
            return res.status(400).json({
                message: "GP date is required when GP number is provided."
            });
        }
        if (gp_date && !gp_no) {
            return res.status(400).json({
                message: "GP number is required when GP date is provided."
            });
        }

        if (po_no && !po_date) {
            return res.status(400).json({
                message: "PO date is required when PO number is provided."
            });
        }
        if (po_date && !po_no) {
            return res.status(400).json({
                message: "PO number is required when PO date is provided."
            });
        }

        // Check if sale exists
        const [saleCheck] = await db.query(
            `SELECT id, invoice_no  FROM SalesMain WHERE id = ?`,
            [id]
        );
        if (saleCheck.length === 0) {
            return res.status(404).json({
                message: "Sale not found."
            });
        }
        const { invoice_no } = saleCheck[0];

        // Validate customer code
        const [customerCheck] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [customer_code, company_id]
        );
        if (customerCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid customer code for this company."
            });
        }

        // Check if financial year exists
        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid financial year for this company."
            });
        }

        const freightValue = parseFloat(freight) || 0;

        // invoice_no is intentionally not part of this UPDATE - it's
        // system-generated once at creation and is never edited afterward,
        // so SalesSequence is never touched here either.
        await db.query(
            `
    UPDATE SalesMain
    SET
        company_id = ?,
        financialyear_id = ?,
        department_id = ?,
        gp_no = ?, gp_date = ?, po_no = ?, po_date = ?,
        invoice_date = ?, builty_no = ?, customer_code = ?, freight = ?
    WHERE id = ?
    `,
            [company_id, financialyear_id, department_id,
                gp_no ? gp_no.trim() : null, gp_date || null,
                po_no ? po_no.trim() : null, po_date || null,
                invoice_date, builty_no ? builty_no.trim() : null,
                customer_code, freightValue, id]
        );

        await logActivity({
            document_type: "SalesMain",
            document_no: invoice_no,
            status: "Edit",
            remarks: `Sale updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        const { warnings } = await syncAutoEntriesForSalesMain(id, { performed_by, system_name_ip });

        res.status(200).json({
            message: "Sale updated successfully.",
            warnings
        });

    } catch (error) {
        console.error("Error updating sale:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This invoice number already exists for the selected company and financial year."
            });
        }

        res.status(500).json({
            message: "Failed to update sale.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Sales Main
// ======================================================
exports.deleteSalesMain = async (req, res) => {
    const connection = await db.getConnection();
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [mainRows] = await connection.query(
            `SELECT invoice_no FROM SalesMain WHERE id = ? AND entry = 'user'`,
            [id]
        );
        if (mainRows.length === 0) {
            connection.release();
            return res.status(404).json({ message: "Sale not found." });
        }
        const { invoice_no } = mainRows[0];


        const [detailCheck] = await connection.query(
            `SELECT COUNT(*) as count FROM SalesDetail WHERE sale_main = ? AND entry = 'user'`,
            [id]
        );
        if (detailCheck[0].count > 0) {
            connection.release();
            return res.status(409).json({
                message: "Cannot delete sale as it has associated details. Please delete sale details first."
            });
        }

        await connection.beginTransaction();
        await deleteAutoEntriesForInvoice(connection, mainRows[0], { performed_by, system_name_ip });
        const [result] = await connection.query(`DELETE FROM SalesMain WHERE id = ?`, [id]);
        await connection.commit();

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Sale not found." });
        }
        await logActivity({
            document_type: "SalesMain",
            document_no: invoice_no,
            status: "Delete",
            remarks: `Sale deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });
        res.status(200).json({ message: "Sale deleted successfully." });
    } catch (error) {
        await connection.rollback();
        console.error("Error deleting sale:", error);
        res.status(500).json({ message: "Failed to delete sale.", error: error.message });
    } finally {
        connection.release();
    }
};

// ======================================================
// Get Sale with Details
// ======================================================
exports.getSaleWithDetails = async (req, res) => {
    try {
        const { id } = req.params;

        const [saleRows] = await db.query(
            `
            SELECT
                sm.id,
                sm.company_id,
                c.company_name,

                sm.financialyear_id,
                sm.department_id,
                fy.year_detail,

                sm.gp_no,
                sm.gp_date,
                sm.po_no,
                sm.po_date,
                sm.invoice_no,
                sm.invoice_date,
                sm.builty_no,

                sm.customer_code,
                coa.account_name AS customer_name,

                sm.freight,
                sm.total,

                sm.created_by,
                sm.add_date,
                sm.update_date

            FROM SalesMain sm

            INNER JOIN CompanyName c
                ON sm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON sm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON sm.customer_code = coa.code

            WHERE sm.id = ?
            `,
            [id]
        );

        if (saleRows.length === 0) {
            return res.status(404).json({
                message: "Sale not found."
            });
        }

        const [detailRows] = await db.query(
            `
            SELECT
                sd.id,
                sd.company_id,
                sd.sale_main,
                sd.financialyear_id,
                sd.Item_code,
                item.details AS item_name,
                sd.entry_no,
                sd.pieces,
                sd.gross_weight,
                sd.tear_weight,
                sd.net_weight,
                sd.rate,
                sd.amount,
                sd.freight,
                sd.gst_percent,
                sd.gst_amount,
                sd.further_percent,
                sd.further_amount,
                sd.other_tax,
                sd.total,
                sd.add_date,
                sd.update_date
            FROM SalesDetail sd
            INNER JOIN ItemDetail item
                ON sd.Item_code = item.code AND sd.company_id = item.company_id
            WHERE sd.sale_main = ?
            ORDER BY sd.entry_no ASC
            `,
            [id]
        );

        res.status(200).json({
            ...saleRows[0],
            details: detailRows
        });

    } catch (error) {
        console.error("Error fetching sale with details:", error);
        res.status(500).json({
            message: "Failed to fetch sale with details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Auto (GL-side) Entries for a Sale
// ======================================================
exports.getAutoEntriesForSalesMain = async (req, res) => {
    try {
        const { id } = req.params;

        const [mainRows] = await db.query(
            `SELECT company_id, financialyear_id, invoice_no FROM SalesMain WHERE id = ?`,
            [id]
        );
        if (mainRows.length === 0) {
            return res.status(404).json({ message: "Sale not found." });
        }
        const { company_id, financialyear_id, invoice_no } = mainRows[0];

        const [autoMains] = await db.query(
            `
            SELECT sm.id, sm.customer_code, coa.account_name AS customer_name,
                   sm.invoice_no, sm.invoice_date, sm.total,
                   sm.add_date, sm.update_date
            FROM SalesMain sm
            LEFT JOIN ChartOfAccount coa
                ON sm.customer_code = coa.code AND coa.company_id = sm.company_id
            WHERE sm.company_id = ? AND sm.financialyear_id = ? AND sm.invoice_no = ? AND sm.entry = 'auto'
            ORDER BY sm.customer_code ASC
            `,
            [company_id, financialyear_id, invoice_no]
        );

        const groups = [];
        for (const am of autoMains) {
            // CHANGED - now also selects gst_amount / further_amount / other_tax
            // so the Auto GL Entries modal can show them, matching Purchase.
            const [details] = await db.query(
                `
                SELECT sd.id, sd.Item_code, item.details AS item_name, sd.entry_no,
                       sd.pieces, sd.net_weight, sd.rate, sd.amount,
                       sd.gst_amount, sd.further_amount, sd.other_tax, sd.total
                FROM SalesDetail sd
                INNER JOIN ItemDetail item
                    ON sd.Item_code = item.code AND sd.company_id = item.company_id
                WHERE sd.sale_main = ?
                ORDER BY sd.entry_no ASC
                `,
                [am.id]
            );

            const totals = details.reduce(
                (acc, d) => {
                    acc.amount += Number(d.amount) || 0;
                    acc.gst_amount += Number(d.gst_amount) || 0;
                    acc.further_amount += Number(d.further_amount) || 0;
                    acc.other_tax += Number(d.other_tax) || 0;
                    acc.total += Number(d.total) || 0;
                    return acc;
                },
                { amount: 0, gst_amount: 0, further_amount: 0, other_tax: 0, total: 0 }
            );

            groups.push({ ...am, details, totals });
        }

        res.status(200).json({ invoice_no, groups });
    } catch (error) {
        console.error("Error fetching auto entries:", error);
        res.status(500).json({ message: "Failed to fetch auto entries.", error: error.message });
    }
};