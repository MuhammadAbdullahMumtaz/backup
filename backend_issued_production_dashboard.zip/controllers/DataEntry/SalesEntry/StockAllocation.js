const db = require("../../../config/db");

// Table each source_type draws its lots from / reverts stock on.
// NEW - 'production' added so Sales can also draw FIFO from finished-goods
// stock (ProductionDetail), not just raw purchase stock.
const SOURCE_TABLE = {
    purchase: "PurchaseDetail",
    sales_return: "SalesReturnDetail",
    production: "ProductionDetail",
};

// Returns FIFO-ordered lots for an item with their REMAINING net_weight,
// i.e. lot net_weight minus whatever SalesDetail rows already consumed from it.
// Lots now come from THREE sources:
//   - PurchaseDetail   (raw stock brought in via GRN)
//   - SalesReturnDetail(raw/finished stock that came back from a customer)
//   - ProductionDetail (finished-goods stock created via Production)
// so Sales can allocate against either raw or finished stock for the same
// item, all merged into one FIFO-ordered list by date.
async function getAvailableLots(company_id, Item_code) {
    const [purchaseLots] = await db.query(
        `SELECT pd.id AS source_detail_id, 'purchase' AS source_type,
                pm.grn_no AS label, pd.entry_no, pd.pieces, pd.net_weight,
                pm.grn_date AS lot_date, pd.stocks
         FROM PurchaseDetail pd
         JOIN PurchaseMain pm ON pd.purchasemain_id = pm.id
         WHERE pd.company_id = ? AND pd.Item_code = ?
           AND pd.stocks = 'available'
           AND pd.entry = 'user'
         ORDER BY pm.grn_date ASC, pd.id ASC`,
        [company_id, Item_code]
    );

    const [returnLots] = await db.query(
        `SELECT srd.id AS source_detail_id, 'sales_return' AS source_type,
            srm.invoice_no AS label, srd.entry_no, srd.pieces, srd.net_weight,
            srm.invoice_date AS lot_date, srd.stocks
     FROM SalesReturnDetail srd
     JOIN SalesReturnMain srm ON srd.sales_return_main = srm.id
     WHERE srd.company_id = ? AND srd.Item_code = ?
       AND srd.stocks = 'available'
       AND srd.entry = 'user'
     ORDER BY srm.invoice_date ASC, srd.id ASC`,
        [company_id, Item_code]
    );

    // NEW - finished-goods lots produced via Production. ProductionDetail
    // has no 'entry' (user/auto) column, so there's no equivalent filter here.
    const [productionLots] = await db.query(
        `SELECT prd.id AS source_detail_id, 'production' AS source_type,
            prm.production_no AS label, prd.entry_no, prd.pieces, prd.net_weight,
            prm.production_date AS lot_date, prd.stocks
     FROM ProductionDetail prd
     JOIN ProductionMain prm ON prd.productionmain_id = prm.id
     WHERE prd.company_id = ? AND prd.Item_code = ?
       AND prd.stocks = 'available'
     ORDER BY prm.production_date ASC, prd.id ASC`,
        [company_id, Item_code]
    );

    const lots = [...purchaseLots, ...returnLots, ...productionLots].sort(
        (a, b) => new Date(a.lot_date) - new Date(b.lot_date) || a.source_detail_id - b.source_detail_id
    );

    // Live remaining = lot's net_weight minus SUM of every SalesDetail row
    // that has ever drawn from it — no matter which sale. This is what makes
    // Entry 2 in the SAME sale immediately see what Entry 1 just took.
    // Generic over source_type/source_detail_id, so this already works
    // unchanged for 'production' lots too.
    for (const lot of lots) {
        const [[{ consumed, consumedPieces }]] = await db.query(
            `SELECT COALESCE(SUM(net_weight),0) AS consumed,
                COALESCE(SUM(pieces),0) AS consumedPieces
         FROM SalesDetail
         WHERE source_type = ? AND source_detail_id = ?`,
            [lot.source_type, lot.source_detail_id]
        );
        lot.remaining_net_weight = Math.max(0, Number(lot.net_weight) - Number(consumed));
        lot.remaining_pieces = Number(lot.pieces) - Number(consumedPieces);
    }

    return lots.filter((l) => l.remaining_net_weight > 0);
}

function allocateFifo(lots, requestedNetWeight, requestedPieces) {
    let remainingWeight = Number(requestedNetWeight);
    const allocations = [];

    for (let i = 0; i < lots.length; i++) {
        const lot = lots[i];
        if (remainingWeight <= 0) break;

        const take = Math.min(lot.remaining_net_weight, remainingWeight);
        if (take <= 0) continue;

        allocations.push({
            source_type: lot.source_type,
            source_detail_id: lot.source_detail_id,
            // grn_no is only meaningful for a purchase-sourced lot (mirrors
            // the original behaviour) - sales_return/production lots leave it null.
            grn_no: lot.source_type === "purchase" ? lot.label : null,
            purchase_entry_no: lot.entry_no,
            net_weight: take,
            will_exhaust_lot: take >= lot.remaining_net_weight,
        });

        remainingWeight -= take;
    }

    if (remainingWeight > 0.0001) {
        const err = new Error("Insufficient stock for this item.");
        err.code = "INSUFFICIENT_STOCK";
        throw err;
    }

    const piecesTotal = Number(requestedPieces) || 0;
    let piecesLeft = piecesTotal;
    allocations.forEach((alloc, i) => {
        const isLast = i === allocations.length - 1;
        const shareRatio = alloc.net_weight / Number(requestedNetWeight);
        const piecesForRow = isLast ? piecesLeft : Math.round(piecesTotal * shareRatio);
        alloc.pieces = piecesForRow;
        piecesLeft -= piecesForRow;
    });

    return allocations;
};

// CHANGED - table lookup now goes through SOURCE_TABLE so 'production' is
// handled the same way 'purchase' and 'sales_return' already were.
async function revertStockIfNeeded(source_type, source_detail_id) {
    const table = SOURCE_TABLE[source_type];
    if (!table) return;

    const [[lotRow]] = await db.query(
        `SELECT net_weight, stocks FROM ${table} WHERE id = ?`,
        [source_detail_id]
    );
    if (!lotRow) return;

    const [[{ consumed }]] = await db.query(
        `SELECT COALESCE(SUM(net_weight),0) AS consumed
         FROM SalesDetail
         WHERE source_type = ? AND source_detail_id = ?`,
        [source_type, source_detail_id]
    );

    const stillFullyConsumed = Number(consumed) >= Number(lotRow.net_weight);
    if (!stillFullyConsumed && lotRow.stocks === 'out') {
        await db.query(`UPDATE ${table} SET stocks = 'available' WHERE id = ?`, [source_detail_id]);
    }
}

module.exports = { getAvailableLots, allocateFifo, revertStockIfNeeded };