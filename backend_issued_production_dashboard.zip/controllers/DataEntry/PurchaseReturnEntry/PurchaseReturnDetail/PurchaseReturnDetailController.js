const db = require("../../../../config/db");
const { syncAutoEntriesForPurchaseReturnMain } = require("../AutoPurchaseReturnSync");
const { logActivity } = require("../../../../utils/ActivityLogger");
const {
    getIssuedConsumedWeight,
    getReturnedWeight,
    syncPurchaseDetailStockFlag
} = require("../../IssuedEntry/IssuedStockAllocation");

// ======================================================
// Resolve the PurchaseDetail row a return line points at, from the
// return's linked GRN + supplier + item code. Returns null if the return
// isn't linked to a GRN, or the item can't be matched to a purchase line -
// those cases are left to the existing item/GRN validation already in
// place.
// ======================================================
async function findPurchaseDetailForReturnItem(company_id, purchase_grn, supplier_code, Item_code) {
    if (!purchase_grn) return null;

    const [purchaseMainRows] = await db.query(
        `SELECT id FROM PurchaseMain
         WHERE grn_no = ? AND company_id = ? AND supplier_code = ? AND entry = 'user'`,
        [purchase_grn, company_id, supplier_code]
    );
    if (purchaseMainRows.length === 0) return null;

    const [purchaseDetailRows] = await db.query(
        `SELECT id, pieces, net_weight FROM PurchaseDetail
         WHERE purchasemain_id = ? AND Item_code = ? AND entry = 'user'`,
        [purchaseMainRows[0].id, Item_code]
    );
    return purchaseDetailRows[0] || null;
}

// Resolves the source PurchaseDetail row for a return line and validates
// that it hasn't been issued out and still has enough net_weight left to
// return. `excludeReturnDetailId` (used on update) leaves that row's own
// current quantity out of the "already returned" total so it can be
// adjusted up or down.
async function resolveAndValidateSourceDetail({
    company_id, purchase_grn, supplier_code, Item_code, netWeightValue, excludeReturnDetailId
}) {
    const purchaseDetail = await findPurchaseDetailForReturnItem(company_id, purchase_grn, supplier_code, Item_code);
    if (!purchaseDetail) {
        const err = new Error("This item was not found on the linked purchase GRN.");
        err.code = "NO_SOURCE_LOT";
        throw err;
    }

    const consumedByIssue = await getIssuedConsumedWeight(purchaseDetail.id);
    if (consumedByIssue > 0) {
        const err = new Error(
            `This item has already been issued (${consumedByIssue} of ${purchaseDetail.net_weight} consumed) from the linked GRN and can't be returned.`
        );
        err.code = "ALREADY_ISSUED";
        throw err;
    }

    let alreadyReturned;
    if (excludeReturnDetailId) {
        const [[row]] = await db.query(
            `SELECT COALESCE(SUM(net_weight),0) AS alreadyReturned
             FROM PurchaseReturnDetail
             WHERE source_detail_id = ? AND entry = 'user' AND id != ?`,
            [purchaseDetail.id, excludeReturnDetailId]
        );
        alreadyReturned = Number(row.alreadyReturned);
    } else {
        alreadyReturned = await getReturnedWeight(purchaseDetail.id);
    }

    const availableToReturn = Number(purchaseDetail.net_weight) - alreadyReturned;
    if (netWeightValue > availableToReturn + 0.0001) {
        const err = new Error(
            `Requested net weight (${netWeightValue}) exceeds what's still available to return (${availableToReturn}).`
        );
        err.code = "EXCEEDS_AVAILABLE";
        throw err;
    }

    return purchaseDetail;
}

// ======================================================
// Get Returnable Items for a GRN
// ======================================================
// Lists the purchase lines under a GRN that are still eligible for a
// return, with pieces/net_weight already reduced by anything already
// returned against them - i.e. this always reflects REMAINING returnable
// stock, not the original purchase quantity. An item already (partially or
// fully) issued out never appears as an option.
exports.getReturnableItemsForGrn = async (req, res) => {
    try {
        const { company_id, grn_no, supplier_code } = req.query;

        if (!company_id || !grn_no || !supplier_code) {
            return res.status(400).json({
                message: "company_id, grn_no and supplier_code are required."
            });
        }

        const [purchaseMainRows] = await db.query(
            `SELECT id FROM PurchaseMain
             WHERE grn_no = ? AND company_id = ? AND supplier_code = ? AND entry = 'user'`,
            [grn_no, company_id, supplier_code]
        );
        if (purchaseMainRows.length === 0) {
            return res.status(200).json([]);
        }

        const [detailRows] = await db.query(
            `SELECT pd.id, pd.Item_code, item.details AS item_name,
                    pd.pieces, pd.net_weight, pd.rate
             FROM PurchaseDetail pd
             INNER JOIN ItemDetail item
                ON pd.Item_code = item.code AND pd.company_id = item.company_id
             WHERE pd.purchasemain_id = ? AND pd.entry = 'user'
             ORDER BY pd.entry_no ASC`,
            [purchaseMainRows[0].id]
        );

        const returnable = [];
        for (const row of detailRows) {
            const consumedByIssue = await getIssuedConsumedWeight(row.id);
            if (consumedByIssue > 0) continue; // already issued - can't return at all

            const [[{ returned, returnedPieces }]] = await db.query(
                `SELECT COALESCE(SUM(net_weight),0) AS returned,
                        COALESCE(SUM(pieces),0) AS returnedPieces
                 FROM PurchaseReturnDetail
                 WHERE source_detail_id = ? AND entry = 'user'`,
                [row.id]
            );

            const remainingNetWeight = Math.max(0, Number(row.net_weight) - Number(returned));
            const remainingPieces = Math.max(0, Number(row.pieces) - Number(returnedPieces));

            if (remainingNetWeight > 0) {
                returnable.push({
                    ...row,
                    net_weight: remainingNetWeight,
                    pieces: remainingPieces,
                });
            }
        }

        res.status(200).json(returnable);
    } catch (error) {
        console.error("Error fetching returnable items:", error);
        res.status(500).json({
            message: "Failed to fetch returnable items.",
            error: error.message
        });
    }
};

// ======================================================
// Get All Purchase Return Details
// ======================================================
exports.getAllPurchaseReturnDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                prd.id,
                prd.company_id,
                c.company_name,
                prd.purchasereturnmain_id,
                prm.return_no,
                prd.financialyear_id,
                fy.year_detail,
                prd.Item_code,
                item.details AS item_name,
                prd.source_detail_id,
                prd.entry_no,
                prd.pieces,
                prd.gross_weight,
                prd.tear_weight,
                prd.net_weight,
                prd.rate,
                prd.amount,
                prd.freight,
                prd.gst_percent,
                prd.gst_amount, 
                prd.further_percent, 
                prd.further_amount, 
                prd.other_tax,
                prd.total,
                prd.add_date,
                prd.update_date
            FROM PurchaseReturnDetail prd
            INNER JOIN CompanyName c
                ON prd.company_id = c.id
            INNER JOIN PurchaseReturnMain prm
                ON prd.purchasereturnmain_id = prm.id
            INNER JOIN FinancialYear fy
                ON prd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON prd.Item_code = item.code AND prd.company_id = item.company_id
            ORDER BY
                prm.return_no,
                prd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching purchase return details:", error);
        res.status(500).json({
            message: "Failed to fetch purchase return details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Purchase Return Details By Purchase Return Main ID
// ======================================================
exports.getPurchaseReturnDetailsByPurchaseReturnMain = async (req, res) => {
    try {
        const { purchasereturnmain_id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                prd.id,
                prd.company_id,
                c.company_name,
                prd.purchasereturnmain_id,
                prm.return_no,
                prd.financialyear_id,
                fy.year_detail,
                prd.Item_code,
                item.details AS item_name,
                prd.source_detail_id,
                prd.entry_no,
                prd.pieces,
                prd.gross_weight,
                prd.tear_weight,
                prd.net_weight,
                prd.rate,
                prd.amount,
                prd.freight,
                prd.gst_percent, prd.gst_amount, prd.further_percent, prd.further_amount, prd.other_tax,
                prd.total,
                prd.add_date,
                prd.update_date
            FROM PurchaseReturnDetail prd
            INNER JOIN CompanyName c
                ON prd.company_id = c.id
            INNER JOIN PurchaseReturnMain prm
                ON prd.purchasereturnmain_id = prm.id
            INNER JOIN FinancialYear fy
                ON prd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON prd.Item_code = item.code AND prd.company_id = item.company_id
            WHERE prd.purchasereturnmain_id = ?
            ORDER BY prd.entry_no ASC
            `,
            [purchasereturnmain_id]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching purchase return details by return:", error);
        res.status(500).json({
            message: "Failed to fetch purchase return details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Purchase Return Detail By ID
// ======================================================
exports.getPurchaseReturnDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                prd.id,
                prd.company_id,
                c.company_name,
                prd.purchasereturnmain_id,
                prm.return_no,
                prd.financialyear_id,
                fy.year_detail,
                prd.Item_code,
                item.details AS item_name,
                prd.source_detail_id,
                prd.entry_no,
                prd.pieces,
                prd.gross_weight,
                prd.tear_weight,
                prd.net_weight,
                prd.rate,
                prd.amount,
                prd.freight,
                prd.gst_percent, prd.gst_amount, prd.further_percent, prd.further_amount, prd.other_tax,
                prd.total,
                prd.add_date,
                prd.update_date
            FROM PurchaseReturnDetail prd
            INNER JOIN CompanyName c
                ON prd.company_id = c.id
            INNER JOIN PurchaseReturnMain prm
                ON prd.purchasereturnmain_id = prm.id
            INNER JOIN FinancialYear fy
                ON prd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON prd.Item_code = item.code AND prd.company_id = item.company_id
            WHERE prd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Purchase return detail not found."
            });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching purchase return detail:", error);
        res.status(500).json({
            message: "Failed to fetch purchase return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Purchase Return Detail
// ======================================================
exports.addPurchaseReturnDetail = async (req, res) => {
    try {
        const {
            company_id,
            purchasereturnmain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            rate,
            freight,
            gst_percent,
            further_percent,
            other_tax,
            total,
            performed_by,
            system_name_ip
        } = req.body;

        // Validate required fields
        // NOTE: financialyear_id is NOT taken from req.body - it's always
        // derived from the parent PurchaseReturnMain row below, so it can never
        // drift out of sync with the return it belongs to.
        if (!company_id || !purchasereturnmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Purchase Return Main, Item Code, and Entry No are required."
            });
        }

        // Validate entry_no is positive
        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        // Validate Item_code length (matches VARCHAR(8) column)
        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const freightValue = parseFloat(freight) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({
                message: "Pieces cannot be negative."
            });
        }
        if (netWeightValue <= 0) {
            return res.status(400).json({
                message: "Net weight must be greater than zero."
            });
        }
        if (rateValue < 0) {
            return res.status(400).json({
                message: "Rate cannot be negative."
            });
        }

        const amountValue = netWeightValue * rateValue;

        const gstPercentValue = parseFloat(gst_percent) || 0;
        const furtherPercentValue = parseFloat(further_percent) || 0;
        const otherTaxValue = parseFloat(other_tax) || 0;

        if (gstPercentValue < 0) {
            return res.status(400).json({ message: "GST percent cannot be negative." });
        }
        if (furtherPercentValue < 0) {
            return res.status(400).json({ message: "Further tax percent cannot be negative." });
        }
        if (otherTaxValue < 0) {
            return res.status(400).json({ message: "Other tax cannot be negative." });
        }

        const gstAmountValue = parseFloat(((amountValue * gstPercentValue) / 100).toFixed(2));
        const furtherAmountValue = parseFloat(((amountValue * furtherPercentValue) / 100).toFixed(2));

        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue + gstAmountValue + furtherAmountValue + otherTaxValue;

        const [returnCheck] = await db.query(
            `SELECT id, financialyear_id, return_no, purchase_grn, supplier_code
             FROM PurchaseReturnMain WHERE id = ? AND company_id = ?`,
            [purchasereturnmain_id, company_id]
        );
        if (returnCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid purchase return for this company."
            });
        }
        const { financialyear_id, return_no, purchase_grn, supplier_code: returnSupplierCode } = returnCheck[0];

        // Resolve the exact PurchaseDetail lot this return line draws down,
        // and validate it hasn't been issued out and still has enough
        // remaining net_weight to cover this return.
        let purchaseDetail;
        try {
            purchaseDetail = await resolveAndValidateSourceDetail({
                company_id,
                purchase_grn,
                supplier_code: returnSupplierCode,
                Item_code,
                netWeightValue
            });
        } catch (e) {
            if (["NO_SOURCE_LOT", "ALREADY_ISSUED", "EXCEEDS_AVAILABLE"].includes(e.code)) {
                return res.status(400).json({ message: e.message });
            }
            throw e;
        }

        // Check if item exists in item master
        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        const [result] = await db.query(
            `
            INSERT INTO PurchaseReturnDetail
            (
                company_id,
                purchasereturnmain_id,
                financialyear_id,
                Item_code,
                source_detail_id,
                entry_no,
                pieces,
                gross_weight,
                tear_weight,
                net_weight,
                rate,
                amount,
                freight,
                gst_percent, gst_amount, further_percent, further_amount, other_tax,
                total
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
                company_id,
                purchasereturnmain_id,
                financialyear_id,
                Item_code,
                purchaseDetail.id,
                entry_no,
                piecesValue,
                grossWeightValue,
                tearWeightValue,
                netWeightValue,
                rateValue,
                amountValue,
                freightValue,
                gstPercentValue, gstAmountValue, furtherPercentValue, furtherAmountValue, otherTaxValue, totalValue
            ]
        );

        // Reflect this return against the purchase lot's stock flag - it
        // flips to 'out' once issued+returned reaches the lot's net_weight.
        await syncPurchaseDetailStockFlag(purchaseDetail.id);

        await logActivity({
            document_type: "PurchaseReturnDetail",
            document_no: `${return_no}-${entry_no}`,
            status: "New",
            remarks: `Purchase return line added (Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        let warnings = [];
        try {
            const syncResult = await syncAutoEntriesForPurchaseReturnMain(purchasereturnmain_id, { performed_by, system_name_ip });
            warnings = syncResult.warnings;
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Purchase return entry was saved, but auto GL entries could not be fully synced.");
        }

        res.status(201).json({
            message: "Purchase return detail added successfully.",
            id: result.insertId,
            warnings
        });
    } catch (error) {
        console.error("Error adding purchase return detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this purchase return."
            });
        }
        res.status(500).json({
            message: "Failed to add purchase return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Purchase Return Detail
// ======================================================
exports.updatePurchaseReturnDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            purchasereturnmain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            rate,
            freight,
            gst_percent,
            further_percent,
            other_tax,
            total,
            performed_by,
            system_name_ip
        } = req.body;

        // Block direct edits of auto-generated rows, and remember which
        // return main + source lot this row belonged to before the update
        // (both may move).
        const [existingRow] = await db.query(
            `SELECT purchasereturnmain_id, entry, source_detail_id FROM PurchaseReturnDetail WHERE id = ?`,
            [id]
        );
        if (existingRow.length === 0) {
            return res.status(404).json({ message: "Purchase return detail not found." });
        }
        if (existingRow[0].entry === "auto") {
            return res.status(400).json({
                message: "Auto-generated entries cannot be edited directly."
            });
        }

        const oldPurchaseReturnMainId = existingRow[0].purchasereturnmain_id;
        const oldSourceDetailId = existingRow[0].source_detail_id;

        if (!company_id || !purchasereturnmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Purchase Return Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const freightValue = parseFloat(freight) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({
                message: "Pieces cannot be negative."
            });
        }
        if (netWeightValue <= 0) {
            return res.status(400).json({
                message: "Net weight must be greater than zero."
            });
        }
        if (rateValue < 0) {
            return res.status(400).json({
                message: "Rate cannot be negative."
            });
        }

        const amountValue = netWeightValue * rateValue;

        const gstPercentValue = parseFloat(gst_percent) || 0;
        const furtherPercentValue = parseFloat(further_percent) || 0;
        const otherTaxValue = parseFloat(other_tax) || 0;

        if (gstPercentValue < 0) {
            return res.status(400).json({ message: "GST percent cannot be negative." });
        }
        if (furtherPercentValue < 0) {
            return res.status(400).json({ message: "Further tax percent cannot be negative." });
        }
        if (otherTaxValue < 0) {
            return res.status(400).json({ message: "Other tax cannot be negative." });
        }

        const gstAmountValue = parseFloat(((amountValue * gstPercentValue) / 100).toFixed(2));
        const furtherAmountValue = parseFloat(((amountValue * furtherPercentValue) / 100).toFixed(2));

        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue + gstAmountValue + furtherAmountValue + otherTaxValue;

        // Check if purchase return detail exists
        const [detailCheck] = await db.query(
            `SELECT id FROM PurchaseReturnDetail WHERE id = ?`,
            [id]
        );
        if (detailCheck.length === 0) {
            return res.status(404).json({
                message: "Purchase return detail not found."
            });
        }

        const [returnCheck] = await db.query(
            `SELECT id, financialyear_id, return_no, purchase_grn, supplier_code
             FROM PurchaseReturnMain WHERE id = ? AND company_id = ?`,
            [purchasereturnmain_id, company_id]
        );
        if (returnCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid purchase return for this company."
            });
        }
        const { financialyear_id, return_no, purchase_grn, supplier_code: returnSupplierCode } = returnCheck[0];

        // Re-resolve the source lot (it may have changed if the item was
        // changed) and re-validate against remaining stock, excluding this
        // row's own current quantity from the "already returned" total.
        let purchaseDetail;
        try {
            purchaseDetail = await resolveAndValidateSourceDetail({
                company_id,
                purchase_grn,
                supplier_code: returnSupplierCode,
                Item_code,
                netWeightValue,
                excludeReturnDetailId: id
            });
        } catch (e) {
            if (["NO_SOURCE_LOT", "ALREADY_ISSUED", "EXCEEDS_AVAILABLE"].includes(e.code)) {
                return res.status(400).json({ message: e.message });
            }
            throw e;
        }

        // Check if item exists
        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        await db.query(
            `
            UPDATE PurchaseReturnDetail
            SET
                company_id = ?,
                purchasereturnmain_id = ?,
                financialyear_id = ?,
                Item_code = ?,
                source_detail_id = ?,
                entry_no = ?,
                pieces = ?,
                gross_weight = ?,
                tear_weight = ?,
                net_weight = ?,
                rate = ?,
                amount = ?,
                freight = ?,
                gst_percent = ?, gst_amount = ?, further_percent = ?, further_amount = ?, other_tax = ?,
                total = ?
            WHERE id = ?
            `,
            [
                company_id,
                purchasereturnmain_id,
                financialyear_id,
                Item_code,
                purchaseDetail.id,
                entry_no,
                piecesValue,
                grossWeightValue,
                tearWeightValue,
                netWeightValue,
                rateValue,
                amountValue,
                freightValue,
                gstPercentValue, gstAmountValue, furtherPercentValue, furtherAmountValue, otherTaxValue,
                totalValue,
                id
            ]
        );

        // Re-sync the stock flag on the (possibly new) source lot, and on
        // the old one too if the item/lot changed - otherwise the old lot
        // would be left stuck at whatever flag it had before the edit.
        await syncPurchaseDetailStockFlag(purchaseDetail.id);
        if (oldSourceDetailId && Number(oldSourceDetailId) !== Number(purchaseDetail.id)) {
            await syncPurchaseDetailStockFlag(oldSourceDetailId);
        }

        await logActivity({
            document_type: "PurchaseReturnDetail",
            document_no: `${return_no}-${entry_no}`,
            status: "Edit",
            remarks: `Purchase return line updated (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        let warnings = [];
        try {
            if (oldPurchaseReturnMainId && Number(oldPurchaseReturnMainId) !== Number(purchasereturnmain_id)) {
                const oldSync = await syncAutoEntriesForPurchaseReturnMain(oldPurchaseReturnMainId, { performed_by, system_name_ip });
                warnings.push(...oldSync.warnings);
            }
            const newSync = await syncAutoEntriesForPurchaseReturnMain(purchasereturnmain_id, { performed_by, system_name_ip });
            warnings.push(...newSync.warnings);
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Entry was updated, but auto GL entries could not be fully synced.");
        }

        res.status(200).json({
            message: "Purchase return detail updated successfully.",
            warnings
        });

    } catch (error) {
        console.error("Error updating purchase return detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this purchase return."
            });
        }
        res.status(500).json({
            message: "Failed to update purchase return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Purchase Return Detail
// ======================================================
exports.deletePurchaseReturnDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [rows] = await db.query(
            `SELECT prd.purchasereturnmain_id, prd.entry, prd.entry_no, prd.Item_code,
                    prd.source_detail_id, prm.return_no
             FROM PurchaseReturnDetail prd
             INNER JOIN PurchaseReturnMain prm ON prd.purchasereturnmain_id = prm.id
             WHERE prd.id = ?`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Purchase return detail not found." });
        }
        const { purchasereturnmain_id, entry, entry_no, Item_code, source_detail_id, return_no } = rows[0];

        if (entry === "auto") {
            return res.status(400).json({
                message: "Auto-generated entries cannot be deleted directly. Delete or edit the corresponding user entry instead."
            });
        }

        const [result] = await db.query(`DELETE FROM PurchaseReturnDetail WHERE id = ?`, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Purchase return detail not found." });
        }

        // Give the returned stock back to the purchase lot's available
        // total now that this return line no longer counts against it.
        if (source_detail_id) {
            await syncPurchaseDetailStockFlag(source_detail_id);
        }

        await logActivity({
            document_type: "PurchaseReturnDetail",
            document_no: `${return_no}-${entry_no}`,
            status: "Delete",
            remarks: `Purchase return line deleted (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        let warnings = [];
        try {
            const syncResult = await syncAutoEntriesForPurchaseReturnMain(purchasereturnmain_id, { performed_by, system_name_ip });
            warnings = syncResult.warnings;
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Entry was deleted, but auto GL entries could not be fully synced.");
        }

        res.status(200).json({ message: "Purchase return detail deleted successfully.", warnings });
    } catch (error) {
        console.error("Error deleting purchase return detail:", error);
        res.status(500).json({
            message: "Failed to delete purchase return detail.",
            error: error.message
        });
    }
};