const db = require("../../../../config/db");
const { syncAutoEntriesForPurchaseReturnMain, deleteAutoEntriesForReturn } = require("../AutoPurchaseReturnSync");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Purchase Return Mains
// ======================================================
exports.getAllPurchaseReturnMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                prm.id,
                prm.company_id,
                c.company_name,

                prm.financialyear_id,
                fy.year_detail,

                prm.return_no,
                prm.return_date,
                prm.gp_no,
                prm.gp_date,

                prm.supplier_code,
                prm.purchase_grn,
                coa.account_name AS supplier_name,

                prm.invoice_no,
                prm.invoice_date,
                prm.freight,
                prm.entry,

                prm.created_by,
                prm.add_date,
                prm.update_date

            FROM PurchaseReturnMain prm

            INNER JOIN CompanyName c
                ON prm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON prm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON prm.supplier_code = coa.code

            ORDER BY prm.return_no ASC
        `);

        res.status(200).json(rows);

    } catch (error) {
        console.error("Error fetching purchase returns:", error);
        res.status(500).json({
            message: "Failed to fetch purchase returns.",
            error: error.message
        });
    }
};

// ======================================================
// Get Next Return Number
// ======================================================
// Same pattern as GRN: unique key is (company_id, financialyear_id, return_no)
// with no month component, so return numbers run continuously across the FY.
exports.getNextReturnNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.params;

        if (!company_id || !financialyear_id) {
            return res.status(400).json({
                message: "Company ID and Financial Year ID are required."
            });
        }

        const [rows] = await db.query(
            `
            SELECT MAX(CAST(SUBSTRING_INDEX(return_no, '-', -1) AS UNSIGNED)) as max_return_no
            FROM PurchaseReturnMain
            WHERE company_id = ?
              AND financialyear_id = ?
            `,
            [company_id, financialyear_id]
        );

        const maxReturnNo = rows[0].max_return_no || 0;
        const nextNumber = maxReturnNo + 1;

        res.status(200).json({
            next_return_number: nextNumber
        });

    } catch (error) {
        console.error("Error generating next return number:", error);
        res.status(500).json({
            message: "Failed to generate next return number.",
            error: error.message
        });
    }
};

// ======================================================
// Get Purchase Return Main By ID
// ======================================================
exports.getPurchaseReturnMainById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                prm.id,
                prm.company_id,
                c.company_name,

                prm.financialyear_id,
                fy.year_detail,

                prm.return_no,
                prm.return_date,
                prm.gp_no,
                prm.gp_date,

                prm.supplier_code,
                prm.purchase_grn,
                coa.account_name AS supplier_name,

                prm.invoice_no,
                prm.invoice_date,
                prm.freight,
                prm.entry,

                prm.created_by,
                prm.add_date,
                prm.update_date

            FROM PurchaseReturnMain prm

            INNER JOIN CompanyName c
                ON prm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON prm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON prm.supplier_code = coa.code

            WHERE prm.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Purchase return not found."
            });
        }

        res.status(200).json(rows[0]);

    } catch (error) {
        console.error("Error fetching purchase return:", error);
        res.status(500).json({
            message: "Failed to fetch purchase return.",
            error: error.message
        });
    }
};

// ======================================================
// Add Purchase Return Main
// ======================================================
exports.addPurchaseReturnMain = async (req, res) => {
    const {
        company_id,
        department_id,
        financialyear_id,
        return_date,
        gp_no,
        gp_date,
        supplier_code,
        invoice_no,
        invoice_date,
        freight,
        purchase_grn,
        performed_by,
        system_name_ip
    } = req.body;

    // Validate required fields (return_no is no longer accepted from the client -
    // it's generated atomically below)
    // AFTER
    if (!company_id || !department_id || !financialyear_id || !return_date ||
        !supplier_code) {
        return res.status(400).json({
            message: "Company, department, financial year, GRN date, and supplier are all required."
        });
    }

    if (gp_no && !gp_date) {
        return res.status(400).json({
            message: "GP date is required when GP number is provided."
        });
    }
    if (gp_date && !gp_no) {
        return res.status(400).json({
            message: "GP number is required when GP date is provided."
        });
    }

    const freightValue = parseFloat(freight) || 0;

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        const [departmentCheck] = await conn.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [supplierCheck] = await conn.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [supplier_code, company_id]
        );
        if (supplierCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid supplier code for this company." });
        }

        if (purchase_grn) {
            const [grnCheck] = await conn.query(
                `SELECT id FROM PurchaseMain
         WHERE grn_no = ? AND company_id = ? AND financialyear_id = ?
           AND supplier_code = ? AND entry = 'user'`,
                [purchase_grn, company_id, financialyear_id, supplier_code]
            );
            if (grnCheck.length === 0) {
                await conn.rollback();
                return res.status(400).json({ message: "Invalid purchase GRN for this supplier." });
            }
        }

        const [financialYearCheck] = await conn.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        // Atomic increment - the Return counter is scoped to (company, financial
        // year) only, NOT supplier, since the compound unique key on
        // PurchaseReturnMain (company, fy, return_no, supplier_code) is what allows
        // the auto GL-sync rows to reuse the same return_no per supplier. This
        // statement takes an exclusive row lock, so a second concurrent
        // request for the same company/FY blocks here until this one
        // commits, then gets the next number - never the same one.
        await conn.query(
            `INSERT INTO PurchaseReturnSequence (company_id, financialyear_id, last_no)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE last_no = last_no + 1`,
            [company_id, financialyear_id]
        );

        const [seqRow] = await conn.query(
            `SELECT last_no FROM PurchaseReturnSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const nextNumber = seqRow[0].last_no;
        const returnNo = String(nextNumber);

        const [result] = await conn.query(
            `INSERT INTO PurchaseReturnMain
        (company_id, department_id, financialyear_id, return_no, return_date, gp_no, gp_date,
         supplier_code, purchase_grn, invoice_no, invoice_date, freight, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [company_id, department_id, financialyear_id, returnNo, return_date,
                gp_no ? gp_no.trim() : null, gp_date || null, supplier_code,
                purchase_grn ? purchase_grn.trim() : null,
                invoice_no ? invoice_no.trim() : null, invoice_date, freightValue,
                performed_by || 'Unknown']
        );
        await conn.commit();

        await logActivity({
            document_type: "PurchaseReturnMain",
            document_no: returnNo,
            status: "New",
            remarks: `Purchase return created (Supplier: ${supplier_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            message: "Purchase return created successfully.",
            id: result.insertId,
            return_no: returnNo
        });
    } catch (error) {
        await conn.rollback();
        console.error("Error adding purchase return:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This Return number already exists for the selected company, financial year, and supplier."
            });
        }
        res.status(500).json({ message: "Failed to create purchase return.", error: error.message });
    } finally {
        conn.release();
    }
};

// ======================================================
// Update Purchase Return Main
// ======================================================
exports.updatePurchaseReturnMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            department_id,
            financialyear_id,
            return_no,
            return_date,
            gp_no,
            gp_date,
            supplier_code,
            purchase_grn,
            invoice_no,
            invoice_date,
            freight,
            performed_by,
            system_name_ip
        } = req.body;

        const [existingMain] = await db.query(
            `SELECT company_id, financialyear_id, return_no, entry FROM PurchaseReturnMain WHERE id = ?`,
            [id]
        );
        if (existingMain.length === 0) {
            return res.status(404).json({ message: "Purchase return not found." });
        }
        if (existingMain[0].entry === "auto") {
            return res.status(400).json({ message: "Auto-generated purchase return headers cannot be edited directly." });
        }
        const oldReturnKey = {
            company_id: existingMain[0].company_id,
            financialyear_id: existingMain[0].financialyear_id,
            return_no: existingMain[0].return_no
        };

        if (!company_id || !financialyear_id || !department_id || !return_no || !return_date || !purchase_grn ||
            !supplier_code) {
            return res.status(400).json({
                message: "Company, financial year, Department,  Return number, Return date, purchase grn, supplier are all required."
            });
        }

        const [departmentCheck] = await db.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        if (!invoice_no.trim()) {
            return res.status(400).json({
                message: "Invoice number cannot be empty."
            });
        }

        if (gp_no && !gp_date) {
            return res.status(400).json({
                message: "GP date is required when GP number is provided."
            });
        }
        if (gp_date && !gp_no) {
            return res.status(400).json({
                message: "GP number is required when GP date is provided."
            });
        }

        // Check if purchase return exists
        const [returnCheck] = await db.query(
            `SELECT id FROM PurchaseReturnMain WHERE id = ?`,
            [id]
        );
        if (returnCheck.length === 0) {
            return res.status(404).json({
                message: "Purchase return not found."
            });
        }

        // Validate supplier code
        const [supplierCheck] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [supplier_code, company_id]
        );
        if (supplierCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid supplier code for this company."
            });
        }

        // after the supplierCheck block
        if (purchase_grn) {
            const [grnCheck] = await db.query(
                `SELECT id FROM PurchaseMain
                 WHERE grn_no = ? AND company_id = ? AND financialyear_id = ?
                   AND supplier_code = ? AND entry = 'user'`,
                [purchase_grn, company_id, financialyear_id, supplier_code]
            );
            if (grnCheck.length === 0) {
                return res.status(400).json({ message: "Invalid purchase GRN for this supplier." });
            }
        }

        // Check if financial year exists
        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid financial year for this company."
            });
        }

        const freightValue = parseFloat(freight) || 0;

        await db.query(
            `
            UPDATE PurchaseReturnMain
            SET
                company_id = ?,
                department_id = ?,
                financialyear_id = ?,
                return_no = ?,
                return_date = ?,
                gp_no = ?,
                gp_date = ?,
                supplier_code = ?,
                purchase_grn = ?,
                invoice_no = ?,
                invoice_date = ?,
                freight = ?
            WHERE id = ?
            `,
            [
                company_id,
                department_id,
                financialyear_id,
                return_no.trim(),
                return_date,
                gp_no ? gp_no.trim() : null,
                gp_date || null,
                supplier_code,
                purchase_grn ? purchase_grn.trim() : null,
                invoice_no ? invoice_no.trim() : null,
                invoice_date,
                freightValue,
                id
            ]
        );

        await logActivity({
            document_type: "PurchaseReturnMain",
            document_no: return_no.trim(),
            status: "Edit",
            remarks: `Purchase return updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        let warnings = [];
        try {
            const returnChanged =
                String(oldReturnKey.return_no) !== String(return_no.trim()) ||
                Number(oldReturnKey.company_id) !== Number(company_id) ||
                Number(oldReturnKey.financialyear_id) !== Number(financialyear_id);

            if (returnChanged) {
                const connection = await db.getConnection();
                try {
                    await connection.beginTransaction();
                    await deleteAutoEntriesForReturn(connection, oldReturnKey, { performed_by, system_name_ip });
                    await connection.commit();
                } catch (e) {
                    await connection.rollback();
                    throw e;
                } finally {
                    connection.release();
                }
            }

            const syncResult = await syncAutoEntriesForPurchaseReturnMain(id, { performed_by, system_name_ip });
            warnings = syncResult.warnings;
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Purchase return was updated, but auto GL entries could not be fully synced.");
        }

        res.status(200).json({ message: "Purchase return updated successfully.", warnings });

    } catch (error) {
        console.error("Error updating purchase return:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This Return number already exists for the selected company and financial year."
            });
        }

        res.status(500).json({
            message: "Failed to update purchase return.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Purchase Return Main
// ======================================================
exports.deletePurchaseReturnMain = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [mainRows] = await db.query(
            `SELECT company_id, financialyear_id, return_no, entry FROM PurchaseReturnMain WHERE id = ?`,
            [id]
        );
        if (mainRows.length === 0) {
            return res.status(404).json({ message: "Purchase return not found." });
        }
        const mainRow = mainRows[0];

        if (mainRow.entry === "auto") {
            return res.status(400).json({
                message: "Auto-generated purchase return entries cannot be deleted directly. Delete the corresponding user entry instead."
            });
        }

        const [detailCheck] = await db.query(
            `SELECT COUNT(*) as count FROM PurchaseReturnDetail WHERE purchasereturnmain_id = ?`,
            [id]
        );
        if (detailCheck[0].count > 0) {
            return res.status(409).json({
                message: "Cannot delete purchase return as it has associated details. Please delete purchase return details first."
            });
        }

        const connection = await db.getConnection();
        try {
            await connection.beginTransaction();
            // safety net: clears any auto rows left behind for this return
            await deleteAutoEntriesForReturn(connection, {
                company_id: mainRow.company_id,
                financialyear_id: mainRow.financialyear_id,
                return_no: mainRow.return_no
            }, { performed_by, system_name_ip });
            const [result] = await connection.query(`DELETE FROM PurchaseReturnMain WHERE id = ?`, [id]);
            await connection.commit();

            if (result.affectedRows === 0) {
                return res.status(404).json({ message: "Purchase return not found." });
            }
            await logActivity({
                document_type: "PurchaseReturnMain",
                document_no: mainRow.return_no,
                status: "Delete",
                remarks: `Purchase return deleted (ID: ${id})`,
                username: performed_by || "Unknown",
                system_name_ip
            });
            res.status(200).json({ message: "Purchase return deleted successfully." });
        } catch (err) {
            await connection.rollback();
            throw err;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error("Error deleting purchase return:", error);
        res.status(500).json({ message: "Failed to delete purchase return.", error: error.message });
    }
};

// ======================================================
// Get Purchase Return with Details
// ======================================================
exports.getPurchaseReturnWithDetails = async (req, res) => {
    try {
        const { id } = req.params;

        const [returnRows] = await db.query(
            `
            SELECT
                prm.id,
                prm.company_id,
                c.company_name,

                prm.financialyear_id,
                fy.year_detail,

                prm.return_no,
                prm.return_date,
                prm.gp_no,
                prm.gp_date,

                prm.supplier_code,
                prm.purchase_grn,
                coa.account_name AS supplier_name,

                prm.invoice_no,
                prm.invoice_date,
                prm.freight,

                prd.gst_percent,
                prd.gst_amount,
                prd.further_percent,
                prd.further_amount,
                prd.other_tax,

                prm.created_by,
                prm.add_date,
                prm.update_date

            FROM PurchaseReturnMain prm

            INNER JOIN CompanyName c
                ON prm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON prm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON prm.supplier_code = coa.code

            WHERE prm.id = ?
            `,
            [id]
        );

        if (returnRows.length === 0) {
            return res.status(404).json({
                message: "Purchase return not found."
            });
        }

        const [detailRows] = await db.query(
            `
            SELECT
                prd.id,
                prd.company_id,
                prd.purchasereturnmain_id,
                prd.financialyear_id,
                prd.Item_code,
                item.details AS item_name,
                prd.entry_no,
                prd.pieces,
                prd.gross_weight,
                prd.tear_weight,
                prd.net_weight,
                prd.rate,
                prd.amount,
                prd.freight,
                prd.total,
                prd.add_date,
                prd.update_date
            FROM PurchaseReturnDetail prd
            INNER JOIN ItemDetail item
                ON prd.Item_code = item.code AND prd.company_id = item.company_id
            WHERE prd.purchasereturnmain_id = ?
            ORDER BY prd.entry_no ASC
            `,
            [id]
        );

        res.status(200).json({
            ...returnRows[0],
            details: detailRows
        });

    } catch (error) {
        console.error("Error fetching purchase return with details:", error);
        res.status(500).json({
            message: "Failed to fetch purchase return with details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Auto (GL-side) Entries for a Purchase Return
// ======================================================
exports.getAutoEntriesForPurchaseReturnMain = async (req, res) => {
    try {
        const { id } = req.params;

        const [mainRows] = await db.query(
            `SELECT company_id, financialyear_id, return_no FROM PurchaseReturnMain WHERE id = ?`,
            [id]
        );
        if (mainRows.length === 0) {
            return res.status(404).json({ message: "Purchase return not found." });
        }
        const { company_id, financialyear_id, return_no } = mainRows[0];

        const [autoMains] = await db.query(
            `
            SELECT prm.id, prm.supplier_code, coa.account_name AS supplier_name,
                   prm.invoice_no, prm.invoice_date, prm.return_no, prm.return_date,
                   prm.add_date, prm.update_date
            FROM PurchaseReturnMain prm
            LEFT JOIN ChartOfAccount coa
                ON prm.supplier_code = coa.code AND coa.company_id = prm.company_id
            WHERE prm.company_id = ? AND prm.financialyear_id = ? AND prm.return_no = ? AND prm.entry = 'auto'
            ORDER BY prm.supplier_code ASC
            `,
            [company_id, financialyear_id, return_no]
        );

        const groups = [];
        for (const am of autoMains) {
            const [details] = await db.query(
                `
    SELECT prd.id, prd.Item_code, item.details AS item_name, prd.entry_no,
       prd.pieces, prd.net_weight, prd.rate, prd.amount,
       prd.gst_percent, prd.gst_amount, prd.further_percent, prd.further_amount, prd.other_tax,
       prd.total
FROM PurchaseReturnDetail prd
                INNER JOIN ItemDetail item
                    ON prd.Item_code = item.code AND prd.company_id = item.company_id
                WHERE prd.purchasereturnmain_id = ?
                ORDER BY prd.entry_no ASC
                `,
                [am.id]
            );

            const totals = details.reduce(
                (acc, d) => {
                    acc.amount += Number(d.amount) || 0;
                    acc.gst_amount += Number(d.gst_amount) || 0;
                    acc.further_amount += Number(d.further_amount) || 0;
                    acc.other_tax += Number(d.other_tax) || 0;
                    acc.total += Number(d.total) || 0;
                    return acc;
                },
                { amount: 0, gst_amount: 0, further_amount: 0, other_tax: 0, total: 0 }
            );

            groups.push({ ...am, details, totals });
        }

        res.status(200).json({ return_no, groups });
    } catch (error) {
        console.error("Error fetching auto entries:", error);
        res.status(500).json({ message: "Failed to fetch auto entries.", error: error.message });
    }
};