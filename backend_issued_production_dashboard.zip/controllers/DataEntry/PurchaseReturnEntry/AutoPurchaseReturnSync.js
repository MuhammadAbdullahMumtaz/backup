const db = require("../../../config/db"); // adjust path to match your project
const { logActivity } = require("../../../utils/ActivityLogger");

/**
 * Rebuilds every "auto" GL-side PurchaseReturnMain/PurchaseReturnDetail row
 * that belongs to a given user-entered PurchaseReturnMain, based on the
 * current set of *user* PurchaseReturnDetail rows under it. Mirrors
 * syncAutoEntriesForSalesReturnMain, grouped by GL_purchase instead of
 * GL_sale, keyed by return_no instead of invoice_no.
 *
 * NOTE: PurchaseReturnMain (unlike SalesMain/SalesReturnMain) has no
 * `total` column - only `freight`. Auto rows always carry freight = 0;
 * the per-line totals live on PurchaseReturnDetail.
 */
async function syncAutoEntriesForPurchaseReturnMain(userPurchaseReturnMainId, meta = {}) {
    const { performed_by, system_name_ip } = meta;
    const warnings = [];
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        const [mainRows] = await connection.query(
            `SELECT id, company_id, department_id, financialyear_id, return_no, return_date,
                    gp_no, gp_date, invoice_no, invoice_date
             FROM PurchaseReturnMain
             WHERE id = ? AND entry = 'user'
             FOR UPDATE`,
            [userPurchaseReturnMainId]
        );

        if (mainRows.length === 0) {
            await connection.commit();
            return { warnings };
        }
        const userMain = mainRows[0];

        const [detailRows] = await connection.query(
            `SELECT prd.Item_code, prd.pieces, prd.net_weight, prd.rate, prd.amount, prd.total,
                    si.details AS subitem_details, coa.code AS account_code
             FROM PurchaseReturnDetail prd
             INNER JOIN ItemDetail i
                ON prd.Item_code = i.code AND prd.company_id = i.company_id
             INNER JOIN SubItem si
                ON i.subitem_id = si.id
             LEFT JOIN ChartOfAccount coa
                ON si.GL_purchase = coa.code
             WHERE prd.purchasereturnmain_id = ? AND prd.entry = 'user'`,
            [userPurchaseReturnMainId]
        );

        const groups = new Map(); // account_code -> array of detail rows
        for (const row of detailRows) {
            if (!row.account_code) {
                warnings.push(
                    `Item "${row.Item_code}" (Sub Item "${row.subitem_details}") has no GL Purchase account configured - skipped in auto entry.`
                );
                continue;
            }
            if (!groups.has(row.account_code)) groups.set(row.account_code, []);
            groups.get(row.account_code).push(row);
        }

        const [existingAutoMains] = await connection.query(
            `SELECT id, supplier_code
             FROM PurchaseReturnMain
             WHERE company_id = ? AND financialyear_id = ? AND return_no = ? AND entry = 'auto'`,
            [userMain.company_id, userMain.financialyear_id, userMain.return_no]
        );
        const existingByCode = new Map(existingAutoMains.map((m) => [m.supplier_code, m.id]));

        // Drop auto mains whose account code is no longer represented
        for (const [code, id] of existingByCode) {
            if (!groups.has(code)) {
                await connection.query(`DELETE FROM PurchaseReturnDetail WHERE purchasereturnmain_id = ?`, [id]);
                await connection.query(`DELETE FROM PurchaseReturnMain WHERE id = ?`, [id]);
                existingByCode.delete(code);

                await logActivity({
                    document_type: "PurchaseReturnMain(Auto)",
                    document_no: userMain.return_no,
                    status: "Delete",
                    remarks: `Auto GL entry removed (GL account: ${code}) - no longer represented`,
                    username: performed_by || "Unknown",
                    system_name_ip
                });
            }
        }

        // Upsert one auto main per remaining/new account code
        for (const [code, rows] of groups) {
            let autoMainId = existingByCode.get(code);
            const isNewAutoMain = !autoMainId;

            if (autoMainId) {
                await connection.query(
                    `UPDATE PurchaseReturnMain
                     SET department_id = ?, gp_no = ?, gp_date = ?,
                         invoice_no = ?, invoice_date = ?, freight = ?
                     WHERE id = ?`,
                    [
                        userMain.department_id, userMain.gp_no, userMain.gp_date,
                        userMain.invoice_no, userMain.invoice_date, 0, autoMainId,
                    ]
                );
                await connection.query(`DELETE FROM PurchaseReturnDetail WHERE purchasereturnmain_id = ?`, [autoMainId]);
            } else {
                // FIXED: was missing userMain.invoice_date in this array,
                // leaving 11 values for 12 columns (ER_WRONG_VALUE_COUNT_ON_ROW).
                const [insertResult] = await connection.query(
                    `INSERT INTO PurchaseReturnMain
                        (company_id, department_id, financialyear_id, return_no, return_date, gp_no, gp_date,
                         supplier_code, invoice_no, invoice_date, freight, entry)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'auto')`,
                    [
                        userMain.company_id, userMain.department_id, userMain.financialyear_id,
                        userMain.return_no, userMain.return_date, userMain.gp_no, userMain.gp_date,
                        code, userMain.invoice_no, userMain.invoice_date, 0,
                    ]
                );
                autoMainId = insertResult.insertId;
            }

            let entryNo = 1;
            for (const row of rows) {
                await connection.query(
                    `INSERT INTO PurchaseReturnDetail
                        (company_id, purchasereturnmain_id, financialyear_id, Item_code, entry_no, entry,
                         pieces, net_weight, rate, amount, freight, total)
                     VALUES (?, ?, ?, ?, ?, 'auto', ?, ?, ?, ?, 0, ?)`,
                    [
                        userMain.company_id, autoMainId, userMain.financialyear_id,
                        row.Item_code, entryNo++, row.pieces, row.net_weight, row.rate, row.amount,
                        row.total,
                    ]
                );
            }
            await logActivity({
                document_type: "PurchaseReturnMain(Auto)",
                document_no: userMain.return_no,
                status: isNewAutoMain ? "New" : "Edit",
                remarks: `Auto GL entry ${isNewAutoMain ? "created" : "synced"} (GL account: ${code}, ${rows.length} line(s))`,
                username: performed_by || "Unknown",
                system_name_ip
            });
        }

        await connection.commit();
        return { warnings };
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
}

/**
 * Deletes every auto row belonging to a given return group. Used when the
 * user's PurchaseReturnMain itself is deleted, or when its (company, FY,
 * return_no) key changes. Caller controls the transaction.
 */
async function deleteAutoEntriesForReturn(connection, { company_id, financialyear_id, return_no }, meta = {}) {
    const { performed_by, system_name_ip } = meta;
    const [autoMains] = await connection.query(
        `SELECT id, supplier_code FROM PurchaseReturnMain
         WHERE company_id = ? AND financialyear_id = ? AND return_no = ? AND entry = 'auto'`,
        [company_id, financialyear_id, return_no]
    );
    for (const m of autoMains) {
        await connection.query(`DELETE FROM PurchaseReturnDetail WHERE purchasereturnmain_id = ?`, [m.id]);
        await connection.query(`DELETE FROM PurchaseReturnMain WHERE id = ?`, [m.id]);

        await logActivity({
            document_type: "PurchaseReturnMain(Auto)",
            document_no: return_no,
            status: "Delete",
            remarks: `Auto GL entry deleted (GL account: ${m.supplier_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });
    }
}

module.exports = {
    syncAutoEntriesForPurchaseReturnMain,
    deleteAutoEntriesForReturn,
};