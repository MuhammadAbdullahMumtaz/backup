const db = require("../../../../config/db");
const { syncAutoEntriesForPurchaseMain } = require("../AutoPurchaseSync");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Purchase Details
// ======================================================
exports.getAllPurchaseDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                pd.id,
                pd.company_id,
                c.company_name,
                pd.purchasemain_id,
                pm.grn_no,
                pd.financialyear_id,
                fy.year_detail,
                pd.Item_code,
                item.details AS item_name,
                pd.entry_no,
                pd.pieces,
                pd.gross_weight,
                pd.tear_weight,
                pd.net_weight,
                pd.rate,
                pd.gst_percent,
                pd.gst_amount,
                pd.further_percent,
                pd.further_amount,
                pd.other_tax,
                pd.amount,
                pd.freight,
                pd.total,
                pd.add_date,
                pd.update_date
            FROM PurchaseDetail pd
            INNER JOIN CompanyName c
                ON pd.company_id = c.id
            INNER JOIN PurchaseMain pm
                ON pd.purchasemain_id = pm.id
            INNER JOIN FinancialYear fy
                ON pd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON pd.Item_code = item.code AND pd.company_id = item.company_id
            ORDER BY
                pm.grn_no,
                pd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching purchase details:", error);
        res.status(500).json({
            message: "Failed to fetch purchase details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Purchase Details By Purchase Main ID
// ======================================================
exports.getPurchaseDetailsByPurchaseMain = async (req, res) => {
    try {
        const { purchasemain_id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                pd.id,
                pd.company_id,
                c.company_name,
                pd.purchasemain_id,
                pm.grn_no,
                pd.financialyear_id,
                fy.year_detail,
                pd.Item_code,
                item.details AS item_name,
                pd.entry_no,
                pd.stocks,
                pd.pieces,
                pd.gross_weight,
                pd.tear_weight,
                pd.net_weight,
                pd.rate,
                pd.gst_percent,
                pd.gst_amount,
                pd.further_percent,
                pd.further_amount,
                pd.other_tax,
                pd.amount,
                pd.freight,
                pd.total,
                pd.add_date,
                pd.update_date
            FROM PurchaseDetail pd
            INNER JOIN CompanyName c
                ON pd.company_id = c.id
            INNER JOIN PurchaseMain pm
                ON pd.purchasemain_id = pm.id
            INNER JOIN FinancialYear fy
                ON pd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON pd.Item_code = item.code AND pd.company_id = item.company_id
            WHERE pd.purchasemain_id = ?
            ORDER BY pd.entry_no ASC
            `,
            [purchasemain_id]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching purchase details by purchase:", error);
        res.status(500).json({
            message: "Failed to fetch purchase details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Purchase Detail By ID
// ======================================================
exports.getPurchaseDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                pd.id,
                pd.company_id,
                c.company_name,
                pd.purchasemain_id,
                pm.grn_no,
                pd.financialyear_id,
                fy.year_detail,
                pd.Item_code,
                item.details AS item_name,
                pd.entry_no,
                pd.stocks,
                pd.pieces,
                pd.gross_weight,
                pd.tear_weight,
                pd.net_weight,
                pd.rate,
                pd.gst_percent,
                pd.gst_amount,
                pd.further_percent,
                pd.further_amount,
                pd.other_tax,
                pd.amount,
                pd.freight,
                pd.total,
                pd.add_date,
                pd.update_date
            FROM PurchaseDetail pd
            INNER JOIN CompanyName c
                ON pd.company_id = c.id
            INNER JOIN PurchaseMain pm
                ON pd.purchasemain_id = pm.id
            INNER JOIN FinancialYear fy
                ON pd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON pd.Item_code = item.code AND pd.company_id = item.company_id
            WHERE pd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Purchase detail not found."
            });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching purchase detail:", error);
        res.status(500).json({
            message: "Failed to fetch purchase detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Purchase Detail
// ======================================================
exports.addPurchaseDetail = async (req, res) => {
    try {
        // AFTER
        const {
            company_id,
            purchasemain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            rate,
            freight,
            gst_percent,
            further_percent,
            other_tax,
            total,
            performed_by,
            system_name_ip
        } = req.body;

        // Validate required fields
        // NOTE: financialyear_id is NOT taken from req.body - it's always
        // derived from the parent PurchaseMain row below, so it can never
        // drift out of sync with the purchase it belongs to.
        if (!company_id || !purchasemain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Purchase Main, Item Code, and Entry No are required."
            });
        }

        // Validate entry_no is positive
        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        // Validate Item_code length (matches VARCHAR(8) column)
        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        // AFTER
        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const freightValue = parseFloat(freight) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({
                message: "Pieces cannot be negative."
            });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({
                message: "Net weight cannot be negative."
            });
        }
        if (rateValue < 0) {
            return res.status(400).json({
                message: "Rate cannot be negative."
            });
        }

        const amountValue = netWeightValue * rateValue;

        const gstPercentValue = parseFloat(gst_percent) || 0;
        const furtherPercentValue = parseFloat(further_percent) || 0;
        const otherTaxValue = parseFloat(other_tax) || 0;

        if (gstPercentValue < 0) {
            return res.status(400).json({ message: "GST percent cannot be negative." });
        }
        if (furtherPercentValue < 0) {
            return res.status(400).json({ message: "Further tax percent cannot be negative." });
        }
        if (otherTaxValue < 0) {
            return res.status(400).json({ message: "Other tax cannot be negative." });
        }

        const gstAmountValue = parseFloat(((amountValue * gstPercentValue) / 100).toFixed(2));
        const furtherAmountValue = parseFloat(((amountValue * furtherPercentValue) / 100).toFixed(2));

        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue + gstAmountValue + furtherAmountValue + otherTaxValue;

        const [purchaseCheck] = await db.query(
            `SELECT id, financialyear_id, grn_no  FROM PurchaseMain WHERE id = ? AND company_id = ?`,
            [purchasemain_id, company_id]
        );
        if (purchaseCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid purchase for this company."
            });
        }
        const { financialyear_id, grn_no } = purchaseCheck[0];

        // Check if item exists in item master
        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        const [result] = await db.query(
            `INSERT INTO PurchaseDetail
    (
        company_id, purchasemain_id, financialyear_id, Item_code, entry_no,
        pieces, gross_weight, tear_weight, net_weight, rate, amount, freight,
        gst_percent, gst_amount, further_percent, further_amount, other_tax, total
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                company_id, purchasemain_id, financialyear_id, Item_code, entry_no,
                piecesValue, grossWeightValue, tearWeightValue, netWeightValue, rateValue, amountValue, freightValue,
                gstPercentValue, gstAmountValue, furtherPercentValue, furtherAmountValue, otherTaxValue, totalValue
            ]
        );

        await logActivity({
            document_type: "PurchaseDetail",
            document_no: `${grn_no}-${entry_no}`,
            status: "New",
            remarks: `Purchase line added (Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        let warnings = [];
        try {
            const syncResult = await syncAutoEntriesForPurchaseMain(purchasemain_id, { performed_by, system_name_ip });
            warnings = syncResult.warnings;
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Purchase entry was saved, but auto GL entries could not be fully synced.");
        }

        res.status(201).json({
            message: "Purchase detail added successfully.",
            id: result.insertId,
            warnings
        });
    } catch (error) {
        console.error("Error adding purchase detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this purchase."
            });
        }
        res.status(500).json({
            message: "Failed to add purchase detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Purchase Detail
// ======================================================
exports.updatePurchaseDetail = async (req, res) => {
    try {
        const { id } = req.params;
        // AFTER
        const {
            company_id,
            purchasemain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            rate,
            freight,
            gst_percent,
            further_percent,
            other_tax,
            total,
            performed_by,
            system_name_ip
        } = req.body;

        // Block direct edits of auto-generated rows, and remember which
        // purchase main this row belonged to before the update (it may move).
        const [existingRow] = await db.query(
            `SELECT purchasemain_id, entry FROM PurchaseDetail WHERE id = ?`,
            [id]
        );
        if (existingRow.length === 0) {
            return res.status(404).json({ message: "Purchase detail not found." });
        }
        if (existingRow[0].entry === "auto") {
            return res.status(400).json({
                message: "Auto-generated entries cannot be edited directly."
            });
        }

        // ===== NEW GUARD: stock consumption check =====
        const netWeightRequested = parseFloat(net_weight) || 0;
        const piecesRequested = parseInt(pieces) || 0;

        // Find every Sales entry currently drawing from this lot.
        const [consumingSales] = await db.query(
            `SELECT sd.net_weight, sm.invoice_no, sm.id AS sale_main_id
             FROM SalesDetail sd
             INNER JOIN SalesMain sm ON sd.sale_main = sm.id
             WHERE sd.source_type = 'purchase' AND sd.source_detail_id = ?`,
            [id]
        );
        const consumedWeight = consumingSales.reduce((s, r) => s + Number(r.net_weight), 0);

        // Case 1: lot is fully "out" - block pieces/net_weight changes entirely.
        if (existingRow[0].stocks === 'out') {
            const piecesChanged = piecesRequested !== Number(existingRow[0].old_pieces);
            const netWeightChanged = netWeightRequested !== Number(existingRow[0].old_net_weight);
            if (piecesChanged || netWeightChanged) {
                const invoiceList = [...new Set(consumingSales.map((r) => r.invoice_no))];
                return res.status(409).json({
                    message: `This stock is fully consumed by Sale invoice(s): ${invoiceList.join(', ') || 'N/A'}. Delete those sale entries first before changing Pieces or Net Weight.`,
                    consuming_sales: invoiceList
                });
            }
        }
        // Case 2: lot is partially consumed - block reducing net_weight below
        // what's already been sold out of it.
        else if (consumedWeight > 0 && netWeightRequested < consumedWeight) {
            const invoiceList = [...new Set(consumingSales.map((r) => r.invoice_no))];
            return res.status(409).json({
                message: `Cannot reduce Net Weight below ${consumedWeight} - it is already used by Sale invoice(s): ${invoiceList.join(', ')}. Delete or reduce those sale entries first.`,
                consuming_sales: invoiceList
            });
        }
        // ===== END NEW GUARD =====

        const oldPurchaseMainId = existingRow[0].purchasemain_id;
        if (!company_id || !purchasemain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Purchase Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        // AFTER
        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const freightValue = parseFloat(freight) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({
                message: "Pieces cannot be negative."
            });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({
                message: "Net weight cannot be negative."
            });
        }
        if (rateValue < 0) {
            return res.status(400).json({
                message: "Rate cannot be negative."
            });
        }

        const amountValue = netWeightValue * rateValue;

        const gstPercentValue = parseFloat(gst_percent) || 0;
        const furtherPercentValue = parseFloat(further_percent) || 0;
        const otherTaxValue = parseFloat(other_tax) || 0;

        if (gstPercentValue < 0) {
            return res.status(400).json({ message: "GST percent cannot be negative." });
        }
        if (furtherPercentValue < 0) {
            return res.status(400).json({ message: "Further tax percent cannot be negative." });
        }
        if (otherTaxValue < 0) {
            return res.status(400).json({ message: "Other tax cannot be negative." });
        }

        const gstAmountValue = parseFloat(((amountValue * gstPercentValue) / 100).toFixed(2));
        const furtherAmountValue = parseFloat(((amountValue * furtherPercentValue) / 100).toFixed(2));

        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue + gstAmountValue + furtherAmountValue + otherTaxValue;

        // Check if purchase detail exists
        const [detailCheck] = await db.query(
            `SELECT id FROM PurchaseDetail WHERE id = ?`,
            [id]
        );
        if (detailCheck.length === 0) {
            return res.status(404).json({
                message: "Purchase detail not found."
            });
        }

        // Check if purchase exists, and re-derive financialyear_id from it -
        // covers the case where purchasemain_id itself changed on update.
        const [purchaseCheck] = await db.query(
            `SELECT id, financialyear_id, grn_no  FROM PurchaseMain WHERE id = ? AND company_id = ?`,
            [purchasemain_id, company_id]
        );
        if (purchaseCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid purchase for this company."
            });
        }
        const { financialyear_id, grn_no } = purchaseCheck[0];

        // Check if item exists
        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        await db.query(
            `
            UPDATE PurchaseDetail
            SET
                company_id = ?,
                purchasemain_id = ?,
                financialyear_id = ?,
                Item_code = ?,
                entry_no = ?,
                pieces = ?,
                gross_weight = ?,
                tear_weight = ?,
                net_weight = ?,
                rate = ?,
                amount = ?,
                freight = ?,
                gst_percent = ?, gst_amount = ?, further_percent = ?, further_amount = ?, other_tax = ?,
                total = ?
            WHERE id = ?
            `,
            [
                company_id,
                purchasemain_id,
                financialyear_id,
                Item_code,
                entry_no,
                piecesValue,
                grossWeightValue,
                tearWeightValue,
                netWeightValue,
                rateValue,
                amountValue,
                freightValue,
                gstPercentValue,
                gstAmountValue,
                furtherPercentValue,
                furtherAmountValue,
                otherTaxValue,
                totalValue,
                id
            ]
        );

        await logActivity({
            document_type: "PurchaseDetail",
            document_no: `${grn_no}-${entry_no}`,
            status: "Edit",
            remarks: `Purchase line updated (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        let warnings = [];
        try {
            if (oldPurchaseMainId && Number(oldPurchaseMainId) !== Number(purchasemain_id)) {
                const oldSync = await syncAutoEntriesForPurchaseMain(oldPurchaseMainId, { performed_by, system_name_ip });
                warnings.push(...oldSync.warnings);
            }
            const newSync = await syncAutoEntriesForPurchaseMain(purchasemain_id, { performed_by, system_name_ip });
            warnings.push(...newSync.warnings);
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Entry was updated, but auto GL entries could not be fully synced.");
        }

        res.status(200).json({
            message: "Purchase detail updated successfully.",
            warnings
        });

    } catch (error) {
        console.error("Error updating purchase detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this purchase."
            });
        }
        res.status(500).json({
            message: "Failed to update purchase detail.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Purchase Detail
// ======================================================
exports.deletePurchaseDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [rows] = await db.query(
            `SELECT pd.purchasemain_id, pd.entry, pd.entry_no, pd.Item_code, pm.grn_no
             FROM PurchaseDetail pd
             INNER JOIN PurchaseMain pm ON pd.purchasemain_id = pm.id
             WHERE pd.id = ?`,   // widened join
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Purchase detail not found." });
        }
        const { purchasemain_id, entry, entry_no, Item_code, grn_no } = rows[0];

        if (entry === "auto") {
            return res.status(400).json({
                message: "Auto-generated entries cannot be deleted directly. Delete or edit the corresponding user entry instead."
            });
        }

        // ===== NEW GUARD =====
        const [consumingSales] = await db.query(
            `SELECT sm.invoice_no
             FROM SalesDetail sd
             INNER JOIN SalesMain sm ON sd.sale_main = sm.id
             WHERE sd.source_type = 'purchase' AND sd.source_detail_id = ?`,
            [id]
        );
        if (consumingSales.length > 0) {
            const invoiceList = [...new Set(consumingSales.map((r) => r.invoice_no))];
            return res.status(409).json({
                message: `Cannot delete - this stock is used by Sale invoice(s): ${invoiceList.join(', ')}. Delete those sale entries first.`,
                consuming_sales: invoiceList
            });
        }
        // ===== END NEW GUARD =====

        const [result] = await db.query(`DELETE FROM PurchaseDetail WHERE id = ?`, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Purchase detail not found." });
        }

        await logActivity({
            document_type: "PurchaseDetail",
            document_no: `${grn_no}-${entry_no}`,
            status: "Delete",
            remarks: `Purchase line deleted (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        let warnings = [];
        try {
            const syncResult = await syncAutoEntriesForPurchaseMain(purchasemain_id, { performed_by, system_name_ip });
            warnings = syncResult.warnings;
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Entry was deleted, but auto GL entries could not be fully synced.");
        }

        res.status(200).json({ message: "Purchase detail deleted successfully.", warnings });
    } catch (error) {
        console.error("Error deleting purchase detail:", error);
        res.status(500).json({
            message: "Failed to delete purchase detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Purchase Detail Stock Status (available -> out)
// ======================================================
exports.updatePurchaseDetailStockStatus = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT id, stocks FROM PurchaseDetail WHERE id = ?`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Purchase detail not found." });
        }
        if (rows[0].stocks === "out") {
            return res.status(400).json({ message: "Stock is already marked as out." });
        }

        await db.query(
            `UPDATE PurchaseDetail SET stocks = 'out' WHERE id = ?`,
            [id]
        );

        res.status(200).json({ message: "Stock status updated to out." });
    } catch (error) {
        console.error("Error updating purchase detail stock status:", error);
        res.status(500).json({
            message: "Failed to update stock status.",
            error: error.message
        });
    }
};