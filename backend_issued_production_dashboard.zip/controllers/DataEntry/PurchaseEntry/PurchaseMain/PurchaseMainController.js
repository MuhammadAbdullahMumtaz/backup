const db = require("../../../../config/db");
const { syncAutoEntriesForPurchaseMain, deleteAutoEntriesForGrn } = require("../AutoPurchaseSync");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Purchase Mains
// ======================================================
exports.getAllPurchaseMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                pm.id,
                pm.company_id,
                c.company_name,

                pm.financialyear_id,
                fy.year_detail,

                pm.grn_no,
                pm.grn_date,
                pm.gp_no,
                pm.gp_date,

                pm.supplier_code,
                coa.account_name AS supplier_name,

                pm.invoice_no,
                pm.invoice_date,
                pm.freight,
                pm.entry,

                pm.created_by,
                pm.add_date,
                pm.update_date

            FROM PurchaseMain pm

            INNER JOIN CompanyName c
                ON pm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON pm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON pm.supplier_code = coa.code

            ORDER BY pm.grn_no ASC
        `);

        res.status(200).json(rows);

    } catch (error) {
        console.error("Error fetching purchases:", error);
        res.status(500).json({
            message: "Failed to fetch purchases.",
            error: error.message
        });
    }
};

// ======================================================
// Get Next GRN Number
// ======================================================
// Unlike VoucherMain (which scopes voucher_no by month), PurchaseMain's
// unique key is (company_id, financialyear_id, grn_no) with no month
// component, so GRN numbers run continuously across the whole financial year.
exports.getNextGrnNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.params;

        if (!company_id || !financialyear_id) {
            return res.status(400).json({
                message: "Company ID and Financial Year ID are required."
            });
        }

        const [rows] = await db.query(
            `
            SELECT MAX(CAST(SUBSTRING_INDEX(grn_no, '-', -1) AS UNSIGNED)) as max_grn_no
            FROM PurchaseMain
            WHERE company_id = ?
              AND financialyear_id = ?
            `,
            [company_id, financialyear_id]
        );

        const maxGrnNo = rows[0].max_grn_no || 0;
        const nextNumber = maxGrnNo + 1;

        res.status(200).json({
            next_grn_number: nextNumber
        });

    } catch (error) {
        console.error("Error generating next GRN number:", error);
        res.status(500).json({
            message: "Failed to generate next GRN number.",
            error: error.message
        });
    }
};

// ======================================================
// Get Purchase Main By ID
// ======================================================
exports.getPurchaseMainById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                pm.id,
                pm.company_id,
                c.company_name,

                pm.financialyear_id,
                fy.year_detail,

                pm.grn_no,
                pm.grn_date,
                pm.gp_no,
                pm.gp_date,

                pm.supplier_code,
                coa.account_name AS supplier_name,

                pm.invoice_no,
                pm.invoice_date,
                pm.freight,
                pm.entry,

                pm.created_by,
                pm.add_date,
                pm.update_date

            FROM PurchaseMain pm

            INNER JOIN CompanyName c
                ON pm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON pm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON pm.supplier_code = coa.code

            WHERE pm.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Purchase not found."
            });
        }

        res.status(200).json(rows[0]);

    } catch (error) {
        console.error("Error fetching purchase:", error);
        res.status(500).json({
            message: "Failed to fetch purchase.",
            error: error.message
        });
    }
};

// ======================================================
// Add Purchase Main
// ======================================================
exports.addPurchaseMain = async (req, res) => {
    const {
        company_id,
        department_id,
        financialyear_id,
        grn_date,
        gp_no,
        gp_date,
        supplier_code,
        invoice_no,
        invoice_date,
        freight,
        performed_by,
        system_name_ip
    } = req.body;

    // Validate required fields (grn_no is no longer accepted from the client -
    // it's generated atomically below)
    if (!company_id || !department_id || !financialyear_id || !grn_date ||   // department_id added
        !supplier_code) {
        return res.status(400).json({
            message: "Company, department, financial year, GRN date, and supplier are all required."
        });
    }

    if (gp_no && !gp_date) {
        return res.status(400).json({
            message: "GP date is required when GP number is provided."
        });
    }
    if (gp_date && !gp_no) {
        return res.status(400).json({
            message: "GP number is required when GP date is provided."
        });
    }

    const freightValue = parseFloat(freight) || 0;

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        const [departmentCheck] = await conn.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [supplierCheck] = await conn.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [supplier_code, company_id]
        );
        if (supplierCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid supplier code for this company." });
        }

        const [financialYearCheck] = await conn.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        // Atomic increment - the GRN counter is scoped to (company, financial
        // year) only, NOT supplier, since the compound unique key on
        // PurchaseMain (company, fy, grn_no, supplier_code) is what allows
        // the auto GL-sync rows to reuse the same grn_no per supplier. This
        // statement takes an exclusive row lock, so a second concurrent
        // request for the same company/FY blocks here until this one
        // commits, then gets the next number - never the same one.
        await conn.query(
            `INSERT INTO PurchaseSequence (company_id, financialyear_id, last_no)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE last_no = last_no + 1`,
            [company_id, financialyear_id]
        );

        const [seqRow] = await conn.query(
            `SELECT last_no FROM PurchaseSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const nextNumber = seqRow[0].last_no;
        const grnNo = String(nextNumber);

        const [result] = await conn.query(
            `INSERT INTO PurchaseMain
    (company_id, department_id, financialyear_id, grn_no, grn_date, gp_no, gp_date,
     supplier_code, invoice_no, invoice_date, freight, created_by)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [company_id, department_id, financialyear_id, grnNo, grn_date,
                gp_no ? gp_no.trim() : null, gp_date || null, supplier_code,
                invoice_no.trim(), invoice_date, freightValue,
                performed_by || 'Unknown']
        );

        await conn.commit();
        await logActivity({
            document_type: "PurchaseMain",
            document_no: grnNo,
            status: "New",
            remarks: `Purchase (GRN) created (Supplier: ${supplier_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            message: "Purchase created successfully.",
            id: result.insertId,
            grn_no: grnNo
        });
    } catch (error) {
        await conn.rollback();
        console.error("Error adding purchase:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This GRN number already exists for the selected company, financial year, and supplier."
            });
        }
        res.status(500).json({ message: "Failed to create purchase.", error: error.message });
    } finally {
        conn.release();
    }
};

// ======================================================
// Update Purchase Main
// ======================================================
exports.updatePurchaseMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            department_id,
            financialyear_id,
            grn_no,
            grn_date,
            gp_no,
            gp_date,
            supplier_code,
            invoice_no,
            invoice_date,
            freight,
            performed_by,
            system_name_ip
        } = req.body;

        const [existingMain] = await db.query(
            `SELECT company_id, financialyear_id, grn_no, entry FROM PurchaseMain WHERE id = ?`,
            [id]
        );
        if (existingMain.length === 0) {
            return res.status(404).json({ message: "Purchase not found." });
        }
        if (existingMain[0].entry === "auto") {
            return res.status(400).json({ message: "Auto-generated purchase headers cannot be edited directly." });
        }
        const oldGrnKey = {
            company_id: existingMain[0].company_id,
            financialyear_id: existingMain[0].financialyear_id,
            grn_no: existingMain[0].grn_no
        };

        if (!company_id || !department_id || !financialyear_id || !grn_no || !grn_date ||
            !supplier_code || !invoice_no || !invoice_date) {
            return res.status(400).json({
                message: "Company, department, financial year, GRN number, GRN date, supplier, invoice number, and invoice date are all required."
            });
        }

        const [departmentCheck] = await db.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        if (!grn_no.trim()) {
            return res.status(400).json({
                message: "GRN number cannot be empty."
            });
        }

        if (!invoice_no.trim()) {
            return res.status(400).json({
                message: "Invoice number cannot be empty."
            });
        }

        if (gp_no && !gp_date) {
            return res.status(400).json({
                message: "GP date is required when GP number is provided."
            });
        }
        if (gp_date && !gp_no) {
            return res.status(400).json({
                message: "GP number is required when GP date is provided."
            });
        }

        // Check if purchase exists
        const [purchaseCheck] = await db.query(
            `SELECT id FROM PurchaseMain WHERE id = ?`,
            [id]
        );
        if (purchaseCheck.length === 0) {
            return res.status(404).json({
                message: "Purchase not found."
            });
        }

        // Validate supplier code
        const [supplierCheck] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [supplier_code, company_id]
        );
        if (supplierCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid supplier code for this company."
            });
        }

        // Check if financial year exists
        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid financial year for this company."
            });
        }

        const freightValue = parseFloat(freight) || 0;

        await db.query(
            `
    UPDATE PurchaseMain
    SET
        company_id = ?,
        department_id = ?,
        financialyear_id = ?,
        grn_no = ?,
        grn_date = ?,
        gp_no = ?,
        gp_date = ?,
        supplier_code = ?,
        invoice_no = ?,
        invoice_date = ?,
        freight = ?
    WHERE id = ?
    `,
            [
                company_id,
                department_id,
                financialyear_id,
                grn_no.trim(),
                grn_date,
                gp_no ? gp_no.trim() : null,
                gp_date || null,
                supplier_code,
                invoice_no.trim(),
                invoice_date,
                freightValue,
                id
            ]
        );

        await logActivity({
            document_type: "PurchaseMain",
            document_no: grn_no.trim(),
            status: "Edit",
            remarks: `Purchase (GRN) updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        let warnings = [];
        try {
            const grnChanged =
                String(oldGrnKey.grn_no) !== String(grn_no.trim()) ||
                Number(oldGrnKey.company_id) !== Number(company_id) ||
                Number(oldGrnKey.financialyear_id) !== Number(financialyear_id);

            if (grnChanged) {
                const connection = await db.getConnection();
                try {
                    await connection.beginTransaction();
                    await deleteAutoEntriesForGrn(connection, oldGrnKey, { performed_by, system_name_ip });
                    await connection.commit();
                } catch (e) {
                    await connection.rollback();
                    throw e;
                } finally {
                    connection.release();
                }
            }

            const syncResult = await syncAutoEntriesForPurchaseMain(id, { performed_by, system_name_ip });
            warnings = syncResult.warnings;
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Purchase was updated, but auto GL entries could not be fully synced.");
        }

        res.status(200).json({ message: "Purchase updated successfully.", warnings });

    } catch (error) {
        console.error("Error updating purchase:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This GRN number already exists for the selected company and financial year."
            });
        }

        res.status(500).json({
            message: "Failed to update purchase.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Purchase Main
// ======================================================
exports.deletePurchaseMain = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [mainRows] = await db.query(
            `SELECT company_id, financialyear_id, grn_no, entry FROM PurchaseMain WHERE id = ?`,
            [id]
        );
        if (mainRows.length === 0) {
            return res.status(404).json({ message: "Purchase not found." });
        }
        const mainRow = mainRows[0];

        if (mainRow.entry === "auto") {
            return res.status(400).json({
                message: "Auto-generated purchase entries cannot be deleted directly. Delete the corresponding user entry instead."
            });
        }

        const [detailCheck] = await db.query(
            `SELECT COUNT(*) as count FROM PurchaseDetail WHERE purchasemain_id = ?`,
            [id]
        );
        if (detailCheck[0].count > 0) {
            return res.status(409).json({
                message: "Cannot delete purchase as it has associated details. Please delete purchase details first."
            });
        }

        const connection = await db.getConnection();
        try {
            await connection.beginTransaction();
            // safety net: clears any auto rows left behind for this grn
            await deleteAutoEntriesForGrn(connection, {
                company_id: mainRow.company_id,
                financialyear_id: mainRow.financialyear_id,
                grn_no: mainRow.grn_no
            }, { performed_by, system_name_ip });
            const [result] = await connection.query(`DELETE FROM PurchaseMain WHERE id = ?`, [id]);
            await connection.commit();

            if (result.affectedRows === 0) {
                return res.status(404).json({ message: "Purchase not found." });
            }

            await logActivity({
                document_type: "PurchaseMain",
                document_no: mainRow.grn_no,
                status: "Delete",
                remarks: `Purchase (GRN) deleted (ID: ${id})`,
                username: performed_by || "Unknown",
                system_name_ip
            });

            res.status(200).json({ message: "Purchase deleted successfully." });
        } catch (err) {
            await connection.rollback();
            throw err;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error("Error deleting purchase:", error);
        res.status(500).json({ message: "Failed to delete purchase.", error: error.message });
    }
};

// ======================================================
// Get Purchase with Details
// ======================================================
exports.getPurchaseWithDetails = async (req, res) => {
    try {
        const { id } = req.params;

        const [purchaseRows] = await db.query(
            `
            SELECT
                pm.id,
                pm.company_id,
                c.company_name,

                pm.financialyear_id,
                fy.year_detail,

                pm.grn_no,
                pm.grn_date,
                pm.gp_no,
                pm.gp_date,

                pm.supplier_code,
                coa.account_name AS supplier_name,

                pm.invoice_no,
                pm.invoice_date,
                pm.freight,

                pm.created_by,
                pm.add_date,
                pm.update_date

            FROM PurchaseMain pm

            INNER JOIN CompanyName c
                ON pm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON pm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON pm.supplier_code = coa.code

            WHERE pm.id = ?
            `,
            [id]
        );

        if (purchaseRows.length === 0) {
            return res.status(404).json({
                message: "Purchase not found."
            });
        }

        const [detailRows] = await db.query(
            `
            SELECT
                pd.id,
                pd.company_id,
                pd.purchasemain_id,
                pd.financialyear_id,
                pd.Item_code,
                item.details AS item_name,
                pd.entry_no,
                pd.pieces,
                pd.gross_weight,
                pd.tear_weight,
                pd.net_weight,
                pd.rate,
                pd.amount,
                pd.freight,
                pd.gst_percent,
                pd.gst_amount,
                pd.further_percent,
                pd.further_amount,
                pd.other_tax,
                pd.total,
                pd.add_date,
                pd.update_date
            FROM PurchaseDetail pd
            INNER JOIN ItemDetail item
                ON pd.Item_code = item.code AND pd.company_id = item.company_id
            WHERE pd.purchasemain_id = ?
            ORDER BY pd.entry_no ASC
            `,
            [id]
        );

        res.status(200).json({
            ...purchaseRows[0],
            details: detailRows
        });

    } catch (error) {
        console.error("Error fetching purchase with details:", error);
        res.status(500).json({
            message: "Failed to fetch purchase with details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Auto (GL-side) Entries for a Purchase
// ======================================================
exports.getAutoEntriesForPurchaseMain = async (req, res) => {
    try {
        const { id } = req.params;

        const [mainRows] = await db.query(
            `SELECT company_id, financialyear_id, grn_no FROM PurchaseMain WHERE id = ?`,
            [id]
        );
        if (mainRows.length === 0) {
            return res.status(404).json({ message: "Purchase not found." });
        }
        const { company_id, financialyear_id, grn_no } = mainRows[0];

        const [autoMains] = await db.query(
            `
            SELECT pm.id, pm.supplier_code, coa.account_name AS supplier_name,
                   pm.invoice_no, pm.invoice_date, pm.grn_no, pm.grn_date,
                   pm.add_date, pm.update_date
            FROM PurchaseMain pm
            LEFT JOIN ChartOfAccount coa
                ON pm.supplier_code = coa.code AND coa.company_id = pm.company_id
            WHERE pm.company_id = ? AND pm.financialyear_id = ? AND pm.grn_no = ? AND pm.entry = 'auto'
            ORDER BY pm.supplier_code ASC
            `,
            [company_id, financialyear_id, grn_no]
        );

        const groups = [];
        for (const am of autoMains) {
            const [details] = await db.query(
                `
                SELECT pd.id, pd.Item_code, item.details AS item_name, pd.entry_no,
                       pd.pieces, pd.net_weight, pd.rate, pd.amount,
                       pd.gst_percent, pd.gst_amount,
                       pd.further_percent, pd.further_amount,
                       pd.other_tax, pd.total
                FROM PurchaseDetail pd
                INNER JOIN ItemDetail item
                    ON pd.Item_code = item.code AND pd.company_id = item.company_id
                WHERE pd.purchasemain_id = ?
                ORDER BY pd.entry_no ASC
                `,
                [am.id]
            );

            const totals = details.reduce(
                (acc, d) => {
                    acc.amount += Number(d.amount) || 0;
                    acc.gst_amount += Number(d.gst_amount) || 0;
                    acc.further_amount += Number(d.further_amount) || 0;
                    acc.other_tax += Number(d.other_tax) || 0;
                    acc.total += Number(d.total) || 0;
                    return acc;
                },
                { amount: 0, gst_amount: 0, further_amount: 0, other_tax: 0, total: 0 }
            );

            groups.push({ ...am, details, totals });
        }

        res.status(200).json({ grn_no, groups });
    } catch (error) {
        console.error("Error fetching auto entries:", error);
        res.status(500).json({ message: "Failed to fetch auto entries.", error: error.message });
    }
};