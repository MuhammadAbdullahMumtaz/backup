const db = require("../../../config/db");
const { logActivity } = require("../../../utils/ActivityLogger");

async function syncAutoEntriesForPurchaseMain(userPurchaseMainId, meta = {}) {
    const { performed_by, system_name_ip } = meta;
    const warnings = [];
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        const [mainRows] = await connection.query(
            `SELECT id, company_id, department_id, financialyear_id, grn_no, grn_date,
            gp_no, gp_date, invoice_no, invoice_date, supplier_code
     FROM PurchaseMain
     WHERE id = ? AND entry = 'user'
     FOR UPDATE`,
            [userPurchaseMainId]
        );

        if (mainRows.length === 0) {
            await connection.commit();
            return { warnings };
        }
        const userMain = mainRows[0];

        const [detailRows] = await connection.query(
            `SELECT pd.Item_code, pd.pieces, pd.gross_weight, pd.tear_weight,
            pd.net_weight, pd.rate, pd.amount, pd.total,
            pd.gst_percent, pd.gst_amount, pd.further_percent, pd.further_amount, pd.other_tax,
            si.details AS subitem_details, coa.code AS account_code
     FROM PurchaseDetail pd
             INNER JOIN ItemDetail i
                ON pd.Item_code = i.code AND pd.company_id = i.company_id
             INNER JOIN SubItem si
                ON i.subitem_id = si.id
             LEFT JOIN ChartOfAccount coa
                ON si.GL_purchase = coa.code AND coa.company_id = pd.company_id
             WHERE pd.purchasemain_id = ? AND pd.entry = 'user'`,
            [userPurchaseMainId]
        );

        const groups = new Map(); // account_code -> detail rows
        for (const row of detailRows) {
            if (!row.account_code) {
                warnings.push(
                    `Item "${row.Item_code}" (Sub Item "${row.subitem_details}") has no GL Purchase account configured - skipped in auto entry.`
                );
                continue;
            }
            if (!groups.has(row.account_code)) groups.set(row.account_code, []);
            groups.get(row.account_code).push(row);
        }

        const [existingAutoMains] = await connection.query(
            `SELECT id, supplier_code
             FROM PurchaseMain
             WHERE company_id = ? AND financialyear_id = ? AND grn_no = ? AND entry = 'auto'`,
            [userMain.company_id, userMain.financialyear_id, userMain.grn_no]
        );
        const existingByCode = new Map(existingAutoMains.map((m) => [m.supplier_code, m.id]));

        // Drop auto mains whose account code is no longer represented
        for (const [code, id] of existingByCode) {
            if (!groups.has(code)) {
                await connection.query(`DELETE FROM PurchaseDetail WHERE purchasemain_id = ?`, [id]);
                await connection.query(`DELETE FROM PurchaseMain WHERE id = ?`, [id]);
                existingByCode.delete(code);

                await logActivity({
                    document_type: "PurchaseMain(Auto)",
                    document_no: userMain.grn_no,
                    status: "Delete",
                    remarks: `Auto GL entry removed (GL account: ${code}) - no longer represented`,
                    username: performed_by || "Unknown",
                    system_name_ip
                });
            }
        }

        for (const [code, rows] of groups) {
            if (!existingByCode.has(code) && String(userMain.supplier_code) === String(code)) {
                warnings.push(
                    `GL Purchase account "${code}" matches this purchase's own supplier - its items were skipped in auto entry to avoid a duplicate entry.`
                );
                continue;
            }

            let autoMainId = existingByCode.get(code);
            const isNewAutoMain = !autoMainId;

            try {
                if (autoMainId) {
                    await connection.query(
                        `UPDATE PurchaseMain
                         SET grn_date = ?, gp_no = ?, gp_date = ?, invoice_no = ?, invoice_date = ?
                         WHERE id = ?`,
                        [userMain.grn_date, userMain.gp_no, userMain.gp_date,
                        userMain.invoice_no, userMain.invoice_date, autoMainId]
                    );
                    await connection.query(`DELETE FROM PurchaseDetail WHERE purchasemain_id = ?`, [autoMainId]);
                } else {
                    const [insertResult] = await connection.query(
                        `INSERT INTO PurchaseMain
        (company_id, department_id, financialyear_id, grn_no, grn_date, gp_no, gp_date,
         supplier_code, invoice_no, invoice_date, freight, entry)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'auto')`,
                        [userMain.company_id, userMain.department_id, userMain.financialyear_id, userMain.grn_no, userMain.grn_date,
                        userMain.gp_no, userMain.gp_date, code, userMain.invoice_no, userMain.invoice_date]
                    );
                    autoMainId = insertResult.insertId;
                }
            } catch (err) {
                if (err.code === "ER_DUP_ENTRY") {
                    warnings.push(`Could not create auto entry for GL Purchase account "${code}" - a conflicting entry already exists.`);
                    continue;
                }
                throw err;
            }

            let entryNo = 1;
            for (const row of rows) {
                await connection.query(
                    `INSERT INTO PurchaseDetail
        (company_id, purchasemain_id, financialyear_id, Item_code, entry_no, entry,
         pieces, gross_weight, tear_weight, net_weight, rate, amount, freight,
         gst_percent, gst_amount, further_percent, further_amount, other_tax, total)
     VALUES (?, ?, ?, ?, ?, 'auto', ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?)`,
                    [userMain.company_id, autoMainId, userMain.financialyear_id, row.Item_code, entryNo++,
                    row.pieces, row.gross_weight, row.tear_weight, row.net_weight, row.rate, row.amount,
                    row.gst_percent, row.gst_amount, row.further_percent, row.further_amount, row.other_tax,
                    row.total]
                );
            }
            await logActivity({
                document_type: "PurchaseMain(Auto)",
                document_no: userMain.grn_no,
                status: isNewAutoMain ? "New" : "Edit",
                remarks: `Auto GL entry ${isNewAutoMain ? "created" : "synced"} (GL account: ${code}, ${rows.length} line(s))`,
                username: performed_by || "Unknown",
                system_name_ip
            });
        }

        await connection.commit();
        return { warnings };
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
}

async function deleteAutoEntriesForGrn(connection, { company_id, financialyear_id, grn_no }, meta = {}) {
    const { performed_by, system_name_ip } = meta;
    const [autoMains] = await connection.query(
        `SELECT id, supplier_code FROM PurchaseMain
         WHERE company_id = ? AND financialyear_id = ? AND grn_no = ? AND entry = 'auto'`,
        [company_id, financialyear_id, grn_no]
    );
    for (const m of autoMains) {
        await connection.query(`DELETE FROM PurchaseDetail WHERE purchasemain_id = ?`, [m.id]);
        await connection.query(`DELETE FROM PurchaseMain WHERE id = ?`, [m.id]);

        await logActivity({
            document_type: "PurchaseMain(Auto)",
            document_no: grn_no,
            status: "Delete",
            remarks: `Auto GL entry deleted (GL account: ${m.supplier_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });
    }
}

module.exports = {
    syncAutoEntriesForPurchaseMain,
    deleteAutoEntriesForGrn,
};