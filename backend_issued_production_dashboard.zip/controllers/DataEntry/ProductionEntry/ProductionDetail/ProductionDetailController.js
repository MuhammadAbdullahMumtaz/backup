// controllers/DataEntry/ProductionEntry/ProductionDetail/ProductionDetailController.js
const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Production Details
// ======================================================
exports.getAllProductionDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                pdt.id, pdt.company_id, c.company_name,
                pdt.department_id, d.department_name,
                pdt.productionmain_id, pm.production_no,
                pdt.financialyear_id, fy.year_detail,
                pdt.Item_code, item.details AS item_name,
                pdt.entry_no,
                pdt.pieces, pdt.net_weight, pdt.rate, pdt.amount, pdt.total,
                pdt.add_date, pdt.update_date
            FROM ProductionDetail pdt
            INNER JOIN CompanyName c ON pdt.company_id = c.id
            INNER JOIN Department d ON pdt.department_id = d.id
            INNER JOIN ProductionMain pm ON pdt.productionmain_id = pm.id
            INNER JOIN FinancialYear fy ON pdt.financialyear_id = fy.id
            INNER JOIN ItemDetail item ON pdt.Item_code = item.code AND pdt.company_id = item.company_id
            ORDER BY pm.production_no, pdt.entry_no
        `);
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching production details:", error);
        res.status(500).json({ message: "Failed to fetch production details.", error: error.message });
    }
};

// ======================================================
// Get Production Details By Production Main ID
// ======================================================
exports.getProductionDetailsByProductionMain = async (req, res) => {
    try {
        const { productionmain_id } = req.params;
        const [rows] = await db.query(
            `
            SELECT
                pdt.id, pdt.company_id, c.company_name,
                pdt.department_id, d.department_name,
                pdt.productionmain_id, pm.production_no,
                pdt.financialyear_id, fy.year_detail,
                pdt.Item_code, item.details AS item_name,
                pdt.entry_no,
                pdt.pieces, pdt.net_weight, pdt.rate, pdt.amount, pdt.total,
                pdt.add_date, pdt.update_date
            FROM ProductionDetail pdt
            INNER JOIN CompanyName c ON pdt.company_id = c.id
            INNER JOIN Department d ON pdt.department_id = d.id
            INNER JOIN ProductionMain pm ON pdt.productionmain_id = pm.id
            INNER JOIN FinancialYear fy ON pdt.financialyear_id = fy.id
            INNER JOIN ItemDetail item ON pdt.Item_code = item.code AND pdt.company_id = item.company_id
            WHERE pdt.productionmain_id = ?
            ORDER BY pdt.entry_no ASC
            `,
            [productionmain_id]
        );
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching production details by main:", error);
        res.status(500).json({ message: "Failed to fetch production details.", error: error.message });
    }
};

// ======================================================
// Get Production Detail By ID
// ======================================================
exports.getProductionDetailById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query(
            `
            SELECT
                pdt.id, pdt.company_id, c.company_name,
                pdt.department_id, d.department_name,
                pdt.productionmain_id, pm.production_no,
                pdt.financialyear_id, fy.year_detail,
                pdt.Item_code, item.details AS item_name,
                pdt.entry_no,
                pdt.pieces, pdt.net_weight, pdt.rate, pdt.amount, pdt.total,
                pdt.add_date, pdt.update_date
            FROM ProductionDetail pdt
            INNER JOIN CompanyName c ON pdt.company_id = c.id
            INNER JOIN Department d ON pdt.department_id = d.id
            INNER JOIN ProductionMain pm ON pdt.productionmain_id = pm.id
            INNER JOIN FinancialYear fy ON pdt.financialyear_id = fy.id
            INNER JOIN ItemDetail item ON pdt.Item_code = item.code AND pdt.company_id = item.company_id
            WHERE pdt.id = ?
            `,
            [id]
        );
        if (rows.length === 0) return res.status(404).json({ message: "Production detail not found." });
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching production detail:", error);
        res.status(500).json({ message: "Failed to fetch production detail.", error: error.message });
    }
};


// ======================================================
// Add Production Detail
// ======================================================
// Plain insert - items produced are entered directly, they are not
// FIFO-allocated against any Issued lot anymore.
exports.addProductionDetail = async (req, res) => {
    try {
        const { company_id, productionmain_id, Item_code, pieces, net_weight, rate, performed_by, system_name_ip } = req.body;

        // department_id and financialyear_id are NOT taken from req.body -
        // they're always derived from the parent ProductionMain row below,
        // so a detail line can never drift out of sync with its header.
        if (!company_id || !productionmain_id || !Item_code) {
            return res.status(400).json({ message: "Company, Production Main, and Item Code are required." });
        }
        if (!net_weight || parseFloat(net_weight) <= 0) {
            return res.status(400).json({ message: "Net weight must be greater than zero." });
        }
        if (String(Item_code).length > 8) {
            return res.status(400).json({ message: "Item code cannot be more than 8 characters." });
        }

        const netWeightValue = parseFloat(net_weight) || 0;
        const piecesValue = parseInt(pieces) || 0;
        const rateValue = parseFloat(rate) || 0;
        const amountValue = netWeightValue * rateValue;

        const [mainCheck] = await db.query(
            `SELECT id, department_id, financialyear_id, production_no FROM ProductionMain WHERE id = ? AND company_id = ?`,
            [productionmain_id, company_id]
        );
        if (mainCheck.length === 0) {
            return res.status(400).json({ message: "Invalid production entry for this company." });
        }
        const { department_id, financialyear_id, production_no } = mainCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({ message: "Invalid item code for this company." });
        }

        const [existing] = await db.query(
            `SELECT COALESCE(MAX(entry_no),0) AS maxNo FROM ProductionDetail WHERE productionmain_id = ?`,
            [productionmain_id]
        );
        const nextEntryNo = existing[0].maxNo + 1;

        const [result] = await db.query(
            `INSERT INTO ProductionDetail
                (company_id, department_id, productionmain_id, financialyear_id, Item_code, entry_no, pieces, net_weight, rate, amount, total)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
            [company_id, department_id, productionmain_id, financialyear_id, Item_code, nextEntryNo,
                piecesValue, netWeightValue, rateValue, amountValue, amountValue]
        );

        await logActivity({
            document_type: "ProductionDetail",
            document_no: `${production_no}-${nextEntryNo}`,
            status: "New",
            remarks: `Production line added (Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({ message: "Production detail added successfully.", id: result.insertId });
    } catch (error) {
        console.error("Error adding production detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({ message: "Entry number already exists for this production entry." });
        }
        res.status(500).json({ message: "Failed to add production detail.", error: error.message });
    }
};

// ======================================================
// Update Production Detail
// ======================================================
// Plain in-place update - no FIFO/stock re-run, no downstream-lock check,
// since Production items no longer carry a source lot to protect.
exports.updateProductionDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id, productionmain_id, Item_code, entry_no,
            pieces, net_weight, rate, total, performed_by, system_name_ip
        } = req.body;

        const [existingRow] = await db.query(
            `SELECT id FROM ProductionDetail WHERE id = ?`,
            [id]
        );
        if (existingRow.length === 0) return res.status(404).json({ message: "Production detail not found." });

        if (!company_id || !productionmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({ message: "Company, Production Main, Item Code, and Entry No are required." });
        }
        if (entry_no <= 0) {
            return res.status(400).json({ message: "Entry number must be a positive integer." });
        }
        if (String(Item_code).length > 8) {
            return res.status(400).json({ message: "Item code cannot be more than 8 characters." });
        }

        const piecesValue = parseInt(pieces) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        if (piecesValue < 0) return res.status(400).json({ message: "Pieces cannot be negative." });
        if (netWeightValue <= 0) return res.status(400).json({ message: "Net weight must be greater than zero." });
        if (rateValue < 0) return res.status(400).json({ message: "Rate cannot be negative." });

        const amountValue = netWeightValue * rateValue;
        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue;

        const [mainCheck] = await db.query(
            `SELECT id, department_id, financialyear_id, production_no FROM ProductionMain WHERE id = ? AND company_id = ?`,
            [productionmain_id, company_id]
        );
        if (mainCheck.length === 0) return res.status(400).json({ message: "Invalid production entry for this company." });
        const { department_id, financialyear_id, production_no } = mainCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) return res.status(400).json({ message: "Invalid item code for this company." });

        await db.query(
            `
            UPDATE ProductionDetail
            SET company_id = ?, department_id = ?, productionmain_id = ?, financialyear_id = ?,
                Item_code = ?, entry_no = ?, pieces = ?, net_weight = ?,
                rate = ?, amount = ?, total = ?
            WHERE id = ?
            `,
            [company_id, department_id, productionmain_id, financialyear_id, Item_code, entry_no,
                piecesValue, netWeightValue, rateValue, amountValue, totalValue, id]
        );

        await logActivity({
            document_type: "ProductionDetail",
            document_no: `${production_no}-${entry_no}`,
            status: "Edit",
            remarks: `Production line updated (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Production detail updated successfully." });
    } catch (error) {
        console.error("Error updating production detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({ message: "Entry number already exists for this production entry." });
        }
        res.status(500).json({ message: "Failed to update production detail.", error: error.message });
    }
};

// ======================================================
// Delete Production Detail
// ======================================================
// No downstream/source-lot bookkeeping anymore - just delete the row.
exports.deleteProductionDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [rows] = await db.query(
            `SELECT pdt.entry_no, pdt.Item_code, pm.production_no
             FROM ProductionDetail pdt
             INNER JOIN ProductionMain pm ON pdt.productionmain_id = pm.id
             WHERE pdt.id = ?`,
            [id]
        );
        if (rows.length === 0) return res.status(404).json({ message: "Production detail not found." });
        const { entry_no, Item_code, production_no } = rows[0];

        const [result] = await db.query(`DELETE FROM ProductionDetail WHERE id = ?`, [id]);
        if (result.affectedRows === 0) return res.status(404).json({ message: "Production detail not found." });

        await logActivity({
            document_type: "ProductionDetail",
            document_no: `${production_no}-${entry_no}`,
            status: "Delete",
            remarks: `Production line deleted (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Production detail deleted successfully." });
    } catch (error) {
        console.error("Error deleting production detail:", error);
        res.status(500).json({ message: "Failed to delete production detail.", error: error.message });
    }
};