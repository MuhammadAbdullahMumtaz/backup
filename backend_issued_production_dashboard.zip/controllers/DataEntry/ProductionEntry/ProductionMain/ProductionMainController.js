// controllers/DataEntry/ProductionEntry/ProductionMain/ProductionMainController.js
const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Production Mains
// ======================================================
exports.getAllProductionMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                pm.id,
                pm.company_id,
                c.company_name,

                pm.department_id,
                d.department_name,

                pm.financialyear_id,
                fy.year_detail,

                pm.production_no,
                pm.production_date,
                pm.issued_no,
                pm.remarks,

                pm.created_by,
                pm.add_date,
                pm.update_date

            FROM ProductionMain pm
            INNER JOIN CompanyName c ON pm.company_id = c.id
            INNER JOIN Department d ON pm.department_id = d.id
            INNER JOIN FinancialYear fy ON pm.financialyear_id = fy.id
            ORDER BY pm.production_no ASC
        `);
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching production entries:", error);
        res.status(500).json({ message: "Failed to fetch production entries.", error: error.message });
    }
};

// ======================================================
// Get Next Production Number (preview only - not reserved)
// ======================================================
exports.getNextProductionNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.params;
        if (!company_id || !financialyear_id) {
            return res.status(400).json({ message: "Company ID and Financial Year ID are required." });
        }
        const [rows] = await db.query(
            `SELECT last_no FROM ProductionSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const lastNo = rows.length > 0 ? rows[0].last_no : 0;
        res.status(200).json({ next_production_number: lastNo + 1 });
    } catch (error) {
        console.error("Error generating next production number:", error);
        res.status(500).json({ message: "Failed to generate next production number.", error: error.message });
    }
};

// ======================================================
// Get Production Main By ID
// ======================================================
exports.getProductionMainById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query(
            `
            SELECT
                pm.id, pm.company_id, c.company_name,
                pm.department_id, d.department_name,
                pm.financialyear_id, fy.year_detail,
                pm.production_no, pm.production_date, pm.issued_no, pm.remarks,
                pm.created_by, pm.add_date, pm.update_date
            FROM ProductionMain pm
            INNER JOIN CompanyName c ON pm.company_id = c.id
            INNER JOIN Department d ON pm.department_id = d.id
            INNER JOIN FinancialYear fy ON pm.financialyear_id = fy.id
            WHERE pm.id = ?
            `,
            [id]
        );
        if (rows.length === 0) return res.status(404).json({ message: "Production entry not found." });
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching production entry:", error);
        res.status(500).json({ message: "Failed to fetch production entry.", error: error.message });
    }
};

// ======================================================
// Add Production Main
// ======================================================
exports.addProductionMain = async (req, res) => {
    const {
        company_id,
        department_id,
        financialyear_id,
        production_date,
        issued_no,
        remarks,
        performed_by,
        system_name_ip
    } = req.body;

    // production_no is not accepted from the client - it's generated
    // atomically below via ProductionSequence. issued_no is now REQUIRED -
    // it's a reference to which Issued batch this production run is
    // against, no longer an optional scoping hint.
    if (!company_id || !department_id || !financialyear_id || !production_date || !issued_no) {
        return res.status(400).json({
            message: "Company, department, financial year, production date, and issued number are all required."
        });
    }

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        const [departmentCheck] = await conn.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [financialYearCheck] = await conn.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        const trimmedIssuedNo = String(issued_no).trim();
        const [issuedCheck] = await conn.query(
            `SELECT id FROM IssuedMain WHERE issued_no = ? AND company_id = ?`,
            [trimmedIssuedNo, company_id]
        );
        if (issuedCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid issued number for this company." });
        }

        await conn.query(
            `INSERT INTO ProductionSequence (company_id, financialyear_id, last_no)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE last_no = last_no + 1`,
            [company_id, financialyear_id]
        );
        const [seqRow] = await conn.query(
            `SELECT last_no FROM ProductionSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );
        const productionNo = String(seqRow[0].last_no);

        const [result] = await conn.query(
            `INSERT INTO ProductionMain
                (company_id, department_id, financialyear_id, production_no, production_date, issued_no, remarks, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [company_id, department_id, financialyear_id, productionNo, production_date,
                trimmedIssuedNo, remarks ? remarks.trim() : null, performed_by || 'Unknown']
        );

        await conn.commit();
        await logActivity({
            document_type: "ProductionMain",
            document_no: productionNo,
            status: "New",
            remarks: `Production entry created (Department: ${department_id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(201).json({
            message: "Production entry created successfully.",
            id: result.insertId,
            production_no: productionNo
        });
    } catch (error) {
        await conn.rollback();
        console.error("Error adding production entry:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This production number already exists for the selected company and financial year."
            });
        }
        res.status(500).json({ message: "Failed to create production entry.", error: error.message });
    } finally {
        conn.release();
    }
};

// ======================================================
// Update Production Main
// ======================================================
exports.updateProductionMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            department_id,
            financialyear_id,
            production_date,
            issued_no,
            remarks,
            performed_by,
            system_name_ip
        } = req.body;

        const [existing] = await db.query(`SELECT production_no FROM ProductionMain WHERE id = ?`, [id]);
        if (existing.length === 0) return res.status(404).json({ message: "Production entry not found." });

        if (!company_id || !department_id || !financialyear_id || !production_date || !issued_no) {
            return res.status(400).json({
                message: "Company, department, financial year, production date, and issued number are all required."
            });
        }

        const [departmentCheck] = await db.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        const trimmedIssuedNo = String(issued_no).trim();
        const [issuedCheck] = await db.query(
            `SELECT id FROM IssuedMain WHERE issued_no = ? AND company_id = ?`,
            [trimmedIssuedNo, company_id]
        );
        if (issuedCheck.length === 0) {
            return res.status(400).json({ message: "Invalid issued number for this company." });
        }

        await db.query(
            `
            UPDATE ProductionMain
            SET company_id = ?, department_id = ?, financialyear_id = ?, production_date = ?, issued_no = ?, remarks = ?
            WHERE id = ?
            `,
            [company_id, department_id, financialyear_id, production_date, trimmedIssuedNo,
                remarks ? remarks.trim() : null, id]
        );

        await logActivity({
            document_type: "ProductionMain",
            document_no: existing[0].production_no,
            status: "Edit",
            remarks: `Production entry updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Production entry updated successfully." });
    } catch (error) {
        console.error("Error updating production entry:", error);
        res.status(500).json({ message: "Failed to update production entry.", error: error.message });
    }
};

// ======================================================
// Get Production with Details
// ======================================================
exports.getProductionWithDetails = async (req, res) => {
    try {
        const { id } = req.params;
        const [mainRows] = await db.query(
            `
            SELECT
                pm.id, pm.company_id, c.company_name,
                pm.department_id, d.department_name,
                pm.financialyear_id, fy.year_detail,
                pm.production_no, pm.production_date, pm.issued_no, pm.remarks,
                pm.created_by, pm.add_date, pm.update_date
            FROM ProductionMain pm
            INNER JOIN CompanyName c ON pm.company_id = c.id
            INNER JOIN Department d ON pm.department_id = d.id
            INNER JOIN FinancialYear fy ON pm.financialyear_id = fy.id
            WHERE pm.id = ?
            `,
            [id]
        );
        if (mainRows.length === 0) return res.status(404).json({ message: "Production entry not found." });

        const [detailRows] = await db.query(
            `
            SELECT
                pdt.id, pdt.company_id, pdt.department_id, pdt.productionmain_id,
                pdt.financialyear_id, pdt.Item_code, item.details AS item_name,
                pdt.entry_no,
                pdt.pieces, pdt.net_weight, pdt.rate, pdt.amount, pdt.total,
                pdt.add_date, pdt.update_date
            FROM ProductionDetail pdt
            INNER JOIN ItemDetail item ON pdt.Item_code = item.code AND pdt.company_id = item.company_id
            WHERE pdt.productionmain_id = ?
            ORDER BY pdt.entry_no ASC
            `,
            [id]
        );

        res.status(200).json({ ...mainRows[0], details: detailRows });
    } catch (error) {
        console.error("Error fetching production entry with details:", error);
        res.status(500).json({ message: "Failed to fetch production entry with details.", error: error.message });
    }
};

// ======================================================
// Delete Production Main
// ======================================================
exports.deleteProductionMain = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [mainRows] = await db.query(`SELECT production_no FROM ProductionMain WHERE id = ?`, [id]);
        if (mainRows.length === 0) return res.status(404).json({ message: "Production entry not found." });

        const [detailCheck] = await db.query(
            `SELECT COUNT(*) as count FROM ProductionDetail WHERE productionmain_id = ?`,
            [id]
        );
        if (detailCheck[0].count > 0) {
            return res.status(409).json({
                message: "Cannot delete production entry as it has associated details. Please delete the details first."
            });
        }

        const [result] = await db.query(`DELETE FROM ProductionMain WHERE id = ?`, [id]);
        if (result.affectedRows === 0) return res.status(404).json({ message: "Production entry not found." });

        await logActivity({
            document_type: "ProductionMain",
            document_no: mainRows[0].production_no,
            status: "Delete",
            remarks: `Production entry deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({ message: "Production entry deleted successfully." });
    } catch (error) {
        console.error("Error deleting production entry:", error);
        res.status(500).json({ message: "Failed to delete production entry.", error: error.message });
    }
};