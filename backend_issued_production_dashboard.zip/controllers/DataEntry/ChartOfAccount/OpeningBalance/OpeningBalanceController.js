const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ==========================================
// Get All Opening Balances
// ==========================================
exports.getAllOpeningBalances = async (req, res) => {

    try {

        const [rows] = await db.query(`
            SELECT
                ob.id,

                ob.company_id,
                c.company_name,

                ob.chartofaccount_id,
                coa.account_name,

                ob.financialyear_id,
                fy.year_detail,

                ob.debit,
                ob.credit,

                ob.add_date,
                ob.update_date

            FROM OpeningBalance ob

            INNER JOIN CompanyName c
                ON ob.company_id = c.id

            INNER JOIN ChartOfAccount coa
                ON ob.chartofaccount_id = coa.id

            INNER JOIN FinancialYear fy
                ON ob.financialyear_id = fy.id

            ORDER BY
                coa.account_name
        `);

        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching Opening Balances.",
            error: err.message
        });

    }

};

// ==========================================
// Get Opening Balance By Id
// ==========================================
exports.getOpeningBalanceById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(`
            SELECT
                ob.*,
                c.company_name,
                coa.account_name,
                fy.year_detail

            FROM OpeningBalance ob

            INNER JOIN CompanyName c
                ON ob.company_id = c.id

            INNER JOIN ChartOfAccount coa
                ON ob.chartofaccount_id = coa.id

            INNER JOIN FinancialYear fy
                ON ob.financialyear_id = fy.id

            WHERE ob.id=?
        `, [id]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Opening Balance not found."
            });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching Opening Balance.",
            error: err.message
        });

    }

};

// ==========================================
// Add Opening Balance
// ==========================================
exports.addOpeningBalance = async (req, res) => {

    try {

        const {
            company_id,
            chartofaccount_id,
            financialyear_id,
            debit = 0,
            credit = 0
        } = req.body;

        if (!company_id || !chartofaccount_id || !financialyear_id) {

            return res.status(400).json({
                success: false,
                message: "Company, Account and Financial Year are required."
            });

        }

        if (Number(debit) > 0 && Number(credit) > 0) {

            return res.status(400).json({
                success: false,
                message: "Debit and Credit cannot both be greater than zero."
            });

        }

        // Company
        const [company] = await db.query(
            `SELECT id
             FROM CompanyName
             WHERE id=?`,
            [company_id]
        );

        if (company.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Company not found."
            });

        }

        // Chart Of Account
        const [account] = await db.query(
            `SELECT company_id, code
             FROM ChartOfAccount
             WHERE id=?`,
            [chartofaccount_id]
        );

        if (account.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Chart Of Account not found."
            });

        }

        if (account[0].company_id != company_id) {

            return res.status(400).json({
                success: false,
                message: "Account belongs to another company."
            });

        }

        // Financial Year
        const [year] = await db.query(
            `SELECT company_id
             FROM FinancialYear
             WHERE id=?`,
            [financialyear_id]
        );

        if (year.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Financial Year not found."
            });

        }

        if (year[0].company_id != company_id) {

            return res.status(400).json({
                success: false,
                message: "Financial Year belongs to another company."
            });

        }

        // Duplicate
        const [duplicate] = await db.query(
            `SELECT id
             FROM OpeningBalance
             WHERE company_id=?
             AND chartofaccount_id=?
             AND financialyear_id=?`,
            [
                company_id,
                chartofaccount_id,
                financialyear_id
            ]
        );

        if (duplicate.length > 0) {

            return res.status(409).json({
                success: false,
                message: "Opening Balance already exists."
            });

        }

        const [result] = await db.query(
            `INSERT INTO OpeningBalance
            (
                company_id,
                chartofaccount_id,
                financialyear_id,
                debit,
                credit
            )
            VALUES
            (?, ?, ?, ?, ?)`,
            [
                company_id,
                chartofaccount_id,
                financialyear_id,
                debit,
                credit
            ]
        );

        const { performed_by, system_name_ip } = req.body;
        // ...after INSERT...
        await logActivity({
            document_type: "OpeningBalance",
            document_no: account[0].code,
            status: "New",
            remarks: `Opening balance added (FY ID: ${financialyear_id}, Debit: ${debit}, Credit: ${credit})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        const [newRow] = await db.query(
            `SELECT *
             FROM OpeningBalance
             WHERE id=?`,
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            message: "Opening Balance added successfully.",
            data: newRow[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error adding Opening Balance.",
            error: err.message
        });

    }

};

// ==========================================
// Update Opening Balance
// ==========================================
exports.updateOpeningBalance = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            company_id,
            chartofaccount_id,
            financialyear_id,
            debit = 0,
            credit = 0
        } = req.body;

        const [record] = await db.query(
            `SELECT id
             FROM OpeningBalance
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Opening Balance not found."
            });

        }

        if (Number(debit) > 0 && Number(credit) > 0) {

            return res.status(400).json({
                success: false,
                message: "Debit and Credit cannot both be greater than zero."
            });

        }

        const [duplicate] = await db.query(
            `SELECT id
             FROM OpeningBalance
             WHERE company_id=?
             AND chartofaccount_id=?
             AND financialyear_id=?
             AND id<>?`,
            [
                company_id,
                chartofaccount_id,
                financialyear_id,
                id
            ]
        );

        if (duplicate.length > 0) {

            return res.status(409).json({
                success: false,
                message: "Another Opening Balance already exists."
            });

        }

        await db.query(
            `UPDATE OpeningBalance
             SET
                company_id=?,
                chartofaccount_id=?,
                financialyear_id=?,
                debit=?,
                credit=?
             WHERE id=?`,
            [
                company_id,
                chartofaccount_id,
                financialyear_id,
                debit,
                credit,
                id
            ]
        );

        const [account] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE id=?`,
            [chartofaccount_id]
        );
        const { performed_by, system_name_ip } = req.body;
        await logActivity({
            document_type: "OpeningBalance",
            document_no: account[0]?.code || null,
            status: "Edit",
            remarks: `Opening balance updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        const [updated] = await db.query(
            `SELECT *
             FROM OpeningBalance
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Opening Balance updated successfully.",
            data: updated[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error updating Opening Balance.",
            error: err.message
        });

    }

};

// ==========================================
// Delete Opening Balance
// ==========================================
exports.deleteOpeningBalance = async (req, res) => {

    try {

        const { id } = req.params;

        const [record] = await db.query(
            `SELECT id
             FROM OpeningBalance
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Opening Balance not found."
            });

        }

        const [account] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE id=?`,
            [record[0].chartofaccount_id]
        );

        const { performed_by, system_name_ip } = req.body;
        await db.query(`DELETE FROM OpeningBalance WHERE id=?`, [id]);
        await logActivity({
            document_type: "OpeningBalance",
            document_no: account[0].code || null,
            status: "Delete",
            remarks: `Opening balance deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({
            success: true,
            message: "Opening Balance deleted successfully."
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error deleting Opening Balance.",
            error: err.message
        });

    }

};