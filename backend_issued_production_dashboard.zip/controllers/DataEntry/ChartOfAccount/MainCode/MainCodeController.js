const db = require("../../../../config/db");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ==========================================
// Get All Main Codes
// ==========================================
exports.getAllMainCodes = async (req, res) => {
    try {

        const [rows] = await db.query(`
            SELECT
                mc.id,
                mc.company_id,
                c.company_name,
                mc.balancesheet_id,
                bs.details AS balance_sheet,
                mc.code,
                mc.details,
                mc.add_date,
                mc.update_date
            FROM MainCode mc
            INNER JOIN CompanyName c
                ON mc.company_id = c.id
            INNER JOIN BalanceSheet bs
                ON mc.balancesheet_id = bs.id
            ORDER BY
                bs.details,
                mc.code
        `);

        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching Main Codes.",
            error: err.message
        });

    }
};

// ==========================================
// Get Main Code By ID
// ==========================================
exports.getMainCodeById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(`
            SELECT
                mc.id,
                mc.company_id,
                c.company_name,
                mc.balancesheet_id,
                bs.details AS balance_sheet,
                mc.code,
                mc.details,
                mc.add_date,
                mc.update_date
            FROM MainCode mc
            INNER JOIN CompanyName c
                ON mc.company_id = c.id
            INNER JOIN BalanceSheet bs
                ON mc.balancesheet_id = bs.id
            WHERE mc.id = ?
        `, [id]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Main Code not found."
            });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching Main Code.",
            error: err.message
        });

    }
};

// ==========================================
// Add Main Code
// ==========================================
exports.addMainCode = async (req, res) => {

    try {

        const {
            company_id,
            balancesheet_id,
            details
        } = req.body;

        if (!company_id || !balancesheet_id || !details) {
            return res.status(400).json({
                success: false,
                message: "Company, Balance Sheet and Details are required."
            });
        }

        // Company Exists
        const [company] = await db.query(
            `SELECT id
             FROM CompanyName
             WHERE id=?`,
            [company_id]
        );

        if (company.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Company not found."
            });
        }

        // Balance Sheet Exists
        const [balanceSheet] = await db.query(
            `SELECT id, company_id
             FROM BalanceSheet
             WHERE id=?`,
            [balancesheet_id]
        );

        if (balanceSheet.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Balance Sheet not found."
            });
        }

        // Company Validation
        if (balanceSheet[0].company_id != company_id) {
            return res.status(400).json({
                success: false,
                message: "Balance Sheet does not belong to selected Company."
            });
        }

        // Duplicate Details Check
        const [duplicate] = await db.query(
            `SELECT id
             FROM MainCode
             WHERE company_id = ?
             AND balancesheet_id = ?
             AND details = ?`,
            [
                company_id,
                balancesheet_id,
                details
            ]
        );

        if (duplicate.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Main Code already exists."
            });
        }

        // Get Next Sequence Number for this Balance Sheet
        const [sequence] = await db.query(
            `SELECT
                COALESCE(MAX(CAST(RIGHT(code, 2) AS UNSIGNED)), 0) + 1 AS nextNo
             FROM MainCode
             WHERE company_id = ?
             AND balancesheet_id = ?`,
            [
                company_id,
                balancesheet_id
            ]
        );

        const nextNo = sequence[0].nextNo;

        if (nextNo > 99) {
            return res.status(400).json({
                success: false,
                message: "Maximum Main Codes (99) reached for this Balance Sheet."
            });
        }

        // Generate Code
        const generatedCode =
            String(balancesheet_id) +
            String(nextNo).padStart(2, "0");

        // Insert Record
        const [result] = await db.query(
            `INSERT INTO MainCode
            (
                company_id,
                balancesheet_id,
                code,
                details
            )
            VALUES
            (?, ?, ?, ?)`,
            [
                company_id,
                balancesheet_id,
                generatedCode,
                details
            ]
        );

        const { performed_by, system_name_ip } = req.body;
        await logActivity({
            document_type: "MainCode",
            document_no: generatedCode,
            status: "New",
            remarks: `Main Code created under Balance Sheet ID ${balancesheet_id}`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        // Fetch Inserted Record
        const [newRow] = await db.query(
            `SELECT *
             FROM MainCode
             WHERE id = ?`,
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            message: "Main Code added successfully.",
            data: newRow[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error adding Main Code.",
            error: err.message
        });

    }

};

// ==========================================
// Update Main Code
// ==========================================
exports.updateMainCode = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            company_id,
            balancesheet_id,
            details
        } = req.body;

        const [record] = await db.query(
            `SELECT id, code FROM MainCode WHERE id=?`,
            [id]
        );

        if (record.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Main Code not found."
            });
        }

        // Validate Balance Sheet
        const [balanceSheet] = await db.query(
            `SELECT company_id
             FROM BalanceSheet
             WHERE id=?`,
            [balancesheet_id]
        );

        if (balanceSheet.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Balance Sheet not found."
            });
        }

        if (balanceSheet[0].company_id != company_id) {
            return res.status(400).json({
                success: false,
                message: "Balance Sheet does not belong to selected Company."
            });
        }

        // Duplicate Check
        const [duplicate] = await db.query(
            `SELECT id
             FROM MainCode
             WHERE company_id=?
             AND balancesheet_id=?
             AND details=?
             AND id<>?`,
            [
                company_id,
                balancesheet_id,
                details,
                id
            ]
        );

        if (duplicate.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Another Main Code already exists."
            });
        }

        await db.query(
            `UPDATE MainCode
             SET
                company_id=?,
                balancesheet_id=?,
                details=?
             WHERE id=?`,
            [
                company_id,
                balancesheet_id,
                details,
                id
            ]
        );

        const { performed_by, system_name_ip } = req.body;
        // ...after UPDATE query...
        await logActivity({
            document_type: "MainCode",
            document_no: record[0].code,
            status: "Edit",
            remarks: `Main Code updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        const [updated] = await db.query(
            `SELECT *
             FROM MainCode
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Main Code updated successfully.",
            data: updated[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error updating Main Code.",
            error: err.message
        });

    }

};

// ==========================================
// Delete Main Code
// ==========================================
exports.deleteMainCode = async (req, res) => {

    try {

        const { id } = req.params;

        const [record] = await db.query(
            `SELECT id
             FROM MainCode
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Main Code not found."
            });
        }

        const { performed_by, system_name_ip } = req.body;
        await db.query(`DELETE FROM MainCode WHERE id=?`, [id]);
        await logActivity({
            document_type: "MainCode",
            document_no: record[0].code,
            status: "Delete",
            remarks: `Main Code deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.status(200).json({
            success: true,
            message: "Main Code deleted successfully."
        });

    } catch (err) {

        console.error(err);

        if (err.code === "ER_ROW_IS_REFERENCED_2" || err.errno === 1451) {
            return res.status(409).json({
                success: false,
                message: "This Main Code has Sub Code(s) linked to it. Please delete those first before deleting this item."
            });
        }

        res.status(500).json({
            success: false,
            message: "Error deleting Main Code.",
            error: err.message
        });

    }

};