const db = require("../../../../config/db");
const { syncAutoEntriesForSalesReturnMain } = require("../AutoSalesReturnSync");
const { logActivity } = require("../../../../utils/ActivityLogger");

const recalcSalesReturnMainTotal = async (sales_return_main) => {
    const [[{ totalSum }]] = await db.query(
        `SELECT COALESCE(SUM(total), 0) AS totalSum FROM SalesReturnDetail WHERE sales_return_main = ?`,
        [sales_return_main]
    );
    await db.query(`UPDATE SalesReturnMain SET total = ? WHERE id = ?`, [totalSum, sales_return_main]);
};

// ======================================================
// Sold-vs-returned helpers
// ======================================================
// Sales Return does NOT do FIFO/source-lot allocation the way Purchase
// Return or Issued do - a return here just has to stay within what was
// actually sold (across ALL SalesDetail lines for this item under the
// linked sales_invoice, regardless of which purchase/return/production lot
// each line drew from) minus whatever has already been returned against
// that same invoice. Once saved, the returned stock becomes visible to
// future Sales automatically via StockAllocation.js's getAvailableLots,
// which already reads SalesReturnDetail rows with stocks = 'available'
// (the column default) - no extra wiring needed there.

async function getSoldWeight(company_id, sales_invoice, customer_code, Item_code) {
    const [[row]] = await db.query(
        `SELECT COALESCE(SUM(sd.net_weight),0) AS sold, COALESCE(SUM(sd.pieces),0) AS soldPieces
         FROM SalesDetail sd
         INNER JOIN SalesMain sm ON sd.sale_main = sm.id
         WHERE sm.invoice_no = ? AND sm.company_id = ? AND sm.customer_code = ? AND sm.entry = 'user'
           AND sd.Item_code = ?`,
        [sales_invoice, company_id, customer_code, Item_code]
    );
    return { sold: Number(row.sold), soldPieces: Number(row.soldPieces) };
}

async function getReturnedWeightForInvoiceItem(company_id, sales_invoice, customer_code, Item_code, excludeReturnDetailId) {
    let query = `
        SELECT COALESCE(SUM(srd.net_weight),0) AS returned, COALESCE(SUM(srd.pieces),0) AS returnedPieces
        FROM SalesReturnDetail srd
        INNER JOIN SalesReturnMain srm ON srd.sales_return_main = srm.id
        WHERE srm.sales_invoice = ? AND srm.company_id = ? AND srm.customer_code = ? AND srm.entry = 'user'
          AND srd.Item_code = ? AND srd.entry = 'user'`;
    const params = [sales_invoice, company_id, customer_code, Item_code];
    if (excludeReturnDetailId) {
        query += ` AND srd.id != ?`;
        params.push(excludeReturnDetailId);
    }
    const [[row]] = await db.query(query, params);
    return { returned: Number(row.returned), returnedPieces: Number(row.returnedPieces) };
}

// Throws if the requested net_weight would push this item's returns past
// what was actually sold on the linked invoice. If the return isn't linked
// to a sales_invoice at all, nothing to validate against - same convention
// Purchase Return uses when purchase_grn is blank.
async function validateReturnAgainstSale({
    company_id, sales_invoice, customer_code, Item_code, netWeightValue, excludeReturnDetailId
}) {
    if (!sales_invoice) return;

    const { sold } = await getSoldWeight(company_id, sales_invoice, customer_code, Item_code);
    if (sold <= 0) {
        const err = new Error("This item was not found on the linked sales invoice.");
        err.code = "NO_SOURCE_SALE";
        throw err;
    }

    const { returned } = await getReturnedWeightForInvoiceItem(
        company_id, sales_invoice, customer_code, Item_code, excludeReturnDetailId
    );
    const availableToReturn = sold - returned;
    if (netWeightValue > availableToReturn + 0.0001) {
        const err = new Error(
            `Requested net weight (${netWeightValue}) exceeds what's still available to return (${availableToReturn}) for this item on invoice ${sales_invoice}.`
        );
        err.code = "EXCEEDS_SOLD";
        throw err;
    }
}

// ======================================================
// Get Returnable Items for a Sales Invoice
// ======================================================
// Lists the items sold under a given sales_invoice, with pieces/net_weight
// reduced by whatever has already been returned against them - drives a
// chip picker on the Sales Return form the same way Purchase Return's
// returnable-items endpoint drives its chip picker. No FIFO/source lot
// involved - purely sold minus returned, aggregated across however many
// SalesDetail lines that item was split into on the original sale.
exports.getReturnableItemsForInvoice = async (req, res) => {
    try {
        const { company_id, sales_invoice, customer_code } = req.query;

        if (!company_id || !sales_invoice || !customer_code) {
            return res.status(400).json({
                message: "company_id, sales_invoice and customer_code are required."
            });
        }

        const [saleMainRows] = await db.query(
            `SELECT id FROM SalesMain
             WHERE invoice_no = ? AND company_id = ? AND customer_code = ? AND entry = 'user'`,
            [sales_invoice, company_id, customer_code]
        );
        if (saleMainRows.length === 0) {
            return res.status(200).json([]);
        }

        const [soldRows] = await db.query(
            `SELECT sd.Item_code, item.details AS item_name,
                    SUM(sd.pieces) AS pieces, SUM(sd.net_weight) AS net_weight,
                    AVG(sd.rate) AS rate
             FROM SalesDetail sd
             INNER JOIN ItemDetail item
                ON sd.Item_code = item.code AND sd.company_id = item.company_id
             WHERE sd.sale_main = ? AND sd.entry = 'user'
             GROUP BY sd.Item_code, item.details`,
            [saleMainRows[0].id]
        );

        const returnable = [];
        for (const row of soldRows) {
            const { returned, returnedPieces } = await getReturnedWeightForInvoiceItem(
                company_id, sales_invoice, customer_code, row.Item_code
            );

            const remainingNetWeight = Math.max(0, Number(row.net_weight) - returned);
            const remainingPieces = Math.max(0, Number(row.pieces) - returnedPieces);

            if (remainingNetWeight > 0) {
                returnable.push({
                    id: row.Item_code, // stable React key; no PurchaseDetail-style row id here
                    Item_code: row.Item_code,
                    item_name: row.item_name,
                    pieces: remainingPieces,
                    net_weight: remainingNetWeight,
                    rate: Number(row.rate) || 0,
                });
            }
        }

        res.status(200).json(returnable);
    } catch (error) {
        console.error("Error fetching returnable items:", error);
        res.status(500).json({
            message: "Failed to fetch returnable items.",
            error: error.message
        });
    }
};

// ======================================================
// Get All Sales Return Details
// ======================================================
exports.getAllSalesReturnDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                srd.id,
                srd.company_id,
                c.company_name,
                srd.sales_return_main,
                srm.invoice_no,
                srm.entry,
                srd.financialyear_id,
                fy.year_detail,
                srd.Item_code,
                item.details AS item_name,
                srd.entry_no,
                srd.stocks,
                srd.pieces,
                srd.gross_weight,
                srd.tear_weight,
                srd.net_weight,
                srd.rate,
                srd.amount,
                srd.freight,
                srd.total,
                srd.add_date,
                srd.update_date
            FROM SalesReturnDetail srd
            INNER JOIN CompanyName c
                ON srd.company_id = c.id
            INNER JOIN SalesReturnMain srm
                ON srd.sales_return_main = srm.id
            INNER JOIN FinancialYear fy
                ON srd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON srd.Item_code = item.code AND srd.company_id = item.company_id
            ORDER BY
                srm.invoice_no,
                srd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sale return details:", error);
        res.status(500).json({
            message: "Failed to fetch sale return details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Return Details By Sales Return Main ID
// ======================================================
exports.getSalesReturnDetailsBySalesReturnMain = async (req, res) => {
    try {
        const { sales_return_main } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                srd.id,
                srd.company_id,
                c.company_name,
                srd.sales_return_main,
                srm.invoice_no,
                srd.financialyear_id,
                fy.year_detail,
                srd.Item_code,
                item.details AS item_name,
                srd.entry_no,
                srd.stocks,
                srd.pieces,
                srd.gross_weight,
                srd.tear_weight,
                srd.net_weight,
                srd.rate,
                srd.amount,
                srd.freight,
                srd.total,
                srd.add_date,
                srd.update_date
            FROM SalesReturnDetail srd
            INNER JOIN CompanyName c
                ON srd.company_id = c.id
            INNER JOIN SalesReturnMain srm
                ON srd.sales_return_main = srm.id
            INNER JOIN FinancialYear fy
                ON srd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON srd.Item_code = item.code AND srd.company_id = item.company_id
            WHERE srd.sales_return_main = ?
            ORDER BY srd.entry_no ASC
            `,
            [sales_return_main]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sale return details by return:", error);
        res.status(500).json({
            message: "Failed to fetch sale return details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Return Detail By ID
// ======================================================
exports.getSalesReturnDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                srd.id,
                srd.company_id,
                c.company_name,
                srd.sales_return_main,
                srm.invoice_no,
                srd.financialyear_id,
                fy.year_detail,
                srd.Item_code,
                item.details AS item_name,
                srd.entry_no,
                srd.stocks,
                srd.pieces,
                srd.gross_weight,
                srd.tear_weight,
                srd.net_weight,
                srd.rate,
                srd.amount,
                srd.freight,
                srd.total,
                srd.add_date,
                srd.update_date
            FROM SalesReturnDetail srd
            INNER JOIN CompanyName c
                ON srd.company_id = c.id
            INNER JOIN SalesReturnMain srm
                ON srd.sales_return_main = srm.id
            INNER JOIN FinancialYear fy
                ON srd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON srd.Item_code = item.code AND srd.company_id = item.company_id
            WHERE srd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Sale return detail not found."
            });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching sale return detail:", error);
        res.status(500).json({
            message: "Failed to fetch sale return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Sales Return Detail
// ======================================================
exports.addSalesReturnDetail = async (req, res) => {
    try {
        const {
            company_id,
            sales_return_main,
            Item_code,
            entry_no,
            pieces,
            net_weight,
            rate,
            total,
            performed_by,
            system_name_ip
        } = req.body;

        if (!company_id || !sales_return_main || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Sales Return Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({ message: "Pieces cannot be negative." });
        }
        if (netWeightValue <= 0) {
            return res.status(400).json({ message: "Net weight must be greater than zero." });
        }
        if (rateValue < 0) {
            return res.status(400).json({ message: "Rate cannot be negative." });
        }

        const amountValue = netWeightValue * rateValue;
        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue;

        // financialyear_id always inherited from the parent SalesReturnMain,
        // never taken from req.body.
        const [saleCheck] = await db.query(
            `SELECT id, financialyear_id, invoice_no, customer_code, sales_invoice
             FROM SalesReturnMain WHERE id = ? AND company_id = ?`,
            [sales_return_main, company_id]
        );
        if (saleCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid sale return for this company."
            });
        }
        const { financialyear_id, invoice_no, customer_code, sales_invoice } = saleCheck[0];

        // No FIFO / source-lot allocation here - just cap the return at
        // what was actually sold (minus anything already returned) on the
        // linked sales_invoice. Once saved, this row's default
        // stocks='available' is what makes it visible to a future Sale via
        // StockAllocation.js's getAvailableLots.
        try {
            await validateReturnAgainstSale({
                company_id,
                sales_invoice,
                customer_code,
                Item_code,
                netWeightValue
            });
        } catch (e) {
            if (["NO_SOURCE_SALE", "EXCEEDS_SOLD"].includes(e.code)) {
                return res.status(400).json({ message: e.message });
            }
            throw e;
        }

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        const [result] = await db.query(
            `
INSERT INTO SalesReturnDetail
(
    company_id,
    sales_return_main,
    financialyear_id,
    Item_code,
    entry_no,
    pieces,
    net_weight,
    rate,
    amount,
    total
)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`,
            [
                company_id,
                sales_return_main,
                financialyear_id,
                Item_code,
                entry_no,
                piecesValue,
                netWeightValue,
                rateValue,
                amountValue,
                totalValue
            ]
        );

        await logActivity({
            document_type: "SalesReturnDetail",
            document_no: `${invoice_no}-${entry_no}`,
            status: "New",
            remarks: `Sale return line added (Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });
        await recalcSalesReturnMainTotal(sales_return_main);
        const { warnings } = await syncAutoEntriesForSalesReturnMain(sales_return_main, { performed_by, system_name_ip });

        res.status(201).json({
            message: "Sale return detail added successfully.",
            id: result.insertId,
            warnings
        });
    } catch (error) {
        console.error("Error adding sale return detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this sale return."
            });
        }
        res.status(500).json({
            message: "Failed to add sale return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Sales Return Detail
// ======================================================
exports.updateSalesReturnDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            sales_return_main,
            Item_code,
            entry_no,
            pieces,
            net_weight,
            rate,
            total,
            performed_by,
            system_name_ip
        } = req.body;

        // Block edits once a later Sale has already drawn this row's stock
        // (source_type = 'sales_return', source_detail_id = this row's id).
        // Mirrors the same guard IssuedDetail uses against PurchaseDetail
        // lots - the physical stock has moved on, so editing the return's
        // quantity out from under it would corrupt the sale that used it.
        const [existingRow] = await db.query(
            `SELECT sales_return_main, stocks FROM SalesReturnDetail WHERE id = ?`,
            [id]
        );
        if (existingRow.length === 0) {
            return res.status(404).json({ message: "Sale return detail not found." });
        }
        if (existingRow[0].stocks === 'out') {
            return res.status(409).json({
                message: "This returned stock has already been used in a later sale and cannot be edited. Delete that sale entry first."
            });
        }

        if (!company_id || !sales_return_main || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Sales Return Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({ message: "Pieces cannot be negative." });
        }
        if (netWeightValue <= 0) {
            return res.status(400).json({ message: "Net weight must be greater than zero." });
        }
        if (rateValue < 0) {
            return res.status(400).json({ message: "Rate cannot be negative." });
        }

        const amountValue = netWeightValue * rateValue;
        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue;

        const [detailCheck] = await db.query(
            `SELECT id FROM SalesReturnDetail WHERE id = ?`,
            [id]
        );
        if (detailCheck.length === 0) {
            return res.status(404).json({
                message: "Sale return detail not found."
            });
        }

        const [saleCheck] = await db.query(
            `SELECT id, financialyear_id, invoice_no, customer_code, sales_invoice
             FROM SalesReturnMain WHERE id = ? AND company_id = ?`,
            [sales_return_main, company_id]
        );
        if (saleCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid sale return for this company."
            });
        }
        const { financialyear_id, invoice_no, customer_code, sales_invoice } = saleCheck[0];

        try {
            await validateReturnAgainstSale({
                company_id,
                sales_invoice,
                customer_code,
                Item_code,
                netWeightValue,
                excludeReturnDetailId: id
            });
        } catch (e) {
            if (["NO_SOURCE_SALE", "EXCEEDS_SOLD"].includes(e.code)) {
                return res.status(400).json({ message: e.message });
            }
            throw e;
        }

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        await db.query(
            `
            UPDATE SalesReturnDetail
            SET
                company_id = ?,
                sales_return_main = ?,
                financialyear_id = ?,
                Item_code = ?,
                entry_no = ?,
                pieces = ?,
                net_weight = ?,
                rate = ?,
                amount = ?,
                total = ?
            WHERE id = ?
            `,
            [
                company_id,
                sales_return_main,
                financialyear_id,
                Item_code,
                entry_no,
                piecesValue,
                netWeightValue,
                rateValue,
                amountValue,
                totalValue,
                id
            ]
        );

        await logActivity({
            document_type: "SalesReturnDetail",
            document_no: `${invoice_no}-${entry_no}`,
            status: "Edit",
            remarks: `Sale return line updated (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        await recalcSalesReturnMainTotal(sales_return_main);
        const { warnings } = await syncAutoEntriesForSalesReturnMain(sales_return_main, { performed_by, system_name_ip });

        res.status(200).json({
            message: "Sale return detail updated successfully.",
            warnings
        });
    } catch (error) {
        console.error("Error updating sale return detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this sale return."
            });
        }
        res.status(500).json({
            message: "Failed to update sale return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Sales Return Detail
// ======================================================
exports.deleteSalesReturnDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [rows] = await db.query(
            `SELECT srd.sales_return_main, srd.entry_no, srd.Item_code, srd.stocks, srm.invoice_no
             FROM SalesReturnDetail srd
             INNER JOIN SalesReturnMain srm ON srd.sales_return_main = srm.id
             WHERE srd.id = ?`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Sale return detail not found." });
        }
        const { sales_return_main, entry_no, Item_code, stocks, invoice_no } = rows[0];

        // Same guard as update - a later Sale already drew from this row's
        // stock, so deleting it out from under that sale would leave the
        // sale referencing stock that no longer exists.
        if (stocks === 'out') {
            return res.status(409).json({
                message: "This returned stock has already been used in a later sale and cannot be deleted. Delete that sale entry first."
            });
        }

        const [result] = await db.query(`DELETE FROM SalesReturnDetail WHERE id = ?`, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Sale return detail not found." });
        }

        await logActivity({
            document_type: "SalesReturnDetail",
            document_no: `${invoice_no}-${entry_no}`,
            status: "Delete",
            remarks: `Sale return line deleted (ID: ${id}, Item: ${Item_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        await recalcSalesReturnMainTotal(sales_return_main);
        const { warnings } = await syncAutoEntriesForSalesReturnMain(sales_return_main, { performed_by, system_name_ip });

        res.status(200).json({ message: "Sale return detail deleted successfully.", warnings });
    } catch (error) {
        console.error("Error deleting sale return detail:", error);
        res.status(500).json({ message: "Failed to delete sale return detail.", error: error.message });
    }
};

// ======================================================
// Update Sales Return Detail Stock Status (available -> out)
// ======================================================
exports.updateSalesReturnDetailStockStatus = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT id, stocks FROM SalesReturnDetail WHERE id = ?`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Sale return detail not found." });
        }
        if (rows[0].stocks === "out") {
            return res.status(400).json({ message: "Stock is already marked as out." });
        }

        await db.query(
            `UPDATE SalesReturnDetail SET stocks = 'out' WHERE id = ?`,
            [id]
        );

        res.status(200).json({ message: "Stock status updated to out." });
    } catch (error) {
        console.error("Error updating sale return detail stock status:", error);
        res.status(500).json({
            message: "Failed to update stock status.",
            error: error.message
        });
    }
};