const db = require("../../../../config/db");
const { syncAutoEntriesForSalesReturnMain, deleteAutoEntriesForReturnInvoice } = require("../AutoSalesReturnSync");
const { logActivity } = require("../../../../utils/ActivityLogger");

// ======================================================
// Get All Sales Return Mains
// ======================================================
exports.getAllSalesReturnMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                srm.id,
                srm.company_id,
                c.company_name,

                srm.financialyear_id,
                fy.year_detail,

                srm.gp_no,
                srm.gp_date,
                srm.po_no,
                srm.po_date,
                srm.invoice_no,
                srm.invoice_date,
                srm.builty_no,

                srm.customer_code,
                srm.sales_invoice,
                coa.account_name AS customer_name,

                srm.freight,
                srm.entry,
                srm.total,

                srm.created_by,
                srm.add_date,
                srm.update_date

            FROM SalesReturnMain srm

            INNER JOIN CompanyName c
                ON srm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON srm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON srm.customer_code = coa.code

            ORDER BY srm.invoice_date DESC, srm.id DESC
        `);

        res.status(200).json(rows);

    } catch (error) {
        console.error("Error fetching sales returns:", error);
        res.status(500).json({
            message: "Failed to fetch sales returns.",
            error: error.message
        });
    }
};

// ======================================================
// Get Next Return Invoice Number (suggestion only - not reserved)
// ======================================================
exports.getNextReturnInvoiceNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id } = req.params;

        if (!company_id || !financialyear_id) {
            return res.status(400).json({
                message: "Company ID and Financial Year ID are required."
            });
        }

        const [rows] = await db.query(
            `SELECT last_no FROM SalesReturnSequence WHERE company_id = ? AND financialyear_id = ?`,
            [company_id, financialyear_id]
        );

        const lastNo = rows.length > 0 ? rows[0].last_no : 0;

        res.status(200).json({
            next_invoice_number: lastNo + 1
        });

    } catch (error) {
        console.error("Error generating next return invoice number:", error);
        res.status(500).json({
            message: "Failed to generate next return invoice number.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Return Main By ID
// ======================================================
exports.getSalesReturnMainById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                srm.id,
                srm.company_id,
                c.company_name,

                srm.financialyear_id,
                fy.year_detail,

                srm.gp_no,
                srm.gp_date,
                srm.po_no,
                srm.po_date,
                srm.invoice_no,
                srm.invoice_date,
                srm.builty_no,

                srm.customer_code,
                srm.sales_invoice,
                coa.account_name AS customer_name,

                srm.freight,
                srm.total,
                srm.created_by,

                srm.add_date,
                srm.update_date

            FROM SalesReturnMain srm

            INNER JOIN CompanyName c
                ON srm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON srm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON srm.customer_code = coa.code

            WHERE srm.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Sale return not found."
            });
        }

        res.status(200).json(rows[0]);

    } catch (error) {
        console.error("Error fetching sale return:", error);
        res.status(500).json({
            message: "Failed to fetch sale return.",
            error: error.message
        });
    }
};

// ======================================================
// Add Sales Return Main
// ======================================================
exports.addSalesReturnMain = async (req, res) => {
    const {
        company_id,
        financialyear_id,
        department_id,
        gp_no,
        gp_date,
        po_no,
        po_date,
        invoice_date,
        builty_no,
        customer_code,
        sales_invoice,
        freight,
        performed_by,
        system_name_ip
    } = req.body;

    if (!company_id || !financialyear_id ||
        !department_id || !customer_code || !invoice_date) {
        return res.status(400).json({
            message: "Company, financial year, customer and invoice date are all required."
        });
    }
    if (gp_no && !gp_date) {
        return res.status(400).json({ message: "GP date is required when GP number is provided." });
    }
    if (gp_date && !gp_no) {
        return res.status(400).json({ message: "GP number is required when GP date is provided." });
    }
    if (po_no && !po_date) {
        return res.status(400).json({ message: "PO date is required when PO number is provided." });
    }
    if (po_date && !po_no) {
        return res.status(400).json({ message: "PO number is required when PO date is provided." });
    }

    const freightValue = parseFloat(freight) || 0;

    const conn = await db.getConnection();
    try {
        await conn.beginTransaction();

        const [customerCheck] = await conn.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [customer_code, company_id]
        );
        if (customerCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid customer code for this company." });
        }

        const [departmentCheck] = await conn.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        // after the customerCheck block
        if (sales_invoice) {
            const [invCheck] = await conn.query(
                `SELECT id FROM SalesMain
         WHERE invoice_no = ? AND company_id = ? AND financialyear_id = ?
           AND customer_code = ? AND entry = 'user'`,
                [sales_invoice, company_id, financialyear_id, customer_code]
            );
            if (invCheck.length === 0) {
                await conn.rollback();
                return res.status(400).json({ message: "Invalid sales invoice for this customer." });
            }
        }

        const [financialYearCheck] = await conn.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid financial year for this company." });
        }

        // Same mutex-and-generator pattern as Sales: lock the sequence row so
        // no other transaction for this company/FY can read/bump last_no
        // while we're computing the next number - guarantees a unique,
        // gap-free invoice_no.
        await conn.query(
            `INSERT IGNORE INTO SalesReturnSequence (company_id, financialyear_id, last_no) VALUES (?, ?, 0)`,
            [company_id, financialyear_id]
        );
        const [seqRows] = await conn.query(
            `SELECT last_no FROM SalesReturnSequence WHERE company_id = ? AND financialyear_id = ? FOR UPDATE`,
            [company_id, financialyear_id]
        );
        const nextNo = seqRows[0].last_no + 1;
        const generatedInvoiceNo = String(nextNo);

        const [result] = await conn.query(
            `INSERT INTO SalesReturnMain
 (company_id, department_id, financialyear_id, gp_no, gp_date, po_no, po_date,
  invoice_no, invoice_date, builty_no, customer_code, sales_invoice, freight, created_by)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [company_id, department_id, financialyear_id,
                gp_no ? gp_no.trim() : null, gp_date || null,
                po_no ? po_no.trim() : null, po_date || null,
                generatedInvoiceNo, invoice_date,
                builty_no ? builty_no.trim() : null, customer_code,
                sales_invoice ? sales_invoice.trim() : null, freightValue,
                performed_by || 'Unknown']
        );

        // Advance the sequence to the number we just used.
        await conn.query(
            `UPDATE SalesReturnSequence SET last_no = ? WHERE company_id = ? AND financialyear_id = ?`,
            [nextNo, company_id, financialyear_id]
        );

        await conn.commit();
        await logActivity({
            document_type: "SalesReturnMain",
            document_no: generatedInvoiceNo,
            status: "New",
            remarks: `Sale return created (Customer: ${customer_code})`,
            username: performed_by || "Unknown",
            system_name_ip
        });
        res.status(201).json({
            message: "Sale return created successfully.",
            id: result.insertId,
            invoice_no: generatedInvoiceNo
        });
    } catch (error) {
        await conn.rollback();
        console.error("Error adding sale return:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This invoice number already exists for the selected company, financial year, and customer."
            });
        }
        res.status(500).json({ message: "Failed to create sale return.", error: error.message });
    } finally {
        conn.release();
    }
};

// ======================================================
// Update Sales Return Main
// ======================================================
exports.updateSalesReturnMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            financialyear_id,
            department_id,
            gp_no,
            gp_date,
            po_no,
            po_date,
            invoice_date,
            builty_no,
            customer_code,
            sales_invoice,
            freight,
            performed_by,
            system_name_ip
        } = req.body;

        if (!company_id || !financialyear_id || !department_id ||
            !customer_code || !invoice_date) {
            return res.status(400).json({
                message: "Company, financial year, customer and invoice date are all required."
            });
        }
        if (gp_no && !gp_date) {
            return res.status(400).json({
                message: "GP date is required when GP number is provided."
            });
        }
        if (gp_date && !gp_no) {
            return res.status(400).json({
                message: "GP number is required when GP date is provided."
            });
        }
        if (po_no && !po_date) {
            return res.status(400).json({
                message: "PO date is required when PO number is provided."
            });
        }
        if (po_date && !po_no) {
            return res.status(400).json({
                message: "PO number is required when PO date is provided."
            });
        }

        const [saleCheck] = await db.query(
            `SELECT id, invoice_no  FROM SalesReturnMain WHERE id = ?`,
            [id]
        );
        if (saleCheck.length === 0) {
            return res.status(404).json({
                message: "Sale return not found."
            });
        }

        const { invoice_no } = saleCheck[0];

        const [customerCheck] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [customer_code, company_id]
        );
        if (customerCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid customer code for this company."
            });
        }

        const [departmentCheck] = await db.query(
            `SELECT id FROM Department WHERE id = ? AND company_id = ?`,
            [department_id, company_id]
        );
        if (departmentCheck.length === 0) {
            await conn.rollback();
            return res.status(400).json({ message: "Invalid department for this company." });
        }

        if (sales_invoice) {
            const [invCheck] = await db.query(
                `SELECT id FROM SalesMain
         WHERE invoice_no = ? AND company_id = ? AND financialyear_id = ?
           AND customer_code = ? AND entry = 'user'`,
                [sales_invoice, company_id, financialyear_id, customer_code]
            );
            if (invCheck.length === 0) {
                await conn.rollback();
                return res.status(400).json({ message: "Invalid sales invoice for this customer." });
            }
        }

        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ? AND company_id = ?`,
            [financialyear_id, company_id]
        );
        if (financialYearCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid financial year for this company."
            });
        }

        const freightValue = parseFloat(freight) || 0;

        // invoice_no is intentionally not part of this UPDATE - it's
        // system-generated once at creation and is never edited afterward,
        // so SalesReturnSequence is never touched here either.
        await db.query(
            `
            UPDATE SalesReturnMain
            SET
                company_id = ?,
                department_id = ?,
                financialyear_id = ?,
                gp_no = ?,
                gp_date = ?,
                po_no = ?,
                po_date = ?,
                invoice_date = ?,
                builty_no = ?,
                customer_code = ?,
                sales_invoice = ?,
                freight = ?
            WHERE id = ?
            `,
            [
                company_id,
                department_id,
                financialyear_id,
                gp_no ? gp_no.trim() : null,
                gp_date || null,
                po_no ? po_no.trim() : null,
                po_date || null,
                invoice_date,
                builty_no ? builty_no.trim() : null,
                customer_code,
                sales_invoice ? sales_invoice.trim() : null,
                freightValue,
                id
            ]
        );

        await logActivity({
            document_type: "SalesReturnMain",
            document_no: invoice_no,
            status: "Edit",
            remarks: `Sale return updated (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        const { warnings } = await syncAutoEntriesForSalesReturnMain(id, { performed_by, system_name_ip });

        res.status(200).json({
            message: "Sale return updated successfully.",
            warnings
        });

    } catch (error) {
        console.error("Error updating sale return:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This invoice number already exists for the selected company and financial year."
            });
        }

        res.status(500).json({
            message: "Failed to update sale return.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Sales Return Main
// ======================================================
exports.deleteSalesReturnMain = async (req, res) => {
    const connection = await db.getConnection();
    try {
        const { id } = req.params;
        const { performed_by, system_name_ip } = req.body;

        const [mainRows] = await connection.query(
            `SELECT company_id, financialyear_id, invoice_no FROM SalesReturnMain WHERE id = ? AND entry = 'user'`,
            [id]
        );
        if (mainRows.length === 0) {
            connection.release();
            return res.status(404).json({ message: "Sale return not found." });
        }

        const [detailCheck] = await connection.query(
            `SELECT COUNT(*) as count FROM SalesReturnDetail WHERE sales_return_main = ? AND entry = 'user'`,
            [id]
        );
        if (detailCheck[0].count > 0) {
            connection.release();
            return res.status(409).json({
                message: "Cannot delete sale return as it has associated details. Please delete return details first."
            });
        }

        await connection.beginTransaction();
        await deleteAutoEntriesForReturnInvoice(connection, mainRows[0], { performed_by, system_name_ip });
        const [result] = await connection.query(`DELETE FROM SalesReturnMain WHERE id = ?`, [id]);
        await connection.commit();

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Sale return not found." });
        }
        await logActivity({
            document_type: "SalesReturnMain",
            document_no: mainRows[0].invoice_no,
            status: "Delete",
            remarks: `Sale return deleted (ID: ${id})`,
            username: performed_by || "Unknown",
            system_name_ip
        });
        res.status(200).json({ message: "Sale return deleted successfully." });
    } catch (error) {
        await connection.rollback();
        console.error("Error deleting sale return:", error);
        res.status(500).json({ message: "Failed to delete sale return.", error: error.message });
    } finally {
        connection.release();
    }
};

// ======================================================
// Get Sales Return with Details
// ======================================================
exports.getSalesReturnWithDetails = async (req, res) => {
    try {
        const { id } = req.params;

        const [saleRows] = await db.query(
            `
            SELECT
                srm.id,
                srm.company_id,
                c.company_name,

                srm.financialyear_id,
                fy.year_detail,

                srm.gp_no,
                srm.gp_date,
                srm.po_no,
                srm.po_date,
                srm.invoice_no,
                srm.invoice_date,
                srm.builty_no,

                srm.customer_code,
                srm.sales_invoice,
                coa.account_name AS customer_name,

                srm.freight,
                srm.total,

                srm.created_by,
                srm.add_date,
                srm.update_date

            FROM SalesReturnMain srm

            INNER JOIN CompanyName c
                ON srm.company_id = c.id

            INNER JOIN FinancialYear fy
                ON srm.financialyear_id = fy.id

            INNER JOIN ChartOfAccount coa
                ON srm.customer_code = coa.code

            WHERE srm.id = ?
            `,
            [id]
        );

        if (saleRows.length === 0) {
            return res.status(404).json({
                message: "Sale return not found."
            });
        }

        const [detailRows] = await db.query(
            `
            SELECT
                srd.id,
                srd.company_id,
                srd.sales_return_main,
                srd.financialyear_id,
                srd.Item_code,
                item.details AS item_name,
                srd.entry_no,
                srd.pieces,
                srd.gross_weight,
                srd.tear_weight,
                srd.net_weight,
                srd.rate,
                srd.amount,
                srd.freight,
                srd.gst_percent,
                srd.gst_amount,
                srd.further_tax_percent,
                srd.further_tax_amount,
                srd.other_tax,
                srd.total,
                srd.add_date,
                srd.update_date
            FROM SalesReturnDetail srd
            INNER JOIN ItemDetail item
                ON srd.Item_code = item.code AND srd.company_id = item.company_id
            WHERE srd.sales_return_main = ?
            ORDER BY srd.entry_no ASC
            `,
            [id]
        );

        res.status(200).json({
            ...saleRows[0],
            details: detailRows
        });

    } catch (error) {
        console.error("Error fetching sale return with details:", error);
        res.status(500).json({
            message: "Failed to fetch sale return with details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Auto (GL-side) Entries for a Sales Return
// ======================================================
exports.getAutoEntriesForSalesReturnMain = async (req, res) => {
    try {
        const { id } = req.params;

        const [mainRows] = await db.query(
            `SELECT company_id, financialyear_id, invoice_no FROM SalesReturnMain WHERE id = ?`,
            [id]
        );
        if (mainRows.length === 0) {
            return res.status(404).json({ message: "Sale return not found." });
        }
        const { company_id, financialyear_id, invoice_no } = mainRows[0];

        const [autoMains] = await db.query(
            `
            SELECT srm.id, srm.customer_code, coa.account_name AS customer_name,
                   srm.invoice_no, srm.invoice_date, srm.total,
                   srm.add_date, srm.update_date
            FROM SalesReturnMain srm
            LEFT JOIN ChartOfAccount coa
                ON srm.customer_code = coa.code AND coa.company_id = srm.company_id
            WHERE srm.company_id = ? AND srm.financialyear_id = ? AND srm.invoice_no = ? AND srm.entry = 'auto'
            ORDER BY srm.customer_code ASC
            `,
            [company_id, financialyear_id, invoice_no]
        );

        const groups = [];
        for (const am of autoMains) {
            const [details] = await db.query(
                `
                SELECT srd.id, srd.Item_code, item.details AS item_name, srd.entry_no,
                       srd.pieces, srd.net_weight, srd.rate, srd.amount, srd.total
                FROM SalesReturnDetail srd
                INNER JOIN ItemDetail item
                    ON srd.Item_code = item.code AND srd.company_id = item.company_id
                WHERE srd.sales_return_main = ?
                ORDER BY srd.entry_no ASC
                `,
                [am.id]
            );

            const totals = details.reduce(
                (acc, d) => {
                    acc.amount += Number(d.amount) || 0;
                    acc.total += Number(d.total) || 0;
                    return acc;
                },
                { amount: 0, total: 0 }
            );

            groups.push({ ...am, details, totals });
        }

        res.status(200).json({ invoice_no, groups });
    } catch (error) {
        console.error("Error fetching auto entries:", error);
        res.status(500).json({ message: "Failed to fetch auto entries.", error: error.message });
    }
};