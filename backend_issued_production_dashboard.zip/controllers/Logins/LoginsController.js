const db = require("../../config/db");
const { logActivity } = require("../../utils/ActivityLogger");

// =============================
// Add Login
// =============================
exports.addLogin = async (req, res) => {

    try {
        const {
            company_id,
            username,
            password,
            role,
            performed_by,
            system_name_ip
        } = req.body;

        const [exist] = await db.query(
            "SELECT id FROM Logins WHERE company_id=? AND username=?",
            [company_id, username]
        );

        if (exist.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Username already exists."
            });
        }

        await db.query(
            `INSERT INTO Logins
            (company_id,username,password,role)
            VALUES(?,?,?,?)`,
            [company_id, username, password, role]
        );

        await logActivity({
            document_type: "Login",
            status: "New",
            remarks: `Login created for username: ${username}`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.json({
            success: true,
            message: "Login Added Successfully"
        });

    } catch (err) {
        res.status(500).json(err);
    }

};

// =============================
// Update Login
// =============================
exports.updateLogin = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            company_id,
            username,
            password,
            role,
            performed_by,
            system_name_ip
        } = req.body;

        await db.query(
            `UPDATE Logins
            SET company_id=?,
            username=?,
            password=?,
            role=?
            WHERE id=?`,
            [company_id, username, password, role, id]
        );

        await logActivity({
            document_type: "Login",
            status: "Edit",
            remarks: `Login updated (ID: ${id}, username: ${username})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.json({
            success: true,
            message: "Login Updated Successfully"
        });

    } catch (err) {
        res.status(500).json(err);
    }

};


// =============================
// Delete Login
// =============================
exports.deleteLogin = async (req, res) => {

    try {

        const { id } = req.params;
        const { performed_by, system_name_ip, target_username } = req.body;

        await db.query(
            "DELETE FROM Logins WHERE id=?",
            [id]
        );

        await logActivity({
            document_type: "Login",
            status: "Delete",
            remarks: `Login deleted (ID: ${id}${target_username ? `, username: ${target_username}` : ''})`,
            username: performed_by || "Unknown",
            system_name_ip
        });

        res.json({
            success: true,
            message: "Login Deleted Successfully"
        });

    } catch (err) {
        res.status(500).json(err);
    }

};

// =============================
// Get All Logins
// =============================
exports.getLogins = async (req, res) => {

    try {

        const [rows] = await db.query(
            `SELECT
                l.id,
                l.company_id,
                c.company_name,
                l.username,
                l.role,
                l.add_date,
                l.update_date
            FROM Logins l
            INNER JOIN CompanyName c
                ON c.id=l.company_id
            ORDER BY c.company_name,l.username`
        );

        res.json({
            success: true,
            data: rows
        });

    } catch (err) {

        res.status(500).json(err);

    }

};


// =============================
// Get Login By Id
// =============================
exports.getLoginById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT
                l.id,
                l.company_id,
                c.company_name,
                l.username,
                l.password,
                l.role,
                l.add_date,
                l.update_date
            FROM Logins l
            INNER JOIN CompanyName c
                ON c.id=l.company_id
            WHERE l.id=?`,
            [id]
        );

        if (rows.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Login Not Found"
            });

        }

        res.json({
            success: true,
            data: rows[0]
        });

    } catch (err) {

        res.status(500).json(err);

    }

};

// ======================================
// Login User
// ======================================
exports.loginUser = async (req, res) => {
    try {
        const { username, password, company_id } = req.body;

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                message: "Username and Password are required."
            });
        }

        const [rows] = await db.query(
            `SELECT
                l.id,
                l.company_id,
                c.company_name,
                l.username,
                l.role
            FROM Logins l
            INNER JOIN CompanyName c
                ON c.id = l.company_id
            WHERE l.username = ?
            AND l.password = ?`,
            [username, password]
        );

        if (rows.length === 0) {
            return res.status(401).json({
                success: false,
                message: "Invalid Username or Password."
            });
        }

        const matchedUser = rows[0];

        // Case 1: A company was selected on the login form.
        // The matched credentials MUST belong to that same company.
        if (company_id) {
            if (parseInt(matchedUser.company_id) !== parseInt(company_id)) {
                return res.status(401).json({
                    success: false,
                    message: "Invalid Username or Password."
                });
            }

            return res.status(200).json({
                success: true,
                message: "Login Successful.",
                user: matchedUser,
                is_main_admin: false
            });
        }

        // Case 2: No company selected - only allowed for the AAM Tech Solutions admin
        if (matchedUser.company_name === 'AAM Tech Solutions') {
            return res.status(200).json({
                success: true,
                message: "Login Successful.",
                user: matchedUser,
                is_main_admin: true
            });
        }

        return res.status(400).json({
            success: false,
            message: "Please select your company and financial year to login."
        });

    } catch (err) {
        res.status(500).json({
            success: false,
            message: err.message
        });
    }
};