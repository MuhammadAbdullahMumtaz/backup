const db = require("../../config/db");

/**
 * ============================================================================
 * DASHBOARD CONTROLLER
 * ============================================================================
 * Powers the "home" dashboard: KPI cards, a month-wise Sales vs Purchases
 * trend, a low-stock alert list, the most recent ActivityLog entries for
 * this company, and a small top-customers leaderboard.
 *
 * Design notes:
 *   - company_id + financialyear_id are required; start_date/end_date are
 *     optional and default to "financial-year-to-date".
 *   - Receivable / Payable totals reuse the same netting idea as
 *     agingController.js (bills - returns - voucher payments/receipts),
 *     summed per account and clamped at zero before being added together.
 *   - Low stock uses "remaining = purchased - issued - returned - sold",
 *     filtered down to items where remaining < ItemDetail.MinLimit.
 *   - ActivityLog has no company_id column, so it is scoped via a join to
 *     Logins (username -> company_id).
 * ============================================================================
 */

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function toSqlDate(d) {
  if (d instanceof Date) {
    const y = d.getUTCFullYear();
    const m = String(d.getUTCMonth() + 1).padStart(2, "0");
    const day = String(d.getUTCDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  const s = String(d).trim();
  const match = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;
  const date = new Date(s);
  if (Number.isNaN(date.getTime())) return null;
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, "0");
  const day = String(date.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeDbDate(value) {
  if (value == null) return null;
  if (value instanceof Date) {
    const y = value.getUTCFullYear();
    const m = String(value.getUTCMonth() + 1).padStart(2, "0");
    const d = String(value.getUTCDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  return String(value).slice(0, 10);
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function round2(n) {
  return Number(toNumber(n).toFixed(2));
}

function monthLabel(ym) {
  const [y, m] = String(ym).split("-");
  const MONTHS_SHORT = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
  ];
  const idx = Number(m) - 1;
  if (idx < 0 || idx > 11) return ym;
  return `${MONTHS_SHORT[idx]} ${y}`;
}

async function fetchFinancialYearById(companyId, financialYearId) {
  const sql = `
    SELECT id, start_date, end_date
    FROM FinancialYear
    WHERE company_id = ? AND id = ?
    LIMIT 1
  `;
  const [rows] = await db.query(sql, [companyId, financialYearId]);
  if (!rows.length) return null;
  return {
    id: rows[0].id,
    start_date: normalizeDbDate(rows[0].start_date),
    end_date: normalizeDbDate(rows[0].end_date),
  };
}

// ============================================================================
// Receivable / Payable outstanding totals (per-account netting, clamped >= 0)
// ============================================================================

async function fetchReceivableOutstanding(companyId, financialyearId, startDate, endDate) {
  const sql = `
    SELECT COALESCE(SUM(GREATEST(bal, 0)), 0) AS total_outstanding
    FROM (
      SELECT acct, SUM(amt) AS bal
      FROM (
        SELECT CONVERT(customer_code USING utf8mb4) COLLATE utf8mb4_general_ci AS acct,
               total AS amt
        FROM SalesMain
        WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
          AND invoice_date BETWEEN ? AND ?

        UNION ALL

        SELECT CONVERT(customer_code USING utf8mb4) COLLATE utf8mb4_general_ci AS acct,
               -total AS amt
        FROM SalesReturnMain
        WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
          AND invoice_date BETWEEN ? AND ?

        UNION ALL

        SELECT CONVERT(CAST(vd.accountcode AS CHAR) USING utf8mb4) COLLATE utf8mb4_general_ci AS acct,
               -vd.credit AS amt
        FROM VoucherDetail vd
        INNER JOIN VoucherMain vm ON vm.id = vd.vouchermain_id
        WHERE vd.company_id = ? AND vd.financialyear_id = ? AND vd.credit > 0
          AND vm.voucher_date BETWEEN ? AND ?
      ) combined
      GROUP BY acct
    ) t
  `;
  const params = [
    companyId, financialyearId, startDate, endDate,
    companyId, financialyearId, startDate, endDate,
    companyId, financialyearId, startDate, endDate,
  ];
  const [rows] = await db.query(sql, params);
  return toNumber(rows[0]?.total_outstanding);
}

async function fetchPayableOutstanding(companyId, financialyearId, startDate, endDate) {
  const sql = `
    SELECT COALESCE(SUM(GREATEST(bal, 0)), 0) AS total_outstanding
    FROM (
      SELECT acct, SUM(amt) AS bal
      FROM (
        SELECT CONVERT(pm.supplier_code USING utf8mb4) COLLATE utf8mb4_general_ci AS acct,
               pd.total AS amt
        FROM PurchaseDetail pd
        INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
        WHERE pd.entry = 'user' AND pm.company_id = ? AND pm.financialyear_id = ?
          AND pm.grn_date BETWEEN ? AND ?

        UNION ALL

        SELECT CONVERT(prm.supplier_code USING utf8mb4) COLLATE utf8mb4_general_ci AS acct,
               -prd.total AS amt
        FROM PurchaseReturnDetail prd
        INNER JOIN PurchaseReturnMain prm ON prm.id = prd.purchasereturnmain_id
        WHERE prd.entry = 'user' AND prm.company_id = ? AND prm.financialyear_id = ?
          AND prm.return_date BETWEEN ? AND ?

        UNION ALL

        SELECT CONVERT(CAST(vd.accountcode AS CHAR) USING utf8mb4) COLLATE utf8mb4_general_ci AS acct,
               -vd.debit AS amt
        FROM VoucherDetail vd
        INNER JOIN VoucherMain vm ON vm.id = vd.vouchermain_id
        WHERE vd.company_id = ? AND vd.financialyear_id = ? AND vd.debit > 0
          AND vm.voucher_date BETWEEN ? AND ?
      ) combined
      GROUP BY acct
    ) t
  `;
  const params = [
    companyId, financialyearId, startDate, endDate,
    companyId, financialyearId, startDate, endDate,
    companyId, financialyearId, startDate, endDate,
  ];
  const [rows] = await db.query(sql, params);
  return toNumber(rows[0]?.total_outstanding);
}

// ============================================================================
// Sales / Purchase totals for the period (net of returns)
// ============================================================================

async function fetchSalesPurchaseTotals(companyId, financialyearId, startDate, endDate) {
  const [[salesRow]] = await db.query(
    `SELECT COALESCE(SUM(total), 0) AS t
     FROM SalesMain
     WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
       AND invoice_date BETWEEN ? AND ?`,
    [companyId, financialyearId, startDate, endDate]
  );

  const [[salesRetRow]] = await db.query(
    `SELECT COALESCE(SUM(total), 0) AS t
     FROM SalesReturnMain
     WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
       AND invoice_date BETWEEN ? AND ?`,
    [companyId, financialyearId, startDate, endDate]
  );

  const [[purRow]] = await db.query(
    `SELECT COALESCE(SUM(pd.total), 0) AS t
     FROM PurchaseDetail pd
     INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
     WHERE pd.entry = 'user' AND pm.company_id = ? AND pm.financialyear_id = ?
       AND pm.grn_date BETWEEN ? AND ?`,
    [companyId, financialyearId, startDate, endDate]
  );

  const [[purRetRow]] = await db.query(
    `SELECT COALESCE(SUM(prd.total), 0) AS t
     FROM PurchaseReturnDetail prd
     INNER JOIN PurchaseReturnMain prm ON prm.id = prd.purchasereturnmain_id
     WHERE prd.entry = 'user' AND prm.company_id = ? AND prm.financialyear_id = ?
       AND prm.return_date BETWEEN ? AND ?`,
    [companyId, financialyearId, startDate, endDate]
  );

  const sales_total = round2(toNumber(salesRow.t) - toNumber(salesRetRow.t));
  const purchase_total = round2(toNumber(purRow.t) - toNumber(purRetRow.t));
  return { sales_total, purchase_total };
}

// ============================================================================
// Month-wise trend (net sales, net purchases) — feeds the line chart
// ============================================================================

async function fetchMonthlyTrend(companyId, financialyearId, startDate, endDate) {
  const [salesRows] = await db.query(
    `SELECT DATE_FORMAT(invoice_date, '%Y-%m') AS ym, COALESCE(SUM(total), 0) AS amt
     FROM SalesMain
     WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
       AND invoice_date BETWEEN ? AND ?
     GROUP BY ym`,
    [companyId, financialyearId, startDate, endDate]
  );

  const [salesRetRows] = await db.query(
    `SELECT DATE_FORMAT(invoice_date, '%Y-%m') AS ym, COALESCE(SUM(total), 0) AS amt
     FROM SalesReturnMain
     WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
       AND invoice_date BETWEEN ? AND ?
     GROUP BY ym`,
    [companyId, financialyearId, startDate, endDate]
  );

  const [purRows] = await db.query(
    `SELECT DATE_FORMAT(pm.grn_date, '%Y-%m') AS ym, COALESCE(SUM(pd.total), 0) AS amt
     FROM PurchaseDetail pd
     INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
     WHERE pd.entry = 'user' AND pm.company_id = ? AND pm.financialyear_id = ?
       AND pm.grn_date BETWEEN ? AND ?
     GROUP BY ym`,
    [companyId, financialyearId, startDate, endDate]
  );

  const [purRetRows] = await db.query(
    `SELECT DATE_FORMAT(prm.return_date, '%Y-%m') AS ym, COALESCE(SUM(prd.total), 0) AS amt
     FROM PurchaseReturnDetail prd
     INNER JOIN PurchaseReturnMain prm ON prm.id = prd.purchasereturnmain_id
     WHERE prd.entry = 'user' AND prm.company_id = ? AND prm.financialyear_id = ?
       AND prm.return_date BETWEEN ? AND ?
     GROUP BY ym`,
    [companyId, financialyearId, startDate, endDate]
  );

  // Build a full month axis from startDate..endDate so empty months still
  // show as 0. Use UTC-only math on the "YYYY-MM" strings to avoid TZ drift.
  const months = [];
  {
    const [sy, sm] = startDate.split("-").map(Number);
    const [ey, em] = endDate.split("-").map(Number);
    let y = sy;
    let m = sm;
    while (y < ey || (y === ey && m <= em)) {
      months.push(`${y}-${String(m).padStart(2, "0")}`);
      m += 1;
      if (m > 12) {
        m = 1;
        y += 1;
      }
    }
  }

  const salesMap = Object.fromEntries(salesRows.map((r) => [r.ym, toNumber(r.amt)]));
  const salesRetMap = Object.fromEntries(salesRetRows.map((r) => [r.ym, toNumber(r.amt)]));
  const purMap = Object.fromEntries(purRows.map((r) => [r.ym, toNumber(r.amt)]));
  const purRetMap = Object.fromEntries(purRetRows.map((r) => [r.ym, toNumber(r.amt)]));

  return months.map((ym) => ({
    ym,
    month: monthLabel(ym),
    sales: round2((salesMap[ym] || 0) - (salesRetMap[ym] || 0)),
    purchases: round2((purMap[ym] || 0) - (purRetMap[ym] || 0)),
  }));
}

// ============================================================================
// Low stock alerts (raw / purchased stock only)
//
// The heavy aggregate lives in an inner subquery so that the outer query
// can reference `remaining` freely in WHERE / ORDER BY. MySQL rejects
// `HAVING remaining < ...` when `remaining` is an aggregate alias that is
// used inside another expression (ER_ILLEGAL_REFERENCE, errno 1247).
// ============================================================================

async function fetchLowStock(companyId, financialyearId, limit) {
  const sql = `
    SELECT
      t.code        AS code,
      t.name        AS name,
      t.unit        AS unit,
      t.min_limit   AS min_limit,
      t.remaining   AS remaining
    FROM (
      SELECT
        it.id,
        it.code        AS code,
        it.details     AS name,
        it.Unit        AS unit,
        it.MinLimit    AS min_limit,
        COALESCE(SUM(pd.net_weight), 0)
          - COALESCE(SUM(iss.consumed_weight), 0)
          - COALESCE(SUM(ret.returned_weight), 0)
          - COALESCE(SUM(sal.sold_weight), 0) AS remaining
      FROM ItemDetail it
      LEFT JOIN (
        SELECT pd.id, pd.Item_code, pd.company_id, pd.net_weight
        FROM PurchaseDetail pd
        INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
        WHERE pd.entry = 'user'
          AND pm.financialyear_id = ?
      ) pd
        ON pd.Item_code = it.code
       AND pd.company_id = it.company_id
      LEFT JOIN (
        SELECT source_detail_id, SUM(net_weight) AS consumed_weight
        FROM IssuedDetail
        WHERE source_type = 'purchase'
        GROUP BY source_detail_id
      ) iss ON iss.source_detail_id = pd.id
      LEFT JOIN (
        SELECT source_detail_id, SUM(net_weight) AS returned_weight
        FROM PurchaseReturnDetail
        WHERE entry = 'user'
        GROUP BY source_detail_id
      ) ret ON ret.source_detail_id = pd.id
      LEFT JOIN (
        SELECT source_detail_id, SUM(net_weight) AS sold_weight
        FROM SalesDetail
        WHERE source_type = 'purchase'
        GROUP BY source_detail_id
      ) sal ON sal.source_detail_id = pd.id
      WHERE it.company_id = ?
      GROUP BY it.id, it.code, it.details, it.Unit, it.MinLimit
    ) t
    WHERE t.min_limit > 0
      AND t.remaining < t.min_limit
    ORDER BY (t.min_limit - t.remaining) DESC
    LIMIT ?
  `;
  const [rows] = await db.query(sql, [financialyearId, companyId, limit]);
  return rows.map((r) => ({
    code: r.code,
    name: r.name || r.code,
    unit: r.unit,
    min_limit: round2(r.min_limit),
    remaining: round2(Math.max(0, toNumber(r.remaining))),
  }));
}

// ============================================================================
// Recent activity (scoped to this company via Logins.username)
// ============================================================================

async function fetchRecentActivity(companyId, limit) {
  const sql = `
    SELECT al.id, al.entry_date, al.document_type, al.document_no,
           al.document_date, al.status, al.username
    FROM ActivityLog al
    INNER JOIN Logins l ON l.username = al.username
    WHERE l.company_id = ?
    ORDER BY al.entry_date DESC
    LIMIT ?
  `;
  const [rows] = await db.query(sql, [companyId, limit]);
  return rows.map((r) => ({
    id: r.id,
    entry_date: r.entry_date instanceof Date ? r.entry_date.toISOString() : r.entry_date,
    document_type: r.document_type,
    document_no: r.document_no,
    document_date: normalizeDbDate(r.document_date),
    status: r.status,
    username: r.username,
  }));
}

// ============================================================================
// Top customers by net sales in the period
// ============================================================================

async function fetchTopCustomers(companyId, financialyearId, startDate, endDate, limit) {
  const sql = `
    SELECT
      coa.code         AS code,
      coa.account_name AS name,
      COALESCE(SUM(t.amt), 0) AS total_sales
    FROM (
      SELECT customer_code, total AS amt
      FROM SalesMain
      WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
        AND invoice_date BETWEEN ? AND ?

      UNION ALL

      SELECT customer_code, -total AS amt
      FROM SalesReturnMain
      WHERE company_id = ? AND financialyear_id = ? AND entry = 'user'
        AND invoice_date BETWEEN ? AND ?
    ) t
    INNER JOIN ChartOfAccount coa
      ON coa.code = t.customer_code
     AND coa.company_id = ?
    GROUP BY coa.id, coa.code, coa.account_name
    HAVING total_sales > 0
    ORDER BY total_sales DESC
    LIMIT ?
  `;
  const params = [
    companyId, financialyearId, startDate, endDate,
    companyId, financialyearId, startDate, endDate,
    companyId, limit,
  ];
  const [rows] = await db.query(sql, params);
  return rows.map((r) => ({
    code: r.code,
    name: r.name,
    total_sales: round2(r.total_sales),
  }));
}

// ============================================================================
// GET /dashboard/summary
//   query: company_id, financialyear_id, start_date (optional), end_date (optional)
//   Defaults to financial-year-to-date when dates are omitted.
// ============================================================================

async function getDashboardSummary(req, res) {
  try {
    const { company_id, financialyear_id } = req.query;
    if (!company_id || !financialyear_id) {
      return res.status(400).json({
        success: false,
        message: "company_id and financialyear_id are required",
      });
    }

    const financialYear = await fetchFinancialYearById(company_id, financialyear_id);
    if (!financialYear) {
      return res.status(400).json({
        success: false,
        message: `Financial year ${financialyear_id} was not found for this company.`,
      });
    }

    const today = toSqlDate(new Date());

    // start: requested → else FY start
    const startDate = req.query.start_date
      ? toSqlDate(req.query.start_date)
      : financialYear.start_date;

    // end: requested → else min(today, FY end). If today is past FY end,
    // we clamp to FY end so the trend axis doesn't spill into next FY.
    let endDate;
    if (req.query.end_date) {
      endDate = toSqlDate(req.query.end_date);
    } else if (today && financialYear.end_date && today > financialYear.end_date) {
      endDate = financialYear.end_date;
    } else {
      endDate = today;
    }

    if (!startDate || !endDate) {
      return res.status(400).json({
        success: false,
        message: "Could not resolve a valid date range for this financial year.",
      });
    }

    // Receivable / Payable are always FY-to-date (cumulative), not period-scoped.
    const outstandingEnd = endDate;

    const [
      { sales_total, purchase_total },
      receivable_outstanding,
      payable_outstanding,
      trend,
      raw_stock_total,
      finished_stock_total,
      recent_activity,
      top_customers,
    ] = await Promise.all([
      fetchSalesPurchaseTotals(company_id, financialyear_id, startDate, endDate),
      fetchReceivableOutstanding(company_id, financialyear_id, financialYear.start_date, outstandingEnd),
      fetchPayableOutstanding(company_id, financialyear_id, financialYear.start_date, outstandingEnd),
      fetchMonthlyTrend(company_id, financialyear_id, startDate, endDate),
      fetchRawStockTotal(company_id, financialyear_id),
      fetchFinishedStockTotal(company_id, financialyear_id),
      fetchRecentActivity(company_id, 8),
      fetchTopCustomers(company_id, financialyear_id, startDate, endDate, 5),
    ]);

    return res.json({
      success: true,
      data: {
        start_date: startDate,
        end_date: endDate,
        kpis: {
          sales_total,
          purchase_total,
          receivable_outstanding: round2(receivable_outstanding),
          payable_outstanding: round2(payable_outstanding),
          raw_stock_total,
          finished_stock_total,
        },
        trend,
        recent_activity,
        top_customers,
      },
    });

  } catch (err) {
    console.error("getDashboardSummary error:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to generate dashboard summary",
    });
  }
}

// ============================================================================
// Raw stock total (sum across all items) — purchased - issued - returned - sold
// ============================================================================
async function fetchRawStockTotal(companyId, financialyearId) {
  const sql = `
    SELECT
      COALESCE(SUM(pd.net_weight), 0)
        - COALESCE(SUM(iss.consumed_weight), 0)
        - COALESCE(SUM(ret.returned_weight), 0)
        - COALESCE(SUM(sal.sold_weight), 0) AS remaining
    FROM (
      SELECT pd.id, pd.net_weight
      FROM PurchaseDetail pd
      INNER JOIN PurchaseMain pm ON pm.id = pd.purchasemain_id
      WHERE pd.entry = 'user'
        AND pm.company_id = ?
        AND pm.financialyear_id = ?
    ) pd
    LEFT JOIN (
      SELECT source_detail_id, SUM(net_weight) AS consumed_weight
      FROM IssuedDetail
      WHERE source_type = 'purchase'
      GROUP BY source_detail_id
    ) iss ON iss.source_detail_id = pd.id
    LEFT JOIN (
      SELECT source_detail_id, SUM(net_weight) AS returned_weight
      FROM PurchaseReturnDetail
      WHERE entry = 'user'
      GROUP BY source_detail_id
    ) ret ON ret.source_detail_id = pd.id
    LEFT JOIN (
      SELECT source_detail_id, SUM(net_weight) AS sold_weight
      FROM SalesDetail
      WHERE source_type = 'purchase'
      GROUP BY source_detail_id
    ) sal ON sal.source_detail_id = pd.id
  `;
  const [rows] = await db.query(sql, [companyId, financialyearId]);
  return round2(Math.max(0, toNumber(rows[0]?.remaining)));
}

// ============================================================================
// Finished stock total (sum across all items) — produced - sold (from production)
// ============================================================================
async function fetchFinishedStockTotal(companyId, financialyearId) {
  const sql = `
    SELECT
      COALESCE(SUM(pd.net_weight), 0)
        - COALESCE(SUM(sal.sold_weight), 0) AS remaining
    FROM (
      SELECT pd.id, pd.net_weight
      FROM ProductionDetail pd
      INNER JOIN ProductionMain pm ON pm.id = pd.productionmain_id
      WHERE pm.company_id = ?
        AND pm.financialyear_id = ?
    ) pd
    LEFT JOIN (
      SELECT source_detail_id, SUM(net_weight) AS sold_weight
      FROM SalesDetail
      WHERE source_type = 'production'
      GROUP BY source_detail_id
    ) sal ON sal.source_detail_id = pd.id
  `;
  const [rows] = await db.query(sql, [companyId, financialyearId]);
  return round2(Math.max(0, toNumber(rows[0]?.remaining)));
}

module.exports = {
  getDashboardSummary,
};