const express = require("express");
const router = express.Router();
const StockReportController = require("../../../controllers/Reporting/StocksReport/StocksReportController");
// Adjust the require path above if you place StockReportController.js
// somewhere other than controllers/StockReport/.

// GET /api/stock-report/financial-year?company_id=&financialyear_id=
router.get("/financial-year", StockReportController.getFinancialYearDates);

// GET /api/stock-report/item-wise?company_id=&financialyear_id=&start_date=&end_date=
router.get("/item-wise", StockReportController.getItemWiseReport);

// GET /api/stock-report/account-wise?company_id=&financialyear_id=&start_date=&end_date=
router.get("/account-wise", StockReportController.getAccountWiseReport);

// GET /api/stock-report/management?company_id=&financialyear_id=&start_date=&end_date=
router.get("/management", StockReportController.getManagementReport);

module.exports = router;
