// routes/agingReport.routes.js
const express = require('express');
const router = express.Router();
const AgingReportController = require('../../../controllers/Reporting/Aging/AgingController'); 

router.get('/receivables', AgingReportController.getReceivablesAging);
router.get('/payables', AgingReportController.getPayablesAging);

router.get("/receivables-summary", AgingReportController.getReceivablesAgingSummary);
router.get("/payables-summary", AgingReportController.getPayablesAgingSummary);
 
router.get("/cities", AgingReportController.getCities);

module.exports = router;