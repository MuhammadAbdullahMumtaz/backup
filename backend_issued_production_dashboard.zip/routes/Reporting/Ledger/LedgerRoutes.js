const express = require("express");
const router = express.Router();

const {
  searchAccounts,
  getLedgerReport,
} = require("../../../controllers/Reporting/Ledger/LedgerController");

router.get("/accounts/search", searchAccounts);

router.get("/report", getLedgerReport);

module.exports = router;