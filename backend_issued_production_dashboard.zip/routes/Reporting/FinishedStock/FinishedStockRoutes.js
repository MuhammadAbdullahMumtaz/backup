const express = require("express");
const router = express.Router();

const {
  searchItems,
  getDepartments,
  getStockSummary,
  getFinishedStockReport,
} = require("../../../controllers/Reporting/FinishedStock/FinishedStockController");

// GET /finished-stock/items/search?company_id=&q=
router.get("/items/search", searchItems);

// GET /finished-stock/departments?company_id=
router.get("/departments", getDepartments);

// GET /finished-stock/items/stock?company_id=&financialyear_id=&department_id=
router.get("/items/stock", getStockSummary);

// GET /finished-stock/report?company_id=&financialyear_id=&item_code=&department_id=&start_date=&end_date=
router.get("/report", getFinishedStockReport);

module.exports = router;