const express = require("express");
const router = express.Router();

const {
  searchItems,
  getDepartments,
  getStockSummary,
  getRawStockReport,
} = require("../../../controllers/Reporting/RawStocks/RawStocksController");

// GET /raw-stock/items/search?company_id=&q=
router.get("/items/search", searchItems);

// GET /raw-stock/departments?company_id=
router.get("/departments", getDepartments);

// GET /raw-stock/items/stock?company_id=&financialyear_id=&department_id=
router.get("/items/stock", getStockSummary);

// GET /raw-stock/report?company_id=&financialyear_id=&item_code=&department_id=&start_date=&end_date=
router.get("/report", getRawStockReport);

module.exports = router;