const express = require("express");
const router = express.Router();

const {
  searchItems,
  getDepartments,
  getStockSummary,
  getProductionReport,
} = require("../../../controllers/Reporting/Production/ProductionController");

router.get("/items/stock", getStockSummary);

// GET /production/items/search?company_id=&q=
router.get("/items/search", searchItems);

// GET /production/departments?company_id=
router.get("/departments", getDepartments);

// GET /production/report?company_id=&financialyear_id=&item_code=&department_id=&start_date=&end_date=
router.get("/report", getProductionReport);

module.exports = router;