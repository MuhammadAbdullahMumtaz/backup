const express = require("express");
const router = express.Router();
const { getFinancialYearRange, getTrialBalance } = require("../../../controllers/Reporting/TrialBalance/TrialBalanceController");
// ^ adjust the require path above to wherever you place trialBalanceController.js
//   (this mirrors LedgerRoutes.js's require path convention).

// GET /api/trial-balance/financial-year?company_id=&financialyear_id=
// Used by the frontend to pre-fill the Start date / End date inputs.
router.get("/financial-year", getFinancialYearRange);

// GET /api/trial-balance/report?company_id=&financialyear_id=&start_date=&end_date=
router.get("/report", getTrialBalance);

module.exports = router;

/**
 * In your app's main router setup (e.g. app.js / server.js), mount this with:
 *
 *   const trialBalanceRoutes = require("./routes/TrialBalanceRoutes");
 *   app.use("/api/trial-balance", trialBalanceRoutes);
 */