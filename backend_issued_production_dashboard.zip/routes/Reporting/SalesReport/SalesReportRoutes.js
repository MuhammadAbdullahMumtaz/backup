const express = require("express");
const router = express.Router();
const salesReportController = require("../../../controllers/Reporting/SalesReport/SalesReportController");

// GET /api/sales-report/top-accounts?company_id=&financialyear_id=&start_date=&end_date=&limit=
router.get("/top-accounts", salesReportController.getTopAccounts);

// GET /api/sales-report/top-cities?company_id=&financialyear_id=&start_date=&end_date=&limit=
router.get("/top-cities", salesReportController.getTopCities);

// GET /api/sales-report/top-items?company_id=&financialyear_id=&start_date=&end_date=&limit=&group_by=item|subitem|mainitem
router.get("/top-items", salesReportController.getTopItems);

// GET /api/sales-report/detailed?company_id=&financialyear_id=&start_date=&end_date=&customer_code=&item_code=&limit=
router.get("/detailed", salesReportController.getDetailedSales);

module.exports = router;
