const express = require("express");
const router = express.Router();
const salesReportController = require("../../../controllers/Reporting/PurchaseReport/PurchaseReportController");

router.get("/date-wise", salesReportController.getDateWiseSummary);

router.get("/account-wise", salesReportController.getAccountWiseSummary);

router.get("/item-wise", salesReportController.getItemWiseSummary);

router.get("/item-group-wise", salesReportController.getItemGroupWiseSummary);

router.get("/detailed", salesReportController.getDetailedPurchases);

module.exports = router;
