const express = require("express");
const router = express.Router();

const {
  searchItems,
  getStockSummary,
  getDepartments,
  getIssuedReport,
} = require("../../../controllers/Reporting/Issued/IssuedController");


router.get("/items/stock", getStockSummary);

// GET /issued/items/search?company_id=&q=
router.get("/items/search", searchItems);

// GET /issued/departments?company_id=
router.get("/departments", getDepartments);

// GET /issued/report?company_id=&financialyear_id=&item_code=&department_id=&start_date=&end_date=
router.get("/report", getIssuedReport);

module.exports = router;