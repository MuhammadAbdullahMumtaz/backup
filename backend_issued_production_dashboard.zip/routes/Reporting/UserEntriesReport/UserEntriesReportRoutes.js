const express = require("express");
const router = express.Router();
const ReportController = require("../../../controllers/Reporting/UserEntriesReport/UserEntriesReportController");

router.get("/users/:company_id", ReportController.getCompanyUsers);
router.post("/entries", ReportController.getUserEntriesReport);

module.exports = router;