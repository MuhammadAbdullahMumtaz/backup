const express = require("express");
const router = express.Router();

const {
  getFinancialYearRange,
  getProfitAndLoss,
} = require("../../../controllers/Reporting/Profitloss/ProfitlossController");

// GET /profit-loss/financial-year?company_id=&financialyear_id=
router.get("/financial-year", getFinancialYearRange);

// GET /profit-loss/report?company_id=&financialyear_id=&start_date=&end_date=
router.get("/report", getProfitAndLoss);

module.exports = router;