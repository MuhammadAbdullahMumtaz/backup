const express = require("express");
const router = express.Router();
const {
  searchItems,
  getItemMovementReport,
  getItemsSummaryReport,
} = require("../../../controllers/Reporting/Gatepass/GatepassController"); 

// GET /api/gatepass-report/items/search?company_id=&q=
router.get("/items/search", searchItems);

// GET /api/gatepass-report/item-report?company_id=&item_code=&department_id=&start_date=&end_date=
router.get("/item-report", getItemMovementReport);

// GET /api/gatepass-report/summary-report?company_id=&department_id=&start_date=&end_date=
router.get("/summary-report", getItemsSummaryReport);

module.exports = router;

// In your main app file, mount this the same way LedgerRoutes.js is mounted, e.g.:
//   app.use("/api/gatepass-report", require("./routes/GatePassReportRoutes"));