const express = require("express");
const router = express.Router();
const SalesContractDetailController = require("../../../../controllers/DataEntry/SalesContractEntry/SalesContractDetail/SalesContractDetailController");

router.get("/", SalesContractDetailController.getAllSalesContractDetails);
router.get("/contract/:salescontractmain_id", SalesContractDetailController.getSalesContractDetailsBySalesContractMain);
router.get("/:id", SalesContractDetailController.getSalesContractDetailById);
router.post("/", SalesContractDetailController.addSalesContractDetail);
router.put("/:id", SalesContractDetailController.updateSalesContractDetail);
router.delete("/:id", SalesContractDetailController.deleteSalesContractDetail);

module.exports = router;