const express = require("express");
const router = express.Router();
const SalesContractMainController = require("../../../../controllers/DataEntry/SalesContractEntry/SalesContractMain/SalesContractMainController");

router.get("/", SalesContractMainController.getAllSalesContractMains);
router.get("/next-number/:company_id/:financialyear_id", SalesContractMainController.getNextContractNumber);
router.get("/:id/with-details", SalesContractMainController.getSalesContractWithDetails);
router.get("/:id", SalesContractMainController.getSalesContractMainById);
router.post("/", SalesContractMainController.addSalesContractMain);
router.put("/:id", SalesContractMainController.updateSalesContractMain);
router.delete("/:id", SalesContractMainController.deleteSalesContractMain);

module.exports = router;