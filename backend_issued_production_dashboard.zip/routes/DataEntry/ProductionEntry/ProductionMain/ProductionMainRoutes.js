const express = require("express");
const router = express.Router();
const ProductionMainController = require("../../../../controllers/DataEntry/ProductionEntry/ProductionMain/ProductionMainController");

router.get("/", ProductionMainController.getAllProductionMains);
router.get("/next-number/:company_id/:financialyear_id", ProductionMainController.getNextProductionNumber);
router.get("/:id/with-details", ProductionMainController.getProductionWithDetails);
router.get("/:id", ProductionMainController.getProductionMainById);
router.post("/", ProductionMainController.addProductionMain);
router.put("/:id", ProductionMainController.updateProductionMain);
router.delete("/:id", ProductionMainController.deleteProductionMain);

module.exports = router;