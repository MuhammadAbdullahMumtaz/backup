const express = require("express");
const router = express.Router();
const ProductionDetailController = require("../../../../controllers/DataEntry/ProductionEntry/ProductionDetail/ProductionDetailController");

router.get("/", ProductionDetailController.getAllProductionDetails);
router.get("/production/:productionmain_id", ProductionDetailController.getProductionDetailsByProductionMain);
router.get("/:id", ProductionDetailController.getProductionDetailById);
router.post("/", ProductionDetailController.addProductionDetail);
router.put("/:id", ProductionDetailController.updateProductionDetail);
router.delete("/:id", ProductionDetailController.deleteProductionDetail);

module.exports = router;