const express = require("express");
const router = express.Router();

const inwardGatePassMainController = require("../../../../controllers/DataEntry/InwardGatePass/InwardGatePassMain/InwardGatePassMainController");

// ==========================================================
// Inward Gate Pass Main Routes
// Base path (mount point), e.g. app.use('/inward-gate-pass-main', router)
// ==========================================================

// Get all inward gate passes
router.get("/", inwardGatePassMainController.getAllInwardGatePassMains);

// Preview the next inward number for a company/financial year
router.get("/next-inward/:company_id/:financialyear_id", inwardGatePassMainController.getNextInwardNumber);

// Get a single inward gate pass with all of its line entries
router.get("/:id/with-details", inwardGatePassMainController.getInwardGatePassWithDetails);

// Get single inward gate pass by id
router.get("/:id", inwardGatePassMainController.getInwardGatePassMainById);

// Add new inward gate pass
router.post("/", inwardGatePassMainController.addInwardGatePassMain);

// Update inward gate pass
router.put("/:id", inwardGatePassMainController.updateInwardGatePassMain);

// Delete inward gate pass
router.delete("/:id", inwardGatePassMainController.deleteInwardGatePassMain);

module.exports = router;