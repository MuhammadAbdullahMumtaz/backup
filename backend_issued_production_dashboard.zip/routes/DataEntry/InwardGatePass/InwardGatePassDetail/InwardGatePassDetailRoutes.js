const express = require("express");
const router = express.Router();

const inwardGatePassDetailController  = require("../../../../controllers/DataEntry/InwardGatePass/InwardGatePassDetail/InwardGatePassDetailController");

// ==========================================================
// Inward Gate Pass Detail Routes
// Base path (mount point), e.g. app.use('/inward-gate-pass-detail', router)
// ==========================================================

// Get all inward gate pass details
router.get("/", inwardGatePassDetailController.getAllInwardGatePassDetails);

// Get details for a specific inward gate pass main
// (matches the frontend's detailByMainPath: `/inward-gate-pass-detail/inward/${mainId}`)
router.get("/inward/:inwardgatepassmain_id", inwardGatePassDetailController.getInwardGatePassDetailsByMain);

// Get single detail by id
router.get("/:id", inwardGatePassDetailController.getInwardGatePassDetailById);

// Add new detail line
router.post("/", inwardGatePassDetailController.addInwardGatePassDetail);

// Update detail line
router.put("/:id", inwardGatePassDetailController.updateInwardGatePassDetail);

// Delete detail line
router.delete("/:id", inwardGatePassDetailController.deleteInwardGatePassDetail);

module.exports = router;