const express = require("express");
const router = express.Router();

const outwardGatePassMainController = require("../../../../controllers/DataEntry/OutwardGatePass/OutwardGatePassMain/OutwardGatePassMainController");

// ==========================================================
// Outward Gate Pass Main Routes
// Base path (mount point), e.g. app.use('/outward-gate-pass-main', router)
// ==========================================================

// Get all outward gate passes
router.get("/", outwardGatePassMainController.getAllOutwardGatePassMains);

// Preview the next outward number for a company/financial year
router.get("/next-outward/:company_id/:financialyear_id", outwardGatePassMainController.getNextOutwardNumber);

// Get a single outward gate pass with all of its line entries
router.get("/:id/with-details", outwardGatePassMainController.getOutwardGatePassWithDetails);

// Get single outward gate pass by id
router.get("/:id", outwardGatePassMainController.getOutwardGatePassMainById);

// Add new outward gate pass
router.post("/", outwardGatePassMainController.addOutwardGatePassMain);

// Update outward gate pass
router.put("/:id", outwardGatePassMainController.updateOutwardGatePassMain);

// Delete outward gate pass
router.delete("/:id", outwardGatePassMainController.deleteOutwardGatePassMain);

module.exports = router;