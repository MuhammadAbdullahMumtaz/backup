const express = require("express");
const router = express.Router();

const outwardGatePassDetailController = require("../../../../controllers/DataEntry/OutwardGatePass/OutwardGatePassDetail/OutwardGatePassDetailController");

// ==========================================================
// Outward Gate Pass Detail Routes
// Base path (mount point), e.g. app.use('/outward-gate-pass-detail', router)
// ==========================================================

// Get all outward gate pass detail lines
router.get("/", outwardGatePassDetailController.getAllOutwardGatePassDetails);

// Get all detail lines for one outward gate pass
router.get("/outward/:outwardgatepassmain_id", outwardGatePassDetailController.getOutwardGatePassDetailsByMain);

// Get a single detail line by id
router.get("/:id", outwardGatePassDetailController.getOutwardGatePassDetailById);

// Add a new detail line
router.post("/", outwardGatePassDetailController.addOutwardGatePassDetail);

// Update a detail line
router.put("/:id", outwardGatePassDetailController.updateOutwardGatePassDetail);

// Delete a detail line
router.delete("/:id", outwardGatePassDetailController.deleteOutwardGatePassDetail);

module.exports = router;