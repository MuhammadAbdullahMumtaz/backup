const express = require("express");
const router = express.Router();

// adjust this path to match where your controller actually lives
const controller = require("../../../../controllers/DataEntry/PurchaseReturnEntry/PurchaseRetrunMain/PurchaseReturnMainController");

router.get("/", controller.getAllPurchaseReturnMains);
router.get("/next-return-number/:company_id/:financialyear_id", controller.getNextReturnNumber);
router.get("/:id/with-details", controller.getPurchaseReturnWithDetails);
router.get("/:id/auto-entries", controller.getAutoEntriesForPurchaseReturnMain);
router.get("/:id", controller.getPurchaseReturnMainById);
router.post("/", controller.addPurchaseReturnMain);
router.put("/:id", controller.updatePurchaseReturnMain);
router.delete("/:id", controller.deletePurchaseReturnMain);

module.exports = router;