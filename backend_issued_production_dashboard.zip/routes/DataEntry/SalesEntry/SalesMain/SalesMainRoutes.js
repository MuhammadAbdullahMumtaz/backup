const express = require("express");
const router = express.Router();

const {
    getAllSalesMains,
    getNextInvoiceNumber,
    getSalesMainById,
    addSalesMain,
    updateSalesMain,
    deleteSalesMain,
    getSaleWithDetails,
    getAutoEntriesForSalesMain,
} = require("../../../../controllers/DataEntry/SalesEntry/SalesMain/SalesMainController");

// Get All
router.get("/", getAllSalesMains);

// Get Next Invoice Number
router.get("/next/:company_id/:financialyear_id", getNextInvoiceNumber);

// Get Auto Entries
router.get("/:id/auto-entries", getAutoEntriesForSalesMain);

// Get With Details
router.get("/:id/details", getSaleWithDetails);

// Get By ID
router.get("/:id", getSalesMainById);

// Insert
router.post("/", addSalesMain);

// Update
router.put("/:id", updateSalesMain);

// Delete
router.delete("/:id", deleteSalesMain);

module.exports = router;