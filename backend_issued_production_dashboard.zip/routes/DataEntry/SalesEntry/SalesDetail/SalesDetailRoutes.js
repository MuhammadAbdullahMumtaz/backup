const express = require("express");
const router = express.Router();

const {
    getAllSalesDetails,
    getSalesDetailsBySalesMain,
    getSalesDetailById,
    addSalesDetail,
    updateSalesDetail,
    deleteSalesDetail,
    getAvailableStock,
} = require("../../../../controllers/DataEntry/SalesEntry/SalesDetail/SalesDetailController");

// Get Available Stock
router.get('/available-stock', getAvailableStock);

// Get All
router.get("/", getAllSalesDetails);

// Get By Sales Main ID
router.get("/sale/:sale_main", getSalesDetailsBySalesMain);

// Get By ID
router.get("/:id", getSalesDetailById);

// Insert
router.post("/", addSalesDetail);

// Update
router.put("/:id", updateSalesDetail);

// Delete
router.delete("/:id", deleteSalesDetail);

module.exports = router;