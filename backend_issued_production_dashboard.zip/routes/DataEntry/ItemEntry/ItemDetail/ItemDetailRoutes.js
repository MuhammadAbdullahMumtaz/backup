const express = require("express");

const router = express.Router();

const {

    getAllItemDetails,
    getItemDetailById,
    addItemDetail,
    updateItemDetail,
    deleteItemDetail

} = require("../../../../controllers/DataEntry/ItemEntry/ItemDetail/ItemDetailController");


// Get All
router.get("/", getAllItemDetails);

// Get By ID
router.get("/:id", getItemDetailById);

// Add
router.post("/", addItemDetail);

// Update
router.put("/:id", updateItemDetail);

// Delete
router.delete("/:id", deleteItemDetail);

module.exports = router;