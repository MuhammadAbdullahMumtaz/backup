// routes/DataEntry/IssuedEntry/IssuedDetailRoutes.js
const express = require("express");
const router = express.Router();
const issuedDetailController = require("../../../../controllers/DataEntry/IssuedEntry/IssuedDetail/IssuedDetailController");

router.get("/", issuedDetailController.getAllIssuedDetails);
router.get("/available-stock", issuedDetailController.getAvailableStockForIssue);
router.get("/issued/:issuedmain_id", issuedDetailController.getIssuedDetailsByIssuedMain);
router.get("/:id", issuedDetailController.getIssuedDetailById);
router.post("/", issuedDetailController.addIssuedDetail);
router.put("/:id", issuedDetailController.updateIssuedDetail);
router.delete("/:id", issuedDetailController.deleteIssuedDetail);

module.exports = router;