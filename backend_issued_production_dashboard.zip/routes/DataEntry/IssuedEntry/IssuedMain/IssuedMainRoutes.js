// routes/DataEntry/IssuedEntry/IssuedMainRoutes.js
const express = require("express");
const router = express.Router();
const issuedMainController = require("../../../../controllers/DataEntry/IssuedEntry/IssuedMain/IssuedMainController");

router.get("/", issuedMainController.getAllIssuedMains);
router.get("/next/:company_id/:financialyear_id", issuedMainController.getNextIssuedNumber);
router.get("/:id", issuedMainController.getIssuedMainById);
router.get("/:id/with-details", issuedMainController.getIssuedWithDetails);
router.post("/", issuedMainController.addIssuedMain);
router.put("/:id", issuedMainController.updateIssuedMain);
router.delete("/:id", issuedMainController.deleteIssuedMain);

module.exports = router;