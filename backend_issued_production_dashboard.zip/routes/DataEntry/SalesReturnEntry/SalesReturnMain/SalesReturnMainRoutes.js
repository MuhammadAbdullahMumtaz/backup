const express = require("express");
const router = express.Router();

const controller = require("../../../../controllers/DataEntry/SalesReturnEntry/SalesReturnMain/SalesReturnMainController");

router.get("/", controller.getAllSalesReturnMains);
router.get("/next/:company_id/:financialyear_id", controller.getNextReturnInvoiceNumber);
router.get("/:id", controller.getSalesReturnMainById);
router.get("/:id/details", controller.getSalesReturnWithDetails);
router.get("/:id/auto-entries", controller.getAutoEntriesForSalesReturnMain);
router.post("/", controller.addSalesReturnMain);
router.put("/:id", controller.updateSalesReturnMain);
router.delete("/:id", controller.deleteSalesReturnMain);

module.exports = router;