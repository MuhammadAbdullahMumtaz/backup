const express = require("express");
const router = express.Router();

const {
    getAllPurchaseMains,
    getNextGrnNumber,
    getPurchaseMainById,
    addPurchaseMain,
    updatePurchaseMain,
    deletePurchaseMain,
    getPurchaseWithDetails,
    getAutoEntriesForPurchaseMain,
} = require("../../../../controllers/DataEntry/PurchaseEntry/PurchaseMain/PurchaseMainController");

// Get All
router.get("/", getAllPurchaseMains);

// Get Next GRN Number
router.get("/next/:company_id/:financialyear_id", getNextGrnNumber);

// Get With Details
router.get("/:id/details", getPurchaseWithDetails);

// Get By ID
router.get("/:id", getPurchaseMainById);

// Get Auto Entries
router.get("/:id/auto-entries", getAutoEntriesForPurchaseMain);

// Insert
router.post("/", addPurchaseMain);

// Update
router.put("/:id", updatePurchaseMain);

// Delete
router.delete("/:id", deletePurchaseMain);

module.exports = router;