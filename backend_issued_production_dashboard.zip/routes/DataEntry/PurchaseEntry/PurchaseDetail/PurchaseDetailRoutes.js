const express = require("express");
const router = express.Router();

const {
    getAllPurchaseDetails,
    getPurchaseDetailsByPurchaseMain,
    getPurchaseDetailById,
    addPurchaseDetail,
    updatePurchaseDetail,
    deletePurchaseDetail,
    updatePurchaseDetailStockStatus,
} = require("../../../../controllers/DataEntry/PurchaseEntry/PurchaseDetail/PurchaseDetailController");

// Get All
router.get("/", getAllPurchaseDetails);

// Get By Purchase Main ID
router.get("/purchase/:purchasemain_id", getPurchaseDetailsByPurchaseMain);

// Get By ID
router.get("/:id", getPurchaseDetailById);

// Insert
router.post("/", addPurchaseDetail);

// Update
router.put("/:id", updatePurchaseDetail);

// Delete
router.delete("/:id", deletePurchaseDetail);

router.put("/:id", updatePurchaseDetailStockStatus);

module.exports = router;