const express = require("express");
const router = express.Router();
const dashboardController = require("../../controllers/Dashboard/DashboardController");
// NOTE: adjust the require path above to match wherever dashboardController.js
// actually lives in your controllers/ tree (same depth as the other
// Reporting controllers, e.g. controllers/Reporting/Dashboard/dashboardController.js).

// GET /api/dashboard/summary?company_id=&financialyear_id=&start_date=&end_date=
router.get("/summary", dashboardController.getDashboardSummary);

module.exports = router;

// Mount this in your main app/router alongside the other Reporting routes, e.g.:
//   app.use("/api/dashboard", require("./routes/dashboardRoutes"));