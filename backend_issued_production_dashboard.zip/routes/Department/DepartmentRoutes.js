const express = require("express");
const router = express.Router();

const departmentController = require("../../controllers/Department/DepartmentController");

// =============================
// Department Routes
// =============================

// Get all departments
router.get("/", departmentController.getDepartments);

// Get single department by id
router.get("/:id", departmentController.getDepartmentById);

// Add new department
router.post("/add", departmentController.addDepartment);

// Update department
router.put("/update/:id", departmentController.updateDepartment);

// Delete department
router.delete("/delete/:id", departmentController.deleteDepartment);

module.exports = router;