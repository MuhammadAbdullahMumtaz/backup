const db = require("../config/db");

exports.logActivity = async ({
    document_type,
    document_no = null,
    document_date = null,
    status,
    remarks = null,
    username,
    system_name_ip = null
}) => {
    try {
        await db.query(
            `INSERT INTO ActivityLog
                (document_type, document_no, document_date, status, remarks, username, system_name_ip)
             VALUES (?,?,?,?,?,?,?)`,
            [document_type, document_no, document_date, status, remarks, username, system_name_ip]
        );
    } catch (err) {
        // Logging failures shouldn't break the main operation, just record it.
        console.error("Failed to insert ActivityLog:", err);
    }
};