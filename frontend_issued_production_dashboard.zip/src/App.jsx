import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import Login from './Features/Auth/Login';
import Dashboard from './dashboard/Dashboard';
import 'react-toastify/dist/ReactToastify.css';

const isAuthenticated = () => {
  const hasToken = localStorage.getItem('token') !== null;
  if (!hasToken) return false;

  try {
    const persistedRoot = JSON.parse(localStorage.getItem('persist:root') || '{}');
    const company = JSON.parse(persistedRoot.company || '{}');
    return Boolean(company.companyId && company.companyName);
  } catch (error) {
    return false;
  }
};

const App = () => {
  const [authenticated, setAuthenticated] = useState(isAuthenticated());

  // Listen for storage changes (when logout happens in another tab)
  useEffect(() => {
    const handleStorageChange = () => {
      setAuthenticated(isAuthenticated());
    };

    window.addEventListener('storage', handleStorageChange);
    
    // Custom event for logout (if you dispatch one)
    const handleCustomAuthChange = () => {
      setAuthenticated(isAuthenticated());
    };
    
    window.addEventListener('authChange', handleCustomAuthChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('authChange', handleCustomAuthChange);
    };
  }, []);

  // Also check periodically (optional)
  useEffect(() => {
    const interval = setInterval(() => {
      const newAuth = isAuthenticated();
      if (newAuth !== authenticated) {
        setAuthenticated(newAuth);
      }
    }, 1000); // Check every second

    return () => clearInterval(interval);
  }, [authenticated]);

  return (
    <Router>
      <div className="app">
        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
        />
        <Routes>
          <Route path="/login" element={authenticated ? <Navigate to="/dashboard" /> : <Login />} />
          <Route
            path="/dashboard/*"
            element={authenticated ? <Dashboard /> : <Navigate to="/login" />}
          />
          <Route path="/" element={<Navigate to={authenticated ? "/dashboard" : "/login"} />} />
          <Route path="*" element={<Navigate to={authenticated ? "/dashboard" : "/login"} />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;