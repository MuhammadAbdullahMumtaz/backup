import React, { useState, useEffect, useRef, useMemo } from "react";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import api from "../services/api";

/**
 * DashboardHome — the "home" landing view.
 *
 * Talks to the dashboard controller's single endpoint:
 *   GET /api/dashboard/summary?company_id=&financialyear_id=&start_date=&end_date=
 * (see dashboardController.js / dashboardRoutes.js)
 *
 * Same conventions as Ledger.jsx: company_id / financialyear_id come from
 * Redux (state.company), dates are plain 'YYYY-MM-DD' strings, and the
 * visual language (colors, radii, spacing) matches the rest of the
 * Reporting pages so it drops straight into the app.
 */

const API = { dashboard: "/dashboard" };

const PALETTE = {
    ink: "#1B2430",
    gold: "#B08A2E",
    paper: "#FAFAF7",
    card: "#F4F2EC",
    cardGold: "#EFE6CE",
    border: "#E6E2D8",
    sales: "#B08A2E",
    purchases: "#4C6E8A",
    danger: "#C0392B",
};

function pad2(n) {
    return String(n).padStart(2, "0");
}
function todayISO() {
    const d = new Date();
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
function monthsAgoISO(months) {
    const d = new Date();
    d.setMonth(d.getMonth() - months);
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
function isoToDisplay(iso) {
    if (!iso) return "";
    const [y, m, d] = String(iso).slice(0, 10).split("-");
    return `${d}-${m}-${y}`;
}
function formatMoney(n) {
    const num = Number(n) || 0;
    const abs = Math.abs(num).toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    return num < 0 ? `(${abs})` : abs;
}
function formatCompact(n) {
    const num = Number(n) || 0;
    const sign = num < 0 ? "-" : "";
    const a = Math.abs(num);
    if (a >= 1_000_000) return `${sign}${(a / 1_000_000).toFixed(1)}M`;
    if (a >= 1_000) return `${sign}${(a / 1_000).toFixed(1)}K`;
    return `${sign}${a.toFixed(0)}`;
}

// ---------------------------------------------------------------------------
// KPI card
// ---------------------------------------------------------------------------
function KpiCard({ label, value, accent, sub, highlight }) {
    return (
        <div
            className={`flex flex-col gap-1.5 rounded-xl border border-[#E6E2D8] px-4 py-4 shadow-sm transition hover:shadow-md ${highlight ? "bg-[#EFE6CE]" : "bg-white"
                }`}
        >
            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{label}</span>
            <span className="text-2xl font-bold tabular-nums" style={{ color: accent || PALETTE.ink }}>
                {value}
            </span>
            {sub && <span className="text-xs text-slate-400">{sub}</span>}
        </div>
    );
}

// ---------------------------------------------------------------------------
// Attractive custom line chart — Sales vs Purchases trend.
// Pure inline SVG (no chart library dependency): gradient area fill under
// the Sales line, smooth curves, grid lines, a live crosshair + tooltip on
// hover, and a small legend.
// ---------------------------------------------------------------------------
function TrendChart({ data }) {
    const wrapRef = useRef(null);
    const [hoverIdx, setHoverIdx] = useState(null);

    const W = 760;
    const H = 300;
    const PAD_L = 48;
    const PAD_R = 16;
    const PAD_T = 20;
    const PAD_B = 34;
    const innerW = W - PAD_L - PAD_R;
    const innerH = H - PAD_T - PAD_B;

    const { points, maxVal, gridLines } = useMemo(() => {
        const vals = data.flatMap((d) => [d.sales, d.purchases]);
        const rawMax = vals.length ? Math.max(...vals, 0) : 0;
        const max = rawMax <= 0 ? 1 : rawMax * 1.15;

        const n = Math.max(data.length - 1, 1);
        const xFor = (i) => PAD_L + (innerW * i) / n;
        const yFor = (v) => PAD_T + innerH - (innerH * v) / max;

        const salesPts = data.map((d, i) => [xFor(i), yFor(d.sales)]);
        const purchasePts = data.map((d, i) => [xFor(i), yFor(d.purchases)]);

        const lines = 4;
        const grid = Array.from({ length: lines + 1 }, (_, i) => {
            const v = (max * (lines - i)) / lines;
            return { y: PAD_T + (innerH * i) / lines, label: formatCompact(v) };
        });

        return { points: { salesPts, purchasePts, xFor, yFor }, maxVal: max, gridLines: grid };
    }, [data, innerW, innerH]);

    function toPath(pts) {
        if (pts.length === 0) return "";
        if (pts.length === 1) return `M ${pts[0][0]},${pts[0][1]}`;
        // Simple Catmull-Rom -> cubic bezier smoothing for a gentle curve.
        let d = `M ${pts[0][0]},${pts[0][1]}`;
        for (let i = 0; i < pts.length - 1; i++) {
            const p0 = pts[i - 1] || pts[i];
            const p1 = pts[i];
            const p2 = pts[i + 1];
            const p3 = pts[i + 2] || p2;
            const cp1x = p1[0] + (p2[0] - p0[0]) / 6;
            const cp1y = p1[1] + (p2[1] - p0[1]) / 6;
            const cp2x = p2[0] - (p3[0] - p1[0]) / 6;
            const cp2y = p2[1] - (p3[1] - p1[1]) / 6;
            d += ` C ${cp1x},${cp1y} ${cp2x},${cp2y} ${p2[0]},${p2[1]}`;
        }
        return d;
    }

    const salesPath = toPath(points.salesPts || []);
    const purchasePath = toPath(points.purchasePts || []);
    const areaPath =
        (points.salesPts || []).length > 0
            ? `${salesPath} L ${points.salesPts[points.salesPts.length - 1][0]},${PAD_T + innerH} L ${points.salesPts[0][0]},${PAD_T + innerH} Z`
            : "";

    function handleMove(e) {
        if (!data.length) return;
        const svg = wrapRef.current;
        if (!svg) return;
        const rect = svg.getBoundingClientRect();
        const relX = ((e.clientX - rect.left) / rect.width) * W;
        const n = Math.max(data.length - 1, 1);
        const idx = Math.round(((relX - PAD_L) / innerW) * n);
        setHoverIdx(Math.min(Math.max(idx, 0), data.length - 1));
    }

    const active = hoverIdx != null ? data[hoverIdx] : null;
    const activeX = hoverIdx != null ? points.xFor(hoverIdx) : null;

    return (
        <div className="rounded-xl border border-[#E6E2D8] bg-white p-5 shadow-sm">
            <div className="mb-3 flex items-center justify-between">
                <div>
                    <span className="mb-0.5 block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                        Trend
                    </span>
                    <h3 className="text-base font-bold text-[#1B2430]">Sales vs Purchases</h3>
                </div>
                <div className="flex items-center gap-4 text-xs font-semibold text-slate-500">
                    <span className="flex items-center gap-1.5">
                        <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: PALETTE.sales }} />
                        Sales
                    </span>
                    <span className="flex items-center gap-1.5">
                        <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: PALETTE.purchases }} />
                        Purchases
                    </span>
                </div>
            </div>

            {data.length === 0 ? (
                <div className="flex h-[260px] items-center justify-center text-sm text-slate-400">
                    No transactions in this period yet.
                </div>
            ) : (
                <svg
                    ref={wrapRef}
                    viewBox={`0 0 ${W} ${H}`}
                    className="w-full cursor-crosshair select-none"
                    onMouseMove={handleMove}
                    onMouseLeave={() => setHoverIdx(null)}
                >
                    <defs>
                        <linearGradient id="salesFill" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor={PALETTE.sales} stopOpacity="0.28" />
                            <stop offset="100%" stopColor={PALETTE.sales} stopOpacity="0" />
                        </linearGradient>
                    </defs>

                    {/* Grid lines + Y labels */}
                    {gridLines.map((g, i) => (
                        <g key={i}>
                            <line x1={PAD_L} x2={W - PAD_R} y1={g.y} y2={g.y} stroke="#E6E2D8" strokeWidth="1" />
                            <text x={PAD_L - 8} y={g.y + 4} textAnchor="end" fontSize="10" fill="#94A3B8">
                                {g.label}
                            </text>
                        </g>
                    ))}

                    {/* X labels */}
                    {data.map((d, i) => (
                        <text
                            key={d.ym}
                            x={points.xFor(i)}
                            y={H - 10}
                            textAnchor="middle"
                            fontSize="10"
                            fill="#94A3B8"
                        >
                            {d.month.split(" ")[0]}
                        </text>
                    ))}

                    {/* Area fill under Sales */}
                    {areaPath && <path d={areaPath} fill="url(#salesFill)" />}

                    {/* Purchases line */}
                    <path d={purchasePath} fill="none" stroke={PALETTE.purchases} strokeWidth="2.5" strokeLinecap="round" />

                    {/* Sales line */}
                    <path d={salesPath} fill="none" stroke={PALETTE.sales} strokeWidth="3" strokeLinecap="round" />

                    {/* Points */}
                    {(points.salesPts || []).map((p, i) => (
                        <circle key={`s${i}`} cx={p[0]} cy={p[1]} r={hoverIdx === i ? 4.5 : 3} fill={PALETTE.sales} />
                    ))}
                    {(points.purchasePts || []).map((p, i) => (
                        <circle key={`p${i}`} cx={p[0]} cy={p[1]} r={hoverIdx === i ? 4.5 : 3} fill={PALETTE.purchases} />
                    ))}

                    {/* Crosshair */}
                    {activeX != null && (
                        <line x1={activeX} x2={activeX} y1={PAD_T} y2={PAD_T + innerH} stroke="#1B2430" strokeOpacity="0.15" strokeWidth="1.5" />
                    )}
                </svg>
            )}

            {active && (
                <div className="mt-3 flex items-center justify-between rounded-lg bg-[#F4F2EC] px-4 py-2.5 text-sm">
                    <span className="font-semibold text-[#1B2430]">{active.month}</span>
                    <div className="flex gap-5 tabular-nums">
                        <span style={{ color: PALETTE.sales }}>Sales: {formatMoney(active.sales)}</span>
                        <span style={{ color: PALETTE.purchases }}>Purchases: {formatMoney(active.purchases)}</span>
                        <span className="font-bold text-[#1B2430]">
                            Net: {formatMoney(active.sales - active.purchases)}
                        </span>
                    </div>
                </div>
            )}
        </div>
    );
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
export default function DashboardHome() {
    const { companyId: rawCompanyId, financialYearId: rawFinancialYearId, user } = useSelector(
        (state) => state.company
    );
    const companyId = rawCompanyId != null && rawCompanyId !== "" ? Number(rawCompanyId) : null;
    const financialYearId = rawFinancialYearId != null && rawFinancialYearId !== "" ? Number(rawFinancialYearId) : null;

    const [startDate] = useState(monthsAgoISO(5)); // last 6 months (inclusive) for the trend axis
    const [endDate] = useState(todayISO());
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!companyId || !financialYearId) {
            setData(null);
            return;
        }
        let cancelled = false;
        (async () => {
            setLoading(true);
            try {
                const res = await api.get(`${API.dashboard}/summary`, {
                    params: { company_id: companyId, financialyear_id: financialYearId, start_date: startDate, end_date: endDate },
                });
                if (!cancelled) {
                    if (res.data?.success) setData(res.data.data);
                    else toast.error(res.data?.message || "Failed to load dashboard.");
                }
            } catch (error) {
                if (!cancelled) toast.error(error?.response?.data?.message || "Could not reach the server.");
            } finally {
                if (!cancelled) setLoading(false);
            }
        })();
        return () => {
            cancelled = true;
        };
    }, [companyId, financialYearId, startDate, endDate]);

    if (!companyId) {
        return (
            <div className="p-8 text-center text-sm text-gray-500">
                No company context found. Please select a company first.
            </div>
        );
    }

    if (!financialYearId) {
        return (
            <div className="p-8 text-center text-sm text-gray-500">
                No financial year selected. Pick one to see your dashboard.
            </div>
        );
    }

    const kpis = data?.kpis;

    return (
        <div className="font-sans text-[#1B2430]">
            <div className="mb-6 flex items-end justify-between">
                <div>
                    <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                        Overview
                    </span>
                    <h1 className="text-2xl font-bold tracking-tight">
                        Welcome back{user?.username ? `, ${user.username}` : ""}
                    </h1>
                    {data && (
                        <p className="mt-1 text-xs text-slate-500">
                            Showing {isoToDisplay(data.start_date)} to {isoToDisplay(data.end_date)}
                        </p>
                    )}
                </div>
                {loading && <span className="text-xs font-semibold text-slate-400">Refreshing…</span>}
            </div>

            {/* KPI cards */}
            <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
                <KpiCard label="Sales" value={loading && !data ? "…" : formatCompact(kpis?.sales_total)} accent={PALETTE.sales} />
                <KpiCard label="Purchases" value={loading && !data ? "…" : formatCompact(kpis?.purchase_total)} accent={PALETTE.purchases} />
                <KpiCard label="Receivables" value={loading && !data ? "…" : formatCompact(kpis?.receivable_outstanding)} accent={PALETTE.ink} />
                <KpiCard label="Payables" value={loading && !data ? "…" : formatCompact(kpis?.payable_outstanding)} accent={PALETTE.ink} />
                <KpiCard label="Raw Stocks" value={loading && !data ? "…" : formatCompact(kpis?.raw_stock_total)} accent={PALETTE.purchases} />
                <KpiCard label="Finished Stocks" value={loading && !data ? "…" : formatCompact(kpis?.finished_stock_total)} accent={PALETTE.sales} />
            </div>

            {/* Chart */}
            <div className="mb-6">
                <TrendChart data={data?.trend || []} />
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
                {/* Low stock */}
                <div className="rounded-xl border border-[#E6E2D8] bg-white p-5 shadow-sm">
                    <h3 className="mb-3 text-base font-bold">Low Stock Alerts</h3>
                    {!data?.low_stock?.length ? (
                        <p className="text-sm text-slate-400">Nothing below its minimum limit. 🎉</p>
                    ) : (
                        <ul className="flex flex-col gap-2">
                            {data.low_stock.map((item) => (
                                <li
                                    key={item.code}
                                    className="flex items-center justify-between rounded-lg bg-[#FBEDEC] px-3 py-2 text-sm"
                                >
                                    <span className="font-medium">{item.name}</span>
                                    <span className="tabular-nums text-[#C0392B]">
                                        {item.remaining} / {item.min_limit} {item.unit || ""}
                                    </span>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                {/* Top customers */}
                <div className="rounded-xl border border-[#E6E2D8] bg-white p-5 shadow-sm">
                    <h3 className="mb-3 text-base font-bold">Top Customers</h3>
                    {!data?.top_customers?.length ? (
                        <p className="text-sm text-slate-400">No sales yet in this period.</p>
                    ) : (
                        <ul className="flex flex-col gap-2">
                            {data.top_customers.map((c, i) => (
                                <li key={c.code} className="flex items-center justify-between rounded-lg bg-[#F4F2EC] px-3 py-2 text-sm">
                                    <span className="font-medium">
                                        <span className="mr-2 text-slate-400">#{i + 1}</span>
                                        {c.name}
                                    </span>
                                    <span className="tabular-nums font-semibold">{formatMoney(c.total_sales)}</span>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                {/* Recent activity */}
                <div className="rounded-xl border border-[#E6E2D8] bg-white p-5 shadow-sm">
                    <h3 className="mb-3 text-base font-bold">Recent Activity</h3>
                    {!data?.recent_activity?.length ? (
                        <p className="text-sm text-slate-400">No recent activity.</p>
                    ) : (
                        <ul className="flex flex-col gap-2">
                            {data.recent_activity.map((a) => (
                                <li key={a.id} className="flex items-center justify-between rounded-lg bg-[#F4F2EC] px-3 py-2 text-sm">
                                    <div className="flex flex-col">
                                        <span className="font-medium">
                                            {a.document_type} {a.document_no ? `#${a.document_no}` : ""}
                                        </span>
                                        <span className="text-xs text-slate-400">{a.username}</span>
                                    </div>
                                    <span
                                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white ${a.status === "Delete" ? "bg-red-600" : a.status === "Edit" ? "bg-amber-500" : "bg-emerald-600"
                                            }`}
                                    >
                                        {a.status}
                                    </span>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
}