import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import Navbar from '../components/Navbar';
import Sidebar from '../components/Sidebar';
import Company from '../features/company/Company';
import Department from '../features/department/Department';
import FinancialYear from '../features/financialyear/FinancialYear';
import Login from '../features/login/Login';
import ChartOfAccount from '../features/DataEntry/chartofaccount/ChartOfAccount';
import ItemEntry from '../features/DataEntry/ItemEntry/ItemEntry';
import VoucherEntry from '../features/DataEntry/VoucherEntry/VoucherEntry';
import InwardGatePassEntry from '../features/DataEntry/InwardGatePass/InwardGatePass';
import PurchaseEntry from '../features/DataEntry/PurchaseEntry/PurchaseEntry';
import IssuedEntry from '../features/DataEntry/IssuedEntry/IssuedEntry';
import ProductionEntry from '../features/DataEntry/ProductionEntry/ProductionEntry';
import SalesContractEntry from '../features/DataEntry/SalesContract/SalesContract';
import OutwardGatePassEntry from '../features/DataEntry/OutwardGatePass/OutwardGatePass';
import SalesEntry from '../features/DataEntry/SalesEntry/SalesEntry';

import Ledger from '../features/Reporting/Ledger/Ledger';
import TrialBalance from '../features/Reporting/TrialBalance/TrialBalance';
import AgingReport from '../features/Reporting/Aging/Aging';
import SalesReport from '../features/Reporting/SalesReport/SalesReport';
import PurchaseReport from '../features/Reporting/PurchaseReport/PurchaseReport';
import IssuedReport from '../features/Reporting/Issued/IssuedReport';
import ProductionReport from '../features/Reporting/Production/ProductionReport';
import GatePassReport from '../features/Reporting/Gatepass/GatepassReport';
import RawStockReport from '../features/Reporting/RawStocks/RawStockReport';
import FinishedStockReport from '../features/Reporting/FinishedStock/FinishedStockReport';
import StockReport from '../features/Reporting/StocksReport/StocksReport';
import UserEntriesReport from '../features/Reporting/UserEntriesReport/UserEntriesReport'
import ProfitLoss from '../features/Reporting/Profitloss/Profitloss';

import DashboardHome from './DashboardHome';

const Dashboard = () => {
  const { user } = useSelector((state) => state.company);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isNavbarOpen, setIsNavbarOpen] = useState(true);
  const [activeView, setActiveView] = useState('home');

  const [previousView, setPreviousView] = useState(null);
  const [ledgerVisited, setLedgerVisited] = useState(false);
  const [trialVisited, setTrialVisited] = useState(false);

  const [navPayload, setNavPayload] = useState(null);

  // Called by Ledger/TrialBalance row double-click
  const handleNavigateFromLedger = (view, payload) => {
    setNavPayload(payload);
    setPreviousView(activeView); // remember we came from Ledger (or Trial Balance)
    setActiveView(view);
  };

  // Called by the "Back" button on Voucher/Purchase/Sales
  const handleBack = () => {
    if (!previousView) return;
    setActiveView(previousView);
    setPreviousView(null);
  };

  const clearNavPayload = () => setNavPayload(null);

  // Use this for ALL normal sidebar/navbar navigation — it breaks the
  // "back" chain since the user is starting a fresh path, not returning.
  const goTo = (view) => {
    setPreviousView(null);
    setActiveView(view);
  };

  useEffect(() => {
    if (activeView === 'ledger-report') setLedgerVisited(true);
    if (activeView === 'trial-balance') setTrialVisited(true);
  }, [activeView]);

  const toggleSidebar = () => setIsSidebarOpen((prev) => !prev);
  const toggleNavbar = () => setIsNavbarOpen((prev) => !prev);

  return (
    <div className="relative min-h-screen">
      {/* Background Image (unchanged) */}
      <div
        className="fixed inset-0 bg-cover bg-center pointer-events-none -z-10"
        style={{
          backgroundColor: '#f9f9f9',
          backgroundImage: `repeating-linear-gradient(
    135deg,
    #e8e8e8 0px,
    #e8e8e8 2px,
    transparent 2px,
    transparent 7px
  )`,
          backgroundSize: 'auto'
        }}
      />

      <Navbar
        isOpen={isNavbarOpen}
        toggleNavbar={toggleNavbar}
        onLogoClick={() => goTo('home')}
        onCompanyClick={() => goTo('company')}
        onFinancialYearClick={() => goTo('financial-year')}
        onLoginClick={() => goTo('login')}
        onDepartmentClick={() => goTo('department')}
      />

      <Sidebar
        isOpen={isSidebarOpen}
        isNavbarOpen={isNavbarOpen}
        toggleSidebar={toggleSidebar}
        onAccountsClick={() => goTo('chart-of-account')}
        onItemEntryClick={() => goTo('item-entry')}
        onInwardGatePassEntryClick={() => goTo('inward-gate-pass-entry')}
        onVoucherEntryClick={() => goTo('voucher-entry')}
        onPurchaseEntryClick={() => goTo('purchase-entry')}
        onIssuedEntryClick={() => goTo('issued-entry')}
        onProductionEntryClick={() => goTo('production-entry')}
        onSalesContractEntryClick={() => goTo('sales-contract-entry')}
        onOutwardGatePassEntryClick={() => goTo('outward-gate-pass-entry')}
        onSalesEntryClick={() => goTo('sales-entry')}
        onLedgerClick={() => goTo('ledger-report')}
        onTrialBalanceClick={() => goTo('trial-balance')}
        onAgingReportClick={() => goTo('aging-report')}
        onSalesReportClick={() => goTo('sales-report')}
        onPurchaseReportClick={() => goTo('purchase-report')}
        onIssuedReportClick={() => goTo('issued-report')}
        onProductionReportClick={() => goTo('production-report')}
        onGatepassReportClick={() => goTo('gatepass-report')}
        onRawStockReportClick={() => goTo('raw-stock-report')}
        onFinishedStockReportClick={() => goTo('finished-stock-report')}
        onStockReportClick={() => goTo('stock-report')}
        onUserEntriesReportClick={() => goTo('user-entries-report')}
        onProfitlossReportClick={() => goTo('profit-loss-report')}
      />

      <div
        className={`relative z-5 transition-all duration-300 ${isSidebarOpen ? 'ml-64' : 'ml-0'
          } ${isNavbarOpen ? 'pt-16' : 'pt-0'}`}
      >
        <div className="p-5 min-h-[calc(100vh-62px)]">
          <div className="bg-white/95 rounded-xl shadow-md min-h-[calc(100vh-92px)] p-5">

            {activeView === 'company' ? (
              <Company />
            ) : activeView === 'department' ? (
              <Department />
            ) : activeView === 'financial-year' ? (
              <FinancialYear />
            ) : activeView === 'login' ? (
              <Login />
            ) : activeView === 'chart-of-account' ? (
              <ChartOfAccount />
            ) : activeView === 'item-entry' ? (
              <ItemEntry />
            ) : activeView === 'inward-gate-pass-entry' ? (
              <InwardGatePassEntry />
            ) : activeView === 'issued-entry' ? (
              <IssuedEntry />
            ) : activeView === 'production-entry' ? (
              <ProductionEntry />
            ) : activeView === 'sales-contract-entry' ? (
              <SalesContractEntry />
            ) : activeView === 'outward-gate-pass-entry' ? (
              <OutwardGatePassEntry />
            ) : activeView === 'aging-report' ? (
              <AgingReport />
            ) : activeView === 'sales-report' ? (
              <SalesReport />
            ) : activeView === 'purchase-report' ? (
              <PurchaseReport />
            ) : activeView === 'issued-report' ? (
              <IssuedReport />
            ) : activeView === 'production-report' ? (
              <ProductionReport />
            ) : activeView === 'gatepass-report' ? (
              <GatePassReport />
            ) : activeView === 'raw-stock-report' ? (
              <RawStockReport />
            ) : activeView === 'finished-stock-report' ? (
              <FinishedStockReport />
            ) : activeView === 'stock-report' ? (
              <StockReport />
            ) : activeView === 'user-entries-report' ? (
              <UserEntriesReport />
            ) : activeView === 'profit-loss-report' ? (
              <ProfitLoss />
            ) : activeView === 'voucher-entry' ? (
              <VoucherEntry
                navPayload={navPayload}
                onNavPayloadConsumed={clearNavPayload}
                onBack={previousView ? handleBack : undefined}
              />
            ) : activeView === 'purchase-entry' ? (
              <PurchaseEntry
                navPayload={navPayload}
                onNavPayloadConsumed={clearNavPayload}
                onBack={previousView ? handleBack : undefined}
              />
            ) : activeView === 'sales-entry' ? (
              <SalesEntry
                navPayload={navPayload}
                onNavPayloadConsumed={clearNavPayload}
                onBack={previousView ? handleBack : undefined}
              />
            ) : activeView === 'trial-balance' || activeView === 'ledger-report' ? null : (

              <DashboardHome />
            )}

            {/* Ledger stays mounted (just hidden) once visited, so its
                account/dates/report state survives a round trip to
                Voucher/Purchase/Sales and back. */}
            {ledgerVisited && (
              <div style={{ display: activeView === 'ledger-report' ? 'block' : 'none' }}>
                <Ledger
                  onNavigate={handleNavigateFromLedger}
                  navPayload={navPayload}
                  onNavPayloadConsumed={clearNavPayload}
                  onBack={previousView ? handleBack : undefined}
                />
              </div>
            )}

            {trialVisited && (
              <div style={{ display: activeView === 'trial-balance' ? 'block' : 'none' }}>
                <TrialBalance
                  onNavigate={handleNavigateFromLedger}
                  navPayload={navPayload}
                  onNavPayloadConsumed={clearNavPayload}
                  onBack={previousView ? handleBack : undefined}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;