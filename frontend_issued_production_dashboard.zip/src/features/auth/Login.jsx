import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { toast } from 'react-toastify';
import { setCompany, setFinancialYear, setCurrentMonth, setUser } from '../../store/slices/companySlice';
import api from '../../services/api';
import loginImage from '../../assets/login.png';

const Login = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [loading, setLoading] = useState(false);
    const [companies, setCompanies] = useState([]);
    const [financialYears, setFinancialYears] = useState([]);
    const [formData, setFormData] = useState({
        companyId: '',
        financialYearId: '',
        username: '',
        password: ''
    });

    useEffect(() => {
        fetchCompanies();
    }, []);

    const fetchCompanies = async () => {
        try {
            const response = await api.get("/company");

            if (response.data && response.data.success && Array.isArray(response.data.data)) {
                const filtered = response.data.data.filter(c => c.company_name !== 'AAM Tech Solutions');
                setCompanies(filtered);
            } else if (Array.isArray(response.data)) {
                const filtered = response.data.filter(c => c.company_name !== 'AAM Tech Solutions');
                setCompanies(filtered);
            } else {
                console.error('Unexpected companies response format:', response.data);
                setCompanies([]);
                toast.error('Invalid companies data format');
            }
        } catch (error) {
            toast.error(error.response?.data?.message || "Unable to load companies");
            console.log('Error fetching companies:', error);
            setCompanies([]);
        }
    };
    
    const fetchFinancialYears = async (companyId) => {
        try {
            const response = await api.get(`/financial-year?companyId=${companyId}`);

            if (response.data && response.data.success) {
                if (Array.isArray(response.data.data)) {
                    setFinancialYears(response.data.data);
                }
                else if (response.data.data && typeof response.data.data === 'object') {
                    if (Array.isArray(response.data.data.rows)) {
                        setFinancialYears(response.data.data.rows);
                    } else {
                        setFinancialYears([response.data.data]);
                    }
                } else {
                    setFinancialYears([]);
                }
            } else if (Array.isArray(response.data)) {
                setFinancialYears(response.data);
            } else {
                console.error('Unexpected financial years response format:', response.data);
                setFinancialYears([]);
                toast.error('Invalid financial years data format');
            }
        } catch (error) {
            toast.error(error.response?.data?.message || "Unable to load Financial Years");
            console.log('Error fetching financial years:', error);
            setFinancialYears([]);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));

        if (name === 'companyId' && value) {
            fetchFinancialYears(value);
            setFormData(prev => ({
                ...prev,
                financialYearId: ''
            }));
        } else if (name === 'companyId' && !value) {
            setFinancialYears([]);
            setFormData(prev => ({
                ...prev,
                financialYearId: ''
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.username || !formData.password) {
            toast.error('Please enter username and password');
            return;
        }

        if (formData.companyId && !formData.financialYearId) {
            toast.error('Please select the financial year');
            return;
        }

        setLoading(true);

        try {
            const loginResponse = await api.post('/login/login', {
                username: formData.username,
                password: formData.password,
                company_id: formData.companyId || undefined
            });

            if (!loginResponse.data.success) {
                toast.error(loginResponse.data.message || 'Login failed');
                return;
            }

            const userData = loginResponse.data.user;
            const isMainAdmin = loginResponse.data.is_main_admin;

            dispatch(setUser(userData));
            localStorage.setItem('token', 'dummy-token');
            localStorage.setItem('user', JSON.stringify(userData));

            if (isMainAdmin) {
                // AAM Tech Solutions main admin - bypass selection, hardcode to id 1
                dispatch(setCompany({ companyId: 1, companyName: 'AAM Tech Solutions' }));
                dispatch(setFinancialYear({ financialYearId: 1, financialYearName: '', currentMonth: '' }));

                try {
                    const monthResponse = await api.get(`/financial-year/current-month/1`);
                    if (monthResponse.data?.success) {
                        dispatch(setCurrentMonth(monthResponse.data.data.current_month));
                    }
                } catch (monthError) {
                    console.error('[LOGIN] Error fetching current month:', monthError);
                }

                toast.success('Login successful!');
                navigate('/dashboard');
                return;
            }

            const selectedCompany = companies.find(c => c.id === parseInt(formData.companyId));
            dispatch(setCompany({
                companyId: formData.companyId,
                companyName: selectedCompany?.company_name || ''
            }));

            const selectedYear = financialYears.find(fy => fy.id === parseInt(formData.financialYearId));
            dispatch(setFinancialYear({
                financialYearId: formData.financialYearId,
                financialYearName: selectedYear?.year_detail || selectedYear?.year_name || '',
                currentMonth: selectedYear?.current_month || ''
            }));

            try {
                const monthResponse = await api.get(`/financial-year/current-month/${formData.financialYearId}`);
                if (monthResponse.data?.success) {
                    dispatch(setCurrentMonth(monthResponse.data.data.current_month));
                }
            } catch (monthError) {
                console.error('[LOGIN] Error fetching current month:', monthError);
            }

            toast.success('Login successful!');
            navigate('/dashboard');

        } catch (error) {
            toast.error(error.response?.data?.message || 'Login failed');
            console.error('Login error:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div
            className="min-h-screen w-full flex items-center justify-center p-4 md:p-8"
            style={{
                backgroundColor: '#fafafa',
                backgroundImage:
                    'radial-gradient(circle, #e5e5e5 1px, transparent 1px)',
                backgroundSize: '18px 18px'
            }}
        >
            <div className="w-full max-w-5xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row min-h-[600px]">
                <div className="w-full md:w-1/2 flex flex-col justify-center p-8 md:p-14">
                    <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-8">
                        Get Started Now
                    </h1>

                    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                        <div className="flex flex-col gap-2">
                            <label className="text-sm font-semibold text-gray-700">
                                Company Name
                            </label>
                            <select
                                name="companyId"
                                value={formData.companyId}
                                onChange={handleChange}
                                className="px-4 py-3 rounded-lg border-2 border-gray-200 bg-white text-sm text-gray-700 placeholder-gray-400 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 transition"
                            >
                                <option value="">Enter Your Company Name</option>
                                {companies && companies.length > 0 ? (
                                    companies.map((company) => (
                                        <option key={company.id} value={company.id}>
                                            {company.company_name}
                                        </option>
                                    ))
                                ) : (
                                    <option value="" disabled>No companies available</option>
                                )}
                            </select>
                        </div>

                        <div className="flex flex-col gap-2">
                            <label className="text-sm font-semibold text-gray-700">
                                Financial Year
                            </label>
                            <select
                                name="financialYearId"
                                value={formData.financialYearId}
                                onChange={handleChange}
                                disabled={!formData.companyId}
                                className="px-4 py-3 rounded-lg border-2 border-gray-200 bg-white text-sm text-gray-700 placeholder-gray-400 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed transition"
                            >
                                <option value="">Enter Your Financial year</option>
                                {financialYears && financialYears.length > 0 ? (
                                    financialYears.map((year) => (
                                        <option key={year.id} value={year.id}>
                                            {year.year_detail || year.year_name || `Year ${year.id}`}
                                        </option>
                                    ))
                                ) : (
                                    <option value="" disabled>No financial years available</option>
                                )}
                            </select>
                        </div>

                        <div className="flex flex-col gap-2">
                            <label className="text-sm font-semibold text-gray-700">
                                Username
                            </label>
                            <input
                                type="text"
                                name="username"
                                value={formData.username}
                                onChange={handleChange}
                                placeholder="Enter Username"
                                required
                                className="px-4 py-3 rounded-lg border-2 border-gray-200 bg-white text-sm text-gray-700 placeholder-gray-400 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 transition"
                            />
                        </div>

                        <div className="flex flex-col gap-2">
                            <label className="text-sm font-semibold text-gray-700">
                                Password
                            </label>
                            <input
                                type="password"
                                name="password"
                                value={formData.password}
                                onChange={handleChange}
                                placeholder="Enter Password"
                                required
                                className="px-4 py-3 rounded-lg border-2 border-gray-200 bg-white text-sm text-gray-700 placeholder-gray-400 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 transition"
                            />
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            className="mt-4 py-3 px-6 rounded-lg bg-green-700 hover:bg-green-800 text-white font-semibold text-base transition duration-200 disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:bg-green-700 shadow-md hover:shadow-lg w-full"
                        >
                            {loading ? "Signing In..." : "Sign In"}
                        </button>
                    </form>
                </div>

                <div className="hidden md:block md:w-1/2 relative">
                    <img
                        src={loginImage}
                        alt="Decorative"
                        className="absolute inset-0 w-full h-full object-cover"
                    />
                </div>
            </div>
        </div>
    );
};

export default Login;