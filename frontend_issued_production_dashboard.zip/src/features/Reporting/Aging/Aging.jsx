import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import api from '../../../services/api';

const LOOKUP_API = { chartOfAccount: '/chart-of-account' };
const CITIES_API = '/aging-report/cities';
const DETAIL_ENDPOINTS = {
    receivable: '/aging-report/receivables',
    payable: '/aging-report/payables',
};
const SUMMARY_ENDPOINTS = {
    receivable: '/aging-report/receivables-summary',
    payable: '/aging-report/payables-summary',
};

const dbDateToDisplay = (raw) => {
    if (!raw) return '';
    const str = String(raw);
    const iso = /^\d{4}-\d{2}-\d{2}/.test(str)
        ? str.slice(0, 10)
        : (() => {
            const d = new Date(raw);
            return isNaN(d.getTime()) ? '' : d.toISOString().slice(0, 10);
        })();
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    return `${d}-${m}-${y}`;
};

function formatMoney(n) {
    const num = Number(n) || 0;
    const abs = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return num < 0 ? `(${abs})` : abs;
}

function formatMoneyRounded(n) {
    const num = Number(n) || 0;
    const abs = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    return num < 0 ? `(${abs})` : abs;
}

// Column tint per bucket, cycling for the fixed-width buckets; the final
// (overflow, e.g. "61+") column always gets the violet tint, matching the
// green -> blue -> amber -> red -> violet reference layout.
const BUCKET_PALETTE = [
    { head: 'text-emerald-300', cell: 'text-emerald-700 bg-emerald-50/60' },
    { head: 'text-sky-300', cell: 'text-sky-700 bg-sky-50/60' },
    { head: 'text-amber-300', cell: 'text-amber-700 bg-amber-50/60' },
    { head: 'text-red-300', cell: 'text-red-700 bg-red-50/60' },
];
const OVERFLOW_TINT = { head: 'text-violet-300', cell: 'text-violet-700 bg-violet-50/60' };

function tintFor(index, isLast) {
    if (isLast) return OVERFLOW_TINT;
    return BUCKET_PALETTE[index % BUCKET_PALETTE.length];
}

// A number input that selects all of its text on focus, so the first
// keystroke (including Backspace/Delete) simply replaces the whole value
// instead of editing individual digits.
function SelectAllNumberInput({ value, onChange, min, max, className }) {
    return (
        <input
            type="number"
            min={min}
            max={max}
            value={value}
            onFocus={(e) => e.target.select()}
            onChange={(e) => onChange(e.target.value)}
            className={className}
        />
    );
}

// ---------------------------------------------------------------------------
// Account search (Detail view) — single-select, shows ONLY the account name
// in the input (no code in the field, no code line underneath it). The code
// still shows next to each row in the dropdown, since that's what
// disambiguates same-named accounts while picking.
// ---------------------------------------------------------------------------
const AccountSearchField = ({ label, accountCode, onSelect, options, placeholder }) => {
    const selected = options.find((opt) => String(opt.code) === String(accountCode));
    const [query, setQuery] = useState(selected ? selected.account_name : '');
    const [open, setOpen] = useState(false);
    const [activeIndex, setActiveIndex] = useState(-1);
    const boxRef = useRef(null);

    useEffect(() => {
        const match = options.find((opt) => String(opt.code) === String(accountCode));
        setQuery(match ? match.account_name : (accountCode ? '' : query));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [accountCode]);

    useEffect(() => {
        function handleClickOutside(e) {
            if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const term = query.trim().toLowerCase();
    const suggestions = term
        ? options.filter((opt) => String(opt.account_name ?? '').toLowerCase().includes(term)).slice(0, 8)
        : options.slice(0, 8);

    const pick = (opt) => {
        setQuery(opt.account_name);
        onSelect(String(opt.code));
        setOpen(false);
        setActiveIndex(-1);
    };

    const handleChange = (e) => {
        const v = e.target.value;
        setQuery(v);
        setOpen(true);
        if (accountCode) onSelect('');
    };

    const handleKeyDown = (e) => {
        if (!open || suggestions.length === 0) return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setActiveIndex((i) => (i + 1) % suggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setActiveIndex((i) => (i - 1 + suggestions.length) % suggestions.length);
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (activeIndex >= 0) pick(suggestions[activeIndex]);
        } else if (e.key === 'Escape') {
            setOpen(false);
        }
    };

    return (
        <div className="relative flex flex-col gap-1.5" ref={boxRef}>
            {label && <label className="text-xs font-semibold text-slate-500">{label}</label>}
            <input
                type="text"
                value={query}
                onChange={handleChange}
                onFocus={(e) => { setOpen(true); e.target.select(); }}
                onKeyDown={handleKeyDown}
                autoComplete="off"
                className="w-full rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
                placeholder={placeholder || 'Search account'}
            />
            {open && suggestions.length > 0 && (
                <ul className="absolute top-full z-30 mt-1 max-h-64 w-full overflow-y-auto rounded-lg border border-[#E6E2D8] bg-white p-1.5 shadow-lg">
                    {suggestions.map((opt, i) => (
                        <li
                            key={opt.code}
                            className={`flex cursor-pointer items-center justify-between gap-3 rounded-md px-2.5 py-2 text-sm ${i === activeIndex ? 'bg-[#F3ECD9]' : ''}`}
                            onMouseDown={() => pick(opt)}
                            onMouseEnter={() => setActiveIndex(i)}
                        >
                            <span className="text-[#1B2430]">{opt.account_name}</span>
                            <span className="font-mono text-xs tabular-nums text-slate-500">{opt.code}</span>
                        </li>
                    ))}
                </ul>
            )}
            {open && term && suggestions.length === 0 && (
                <div className="absolute top-full z-30 mt-1 w-full rounded-lg border border-[#E6E2D8] bg-white p-3 text-center text-sm text-slate-500 shadow-lg">
                    No accounts found
                </div>
            )}
        </div>
    );
};

// ---------------------------------------------------------------------------
// Generic searchable, checkbox-based multi-select. Used for BOTH the city
// filter and the account filter on the Summary view — same
// search-then-pick interaction pattern as the single-account search, but
// multi-select with a "select all" affordance instead of committing one
// value. `items` is an array of {value, label, sublabel?}.
// ---------------------------------------------------------------------------
function MultiSelectFilter({ label, items, selected, onChange, placeholder, selectAllText }) {
    const [query, setQuery] = useState('');
    const [open, setOpen] = useState(false);
    const boxRef = useRef(null);

    useEffect(() => {
        function handleClickOutside(e) {
            if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const term = query.trim().toLowerCase();
    const visible = term
        ? items.filter(
              (it) =>
                  it.label.toLowerCase().includes(term) ||
                  (it.sublabel ?? '').toLowerCase().includes(term)
          )
        : items;

    const toggleValue = (value) => {
        const next = new Set(selected);
        if (next.has(value)) next.delete(value);
        else next.add(value);
        onChange(Array.from(next));
    };

    const selectAll = () => onChange(items.map((it) => it.value));
    const clearAll = () => onChange([]);

    const summaryText =
        selected.length === 0 || selected.length === items.length
            ? placeholder
            : `${selected.length} selected`;

    return (
        <div className="relative flex flex-col gap-1.5" ref={boxRef}>
            <label className="text-xs font-semibold text-slate-500">{label}</label>
            <button
                type="button"
                onClick={() => setOpen((o) => !o)}
                className="flex w-full items-center justify-between rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-left text-sm text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
            >
                <span>{summaryText}</span>
                <span className="text-slate-400">▾</span>
            </button>

            {open && (
                <div className="absolute top-full z-30 mt-1 w-80 rounded-lg border border-[#E6E2D8] bg-white shadow-lg">
                    <div className="border-b border-[#E6E2D8] p-2">
                        <input
                            type="text"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder="Search…"
                            autoComplete="off"
                            className="w-full rounded-md border border-[#E6E2D8] px-2.5 py-1.5 text-sm outline-none focus:border-[#B08A2E]"
                        />
                    </div>

                    <div className="flex items-center justify-between gap-2 border-b border-[#E6E2D8] px-3 py-2">
                        <button type="button" onClick={selectAll} className="text-xs font-semibold text-[#1B2430] hover:underline">
                            {selectAllText}
                        </button>
                        <button type="button" onClick={clearAll} className="text-xs font-semibold text-red-600 hover:underline">
                            Clear
                        </button>
                    </div>

                    <div className="max-h-56 overflow-y-auto p-2">
                        {visible.length === 0 ? (
                            <div className="px-2 py-3 text-center text-sm text-slate-400">No results found</div>
                        ) : (
                            visible.map((it) => (
                                <label
                                    key={it.value}
                                    className="flex cursor-pointer items-center justify-between gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-[#F3ECD9]"
                                >
                                    <span className="flex items-center gap-2">
                                        <input
                                            type="checkbox"
                                            checked={selected.includes(it.value)}
                                            onChange={() => toggleValue(it.value)}
                                            className="h-3.5 w-3.5 accent-[#1B2430]"
                                        />
                                        <span className="text-[#1B2430]">{it.label}</span>
                                    </span>
                                    {it.sublabel && (
                                        <span className="font-mono text-xs tabular-nums text-slate-400">{it.sublabel}</span>
                                    )}
                                </label>
                            ))
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

// ---------------------------------------------------------------------------
// Main combined page
// ---------------------------------------------------------------------------
export default function AgingReport() {
    const { companyId: rawCompanyId, financialYearId: rawFinancialYearId } = useSelector((state) => state.company);
    const companyId = rawCompanyId ? Number(rawCompanyId) : null;
    const financialYearId = rawFinancialYearId ? Number(rawFinancialYearId) : null;

    // 'detail' | 'summary'
    const [view, setView] = useState('detail');
    const [isPayable, setIsPayable] = useState(false);
    const mode = isPayable ? 'payable' : 'receivable';

    // ---- Detail view state ----
    const [chartOfAccounts, setChartOfAccounts] = useState([]);
    const [accountsLoaded, setAccountsLoaded] = useState(false);
    const [accountCode, setAccountCode] = useState('');
    const [report, setReport] = useState(null);
    const [detailLoading, setDetailLoading] = useState(false);

    // ---- Summary view state ----
    const [cities, setCities] = useState([]);
    const [selectedCities, setSelectedCities] = useState([]);
    const [selectedAccounts, setSelectedAccounts] = useState([]);
    const [numBuckets, setNumBuckets] = useState(4);
    const [daysPerBucket, setDaysPerBucket] = useState(15);
    const [startDay, setStartDay] = useState(1);
    const [summary, setSummary] = useState(null);
    const [summaryLoading, setSummaryLoading] = useState(false);

    const ensureAccountsLoaded = useCallback(async () => {
        if (accountsLoaded) return;
        const res = await api.get(`${LOOKUP_API.chartOfAccount}/`);
        setChartOfAccounts(res.data?.data || []);
        setAccountsLoaded(true);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [accountsLoaded]);

    useEffect(() => {
        if (companyId) ensureAccountsLoaded();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    useEffect(() => {
        if (!companyId) return;
        (async () => {
            try {
                const res = await api.get(CITIES_API, { params: { company_id: companyId } });
                setCities(res.data?.cities || []);
            } catch (error) {
                toast.error(error?.response?.data?.message || 'Failed to load cities');
            }
        })();
    }, [companyId]);

    const companyAccounts = useMemo(
        () => chartOfAccounts.filter((coa) => coa.company_id === companyId),
        [chartOfAccounts, companyId]
    );

    const accountFilterItems = useMemo(
        () => companyAccounts.map((coa) => ({ value: String(coa.code), label: coa.account_name, sublabel: coa.code })),
        [companyAccounts]
    );

    const handleToggleMode = () => {
        setIsPayable((prev) => !prev);
        setAccountCode('');
        setReport(null);
        setSummary(null);
        setSelectedCities([]);
        setSelectedAccounts([]);
    };

    const handleChangeView = (next) => {
        setView(next);
    };

    const handleGenerateDetail = async () => {
        if (!accountCode) {
            toast.error('Please select an account');
            return;
        }
        if (!companyId || !financialYearId) {
            toast.error('No company/financial year selected');
            return;
        }

        setDetailLoading(true);
        try {
            const res = await api.get(DETAIL_ENDPOINTS[mode], {
                params: {
                    company_id: companyId,
                    financialyear_id: financialYearId,
                    account_code: accountCode,
                },
            });
            setReport(res.data);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to generate report');
            setReport(null);
        } finally {
            setDetailLoading(false);
        }
    };

    // Shared by the Generate button AND by auto-triggering whenever the
    // account filter changes (see effect below).
    const runSummary = useCallback(
        async ({ cities: citiesArg, accounts: accountsArg, silent } = {}) => {
            if (!companyId || !financialYearId) {
                if (!silent) toast.error('No company/financial year selected');
                return;
            }
            if (numBuckets < 1 || daysPerBucket < 1) {
                if (!silent) toast.error('Buckets and days per bucket must be at least 1');
                return;
            }

            setSummaryLoading(true);
            try {
                const res = await api.get(SUMMARY_ENDPOINTS[mode], {
                    params: {
                        company_id: companyId,
                        financialyear_id: financialYearId,
                        cities: (citiesArg ?? selectedCities).join(','),
                        account_codes: (accountsArg ?? selectedAccounts).join(','),
                        num_buckets: numBuckets,
                        days_per_bucket: daysPerBucket,
                        start_day: startDay,
                    },
                });
                setSummary(res.data);
            } catch (error) {
                if (!silent) toast.error(error?.response?.data?.message || 'Failed to generate summary');
                setSummary(null);
            } finally {
                setSummaryLoading(false);
            }
        },
        [companyId, financialYearId, mode, numBuckets, daysPerBucket, startDay, selectedCities, selectedAccounts]
    );

    const handleGenerateSummary = () => runSummary();

    // Selecting an account (or accounts) in the summary filter immediately
    // reveals its aging below, using whatever bucket settings are
    // currently set — no need to also press "Generate Report".
    const handleAccountFilterChange = (nextAccounts) => {
        setSelectedAccounts(nextAccounts);
        if (view === 'summary' && nextAccounts.length > 0) {
            runSummary({ accounts: nextAccounts });
        }
    };

    const handleCancelSummary = () => {
        setSelectedCities([]);
        setSelectedAccounts([]);
        setNumBuckets(4);
        setDaysPerBucket(15);
        setStartDay(1);
        setSummary(null);
    };

    const printRef = useRef(null);

    const handlePrint = () => window.print();

    async function handleExportPdf() {
        if (!printRef.current) return;
        const canvas = await html2canvas(printRef.current, { scale: 2, backgroundColor: '#ffffff' });
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' });
        const pageWidth = pdf.internal.pageSize.getWidth();
        const pageHeight = pdf.internal.pageSize.getHeight();
        const imgWidth = pageWidth - 40;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;

        let heightLeft = imgHeight;
        let position = 20;

        pdf.addImage(imgData, 'PNG', 20, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;

        while (heightLeft > 0) {
            position = heightLeft - imgHeight + 20;
            pdf.addPage();
            pdf.addImage(imgData, 'PNG', 20, position, imgWidth, imgHeight);
            heightLeft -= pageHeight;
        }

        const who = isPayable ? 'Payables' : 'Receivables';
        const scope =
            view === 'detail'
                ? (report?.account_name || 'Account').replace(/\s+/g, '_')
                : 'Summary';
        pdf.save(`Aging_${who}_${scope}.pdf`);
    }

    const columnCount = summary ? summary.labels.length : 0;

    if (!companyId) {
        return (
            <div className="min-h-screen bg-[#FAFAF7] p-8">
                <div className="mx-auto max-w-md rounded-lg border border-[#E6E2D8] bg-white p-8 text-center text-sm text-gray-500 shadow-sm">
                    No company context found. Please select a company first.
                </div>
            </div>
        );
    }

    const numberInputClass =
        'w-32 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums outline-none focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20';

    return (
        <div className="min-h-screen bg-[#FAFAF7] p-8 font-sans text-[#1B2430] print:bg-white print:p-0">
            <div className="mb-5 rounded-xl border border-[#E6E2D8] bg-white p-6 shadow-sm print:hidden">
                <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                            Reporting
                        </span>
                        <h1 className="text-2xl font-bold tracking-tight">
                            Aging Report {view === 'summary' ? '— Summary' : ''}
                        </h1>
                    </div>

                    <div className="flex items-center gap-3">
                        {/* Detail / Summary view switch */}
                        <div className="inline-flex rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] p-0.5 text-sm">
                            <button
                                type="button"
                                onClick={() => handleChangeView('detail')}
                                className={`rounded-md px-3 py-1.5 font-semibold transition-colors ${view === 'detail' ? 'bg-[#B08A2E] text-white shadow-sm' : 'text-slate-600 hover:bg-white'}`}
                            >
                                Detail
                            </button>
                            <button
                                type="button"
                                onClick={() => handleChangeView('summary')}
                                className={`rounded-md px-3 py-1.5 font-semibold transition-colors ${view === 'summary' ? 'bg-[#B08A2E] text-white shadow-sm' : 'text-slate-600 hover:bg-white'}`}
                            >
                                Summary
                            </button>
                        </div>

                        {/* Receivables / Payables mode switch */}
                        <div className="inline-flex rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] p-0.5 text-sm">
                            <button
                                type="button"
                                onClick={() => isPayable && handleToggleMode()}
                                className={`rounded-md px-3 py-1.5 font-semibold transition-colors ${!isPayable ? 'bg-[#1B2430] text-white shadow-sm' : 'text-slate-600 hover:bg-white'}`}
                            >
                                Receivables
                            </button>
                            <button
                                type="button"
                                onClick={() => !isPayable && handleToggleMode()}
                                className={`rounded-md px-3 py-1.5 font-semibold transition-colors ${isPayable ? 'bg-red-600 text-white shadow-sm' : 'text-slate-600 hover:bg-white'}`}
                            >
                                Payables
                            </button>
                        </div>
                    </div>
                </div>

                {/* ---- Detail controls ---- */}
                {view === 'detail' && (
                    <div className="flex flex-wrap items-end gap-4">
                        <div className="min-w-[260px] flex-1">
                            <AccountSearchField
                                label={isPayable ? 'Supplier' : 'Customer'}
                                accountCode={accountCode}
                                onSelect={setAccountCode}
                                options={companyAccounts}
                                placeholder={`Search ${isPayable ? 'supplier' : 'customer'} name`}
                            />
                        </div>

                        <button
                            type="button"
                            onClick={handleGenerateDetail}
                            disabled={detailLoading}
                            className="rounded-lg bg-[#1B2430] px-5 py-2.5 text-sm font-semibold text-white transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
                        >
                            {detailLoading ? 'Generating…' : 'Generate'}
                        </button>
                    </div>
                )}

                {/* ---- Summary controls ---- */}
                {view === 'summary' && (
                    <div className="flex flex-wrap items-end gap-4">
                        <div className="w-72">
                            <MultiSelectFilter
                                label={isPayable ? 'Supplier' : 'Customer'}
                                items={accountFilterItems}
                                selected={selectedAccounts}
                                onChange={handleAccountFilterChange}
                                placeholder={`All ${isPayable ? 'suppliers' : 'customers'}`}
                                selectAllText={`Select All ${isPayable ? 'Suppliers' : 'Customers'}`}
                            />
                        </div>

                        <div className="w-64">
                            <MultiSelectFilter
                                label="City"
                                items={cities.map((c) => ({ value: c, label: c }))}
                                selected={selectedCities}
                                onChange={setSelectedCities}
                                placeholder="All cities"
                                selectAllText="Select All Cities"
                            />
                        </div>

                        <div className="flex flex-col gap-1.5">
                            <label className="text-xs font-semibold text-slate-500">Number of Buckets</label>
                            <SelectAllNumberInput
                                min={1}
                                max={12}
                                value={numBuckets}
                                onChange={(v) => setNumBuckets(Math.max(1, Math.min(12, Number(v) || 1)))}
                                className={numberInputClass}
                            />
                        </div>

                        <div className="flex flex-col gap-1.5">
                            <label className="text-xs font-semibold text-slate-500">Days per Bucket</label>
                            <SelectAllNumberInput
                                min={1}
                                value={daysPerBucket}
                                onChange={(v) => setDaysPerBucket(Math.max(1, Number(v) || 1))}
                                className={numberInputClass}
                            />
                        </div>

                        <div className="flex flex-col gap-1.5">
                            <label className="text-xs font-semibold text-slate-500">Start Day</label>
                            <SelectAllNumberInput
                                min={0}
                                value={startDay}
                                onChange={(v) => setStartDay(Math.max(0, Number(v) || 0))}
                                className={numberInputClass}
                            />
                        </div>

                        <button
                            type="button"
                            onClick={handleGenerateSummary}
                            disabled={summaryLoading}
                            className="rounded-lg bg-[#1B2430] px-5 py-2.5 text-sm font-semibold text-white transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
                        >
                            {summaryLoading ? 'Generating…' : 'Generate Report'}
                        </button>

                        <button
                            type="button"
                            onClick={handleCancelSummary}
                            className="rounded-lg border border-red-200 bg-red-50 px-5 py-2.5 text-sm font-semibold text-red-600 transition active:translate-y-px hover:bg-red-100"
                        >
                            Cancel
                        </button>
                    </div>
                )}

                {((view === 'detail' && report) || (view === 'summary' && summary)) && (
                    <div className="mt-4 flex gap-2.5 border-t border-[#E6E2D8] pt-4">
                        <button
                            type="button"
                            onClick={handlePrint}
                            className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
                        >
                            Print
                        </button>
                        <button
                            type="button"
                            onClick={handleExportPdf}
                            className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
                        >
                            Export PDF
                        </button>
                    </div>
                )}
            </div>

            {/* ================= DETAIL RESULTS ================= */}
            {view === 'detail' && report && (
                <div ref={printRef} className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none">
                    <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
                        <div>
                            <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                                {isPayable ? 'Payables Aging' : 'Receivables Aging'}
                            </span>
                            <h2 className="text-2xl font-bold">{report.account_name}</h2>
                            <span className="mt-1 block font-mono text-xs tabular-nums text-slate-500">
                                Account Code: {report.account_code}
                            </span>
                        </div>
                    </div>

                    <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
                        <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
                            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Open Bills</span>
                            <span className="text-lg font-bold tabular-nums">{report.rows.length}</span>
                        </div>
                        <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
                            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Max Days Outstanding</span>
                            <span className="text-lg font-bold tabular-nums">
                                {report.rows.length ? Math.max(...report.rows.map((r) => r.days)) : 0}
                            </span>
                        </div>
                        <div className="flex flex-col gap-1 rounded-lg bg-[#EFE6CE] px-3.5 py-3">
                            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Total Outstanding</span>
                            <span className="text-lg font-bold tabular-nums">{formatMoney(report.total_outstanding)}</span>
                        </div>
                    </div>

                    {report.rows.length === 0 ? (
                        <div className="py-10 text-center text-sm text-slate-400">
                            No outstanding bills for this account.
                        </div>
                    ) : (
                        <table className="w-full border-collapse text-[13.5px]">
                            <thead>
                                <tr>
                                    <th className="sticky top-0 whitespace-nowrap bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">Inv./GRN No</th>
                                    <th className="sticky top-0 whitespace-nowrap bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">Date</th>
                                    <th className="sticky top-0 min-w-[260px] bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">Narration</th>
                                    <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">Bill Amount</th>
                                    <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">Outstanding</th>
                                    <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">Days</th>
                                    <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                {report.rows.map((row, idx) => (
                                    <tr key={`${row.bill_no}-${idx}`} className="odd:bg-white even:bg-[#F4F2EC] hover:bg-[#F3ECD9]">
                                        <td className="border-b border-[#E6E2D8] px-3 py-2.5 font-medium text-[#1B2430]">{row.bill_no}</td>
                                        <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5 text-slate-600">{dbDateToDisplay(row.bill_date)}</td>
                                        <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-slate-600" title={row.narration}>{row.narration}</td>
                                        <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">{formatMoney(row.bill_amount)}</td>
                                        <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right font-semibold tabular-nums">{formatMoney(row.outstanding)}</td>
                                        <td className={`border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums ${row.days > 60 ? 'font-semibold text-red-600' : 'text-slate-700'}`}>{row.days}</td>
                                        <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right font-bold tabular-nums">{formatMoney(row.balance)}</td>
                                    </tr>
                                ))}
                            </tbody>
                            <tfoot>
                                <tr className="border-y border-[#1B2430] bg-[#F3ECD9] font-bold">
                                    <td colSpan={4} className="px-3 py-2.5 text-center">Total</td>
                                    <td className="px-3 py-2.5 text-right tabular-nums">
                                        {formatMoney(report.rows.reduce((s, r) => s + Number(r.outstanding), 0))}
                                    </td>
                                    <td></td>
                                    <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.total_outstanding)}</td>
                                </tr>
                            </tfoot>
                        </table>
                    )}
                </div>
            )}

            {/* ================= SUMMARY RESULTS ================= */}
            {view === 'summary' && summary && (
                <div ref={printRef} className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none">
                    <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
                        <div>
                            <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                                {isPayable ? 'Payables' : 'Receivables'} Aging Summary
                            </span>
                            <h2 className="text-2xl font-bold">
                                {selectedAccounts.length > 0
                                    ? `${selectedAccounts.length} selected ${isPayable ? 'supplier(s)' : 'customer(s)'}`
                                    : selectedCities.length === 0 || selectedCities.length === cities.length
                                    ? 'All Cities'
                                    : selectedCities.join(', ')}
                            </h2>
                        </div>
                        <div className="text-sm font-semibold tabular-nums text-slate-500">
                            {summary.rows.length} {isPayable ? 'suppliers' : 'customers'} with outstanding balance
                        </div>
                    </div>

                    <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
                        <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
                            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                                {isPayable ? 'Suppliers' : 'Customers'}
                            </span>
                            <span className="text-lg font-bold tabular-nums">{summary.rows.length}</span>
                        </div>
                        <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
                            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Buckets</span>
                            <span className="text-lg font-bold tabular-nums">{summary.labels.join(' / ')}</span>
                        </div>
                        <div className="flex flex-col gap-1 rounded-lg bg-[#EFE6CE] px-3.5 py-3">
                            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Total Outstanding</span>
                            <span className="text-lg font-bold tabular-nums">{formatMoneyRounded(summary.totals.balance)}</span>
                        </div>
                    </div>

                    {summary.rows.length === 0 ? (
                        <div className="py-10 text-center text-sm text-slate-400">
                            No outstanding balances for the current filters.
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full border-collapse text-[13.5px]">
                                <thead>
                                    <tr>
                                        <th className="sticky top-0 whitespace-nowrap bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">Code</th>
                                        <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                                            {isPayable ? 'Supplier' : 'Customer'}
                                        </th>
                                        <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">Balance</th>
                                        {summary.labels.map((label, i) => {
                                            const isLast = i === columnCount - 1;
                                            const tint = tintFor(i, isLast);
                                            return (
                                                <th
                                                    key={label}
                                                    className={`sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide ${tint.head}`}
                                                >
                                                    {label}
                                                </th>
                                            );
                                        })}
                                        <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">Max Day</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {summary.rows.map((row) => (
                                        <tr key={row.code} className="odd:bg-white even:bg-[#F4F2EC] hover:bg-[#F3ECD9]">
                                            <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5 font-mono text-xs tabular-nums text-slate-500">{row.code}</td>
                                            <td className="border-b border-[#E6E2D8] px-3 py-2.5 font-medium text-[#1B2430]">{row.account_name}</td>
                                            <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right font-bold tabular-nums">{formatMoneyRounded(row.balance)}</td>
                                            {row.buckets.map((val, i) => {
                                                const isLast = i === columnCount - 1;
                                                const tint = tintFor(i, isLast);
                                                return (
                                                    <td
                                                        key={i}
                                                        className={`border-b border-[#E6E2D8] px-3 py-2.5 text-right font-semibold tabular-nums ${tint.cell}`}
                                                    >
                                                        {formatMoneyRounded(val)}
                                                    </td>
                                                );
                                            })}
                                            <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums text-slate-700">{row.max_day}</td>
                                        </tr>
                                    ))}
                                </tbody>
                                <tfoot>
                                    <tr className="border-y border-[#1B2430] bg-[#F3ECD9] font-bold">
                                        <td colSpan={2} className="px-3 py-2.5">Total</td>
                                        <td className="px-3 py-2.5 text-right tabular-nums">{formatMoneyRounded(summary.totals.balance)}</td>
                                        {summary.totals.buckets.map((val, i) => (
                                            <td key={i} className="px-3 py-2.5 text-right tabular-nums">{formatMoneyRounded(val)}</td>
                                        ))}
                                        <td className="px-3 py-2.5 text-right tabular-nums">—</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}