import React, { useState, useEffect, useRef, useCallback } from "react";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { ChevronDown, ChevronRight } from "lucide-react";
import api from '../../../services/api'

/**
 * Trial Balance report page — 4 levels deep, styled the same way as
 * Ledger.jsx (same Tailwind palette, same print / export-PDF pattern).
 *
 *   Level 1 -> BalanceSheet    (e.g. "CAPITAL")
 *   Level 2 -> MainCode        (e.g. "1001  CAPITAL A/C")
 *   Level 3 -> SubCode         (e.g. "10010  SHARE CAPITAL")
 *   Level 4 -> ChartOfAccount  (the actual ledger account — the leaf)
 *
 * Every group row can be collapsed/expanded; a bold totals row is printed
 * right after a group's children, the same way the sample trial balance
 * prints a totals line under every account-group and every group-of-groups.
 *
 * Trial balance endpoint (see TrialBalanceRoutes.js):
 *   GET /api/trial-balance/report?company_id=&financialyear_id=&start_date=&end_date=
 *   GET /api/trial-balance/financial-year?company_id=&financialyear_id=
 *     -> used only to pre-fill Start date / End date with the selected
 *        financial year's own start_date / end_date.
 */

const API = {
  trialBalance: "/trial-balance",
};

// ---------------------------------------------------------------------------
// Date helpers — plain string manipulation, no Date-object re-parsing, so no
// timezone shift ever touches a date (same approach as Ledger.jsx).
// ---------------------------------------------------------------------------
function pad2(n) {
  return String(n).padStart(2, "0");
}

function isoToDisplay(iso) {
  if (!iso) return "";
  const [y, m, d] = String(iso).slice(0, 10).split("-");
  return `${d}-${m}-${y}`;
}

function displayToIso(display) {
  if (!display) return "";
  const [d, m, y] = display.split("-");
  return `${y}-${pad2(m)}-${pad2(d)}`;
}

function formatMoney(n) {
  const num = Number(n) || 0;
  if (num === 0) return "0";
  const abs = Math.abs(num).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return num < 0 ? `(${abs})` : abs;
}

function isZeroRow(a) {
  return (
    Number(a.opening_debit) === 0 &&
    Number(a.opening_credit) === 0 &&
    Number(a.period_debit) === 0 &&
    Number(a.period_credit) === 0 &&
    Number(a.closing_debit) === 0 &&
    Number(a.closing_credit) === 0
  );
}

// ---------------------------------------------------------------------------
// Small presentational helpers
// ---------------------------------------------------------------------------

// A group header row (BalanceSheet / MainCode / SubCode) — name only, no
// numbers, collapsible.
function GroupHeaderRow({ level, code, details, isOpen, onToggle, colSpan }) {
  const styles = {
    1: "bg-[#1B2430] text-white text-[13px] font-bold uppercase tracking-wide",
    2: "bg-[#33404F] text-white text-[12.5px] font-semibold",
    3: "bg-[#F3ECD9] text-[#1B2430] text-[12.5px] font-semibold",
  };
  const paddingLeft = { 1: "pl-3", 2: "pl-8", 3: "pl-14" };

  return (
    <tr className={`${styles[level]} print:break-inside-avoid`}>
      <td colSpan={colSpan} className={`px-3 py-2 ${paddingLeft[level]}`}>
        <button
          type="button"
          onClick={onToggle}
          className="flex items-center gap-1.5 print:pointer-events-none"
        >
          {isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          {code ? <span className="font-mono tabular-nums">{code}</span> : null}
          <span>{details}</span>
        </button>
      </td>
    </tr>
  );
}

// A totals row printed right after a group's children close out.
function GroupTotalRow({ label, totals, emphasise }) {
  return (
    <tr
      className={`border-y font-bold ${emphasise ? "border-[#1B2430] bg-[#EFE6CE] text-[13px]" : "border-[#E6E2D8] bg-[#F4F2EC] text-[12.5px]"
        }`}
    >
      <td className="px-3 py-1.5 text-right italic text-slate-500" colSpan={2}>
        {label}
      </td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(totals.opening_debit)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(totals.opening_credit)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(totals.period_debit)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(totals.period_credit)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(totals.closing_debit)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(totals.closing_credit)}</td>
    </tr>
  );
}

// A leaf ChartOfAccount row.
function AccountRow({ account, onDoubleClick }) {
  return (
    <tr
      className="odd:bg-white even:bg-[#FAFAF7] text-[13px] cursor-pointer"
      onDoubleClick={onDoubleClick}
      title="Double-click to open this account's ledger"
    >
      <td className="border-b border-[#E6E2D8] px-3 py-1.5 pl-20 font-mono text-xs tabular-nums text-slate-500">
        {account.code}
      </td>
      <td className="border-b border-[#E6E2D8] px-3 py-1.5">{account.account_name}</td>
      <td className="border-b border-[#E6E2D8] px-3 py-1.5 text-right tabular-nums">
        {formatMoney(account.opening_debit)}
      </td>
      <td className="border-b border-[#E6E2D8] px-3 py-1.5 text-right tabular-nums">
        {formatMoney(account.opening_credit)}
      </td>
      <td className="border-b border-[#E6E2D8] px-3 py-1.5 text-right tabular-nums">
        {formatMoney(account.period_debit)}
      </td>
      <td className="border-b border-[#E6E2D8] px-3 py-1.5 text-right tabular-nums">
        {formatMoney(account.period_credit)}
      </td>
      <td className="border-b border-[#E6E2D8] px-3 py-1.5 text-right font-semibold tabular-nums">
        {formatMoney(account.closing_debit)}
      </td>
      <td className="border-b border-[#E6E2D8] px-3 py-1.5 text-right font-semibold tabular-nums">
        {formatMoney(account.closing_credit)}
      </td>
    </tr>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------
export default function TrialBalance({ onNavigate }) {
  const { companyId: rawCompanyId, financialYearId: rawFinancialYearId } = useSelector(
    (state) => state.company
  );
  const companyId =
    rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== "" ? Number(rawCompanyId) : null;
  const financialYearId =
    rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ""
      ? Number(rawFinancialYearId)
      : null;

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [startDateText, setStartDateText] = useState("");
  const [endDateText, setEndDateText] = useState("");

  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [fyLoading, setFyLoading] = useState(false);

  // collapsed[key] === true means that group is collapsed. Everything is
  // expanded by default (matches the printed sample, which shows every level).
  const [collapsed, setCollapsed] = useState(() => new Set());

  const printRef = useRef(null);

  // Whenever the company or financial year changes: clear any old report,
  // and pre-fill Start date / End date with that financial year's own dates.
  useEffect(() => {
    setReport(null);
    setCollapsed(new Set());

    if (!companyId || !financialYearId) {
      setStartDate("");
      setEndDate("");
      setStartDateText("");
      setEndDateText("");
      return;
    }

    let cancelled = false;
    setFyLoading(true);
    api
      .get(`${API.trialBalance}/financial-year`, {
        params: { company_id: companyId, financialyear_id: financialYearId },
      })
      .then((res) => {
        if (cancelled) return;
        const fy = res.data?.data;
        if (fy) {
          setStartDate(fy.start_date);
          setEndDate(fy.end_date);
          setStartDateText(isoToDisplay(fy.start_date));
          setEndDateText(isoToDisplay(fy.end_date));
        }
      })
      .catch((error) => {
        if (!cancelled) {
          toast.error(error?.response?.data?.message || "Failed to load financial year dates");
        }
      })
      .finally(() => {
        if (!cancelled) setFyLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [companyId, financialYearId]);

  async function generateReport() {
    if (!financialYearId) {
      toast.error("Please select a financial year first.");
      return;
    }
    if (!startDate || !endDate) {
      toast.error("Please choose a start and end date.");
      return;
    }
    setLoading(true);
    try {
      const res = await api.get(`${API.trialBalance}/report`, {
        params: {
          company_id: companyId,
          financialyear_id: financialYearId,
          start_date: startDate,
          end_date: endDate,
        },
      });
      if (res.data?.success) {
        setReport(res.data.data);
        setCollapsed(new Set());
      } else {
        toast.error(res.data?.message || "Failed to generate trial balance.");
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || "Could not reach the server. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handleAccountDoubleClick(account) {
    if (!onNavigate || !report) return;
    onNavigate('ledger-report', {
      account_id: account.id,
      account_code: account.code,
      account_name: account.account_name,
      start_date: report.start_date,
      end_date: report.end_date,
    });
  }

  const toggle = useCallback((key) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  function expandAll() {
    setCollapsed(new Set());
  }

  function collapseAll() {
    if (!report) return;
    const keys = new Set();
    for (const bs of report.balancesheets) {
      keys.add(`bs-${bs.id}`);
      for (const mc of bs.maincodes) {
        keys.add(`mc-${mc.id}`);
        for (const sc of mc.subcodes) {
          keys.add(`sc-${sc.id}`);
        }
      }
    }
    setCollapsed(keys);
  }

  function handlePrint() {
    window.print();
  }

  async function handleExportPdf() {
    if (!printRef.current) return;
    const canvas = await html2canvas(printRef.current, { scale: 2, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth - 40;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 20;

    pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight + 20;
      pdf.addPage();
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    pdf.save(`Trial_Balance_${startDate}_to_${endDate}.pdf`);
  }

  if (!companyId) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] p-8">
        <div className="mx-auto max-w-md rounded-lg border border-[#E6E2D8] bg-white p-8 text-center text-sm text-gray-500 shadow-sm">
          No company context found. Please select a company first.
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF7] p-8 font-sans text-[#1B2430] print:bg-white print:p-0">
      <div className="mb-5 rounded-xl border border-[#E6E2D8] bg-white p-6 shadow-sm print:hidden">
        <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
          Reporting
        </span>
        <h1 className="mb-4 text-2xl font-bold tracking-tight">Trial Balance</h1>

        {!financialYearId && (
          <div className="mb-4 max-w-md rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-600">
            No financial year selected. Please pick one first.
          </div>
        )}

        <div className="flex flex-wrap items-end gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Start date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20 disabled:cursor-not-allowed disabled:opacity-60"
              type="text"
              value={startDateText}
              disabled={fyLoading || !financialYearId}
              onChange={(e) => {
                const v = e.target.value;
                setStartDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setStartDate(displayToIso(v));
              }}
              onBlur={() => setStartDateText(isoToDisplay(startDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">End date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20 disabled:cursor-not-allowed disabled:opacity-60"
              type="text"
              value={endDateText}
              disabled={fyLoading || !financialYearId}
              onChange={(e) => {
                const v = e.target.value;
                setEndDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setEndDate(displayToIso(v));
              }}
              onBlur={() => setEndDateText(isoToDisplay(endDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <button
            className="rounded-lg bg-[#1B2430] px-5 py-2.5 text-sm font-semibold text-white transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
            onClick={generateReport}
            disabled={loading || fyLoading}
          >
            {loading ? "Generating…" : "Generate"}
          </button>

          {report && (
            <div className="flex gap-2.5">
              <button
                className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
                onClick={expandAll}
              >
                Expand all
              </button>
              <button
                className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
                onClick={collapseAll}
              >
                Collapse all
              </button>
            </div>
          )}
        </div>

        {report && (
          <div className="mt-4 flex gap-2.5 border-t border-[#E6E2D8] pt-4">
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handlePrint}
            >
              Print
            </button>
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handleExportPdf}
            >
              Export PDF
            </button>
          </div>
        )}
      </div>

      {report && (
        <div
          ref={printRef}
          className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none"
        >
          <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
            <div>
              <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                Trial Balance
              </span>
              <h2 className="text-2xl font-bold">Trial Balance Report</h2>
            </div>
            <div className="text-sm font-semibold tabular-nums text-slate-500">
              <span>{isoToDisplay(report.start_date)}</span>
              <span className="mx-2 text-[#B08A2E]">to</span>
              <span>{isoToDisplay(report.end_date)}</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[980px] border-collapse text-[13.5px]">
              <thead>
                <tr>
                  <th
                    colSpan={2}
                    className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white"
                  >
                    Description
                  </th>
                  <th
                    colSpan={2}
                    className="sticky top-0 border-l border-white/20 bg-[#1B2430] px-3 py-2.5 text-center text-[11px] font-bold uppercase tracking-wide text-white"
                  >
                    Opening balance
                  </th>
                  <th
                    colSpan={2}
                    className="sticky top-0 border-l border-white/20 bg-[#1B2430] px-3 py-2.5 text-center text-[11px] font-bold uppercase tracking-wide text-white"
                  >
                    During the period
                  </th>
                  <th
                    colSpan={2}
                    className="sticky top-0 border-l border-white/20 bg-[#1B2430] px-3 py-2.5 text-center text-[11px] font-bold uppercase tracking-wide text-white"
                  >
                    Closing balance
                  </th>
                </tr>
                <tr>
                  <th className="sticky top-0 bg-[#293241] px-3 py-1.5 text-left text-[10.5px] font-semibold uppercase text-white/80">
                    Code
                  </th>
                  <th className="sticky top-0 bg-[#293241] px-3 py-1.5 text-left text-[10.5px] font-semibold uppercase text-white/80">
                    Account
                  </th>
                  <th className="sticky top-0 bg-[#293241] px-3 py-1.5 text-right text-[10.5px] font-semibold uppercase text-white/80">
                    Debit
                  </th>
                  <th className="sticky top-0 bg-[#293241] px-3 py-1.5 text-right text-[10.5px] font-semibold uppercase text-white/80">
                    Credit
                  </th>
                  <th className="sticky top-0 bg-[#293241] px-3 py-1.5 text-right text-[10.5px] font-semibold uppercase text-white/80">
                    Debit
                  </th>
                  <th className="sticky top-0 bg-[#293241] px-3 py-1.5 text-right text-[10.5px] font-semibold uppercase text-white/80">
                    Credit
                  </th>
                  <th className="sticky top-0 bg-[#293241] px-3 py-1.5 text-right text-[10.5px] font-semibold uppercase text-white/80">
                    Debit
                  </th>
                  <th className="sticky top-0 bg-[#293241] px-3 py-1.5 text-right text-[10.5px] font-semibold uppercase text-white/80">
                    Credit
                  </th>
                </tr>
              </thead>
              <tbody>
                {report.balancesheets.map((bs) => {
                  const bsKey = `bs-${bs.id}`;
                  const bsOpen = !collapsed.has(bsKey);
                  return (
                    <React.Fragment key={bsKey}>
                      <GroupHeaderRow
                        level={1}
                        details={bs.details}
                        isOpen={bsOpen}
                        onToggle={() => toggle(bsKey)}
                        colSpan={8}
                      />
                      {bsOpen &&
                        bs.maincodes.map((mc) => {
                          const mcKey = `mc-${mc.id}`;
                          const mcOpen = !collapsed.has(mcKey);
                          return (
                            <React.Fragment key={mcKey}>
                              <GroupHeaderRow
                                level={2}
                                code={mc.code}
                                details={mc.details}
                                isOpen={mcOpen}
                                onToggle={() => toggle(mcKey)}
                                colSpan={8}
                              />
                              {mcOpen &&
                                mc.subcodes.map((sc) => {
                                  const scKey = `sc-${sc.id}`;
                                  const scOpen = !collapsed.has(scKey);
                                  return (
                                    <React.Fragment key={scKey}>
                                      <GroupHeaderRow
                                        level={3}
                                        code={sc.code}
                                        details={sc.details}
                                        isOpen={scOpen}
                                        onToggle={() => toggle(scKey)}
                                        colSpan={8}
                                      />
                                      {scOpen &&
                                        sc.accounts
                                        .filter((account) => !isZeroRow(account))
                                        .map((account) => (
                                          <AccountRow
                                            key={account.id}
                                            account={account}
                                            onDoubleClick={() => handleAccountDoubleClick(account)}
                                          />
                                        ))}
                                      {scOpen && (
                                        <GroupTotalRow label={`Total — ${sc.details}`} totals={sc.totals} />
                                      )}
                                    </React.Fragment>
                                  );
                                })}
                              {mcOpen && (
                                <GroupTotalRow label={`Total — ${mc.details}`} totals={mc.totals} />
                              )}
                            </React.Fragment>
                          );
                        })}
                      {bsOpen && (
                        <GroupTotalRow label={`Total — ${bs.details}`} totals={bs.totals} emphasise />
                      )}
                    </React.Fragment>
                  );
                })}

                <tr className="border-y-2 border-[#1B2430] bg-[#1B2430] text-[13.5px] font-bold text-white">
                  <td className="px-3 py-2.5 text-right" colSpan={2}>
                    Trial Total
                  </td>
                  <td className="px-3 py-2.5 text-right tabular-nums">
                    {formatMoney(report.grand_total.opening_debit)}
                  </td>
                  <td className="px-3 py-2.5 text-right tabular-nums">
                    {formatMoney(report.grand_total.opening_credit)}
                  </td>
                  <td className="px-3 py-2.5 text-right tabular-nums">
                    {formatMoney(report.grand_total.period_debit)}
                  </td>
                  <td className="px-3 py-2.5 text-right tabular-nums">
                    {formatMoney(report.grand_total.period_credit)}
                  </td>
                  <td className="px-3 py-2.5 text-right tabular-nums">
                    {formatMoney(report.grand_total.closing_debit)}
                  </td>
                  <td className="px-3 py-2.5 text-right tabular-nums">
                    {formatMoney(report.grand_total.closing_credit)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}