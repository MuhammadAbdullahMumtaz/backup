import React, { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import api from '../../../services/api'

/**
 * Profit & Loss report page — styled to match Ledger.jsx exactly (same
 * Tailwind palette, same header-card + report-card layout, same
 * Print/Export PDF buttons). Unlike Ledger, there's no account picker -
 * P&L is company-wide, not per-account - so the controls are just the
 * two date fields and Generate.
 *
 * Endpoint (ProfitLossRoutes.js, mounted at /api/profit-loss):
 *   GET /api/profit-loss/financial-year?company_id=&financialyear_id=
 *   GET /api/profit-loss/report?company_id=&financialyear_id=&start_date=&end_date=
 */

const API = {
  profitLoss: "/profit-loss-report",
};

// ---------------------------------------------------------------------------
// Date helpers - identical to Ledger.jsx's, kept as plain string math so no
// timezone conversion ever touches a date.
// ---------------------------------------------------------------------------
function pad2(n) {
  return String(n).padStart(2, "0");
}

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function monthsAgoISO(months) {
  const d = new Date();
  d.setMonth(d.getMonth() - months);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function isoToDisplay(iso) {
  if (!iso) return "";
  const [y, m, d] = String(iso).slice(0, 10).split("-");
  return `${d}-${m}-${y}`;
}

function displayToIso(display) {
  if (!display) return "";
  const [d, m, y] = display.split("-");
  return `${y}-${pad2(m)}-${pad2(d)}`;
}

function formatMoney(n) {
  const num = Number(n) || 0;
  const abs = Math.abs(num).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return num < 0 ? `(${abs})` : abs;
}

// ---------------------------------------------------------------------------
// A single BalanceSheet group, rendered as a classic statement block:
// group heading, then each MainCode > SubCode > Account indented further,
// then a group subtotal row.
// ---------------------------------------------------------------------------
function StatementSection({ balancesheets, accentClass }) {
  if (!balancesheets || balancesheets.length === 0) {
    return (
      <tr>
        <td colSpan={2} className="px-3 py-3 text-center text-sm text-slate-400">
          No activity in this period.
        </td>
      </tr>
    );
  }

  return balancesheets.map((bs) => (
    <React.Fragment key={`bs-${bs.id}`}>
      <tr className="bg-[#F4F2EC]">
        <td className="px-3 py-2 font-bold text-[#1B2430]">{bs.details}</td>
        <td className="px-3 py-2 text-right font-bold tabular-nums text-[#1B2430]"></td>
      </tr>
      {bs.maincodes.map((mc) => (
        <React.Fragment key={`mc-${mc.id}`}>
          <tr>
            <td className="px-3 py-1.5 pl-6 font-semibold text-[#1B2430]">{mc.details}</td>
            <td className="px-3 py-1.5 text-right"></td>
          </tr>
          {mc.subcodes.map((sc) => (
            <React.Fragment key={`sc-${sc.id}`}>
              {sc.accounts.map((acc) => (
                <tr key={acc.id} className="odd:bg-white even:bg-[#FAFAF7]">
                  <td className="border-b border-[#E6E2D8] px-3 py-1.5 pl-12 text-[#1B2430]">
                    {acc.account_name}
                    <span className="ml-2 font-mono text-xs text-slate-400">({acc.code})</span>
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-1.5 text-right tabular-nums text-[#1B2430]">
                    {formatMoney(acc.amount)}
                  </td>
                </tr>
              ))}
              <tr>
                <td className="px-3 py-1 pl-9 text-xs font-semibold uppercase tracking-wide text-slate-500">
                  {sc.details} total
                </td>
                <td className="px-3 py-1 text-right text-xs font-semibold tabular-nums text-slate-500">
                  {formatMoney(sc.total)}
                </td>
              </tr>
            </React.Fragment>
          ))}
        </React.Fragment>
      ))}
      <tr className={`border-y border-[#1B2430]/20 font-bold ${accentClass}`}>
        <td className="px-3 py-2">{bs.details} total</td>
        <td className="px-3 py-2 text-right tabular-nums">{formatMoney(bs.total)}</td>
      </tr>
    </React.Fragment>
  ));
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------
export default function ProfitLoss() {
  const { companyId: rawCompanyId, financialYearId: rawFinancialYearId } = useSelector(
    (state) => state.company
  );
  const companyId =
    rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== "" ? Number(rawCompanyId) : null;
  const financialYearId =
    rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ""
      ? Number(rawFinancialYearId)
      : null;

  const [startDate, setStartDate] = useState(monthsAgoISO(2));
  const [endDate, setEndDate] = useState(todayISO());
  const [startDateText, setStartDateText] = useState(isoToDisplay(monthsAgoISO(2)));
  const [endDateText, setEndDateText] = useState(isoToDisplay(todayISO()));
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const printRef = useRef(null);

  // Prefill Start/End date with the selected financial year's own range,
  // same behavior as Trial Balance's financial-year endpoint.
  useEffect(() => {
    if (!companyId || !financialYearId) return;
    let cancelled = false;
    api
      .get(`${API.profitLoss}/financial-year`, { params: { company_id: companyId, financialyear_id: financialYearId } })
      .then((res) => {
        if (cancelled || !res.data?.success) return;
        const { start_date, end_date } = res.data.data;
        setStartDate(start_date);
        setEndDate(end_date);
        setStartDateText(isoToDisplay(start_date));
        setEndDateText(isoToDisplay(end_date));
      })
      .catch(() => {});
    setReport(null);
    return () => { cancelled = true; };
  }, [companyId, financialYearId]);

  async function generateReport() {
    if (!companyId) {
      toast.error("Please select a company first.");
      return;
    }
    if (!financialYearId) {
      toast.error("Please select a financial year first.");
      return;
    }
    setLoading(true);
    try {
      const res = await api.get(`${API.profitLoss}/report`, {
        params: {
          company_id: companyId,
          financialyear_id: financialYearId,
          start_date: startDate,
          end_date: endDate,
        },
      });
      if (res.data?.success) {
        setReport(res.data.data);
      } else {
        toast.error(res.data?.message || "Failed to generate report.");
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || "Could not reach the server. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handlePrint() {
    window.print();
  }

  async function handleExportPdf() {
    if (!printRef.current) return;
    const canvas = await html2canvas(printRef.current, { scale: 2, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth - 40;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 20;

    pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight + 20;
      pdf.addPage();
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    pdf.save(`Profit_And_Loss_${startDate}_to_${endDate}.pdf`);
  }

  if (!companyId) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] p-8">
        <div className="mx-auto max-w-md rounded-lg border border-[#E6E2D8] bg-white p-8 text-center text-sm text-gray-500 shadow-sm">
          No company context found. Please select a company first.
        </div>
      </div>
    );
  }

  const isProfit = report ? report.net_profit >= 0 : true;

  return (
    <div className="min-h-screen bg-[#FAFAF7] p-8 font-sans text-[#1B2430] print:bg-white print:p-0">
      <div className="mb-5 rounded-xl border border-[#E6E2D8] bg-white p-6 shadow-sm print:hidden">
        <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
          Reporting
        </span>
        <h1 className="mb-4 text-2xl font-bold tracking-tight">Profit &amp; Loss Statement</h1>

        {!financialYearId && (
          <div className="mb-4 max-w-md rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-600">
            No financial year selected. Please pick one to generate this report.
          </div>
        )}

        <div className="flex flex-wrap items-end gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Start date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={startDateText}
              onChange={(e) => {
                const v = e.target.value;
                setStartDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setStartDate(displayToIso(v));
              }}
              onBlur={() => setStartDateText(isoToDisplay(startDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">End date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={endDateText}
              onChange={(e) => {
                const v = e.target.value;
                setEndDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setEndDate(displayToIso(v));
              }}
              onBlur={() => setEndDateText(isoToDisplay(endDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <button
            className="rounded-lg bg-[#1B2430] px-5 py-2.5 text-sm font-semibold text-white transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
            onClick={generateReport}
            disabled={loading}
          >
            {loading ? "Generating…" : "Generate"}
          </button>
        </div>

        {report && (
          <div className="mt-4 flex gap-2.5 border-t border-[#E6E2D8] pt-4">
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handlePrint}
            >
              Print
            </button>
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handleExportPdf}
            >
              Export PDF
            </button>
          </div>
        )}
      </div>

      {report && (
        <div
          ref={printRef}
          className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none"
        >
          <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
            <div>
              <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                Profit &amp; Loss Statement
              </span>
              <h2 className="text-2xl font-bold">Company Overview</h2>
            </div>
            <div className="text-sm font-semibold tabular-nums text-slate-500">
              <span>{isoToDisplay(report.start_date)}</span>
              <span className="mx-2 text-[#B08A2E]">to</span>
              <span>{isoToDisplay(report.end_date)}</span>
            </div>
          </div>

          <div className="mb-5 grid grid-cols-3 gap-3">
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Total Income
              </span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.income.total)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Total Expense
              </span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.expenses.total)}</span>
            </div>
            <div className={`flex flex-col gap-1 rounded-lg px-3.5 py-3 ${isProfit ? "bg-[#EFE6CE]" : "bg-red-50"}`}>
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                {isProfit ? "Net Profit" : "Net Loss"}
              </span>
              <span className={`text-lg font-bold tabular-nums ${isProfit ? "" : "text-red-700"}`}>
                {formatMoney(Math.abs(report.net_profit))}
              </span>
            </div>
          </div>

          <table className="w-full border-collapse text-[13.5px]">
            <thead>
              <tr>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                  Particulars
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Amount
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td colSpan={2} className="bg-emerald-50 px-3 py-2 text-sm font-bold uppercase tracking-wide text-emerald-800">
                  Income
                </td>
              </tr>
              <StatementSection balancesheets={report.income.balancesheets} accentClass="bg-emerald-50 text-emerald-800" />
              <tr className="border-y-2 border-[#1B2430] bg-emerald-100 font-bold">
                <td className="px-3 py-2.5">Total Income</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.income.total)}</td>
              </tr>

              <tr>
                <td colSpan={2} className="bg-red-50 px-3 py-2 text-sm font-bold uppercase tracking-wide text-red-800">
                  Expenses
                </td>
              </tr>
              <StatementSection balancesheets={report.expenses.balancesheets} accentClass="bg-red-50 text-red-800" />
              <tr className="border-y-2 border-[#1B2430] bg-red-100 font-bold">
                <td className="px-3 py-2.5">Total Expenses</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.expenses.total)}</td>
              </tr>

              <tr className={`border-y-2 border-[#1B2430] font-bold ${isProfit ? "bg-[#F3ECD9]" : "bg-red-100"}`}>
                <td className="px-3 py-3 text-base">{isProfit ? "Net Profit" : "Net Loss"}</td>
                <td className={`px-3 py-3 text-right text-base tabular-nums ${isProfit ? "" : "text-red-700"}`}>
                  {formatMoney(Math.abs(report.net_profit))}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}