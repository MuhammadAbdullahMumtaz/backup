import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import api from "../../../services/api";

const API = {
  purchaseReport: "/purchase-report",
  chartOfAccount: "/chart-of-account",
  itemDetail: "/item-detail",
};

const REPORT_TYPES = [
  { key: "dateWise", label: "Date Wise" },
  { key: "accountWise", label: "Account Wise" },
  { key: "itemWise", label: "Item Wise" },
  { key: "itemGroupWise", label: "Item Group Wise" },
  { key: "detailed", label: "Detailed Purchases" },
];

// ---------------------------------------------------------------------------
// Date helpers (same convention as Ledger.jsx / SalesReport.jsx: plain
// string manipulation, no Date-object timezone shifting)
// ---------------------------------------------------------------------------
function pad2(n) {
  return String(n).padStart(2, "0");
}
function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
function monthsAgoISO(months) {
  const d = new Date();
  d.setMonth(d.getMonth() - months);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
function isoToDisplay(iso) {
  if (!iso) return "";
  const [y, m, d] = String(iso).slice(0, 10).split("-");
  return `${d}-${m}-${y}`;
}
function displayToIso(display) {
  if (!display) return "";
  const [d, m, y] = display.split("-");
  return `${y}-${pad2(m)}-${pad2(d)}`;
}
function formatMoney(n) {
  const num = Number(n) || 0;
  const abs = Math.abs(num).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return num < 0 ? `(${abs})` : abs;
}
function formatNumber(n) {
  const num = Number(n) || 0;
  return num.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

// ---------------------------------------------------------------------------
// Column definitions per report type
//   money/numeric columns get right-aligned + summed in the footer.
//   Purchase-count / return-count columns make the netting (purchases minus
//   returns) visible instead of silently folding returns into one number.
// ---------------------------------------------------------------------------
const DATE_WISE_COLUMNS = [
  { key: "date", label: "Date", date: true },
  { key: "purchase_count", label: "GRNs", numeric: true },
  { key: "return_count", label: "Returns", numeric: true },
  { key: "total_pieces", label: "Pieces", numeric: true },
  { key: "total_net_weight", label: "Net Weight", numeric: true },
  { key: "total_amount", label: "Amount", numeric: true, money: true },
  { key: "total_freight", label: "Freight", numeric: true, money: true },
  { key: "total_value", label: "Total Value", numeric: true, money: true, sum: true },
];

const ACCOUNT_WISE_COLUMNS = [
  { key: "supplier_code", label: "Code" },
  { key: "supplier_name", label: "Supplier" },
  { key: "city", label: "City" },
  { key: "purchase_count", label: "GRNs", numeric: true },
  { key: "return_count", label: "Returns", numeric: true },
  { key: "total_pieces", label: "Pieces", numeric: true },
  { key: "total_net_weight", label: "Net Weight", numeric: true },
  { key: "total_amount", label: "Amount", numeric: true, money: true },
  { key: "total_freight", label: "Freight", numeric: true, money: true },
  { key: "total_value", label: "Total Value", numeric: true, money: true, sum: true },
];

const ITEM_WISE_COLUMNS = [
  { key: "item_code", label: "Code" },
  { key: "item_name", label: "Item" },
  { key: "purchase_count", label: "GRNs", numeric: true },
  { key: "total_pieces", label: "Pieces", numeric: true },
  { key: "total_net_weight", label: "Net Weight", numeric: true },
  { key: "avg_rate", label: "Avg Rate", numeric: true, money: true },
  { key: "total_amount", label: "Amount", numeric: true, money: true },
  { key: "total_value", label: "Total Value", numeric: true, money: true, sum: true },
];

const ITEM_GROUP_WISE_COLUMNS = [
  { key: "group_code", label: "Code" },
  { key: "group_name", label: "Group" },
  { key: "purchase_count", label: "GRNs", numeric: true },
  { key: "total_pieces", label: "Pieces", numeric: true },
  { key: "total_net_weight", label: "Net Weight", numeric: true },
  { key: "avg_rate", label: "Avg Rate", numeric: true, money: true },
  { key: "total_amount", label: "Amount", numeric: true, money: true },
  { key: "total_value", label: "Total Value", numeric: true, money: true, sum: true },
];

// Every field the "Detailed" report can show. `default: true` fields are
// visible out of the box; the user can toggle any of these on/off, mirroring
// the fields present on the actual GRN / Purchase Return entry forms. Unlike
// the summary reports, rows here are NOT netted — each purchase or return
// line shows exactly as entered, distinguished by the Type column.
const DETAILED_FIELDS = [
  { key: "type", label: "Type", default: true },
  { key: "doc_no", label: "GRN / Return No", default: true },
  { key: "doc_date", label: "Date", default: true, date: true },
  { key: "supplier_name", label: "Supplier", default: true },
  { key: "supplier_code", label: "Supplier Code", default: false },
  { key: "city", label: "City", default: true },
  { key: "province", label: "Province", default: false },
  { key: "item_name", label: "Item", default: true },
  { key: "item_code", label: "Item Code", default: false },
  { key: "item_sub", label: "Item Sub", default: false },
  { key: "stocks", label: "Stock Status", default: false },
  { key: "pieces", label: "Pieces", default: true, numeric: true },
  { key: "gross_weight", label: "Gross Weight", default: false, numeric: true },
  { key: "tear_weight", label: "Tear Weight", default: false, numeric: true },
  { key: "net_weight", label: "Net Weight", default: true, numeric: true },
  { key: "rate", label: "Rate", default: true, numeric: true, money: true },
  { key: "amount", label: "Amount", default: true, numeric: true, money: true },
  { key: "detail_freight", label: "Freight", default: false, numeric: true, money: true },
  { key: "total", label: "Total", default: true, numeric: true, money: true, sum: true },
  { key: "gp_no", label: "GP No", default: false },
  { key: "gp_date", label: "GP Date", default: false, date: true },
  { key: "invoice_no", label: "Invoice No", default: false },
  { key: "invoice_date", label: "Invoice Date", default: false, date: true },
];

function defaultVisibility(fields) {
  const map = {};
  fields.forEach((f) => (map[f.key] = !!f.default));
  return map;
}

// ---------------------------------------------------------------------------
// Small searchable combobox, reused for the optional Supplier / Item filters
// on the Detailed report. Same fetch-once-then-filter-client-side pattern
// used throughout the app (ChartOfAccount.jsx, PurchaseEntry.jsx, Ledger.jsx).
// ---------------------------------------------------------------------------
function SearchableFilter({ label, value, onChange, loadOptions, codeKey, labelKey, placeholder }) {
  const [query, setQuery] = useState("");
  const [options, setOptions] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const boxRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const ensureLoaded = useCallback(async () => {
    if (loaded || loading) return;
    setLoading(true);
    try {
      const list = await loadOptions();
      setOptions(list);
      setLoaded(true);
    } catch (error) {
      toast.error("Failed to load options");
    } finally {
      setLoading(false);
    }
  }, [loaded, loading, loadOptions]);

  const term = query.trim().toLowerCase();
  const suggestions = term
    ? options
        .filter(
          (o) =>
            String(o[labelKey] ?? "").toLowerCase().includes(term) ||
            String(o[codeKey] ?? "").toLowerCase().includes(term)
        )
        .slice(0, 8)
    : options.slice(0, 8);

  function pick(opt) {
    setQuery(opt ? `${opt[labelKey]}` : "");
    onChange(opt ? opt[codeKey] : "");
    setOpen(false);
  }

  return (
    <div className="relative flex min-w-[200px] flex-col gap-1.5" ref={boxRef}>
      <label className="text-xs font-semibold text-slate-500">{label}</label>
      <input
        className="rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
        type="text"
        placeholder={placeholder}
        value={value ? query || value : query}
        onChange={(e) => {
          setQuery(e.target.value);
          if (!e.target.value) onChange("");
          setOpen(true);
        }}
        onFocus={(e) => {
          setOpen(true);
          ensureLoaded();
          e.target.select();
        }}
      />
      {open && (
        <div className="absolute top-full z-30 mt-1 max-h-64 w-full min-w-[260px] overflow-y-auto rounded-lg border border-[#E6E2D8] bg-white p-1.5 shadow-lg">
          <div
            className="cursor-pointer rounded-md px-2.5 py-2 text-sm font-semibold text-[#B08A2E] hover:bg-[#F3ECD9]"
            onMouseDown={() => pick(null)}
          >
            All / clear
          </div>
          {loading && <div className="px-2.5 py-2 text-sm text-slate-400">Loading…</div>}
          {!loading &&
            suggestions.map((opt) => (
              <div
                key={opt[codeKey]}
                className="flex cursor-pointer items-center justify-between gap-3 rounded-md px-2.5 py-2 text-sm hover:bg-[#F3ECD9]"
                onMouseDown={() => pick(opt)}
              >
                <span className="text-[#1B2430]">{opt[labelKey]}</span>
                <span className="font-mono text-xs tabular-nums text-slate-500">{opt[codeKey]}</span>
              </div>
            ))}
          {!loading && loaded && suggestions.length === 0 && (
            <div className="px-2.5 py-2 text-sm text-slate-400">No matches</div>
          )}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Generic ledger-styled results table. The "Type" column (Detailed report
// only) gets a small colored badge so Purchase vs Return rows are easy to
// scan at a glance.
// ---------------------------------------------------------------------------
function ReportTable({ columns, rows, totals }) {
  function renderCell(col, row) {
    const val = row[col.key];
    if (col.key === "type") {
      const isReturn = val === "Return";
      return (
        <span
          className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-bold uppercase tracking-wide ${
            isReturn ? "bg-rose-50 text-rose-600" : "bg-emerald-50 text-emerald-600"
          }`}
        >
          {val}
        </span>
      );
    }
    if (col.date) return isoToDisplay(val);
    if (col.money) return formatMoney(val);
    if (col.numeric) return formatNumber(val);
    return val ?? "";
  }

  return (
    <table className="w-full border-collapse text-[13.5px]">
      <thead>
        <tr>
          <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
            S.No
          </th>
          {columns.map((col) => (
            <th
              key={col.key}
              className={`sticky top-0 whitespace-nowrap bg-[#1B2430] px-3 py-2.5 text-[11px] font-bold uppercase tracking-wide text-white ${
                col.numeric ? "text-right" : "text-left"
              }`}
            >
              {col.label}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, idx) => (
          <tr key={row.doc_id ? `${row.doc_id}-${row.type}-${row.entry_no}-${idx}` : idx} className="odd:bg-white even:bg-[#F4F2EC]">
            <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">{row.s_no ?? idx + 1}</td>
            {columns.map((col) => (
              <td
                key={col.key}
                className={`border-b border-[#E6E2D8] px-3 py-2.5 ${col.numeric ? "text-right tabular-nums" : ""}`}
              >
                {renderCell(col, row)}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
      {totals && (
        <tfoot>
          <tr className="border-y border-[#1B2430] bg-[#F3ECD9] font-bold">
            <td className="px-3 py-2.5 text-center" colSpan={1 + columns.filter((c) => !c.sum).length}>
              Total (Purchases − Returns)
            </td>
            {columns
              .filter((c) => c.sum)
              .map((c) => (
                <td key={c.key} className="px-3 py-2.5 text-right tabular-nums">
                  {c.money ? formatMoney(totals[c.key]) : formatNumber(totals[c.key])}
                </td>
              ))}
          </tr>
        </tfoot>
      )}
    </table>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------
export default function PurchaseReport() {
  const { companyId: rawCompanyId, financialYearId: rawFinancialYearId } = useSelector((state) => state.company);
  const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== "" ? Number(rawCompanyId) : null;
  const financialYearId =
    rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ""
      ? Number(rawFinancialYearId)
      : null;

  const [reportType, setReportType] = useState("dateWise");

  const [startDate, setStartDate] = useState(monthsAgoISO(1));
  const [endDate, setEndDate] = useState(todayISO());
  const [startDateText, setStartDateText] = useState(isoToDisplay(monthsAgoISO(1)));
  const [endDateText, setEndDateText] = useState(isoToDisplay(todayISO()));

  const [limit, setLimit] = useState(20);
  const [groupBy, setGroupBy] = useState("subitem"); // item-group-wise grouping
  const [supplierFilter, setSupplierFilter] = useState("");
  const [itemFilter, setItemFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("all"); // detailed: all | purchase | return
  const [visibleFields, setVisibleFields] = useState(defaultVisibility(DETAILED_FIELDS));
  const [showFieldPicker, setShowFieldPicker] = useState(false);

  const [rows, setRows] = useState([]);
  const [totals, setTotals] = useState(null);
  const [loading, setLoading] = useState(false);
  const [hasRun, setHasRun] = useState(false);

  const printRef = useRef(null);

  // Reset results whenever the report type or company/FY context changes
  useEffect(() => {
    setRows([]);
    setTotals(null);
    setHasRun(false);
  }, [reportType, companyId, financialYearId]);

  const loadSuppliers = useCallback(async () => {
    const res = await api.get(`${API.chartOfAccount}/`, { params: { company_id: companyId } });
    return (res.data?.data || []).filter((c) => c.company_id === companyId);
  }, [companyId]);

  const loadItems = useCallback(async () => {
    const res = await api.get(`${API.itemDetail}/`);
    const data = res.data?.data || res.data || [];
    return (Array.isArray(data) ? data : []).filter((i) => i.company_id === companyId);
  }, [companyId]);

  const columns = useMemo(() => {
    if (reportType === "dateWise") return DATE_WISE_COLUMNS;
    if (reportType === "accountWise") return ACCOUNT_WISE_COLUMNS;
    if (reportType === "itemWise") return ITEM_WISE_COLUMNS;
    if (reportType === "itemGroupWise") return ITEM_GROUP_WISE_COLUMNS;
    return DETAILED_FIELDS.filter((f) => visibleFields[f.key]);
  }, [reportType, visibleFields]);

  async function generateReport() {
    if (!companyId || !financialYearId) {
      toast.error("Please select a company and financial year first.");
      return;
    }
    setLoading(true);
    setHasRun(true);
    try {
      const baseParams = {
        company_id: companyId,
        financialyear_id: financialYearId,
        start_date: startDate,
        end_date: endDate,
      };

      if (reportType === "dateWise") {
        const res = await api.get(`${API.purchaseReport}/date-wise`, { params: baseParams });
        setRows(res.data?.data || []);
        setTotals(null);
      } else if (reportType === "accountWise") {
        const res = await api.get(`${API.purchaseReport}/account-wise`, { params: { ...baseParams, limit } });
        setRows(res.data?.data || []);
        setTotals(null);
      } else if (reportType === "itemWise") {
        const res = await api.get(`${API.purchaseReport}/item-wise`, { params: { ...baseParams, limit } });
        setRows(res.data?.data || []);
        setTotals(null);
      } else if (reportType === "itemGroupWise") {
        const res = await api.get(`${API.purchaseReport}/item-group-wise`, {
          params: { ...baseParams, limit, group_by: groupBy },
        });
        setRows(res.data?.data || []);
        setTotals(null);
      } else {
        const res = await api.get(`${API.purchaseReport}/detailed`, {
          params: {
            ...baseParams,
            supplier_code: supplierFilter || undefined,
            item_code: itemFilter || undefined,
            type: typeFilter !== "all" ? typeFilter : undefined,
          },
        });
        setRows(res.data?.data || []);
        setTotals(res.data?.totals || null);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || "Failed to generate report.");
      setRows([]);
      setTotals(null);
    } finally {
      setLoading(false);
    }
  }

  function handlePrint() {
    window.print();
  }

  async function handleExportPdf() {
    if (!printRef.current) return;
    const canvas = await html2canvas(printRef.current, { scale: 2, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth - 40;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 20;
    pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
    while (heightLeft > 0) {
      position = heightLeft - imgHeight + 20;
      pdf.addPage();
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    const typeLabel = REPORT_TYPES.find((t) => t.key === reportType)?.label || "Purchase_Report";
    pdf.save(`${typeLabel.replace(/\s+/g, "_")}_${startDate}_to_${endDate}.pdf`);
  }

  function toggleField(key) {
    setVisibleFields((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  if (!companyId) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] p-8">
        <div className="mx-auto max-w-md rounded-lg border border-[#E6E2D8] bg-white p-8 text-center text-sm text-gray-500 shadow-sm">
          No company context found. Please select a company first.
        </div>
      </div>
    );
  }

  const reportTitle = REPORT_TYPES.find((t) => t.key === reportType)?.label || "Purchase Report";

  return (
    <div className="min-h-screen bg-[#FAFAF7] p-8 font-sans text-[#1B2430] print:bg-white print:p-0">
      <div className="mb-5 rounded-xl border border-[#E6E2D8] bg-white p-6 shadow-sm print:hidden">
        <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
          Reporting
        </span>
        <h1 className="mb-4 text-2xl font-bold tracking-tight">Purchase Report</h1>

        {!financialYearId && (
          <div className="mb-4 max-w-md rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-600">
            No financial year selected. Please pick one to generate reports.
          </div>
        )}

        {/* Report type tabs */}
        <div className="mb-4 inline-flex flex-wrap gap-1 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] p-1">
          {REPORT_TYPES.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setReportType(t.key)}
              className={`rounded-md px-3.5 py-2 text-sm font-semibold transition ${
                reportType === t.key ? "bg-[#1B2430] text-white shadow-sm" : "text-slate-600 hover:bg-white"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Shared + per-type filters */}
        <div className="flex flex-wrap items-end gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Start date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={startDateText}
              onChange={(e) => {
                const v = e.target.value;
                setStartDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setStartDate(displayToIso(v));
              }}
              onBlur={() => setStartDateText(isoToDisplay(startDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">End date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={endDateText}
              onChange={(e) => {
                const v = e.target.value;
                setEndDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setEndDate(displayToIso(v));
              }}
              onBlur={() => setEndDateText(isoToDisplay(endDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          {(reportType === "accountWise" || reportType === "itemWise" || reportType === "itemGroupWise") && (
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-500">Show top</label>
              <input
                className="w-24 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
                type="number"
                min="1"
                max="500"
                value={limit}
                onChange={(e) => setLimit(Number(e.target.value) || 20)}
              />
            </div>
          )}

          {reportType === "itemGroupWise" && (
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-500">Group by</label>
              <select
                className="rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
                value={groupBy}
                onChange={(e) => setGroupBy(e.target.value)}
              >
                <option value="subitem">Item Sub (custom group)</option>
                <option value="mainitem">Main Item</option>
              </select>
            </div>
          )}

          {reportType === "detailed" && (
            <>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-500">Type</label>
                <select
                  className="rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value)}
                >
                  <option value="all">Purchases & Returns</option>
                  <option value="purchase">Purchases only</option>
                  <option value="return">Returns only</option>
                </select>
              </div>
              <SearchableFilter
                label="Supplier (optional)"
                value={supplierFilter}
                onChange={setSupplierFilter}
                loadOptions={loadSuppliers}
                codeKey="code"
                labelKey="account_name"
                placeholder="All suppliers"
              />
              <SearchableFilter
                label="Item (optional)"
                value={itemFilter}
                onChange={setItemFilter}
                loadOptions={loadItems}
                codeKey="code"
                labelKey="details"
                placeholder="All items"
              />
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-500">Columns</label>
                <button
                  type="button"
                  onClick={() => setShowFieldPicker((p) => !p)}
                  className="rounded-lg border border-[#E6E2D8] bg-white px-3.5 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
                >
                  {showFieldPicker ? "Hide fields" : "Choose fields"}
                </button>
              </div>
            </>
          )}

          <button
            className="rounded-lg bg-[#1B2430] px-5 py-2.5 text-sm font-semibold text-white transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
            onClick={generateReport}
            disabled={loading}
          >
            {loading ? "Generating…" : "Generate"}
          </button>
        </div>

        {/* Field picker for the Detailed report */}
        {reportType === "detailed" && showFieldPicker && (
          <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] p-4 sm:grid-cols-3 lg:grid-cols-4">
            {DETAILED_FIELDS.map((f) => (
              <label key={f.key} className="flex cursor-pointer items-center gap-2 text-sm text-[#1B2430]">
                <input
                  type="checkbox"
                  checked={!!visibleFields[f.key]}
                  onChange={() => toggleField(f.key)}
                  className="h-4 w-4 rounded border-[#E6E2D8] text-[#B08A2E] focus:ring-[#B08A2E]"
                />
                {f.label}
              </label>
            ))}
          </div>
        )}

        {hasRun && rows.length > 0 && (
          <div className="mt-4 flex gap-2.5 border-t border-[#E6E2D8] pt-4">
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handlePrint}
            >
              Print
            </button>
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handleExportPdf}
            >
              Export PDF
            </button>
          </div>
        )}
      </div>

      {hasRun && (
        <div
          ref={printRef}
          className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none"
        >
          <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
            <div>
              <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                Purchase Report
              </span>
              <h2 className="text-2xl font-bold">{reportTitle}</h2>
            </div>
            <div className="text-sm font-semibold tabular-nums text-slate-500">
              <span>{isoToDisplay(startDate)}</span>
              <span className="mx-2 text-[#B08A2E]">to</span>
              <span>{isoToDisplay(endDate)}</span>
            </div>
          </div>

          {loading ? (
            <div className="py-10 text-center text-sm text-slate-400">Generating…</div>
          ) : rows.length === 0 ? (
            <div className="py-10 text-center text-sm text-slate-400">No data found for this selection.</div>
          ) : (
            <div className="overflow-x-auto">
              <ReportTable columns={columns} rows={rows} totals={totals} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}