import React, { useState, useEffect, useRef, useCallback } from "react";
import { toast } from "react-toastify";
import { useSelector, useDispatch } from "react-redux";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { useNavigate } from "react-router-dom";
import { setCurrentMonth } from "../../../store/slices/companySlice";
import api from '../../../services/api'

/**
 * Ledger report page — styled with Tailwind utility classes only.
 *
 * Account search mirrors ChartOfAccount.jsx exactly:
 *   - company_id / financialyear_id come from Redux (state.company), not
 *     localStorage.
 *   - There's no separate "search accounts" endpoint. We fetch every
 *     ChartOfAccount row for the current company + financial year from
 *     GET /api/chart-of-account/ (same endpoint ChartOfAccount.jsx uses)
 *     and filter client-side on account_name / code, exactly like the
 *     Chart Of Account page's own search box does.
 *
 * Ledger report endpoint (separate, from LedgerRoutes.js):
 *   GET /api/ledger/report?company_id=&financialyear_id=&account_id=&account_code=&start_date=&end_date=
 *   financialyear_id is sent straight from Redux — the backend does a plain
 *   PK lookup on FinancialYear instead of scanning date ranges for it.
 */

const API = {
  chartOfAccount: "/chart-of-account",
  ledger: "/ledger",
};

// ---------------------------------------------------------------------------
// Date helpers — parsed/printed as plain strings so no timezone conversion
// ever touches a date, which is what causes the "MySQL date is one day back"
// symptom in the first place.
// ---------------------------------------------------------------------------
function pad2(n) {
  return String(n).padStart(2, "0");
}

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function monthsAgoISO(months) {
  const d = new Date();
  d.setMonth(d.getMonth() - months);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

// 'YYYY-MM-DD' -> 'DD-MM-YYYY', pure string manipulation, no Date object
function isoToDisplay(iso) {
  if (!iso) return "";
  const [y, m, d] = String(iso).slice(0, 10).split("-");
  return `${d}-${m}-${y}`;
}

// 'DD-MM-YYYY' -> 'YYYY-MM-DD'
function displayToIso(display) {
  if (!display) return "";
  const [d, m, y] = display.split("-");
  return `${y}-${pad2(m)}-${pad2(d)}`;
}

function formatMoney(n) {
  const num = Number(n) || 0;
  const abs = Math.abs(num).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return num < 0 ? `(${abs})` : abs;
}

// Color-codes the Type badge per voucher source, and clearly flags returns
// (red) vs. their forward counterparts (blue/green) so a Purchase Return or
// Sales Return row is unmistakable at a glance in the ledger table.
function voucherTypeBadgeClass(type) {
  if (type === 'P' || type === 'P (Auto)') return 'bg-blue-600';
  if (type === 'PR' || type === 'PR (Auto)') return 'bg-red-600';
  if (type === 'S' || type === 'S (Auto)') return 'bg-emerald-600';
  if (type === 'SR' || type === 'SR (Auto)') return 'bg-orange-600';
  return 'bg-[#1B2430]'; // Voucher entries (JV, PV, BRV, etc.) - default
}

function isReturnRow(type) {
  return type === 'PR' || type === 'PR (Auto)' || type === 'SR' || type === 'SR (Auto)';
}

// ---------------------------------------------------------------------------
// Account search combobox
//   Same fetch-then-filter-client-side approach as ChartOfAccount.jsx's
//   search box: pull the full ChartOfAccount list for this company +
//   financial year once, then filter in memory as the user types.
//   Up/Down to move, Enter to pick, Esc to close.
// ---------------------------------------------------------------------------
function AccountSearch({ companyId, financialYearId, value, onSelect }) {
  const [query, setQuery] = useState(value ? value.name : "");
  const [allAccounts, setAllAccounts] = useState([]);
  const [accountsLoaded, setAccountsLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const boxRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Reset the cached list whenever the company or financial year changes,
  // same as ChartOfAccount.jsx re-scoping chartAccountsBySC per finyear.
  useEffect(() => {
    setAllAccounts([]);
    setAccountsLoaded(false);
  }, [companyId, financialYearId]);

  const loadAccountsIfNeeded = useCallback(async () => {
    if (accountsLoaded || loading || !companyId || !financialYearId) return;
    setLoading(true);
    try {
      const res = await api.get(`${API.chartOfAccount}/`, {
        params: { company_id: companyId, financialyear_id: financialYearId },
      });
      const filtered = (res.data?.data || []).filter(
        (coa) => coa.company_id === companyId && coa.financialyear_id === financialYearId
      );
      setAllAccounts(filtered);
      setAccountsLoaded(true);
    } catch (error) {
      toast.error(error?.response?.data?.message || "Failed to load accounts");
    } finally {
      setLoading(false);
    }
  }, [companyId, financialYearId, accountsLoaded, loading]);

  function filterAccounts(term) {
    const t = term.trim().toLowerCase();
    if (!t) return [];
    return allAccounts.filter(
      (coa) =>
        coa.account_name.toLowerCase().includes(t) ||
        (coa.code && coa.code.toLowerCase().includes(t))
    );
  }

  function handleChange(e) {
    const q = e.target.value;
    setQuery(q);
    setOpen(true);
    if (!accountsLoaded) {
      loadAccountsIfNeeded();
      return;
    }
    const results = filterAccounts(q);
    setSuggestions(results);
    setActiveIndex(results.length ? 0 : -1);
  }

  // Once the list finishes loading, (re)apply whatever the user already typed.
  useEffect(() => {
    if (accountsLoaded && query.trim()) {
      const results = filterAccounts(query);
      setSuggestions(results);
      setActiveIndex(results.length ? 0 : -1);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accountsLoaded, allAccounts]);

  function handleFocus(e) {
    setOpen(true);
    if (!accountsLoaded) loadAccountsIfNeeded();
    else if (query.trim()) setSuggestions(filterAccounts(query));
    e.target.select();
  }

  function pick(coa) {
    const picked = { id: coa.id, code: coa.code, name: coa.account_name };
    setQuery(picked.name);
    setOpen(false);
    onSelect(picked);
  }

  function handleKeyDown(e) {
    if (!open || suggestions.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => (i + 1) % suggestions.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => (i - 1 + suggestions.length) % suggestions.length);
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (activeIndex >= 0 && suggestions[activeIndex]) pick(suggestions[activeIndex]);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  }

  const disabled = !companyId || !financialYearId;

  return (
    <div className="relative flex min-w-[240px] flex-col gap-1.5" ref={boxRef}>
      <label className="text-xs font-semibold text-slate-500">Account</label>
      <input
        className="rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20 disabled:cursor-not-allowed disabled:opacity-60"
        type="text"
        placeholder={disabled ? "Select a financial year first…" : "Search account name or code…"}
        value={query}
        onChange={handleChange}
        onFocus={handleFocus}
        onKeyDown={handleKeyDown}
        autoComplete="off"
        showAllOnFocus
        disabled={disabled}
      />

      {open && loading && (
        <div className="absolute top-full z-30 mt-1 w-full rounded-lg border border-[#E6E2D8] bg-white p-3 text-center text-sm text-slate-500 shadow-lg">
          Loading accounts…
        </div>
      )}

      {open && !loading && query.trim() && suggestions.length > 0 && (
        <ul className="absolute top-full z-30 mt-1 max-h-64 w-full overflow-y-auto rounded-lg border border-[#E6E2D8] bg-white p-1.5 shadow-lg">
          {suggestions.map((coa, i) => (
            <li
              key={coa.id}
              className={`flex cursor-pointer items-center justify-between gap-3 rounded-md px-2.5 py-2 text-sm ${i === activeIndex ? "bg-[#F3ECD9]" : ""
                }`}
              onMouseDown={() => pick(coa)}
              onMouseEnter={() => setActiveIndex(i)}
            >
              <span className="text-[#1B2430]">{coa.account_name}</span>
              <span className="font-mono text-xs tabular-nums text-slate-500">{coa.code}</span>
            </li>
          ))}
        </ul>
      )}

      {open && !loading && accountsLoaded && query.trim() && suggestions.length === 0 && (
        <div className="absolute top-full z-30 mt-1 w-full rounded-lg border border-[#E6E2D8] bg-white p-3 text-center text-sm text-slate-500 shadow-lg">
          No accounts found
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------
export default function Ledger({ onNavigate, navPayload, onNavPayloadConsumed }) {
  // Same Redux source and null-safe Number(...) coercion as ChartOfAccount.jsx
  const { companyId: rawCompanyId, financialYearId: rawFinancialYearId } = useSelector(
    (state) => state.company
  );
  const companyId =
    rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== "" ? Number(rawCompanyId) : null;
  const financialYearId =
    rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ""
      ? Number(rawFinancialYearId)
      : null;

  const [account, setAccount] = useState(null);
  const [startDate, setStartDate] = useState(monthsAgoISO(2));
  const [endDate, setEndDate] = useState(todayISO());
  const [startDateText, setStartDateText] = useState(isoToDisplay(monthsAgoISO(2)));
  const [endDateText, setEndDateText] = useState(isoToDisplay(todayISO()));
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const printRef = useRef(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const pendingHandledRef = useRef(false);
  const pendingAccountIdRef = useRef(null);
  const lastNavPayloadRef = useRef(null); // NEW

  // Coming from Trial Balance double-click: preselect the account + FY dates
  useEffect(() => {
    if (!navPayload?.account_id || !financialYearId) return;
    if (lastNavPayloadRef.current === navPayload) return; // CHANGED: only skip if it's this exact payload again
    lastNavPayloadRef.current = navPayload; // CHANGED

    const picked = {
      id: navPayload.account_id,
      code: navPayload.account_code,
      name: navPayload.account_name,
    };
    setAccount(picked);
    pendingAccountIdRef.current = navPayload.account_id;

    if (navPayload.start_date) {
      setStartDate(navPayload.start_date);
      setStartDateText(isoToDisplay(navPayload.start_date));
    }
    if (navPayload.end_date) {
      setEndDate(navPayload.end_date);
      setEndDateText(isoToDisplay(navPayload.end_date));
    }

    pendingHandledRef.current = true; // re-armed every time, unlike before
    onNavPayloadConsumed && onNavPayloadConsumed();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navPayload, financialYearId]);

  // Once the picked account + dates land in state, fire the report automatically
  useEffect(() => {
    if (pendingHandledRef.current !== true) return; // not pending, or already done
    if (!account || account.id !== pendingAccountIdRef.current) return; // CHANGED: compare against ref, not navPayload
    generateReport();
    pendingHandledRef.current = 'done'; // prevent re-firing
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [account, startDate, endDate]);

  const MONTHS = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  function monthNameFromDateStr(dateStr) {
    if (!dateStr) return '';
    const parts = String(dateStr).slice(0, 10).split('-');
    if (parts.length !== 3) return '';
    return MONTHS[Number(parts[1]) - 1] || '';
  }

  function handleRowDoubleClick(row) {
    if (!onNavigate) return;

    // Purchase (normal or auto) - just open the GRN, no month change needed
    if (row.voucher_type === 'P' || row.voucher_type === 'P (Auto)') {
      onNavigate('purchase-entry', { grn_no: row.voucher_no, mode: 'purchase' });
      return;
    }
    // Purchase Return (normal or auto) - open in Return mode
    if (row.voucher_type === 'PR' || row.voucher_type === 'PR (Auto)') {
      onNavigate('purchase-entry', { return_no: row.voucher_no, mode: 'purchaseReturn' });
      return;
    }
    // Sales - voucher_no represents the invoice_no
    if (row.voucher_type === 'S' || row.voucher_type === 'S (Auto)') {
      onNavigate('sales-entry', { invoice_no: row.voucher_no, mode: 'sale' });
      return;
    }
    // Sales Return - open in Return mode
    if (row.voucher_type === 'SR' || row.voucher_type === 'SR (Auto)') {
      onNavigate('sales-entry', { invoice_no: row.voucher_no, mode: 'return' });
      return;
    }
    // Anything else is a Voucher Entry type (JV, PV, BRV, etc.)
    const month = monthNameFromDateStr(row.date);
    if (month) dispatch(setCurrentMonth(month));
    onNavigate('voucher-entry', { voucher_type: row.voucher_type, voucher_no: row.voucher_no });
  }

  useEffect(() => {
    if (navPayload?.account_id) return;
    setAccount(null);
    setReport(null);
  }, [companyId, financialYearId]);

  async function generateReport() {
    if (!account) {
      toast.error("Please select an account first.");
      return;
    }
    if (!financialYearId) {
      toast.error("Please select a financial year first.");
      return;
    }
    setLoading(true);
    try {
      const res = await api.get(`${API.ledger}/report`, {
        params: {
          company_id: companyId,
          financialyear_id: financialYearId,
          account_id: account.id,
          account_code: account.code,
          start_date: startDate,
          end_date: endDate,
        },
      });
      if (res.data?.success) {
        setReport(res.data.data);
      } else {
        toast.error(res.data?.message || "Failed to generate report.");
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || "Could not reach the server. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handlePrint() {
    window.print();
  }

  async function handleExportPdf() {
    if (!printRef.current) return;
    const canvas = await html2canvas(printRef.current, { scale: 2, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth - 40;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 20;

    pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight + 20;
      pdf.addPage();
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    const fileName = `Ledger_${account ? account.name.replace(/\s+/g, "_") : "Account"}_${startDate}_to_${endDate}.pdf`;
    pdf.save(fileName);
  }

  if (!companyId) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] p-8">
        <div className="mx-auto max-w-md rounded-lg border border-[#E6E2D8] bg-white p-8 text-center text-sm text-gray-500 shadow-sm">
          No company context found. Please select a company first.
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF7] p-8 font-sans text-[#1B2430] print:bg-white print:p-0">
      <div className="mb-5 rounded-xl border border-[#E6E2D8] bg-white p-6 shadow-sm print:hidden">
        <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
          Reporting
        </span>
        <h1 className="mb-4 text-2xl font-bold tracking-tight">Account Ledger</h1>

        {!financialYearId && (
          <div className="mb-4 max-w-md rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-600">
            No financial year selected. Accounts are scoped per financial year, so pick one to search parties.
          </div>
        )}

        <div className="flex flex-wrap items-end gap-4">
          <AccountSearch
            companyId={companyId}
            financialYearId={financialYearId}
            value={account}
            onSelect={setAccount}
          />

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Start date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={startDateText}
              onChange={(e) => {
                const v = e.target.value;
                setStartDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setStartDate(displayToIso(v));
              }}
              onBlur={() => setStartDateText(isoToDisplay(startDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">End date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={endDateText}
              onChange={(e) => {
                const v = e.target.value;
                setEndDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setEndDate(displayToIso(v));
              }}
              onBlur={() => setEndDateText(isoToDisplay(endDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <button
            className="rounded-lg bg-[#1B2430] px-5 py-2.5 text-sm font-semibold text-white transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
            onClick={generateReport}
            disabled={loading}
          >
            {loading ? "Generating…" : "Generate"}
          </button>
        </div>

        {report && (
          <div className="mt-4 flex gap-2.5 border-t border-[#E6E2D8] pt-4">
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handlePrint}
            >
              Print
            </button>
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handleExportPdf}
            >
              Export PDF
            </button>
          </div>
        )}
      </div>

      {report && (
        <div
          ref={printRef}
          className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none"
        >
          <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
            <div>
              <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                Ledger Statement
              </span>
              <h2 className="text-2xl font-bold">{account?.name}</h2>
              <span className="mt-1 block font-mono text-xs tabular-nums text-slate-500">
                Account Code: {account?.code}
              </span>
            </div>
            <div className="text-sm font-semibold tabular-nums text-slate-500">
              <span>{isoToDisplay(report.start_date)}</span>
              <span className="mx-2 text-[#B08A2E]">to</span>
              <span>{isoToDisplay(report.end_date)}</span>
            </div>
          </div>

          <div className="mb-5 grid grid-cols-4 gap-3">
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Opening balance
              </span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.opening_balance)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Total debit
              </span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.total_debit)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Total credit
              </span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.total_credit)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#EFE6CE] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Closing balance
              </span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.closing_balance)}</span>
            </div>
          </div>

          <table className="w-full border-collapse text-[13.5px]">
            <thead>
              <tr>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  S.No
                </th>
                <th className="sticky top-0 whitespace-nowrap bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                  Date
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-center text-[11px] font-bold uppercase tracking-wide text-white">
                  Type
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  V.No
                </th>
                <th className="sticky top-0 min-w-[260px] bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                  Narration
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Debit
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Credit
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Balance
                </th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-y border-[#1B2430] bg-[#F3ECD9] font-bold">
                <td colSpan={7} className="px-3 py-2.5 text-center">
                  Opening Balance
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.opening_balance)}</td>
              </tr>
              {report.rows.map((r) => (
                <tr
                  key={r.s_no}
                  className={`${isReturnRow(r.voucher_type) ? 'bg-red-50' : 'odd:bg-white even:bg-[#F4F2EC]'}`}
                  onDoubleClick={() => handleRowDoubleClick(r)}
                  title="Double-click to open this entry"
                >
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">{r.s_no}</td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5">
                    {isoToDisplay(r.date)}
                  </td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5 text-center">
                    <span
                      className={`inline-block min-w-[22px] rounded-full px-2 py-0.5 text-[11px] font-bold text-white ${voucherTypeBadgeClass(r.voucher_type)}`}
                    >
                      {r.voucher_type}
                    </span>
                  </td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {r.voucher_no}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5">
                    {r.narration}
                    {isReturnRow(r.voucher_type) && (
                      <span className="ml-2 inline-block rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-red-700">
                        Return
                      </span>
                    )}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {r.debit ? formatMoney(r.debit) : "0"}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {r.credit ? formatMoney(r.credit) : "0"}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right font-bold tabular-nums">
                    {formatMoney(r.balance)}
                  </td>
                </tr>
              ))}
              <tr className="border-y border-[#1B2430] bg-[#F3ECD9] font-bold">
                <td colSpan={5} className="px-3 py-2.5 text-center">
                  Total Balance
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.total_debit)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.total_credit)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.closing_balance)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}