import React, { useState, useEffect, useRef, useCallback } from "react";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import api from '../../../services/api'

/**
 * Gate Pass Report page — deliberately mirrors Ledger.jsx: same Tailwind
 * palette/classes, same header-card + table layout, same print/export PDF
 * flow. Two modes, switched with a segmented control:
 *
 *   "item"    — Item Movement: pick one item (search box just like the
 *               ledger's AccountSearch, but over ItemDetail), see every
 *               Inward/Outward gate pass line for it in the date range,
 *               merged chronologically with a running weight balance.
 *   "summary" — All Items Summary: no item picked, one row per item that
 *               moved in the date range, with in/out/net totals only
 *               (no running balance — it's a period summary).
 *
 * Backend endpoints (from GatePassReportRoutes.js):
 *   GET /api/gatepass-report/items/search?company_id=&q=
 *   GET /api/gatepass-report/item-report?company_id=&item_code=&department_id=&start_date=&end_date=
 *   GET /api/gatepass-report/summary-report?company_id=&department_id=&start_date=&end_date=
 */

const API = {
  gatepass: "/gatepass-report",
};

// ---------------------------------------------------------------------------
// Date helpers — identical to Ledger.jsx, plain string manipulation only.
// ---------------------------------------------------------------------------
function pad2(n) {
  return String(n).padStart(2, "0");
}

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function monthsAgoISO(months) {
  const d = new Date();
  d.setMonth(d.getMonth() - months);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function isoToDisplay(iso) {
  if (!iso) return "";
  const [y, m, d] = String(iso).slice(0, 10).split("-");
  return `${d}-${m}-${y}`;
}

function displayToIso(display) {
  if (!display) return "";
  const [d, m, y] = display.split("-");
  return `${y}-${pad2(m)}-${pad2(d)}`;
}

function formatMoney(n) {
  const num = Number(n) || 0;
  const abs = Math.abs(num).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return num < 0 ? `(${abs})` : abs;
}

function formatCount(n) {
  return (Number(n) || 0).toLocaleString("en-US");
}

function movementBadgeClass(type) {
  if (type === "IN") return "bg-blue-600";
  if (type === "OUT") return "bg-orange-600";
  return "bg-[#1B2430]";
}

// ---------------------------------------------------------------------------
// Item search combobox — same fetch-then-filter-client-side shape as the
// ledger's AccountSearch, over the /items/search endpoint.
// ---------------------------------------------------------------------------
function ItemSearch({ companyId, value, onSelect }) {
  const [query, setQuery] = useState(value ? value.name : "");
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const boxRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const runSearch = useCallback(
    async (term) => {
      if (!companyId) return;
      setLoading(true);
      try {
        const res = await api.get(`${API.gatepass}/items/search`, {
          params: { company_id: companyId, q: term },
        });
        const results = res.data?.data || [];
        setSuggestions(results);
        setActiveIndex(results.length ? 0 : -1);
      } catch (error) {
        toast.error(error?.response?.data?.message || "Failed to search items");
      } finally {
        setLoading(false);
      }
    },
    [companyId]
  );

  function handleChange(e) {
    const q = e.target.value;
    setQuery(q);
    setOpen(true);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!q.trim()) {
      setSuggestions([]);
      return;
    }
    debounceRef.current = setTimeout(() => runSearch(q), 250);
  }

  function handleFocus(e) {
    setOpen(true);
    if (query.trim()) runSearch(query);
    e.target.select();
  }

  function pick(item) {
    const picked = { code: item.code, name: item.name, unit: item.unit };
    setQuery(picked.name);
    setOpen(false);
    onSelect(picked);
  }

  function handleKeyDown(e) {
    if (!open || suggestions.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => (i + 1) % suggestions.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => (i - 1 + suggestions.length) % suggestions.length);
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (activeIndex >= 0 && suggestions[activeIndex]) pick(suggestions[activeIndex]);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  }

  const disabled = !companyId;

  return (
    <div className="relative flex min-w-[240px] flex-col gap-1.5" ref={boxRef}>
      <label className="text-xs font-semibold text-slate-500">Item</label>
      <input
        className="rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20 disabled:cursor-not-allowed disabled:opacity-60"
        type="text"
        placeholder={disabled ? "Select a company first…" : "Search item name or code…"}
        value={query}
        onChange={handleChange}
        onFocus={handleFocus}
        onKeyDown={handleKeyDown}
        autoComplete="off"
        disabled={disabled}
      />

      {open && loading && (
        <div className="absolute top-full z-30 mt-1 w-full rounded-lg border border-[#E6E2D8] bg-white p-3 text-center text-sm text-slate-500 shadow-lg">
          Searching…
        </div>
      )}

      {open && !loading && query.trim() && suggestions.length > 0 && (
        <ul className="absolute top-full z-30 mt-1 max-h-64 w-full overflow-y-auto rounded-lg border border-[#E6E2D8] bg-white p-1.5 shadow-lg">
          {suggestions.map((item, i) => (
            <li
              key={item.code}
              className={`flex cursor-pointer items-center justify-between gap-3 rounded-md px-2.5 py-2 text-sm ${
                i === activeIndex ? "bg-[#F3ECD9]" : ""
              }`}
              onMouseDown={() => pick(item)}
              onMouseEnter={() => setActiveIndex(i)}
            >
              <span className="text-[#1B2430]">{item.name}</span>
              <span className="font-mono text-xs tabular-nums text-slate-500">{item.code}</span>
            </li>
          ))}
        </ul>
      )}

      {open && !loading && query.trim() && suggestions.length === 0 && (
        <div className="absolute top-full z-30 mt-1 w-full rounded-lg border border-[#E6E2D8] bg-white p-3 text-center text-sm text-slate-500 shadow-lg">
          No items found
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------
export default function GatePassReport() {
  const { companyId: rawCompanyId } = useSelector((state) => state.company);
  const companyId =
    rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== "" ? Number(rawCompanyId) : null;

  const [mode, setMode] = useState("item"); // 'item' | 'summary'
  const [item, setItem] = useState(null);
  const [startDate, setStartDate] = useState(monthsAgoISO(2));
  const [endDate, setEndDate] = useState(todayISO());
  const [startDateText, setStartDateText] = useState(isoToDisplay(monthsAgoISO(2)));
  const [endDateText, setEndDateText] = useState(isoToDisplay(todayISO()));
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const printRef = useRef(null);

  useEffect(() => {
    setItem(null);
    setReport(null);
  }, [companyId, mode]);

  async function generateReport() {
    if (mode === "item" && !item) {
      toast.error("Please select an item first.");
      return;
    }
    if (!companyId) {
      toast.error("No company context found.");
      return;
    }
    setLoading(true);
    try {
      if (mode === "item") {
        const res = await api.get(`${API.gatepass}/item-report`, {
          params: {
            company_id: companyId,
            item_code: item.code,
            start_date: startDate,
            end_date: endDate,
          },
        });
        if (res.data?.success) setReport(res.data.data);
        else toast.error(res.data?.message || "Failed to generate report.");
      } else {
        const res = await api.get(`${API.gatepass}/summary-report`, {
          params: {
            company_id: companyId,
            start_date: startDate,
            end_date: endDate,
          },
        });
        if (res.data?.success) setReport(res.data.data);
        else toast.error(res.data?.message || "Failed to generate report.");
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || "Could not reach the server. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handlePrint() {
    window.print();
  }

  async function handleExportPdf() {
    if (!printRef.current) return;
    const canvas = await html2canvas(printRef.current, { scale: 2, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth - 40;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 20;

    pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight + 20;
      pdf.addPage();
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    const label = mode === "item" ? (item ? item.name.replace(/\s+/g, "_") : "Item") : "AllItems";
    const fileName = `GatePass_${label}_${startDate}_to_${endDate}.pdf`;
    pdf.save(fileName);
  }

  if (!companyId) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] p-8">
        <div className="mx-auto max-w-md rounded-lg border border-[#E6E2D8] bg-white p-8 text-center text-sm text-gray-500 shadow-sm">
          No company context found. Please select a company first.
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF7] p-8 font-sans text-[#1B2430] print:bg-white print:p-0">
      <div className="mb-5 rounded-xl border border-[#E6E2D8] bg-white p-6 shadow-sm print:hidden">
        <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
          Reporting
        </span>
        <h1 className="mb-4 text-2xl font-bold tracking-tight">Gate Pass Report</h1>

        <div className="mb-4 inline-flex rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] p-1">
          <button
            className={`rounded-md px-4 py-2 text-sm font-semibold transition ${
              mode === "item" ? "bg-[#1B2430] text-white" : "text-[#1B2430]"
            }`}
            onClick={() => setMode("item")}
          >
            Item Movement
          </button>
          <button
            className={`rounded-md px-4 py-2 text-sm font-semibold transition ${
              mode === "summary" ? "bg-[#1B2430] text-white" : "text-[#1B2430]"
            }`}
            onClick={() => setMode("summary")}
          >
            All Items Summary
          </button>
        </div>

        <div className="flex flex-wrap items-end gap-4">
          {mode === "item" && <ItemSearch companyId={companyId} value={item} onSelect={setItem} />}

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Start date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={startDateText}
              onChange={(e) => {
                const v = e.target.value;
                setStartDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setStartDate(displayToIso(v));
              }}
              onBlur={() => setStartDateText(isoToDisplay(startDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">End date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={endDateText}
              onChange={(e) => {
                const v = e.target.value;
                setEndDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setEndDate(displayToIso(v));
              }}
              onBlur={() => setEndDateText(isoToDisplay(endDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <button
            className="rounded-lg bg-[#1B2430] px-5 py-2.5 text-sm font-semibold text-white transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
            onClick={generateReport}
            disabled={loading}
          >
            {loading ? "Generating…" : "Generate"}
          </button>
        </div>

        {report && (
          <div className="mt-4 flex gap-2.5 border-t border-[#E6E2D8] pt-4">
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handlePrint}
            >
              Print
            </button>
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handleExportPdf}
            >
              Export PDF
            </button>
          </div>
        )}
      </div>

      {/* -------------------------------------------------------------- */}
      {/* MODE: Item Movement                                             */}
      {/* -------------------------------------------------------------- */}
      {report && mode === "item" && (
        <div
          ref={printRef}
          className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none"
        >
          <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
            <div>
              <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                Gate Pass — Item Movement
              </span>
              <h2 className="text-2xl font-bold">{report.item_name}</h2>
              <span className="mt-1 block font-mono text-xs tabular-nums text-slate-500">
                Item Code: {report.item_code}
              </span>
            </div>
            <div className="text-sm font-semibold tabular-nums text-slate-500">
              <span>{isoToDisplay(report.start_date)}</span>
              <span className="mx-2 text-[#B08A2E]">to</span>
              <span>{isoToDisplay(report.end_date)}</span>
            </div>
          </div>

          <div className="mb-5 grid grid-cols-5 gap-3">
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">In (pcs)</span>
              <span className="text-lg font-bold tabular-nums">{formatCount(report.total_pieces_in)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">In weight</span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.total_weight_in)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Out (pcs)</span>
              <span className="text-lg font-bold tabular-nums">{formatCount(report.total_pieces_out)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Out weight</span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.total_weight_out)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#EFE6CE] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Net weight (in-out)
              </span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.net_weight)}</span>
            </div>
          </div>

          <table className="w-full border-collapse text-[13.5px]">
            <thead>
              <tr>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  S.No
                </th>
                <th className="sticky top-0 whitespace-nowrap bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                  Date
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-center text-[11px] font-bold uppercase tracking-wide text-white">
                  Type
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Gate Pass No
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                  Party
                </th>
                <th className="sticky top-0 min-w-[220px] bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                  Narration
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Pieces
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Weight
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Weight Balance
                </th>
              </tr>
            </thead>
            <tbody>
              {report.rows.map((r) => (
                <tr
                  key={r.s_no}
                  className={`${r.movement_type === "OUT" ? "bg-orange-50" : "odd:bg-white even:bg-[#F4F2EC]"}`}
                >
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">{r.s_no}</td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5">{isoToDisplay(r.date)}</td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5 text-center">
                    <span
                      className={`inline-block min-w-[22px] rounded-full px-2 py-0.5 text-[11px] font-bold text-white ${movementBadgeClass(
                        r.movement_type
                      )}`}
                    >
                      {r.movement_type}
                    </span>
                  </td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {r.voucher_no}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5">{r.party_name}</td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5">{r.narration}</td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {formatCount(r.pieces)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {formatMoney(r.weight)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right font-bold tabular-nums">
                    {formatMoney(r.weight_balance)}
                  </td>
                </tr>
              ))}
              <tr className="border-y border-[#1B2430] bg-[#F3ECD9] font-bold">
                <td colSpan={6} className="px-3 py-2.5 text-center">
                  Totals
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums">
                  {formatCount(report.total_pieces_in)} / {formatCount(report.total_pieces_out)}
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums">
                  {formatMoney(report.total_weight_in)} / {formatMoney(report.total_weight_out)}
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.net_weight)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {/* -------------------------------------------------------------- */}
      {/* MODE: All Items Summary                                         */}
      {/* -------------------------------------------------------------- */}
      {report && mode === "summary" && (
        <div
          ref={printRef}
          className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none"
        >
          <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
            <div>
              <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                Gate Pass — All Items Summary
              </span>
              <h2 className="text-2xl font-bold">Stock Movement</h2>
            </div>
            <div className="text-sm font-semibold tabular-nums text-slate-500">
              <span>{isoToDisplay(report.start_date)}</span>
              <span className="mx-2 text-[#B08A2E]">to</span>
              <span>{isoToDisplay(report.end_date)}</span>
            </div>
          </div>

          <div className="mb-5 grid grid-cols-5 gap-3">
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">In (pcs)</span>
              <span className="text-lg font-bold tabular-nums">{formatCount(report.total_pieces_in)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">In weight</span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.total_weight_in)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Out (pcs)</span>
              <span className="text-lg font-bold tabular-nums">{formatCount(report.total_pieces_out)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Out weight</span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.total_weight_out)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#EFE6CE] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Net weight (in-out)
              </span>
              <span className="text-lg font-bold tabular-nums">{formatMoney(report.net_weight)}</span>
            </div>
          </div>

          <table className="w-full border-collapse text-[13.5px]">
            <thead>
              <tr>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  S.No
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                  Item
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Code
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  In (pcs)
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  In weight
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Out (pcs)
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Out weight
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Net (pcs)
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Net weight
                </th>
              </tr>
            </thead>
            <tbody>
              {report.rows.map((r, idx) => (
                <tr key={r.item_code} className="odd:bg-white even:bg-[#F4F2EC]">
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">{idx + 1}</td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5">{r.item_name}</td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5 text-right font-mono text-xs tabular-nums text-slate-500">
                    {r.item_code}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {formatCount(r.pieces_in)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {formatMoney(r.weight_in)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {formatCount(r.pieces_out)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {formatMoney(r.weight_out)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {formatCount(r.net_pieces)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right font-bold tabular-nums">
                    {formatMoney(r.net_weight)}
                  </td>
                </tr>
              ))}
              <tr className="border-y border-[#1B2430] bg-[#F3ECD9] font-bold">
                <td colSpan={3} className="px-3 py-2.5 text-center">
                  Totals
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatCount(report.total_pieces_in)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.total_weight_in)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatCount(report.total_pieces_out)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.total_weight_out)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatCount(report.net_pieces)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatMoney(report.net_weight)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}