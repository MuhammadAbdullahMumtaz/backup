import React, { useState, useEffect, useRef, useCallback } from "react";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import api from '../../../services/api'

/**
 * Raw Stock report page — styled with Tailwind utility classes only,
 * matching Ledger.jsx / IssuedReport.jsx / ProductionReport.jsx.
 *
 * Item search mirrors AccountSearch in Ledger.jsx:
 *   - company_id comes from Redux (state.company), not localStorage.
 *   - GET /api/raw-stock/items/search?company_id=&q= filters ItemDetail
 *     server-side (LIKE on details/code).
 *
 * Department is an optional filter, loaded once per company via
 *   GET /api/raw-stock/departments?company_id=
 *
 * "Show All Items" panel:
 *   GET /api/raw-stock/items/stock?company_id=&financialyear_id=&department_id=
 *   Lists every item that still has raw (purchased) stock on hand right
 *   now; zero-stock items are excluded server-side.
 *
 * Report endpoint:
 *   GET /api/raw-stock/report?company_id=&financialyear_id=&item_code=
 *       &department_id=&start_date=&end_date=
 *
 * A row here is one PURCHASE LOT (GRN line) for the selected item. Each
 * lot shows what it originally brought in, how much has been drawn off it
 * via Issued / Purchase Return / direct Sales, and what's physically left
 * — reconciled server-side from all three consumers, not just the
 * PurchaseDetail.stocks flag (see RawStockController.js for why).
 */

const API = {
  rawStock: "/raw-stock-report",
};

function pad2(n) {
  return String(n).padStart(2, "0");
}

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function monthsAgoISO(months) {
  const d = new Date();
  d.setMonth(d.getMonth() - months);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function isoToDisplay(iso) {
  if (!iso) return "";
  const [y, m, d] = String(iso).slice(0, 10).split("-");
  return `${d}-${m}-${y}`;
}

function displayToIso(display) {
  if (!display) return "";
  const [d, m, y] = display.split("-");
  return `${y}-${pad2(m)}-${pad2(d)}`;
}

function formatNumber(n) {
  const num = Number(n) || 0;
  return num.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function stockBadgeClass(stocks) {
  return stocks === 'out' ? 'bg-slate-500' : 'bg-emerald-600';
}

// ---------------------------------------------------------------------------
// Item search combobox — same pattern as IssuedReport.jsx / ProductionReport.jsx,
// backed by /raw-stock/items/search.
// ---------------------------------------------------------------------------
function ItemSearch({ companyId, value, onSelect }) {
  const [query, setQuery] = useState(value ? value.name : "");
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const boxRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const runSearch = useCallback(
    async (term) => {
      if (!companyId || !term.trim()) {
        setSuggestions([]);
        return;
      }
      setLoading(true);
      try {
        const res = await api.get(`${API.rawStock}/items/search`, {
          params: { company_id: companyId, q: term },
        });
        const results = res.data?.data || [];
        setSuggestions(results);
        setActiveIndex(results.length ? 0 : -1);
      } catch (error) {
        toast.error(error?.response?.data?.message || "Failed to search items");
      } finally {
        setLoading(false);
      }
    },
    [companyId]
  );

  function handleChange(e) {
    const q = e.target.value;
    setQuery(q);
    setOpen(true);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => runSearch(q), 250);
  }

  function handleFocus(e) {
    setOpen(true);
    if (query.trim()) runSearch(query);
    e.target.select();
  }

  function pick(item) {
    const picked = { code: item.code, name: item.name, unit: item.unit };
    setQuery(picked.name);
    setOpen(false);
    onSelect(picked);
  }

  function handleKeyDown(e) {
    if (!open || suggestions.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => (i + 1) % suggestions.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => (i - 1 + suggestions.length) % suggestions.length);
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (activeIndex >= 0 && suggestions[activeIndex]) pick(suggestions[activeIndex]);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  }

  const disabled = !companyId;

  return (
    <div className="relative flex min-w-[240px] flex-col gap-1.5" ref={boxRef}>
      <label className="text-xs font-semibold text-slate-500">Item</label>
      <input
        className="rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20 disabled:cursor-not-allowed disabled:opacity-60"
        type="text"
        placeholder={disabled ? "No company selected…" : "Search item name or code…"}
        value={query}
        onChange={handleChange}
        onFocus={handleFocus}
        onKeyDown={handleKeyDown}
        autoComplete="off"
        disabled={disabled}
      />

      {open && loading && (
        <div className="absolute top-full z-30 mt-1 w-full rounded-lg border border-[#E6E2D8] bg-white p-3 text-center text-sm text-slate-500 shadow-lg">
          Searching…
        </div>
      )}

      {open && !loading && query.trim() && suggestions.length > 0 && (
        <ul className="absolute top-full z-30 mt-1 max-h-64 w-full overflow-y-auto rounded-lg border border-[#E6E2D8] bg-white p-1.5 shadow-lg">
          {suggestions.map((item, i) => (
            <li
              key={item.code}
              className={`flex cursor-pointer items-center justify-between gap-3 rounded-md px-2.5 py-2 text-sm ${i === activeIndex ? "bg-[#F3ECD9]" : ""
                }`}
              onMouseDown={() => pick(item)}
              onMouseEnter={() => setActiveIndex(i)}
            >
              <span className="text-[#1B2430]">{item.name}</span>
              <span className="font-mono text-xs tabular-nums text-slate-500">{item.code}</span>
            </li>
          ))}
        </ul>
      )}

      {open && !loading && query.trim() && suggestions.length === 0 && (
        <div className="absolute top-full z-30 mt-1 w-full rounded-lg border border-[#E6E2D8] bg-white p-3 text-center text-sm text-slate-500 shadow-lg">
          No items found
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------
export default function RawStockReport({ onNavigate }) {
  const { companyId: rawCompanyId, financialYearId: rawFinancialYearId } = useSelector(
    (state) => state.company
  );
  const companyId =
    rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== "" ? Number(rawCompanyId) : null;
  const financialYearId =
    rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ""
      ? Number(rawFinancialYearId)
      : null;

  const [item, setItem] = useState(null);
  const [departments, setDepartments] = useState([]);
  const [departmentId, setDepartmentId] = useState("");
  const [startDate, setStartDate] = useState(monthsAgoISO(2));
  const [endDate, setEndDate] = useState(todayISO());
  const [startDateText, setStartDateText] = useState(isoToDisplay(monthsAgoISO(2)));
  const [endDateText, setEndDateText] = useState(isoToDisplay(todayISO()));
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  // "Show All Items" panel — every item that still has raw (purchased)
  // stock on hand right now, zero-stock items excluded server-side.
  const [showAllItems, setShowAllItems] = useState(false);
  const [stockItems, setStockItems] = useState([]);
  const [stockLoading, setStockLoading] = useState(false);
  const [stockLoaded, setStockLoaded] = useState(false);

  const printRef = useRef(null);

  useEffect(() => {
    setItem(null);
    setReport(null);
    setDepartmentId("");
    setShowAllItems(false);
    setStockItems([]);
    setStockLoaded(false);
    if (!companyId) {
      setDepartments([]);
      return;
    }
    (async () => {
      try {
        const res = await api.get(`${API.rawStock}/departments`, { params: { company_id: companyId } });
        setDepartments(res.data?.data || []);
      } catch (error) {
        toast.error(error?.response?.data?.message || "Failed to load departments");
      }
    })();
  }, [companyId]);

  // Department filter changes which items count as "in stock", so the
  // cached list is invalidated whenever it changes.
  useEffect(() => {
    setStockLoaded(false);
    setStockItems([]);
  }, [departmentId]);

  async function loadStockSummary() {
    if (!financialYearId) {
      toast.error("Please select a financial year first.");
      return;
    }
    setStockLoading(true);
    try {
      const res = await api.get(`${API.rawStock}/items/stock`, {
        params: {
          company_id: companyId,
          financialyear_id: financialYearId,
          department_id: departmentId || undefined,
        },
      });
      setStockItems(res.data?.data || []);
      setStockLoaded(true);
    } catch (error) {
      toast.error(error?.response?.data?.message || "Failed to load stock summary");
    } finally {
      setStockLoading(false);
    }
  }

  function handleToggleAllItems() {
    const next = !showAllItems;
    setShowAllItems(next);
    if (next && !stockLoaded) loadStockSummary();
  }

  async function handleStockItemSelect(stockItem) {
    const picked = { code: stockItem.code, name: stockItem.name, unit: stockItem.unit };
    setItem(picked);
    setShowAllItems(false);
    await generateReport(picked);
  }

  function handleRowDoubleClick(row) {
    if (!onNavigate) return;
    onNavigate('purchase-entry', { grn_no: row.doc_no, mode: 'purchase' });
  }

  async function generateReport(itemOverride) {
    const activeItem = itemOverride || item;
    if (!activeItem) {
      toast.error("Please select an item first.");
      return;
    }
    if (!financialYearId) {
      toast.error("Please select a financial year first.");
      return;
    }
    setLoading(true);
    try {
      const res = await api.get(`${API.rawStock}/report`, {
        params: {
          company_id: companyId,
          financialyear_id: financialYearId,
          item_code: activeItem.code,
          department_id: departmentId || undefined,
          start_date: startDate,
          end_date: endDate,
        },
      });
      if (res.data?.success) {
        setReport(res.data.data);
      } else {
        toast.error(res.data?.message || "Failed to generate report.");
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || "Could not reach the server. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handlePrint() {
    window.print();
  }

  async function handleExportPdf() {
    if (!printRef.current) return;
    const canvas = await html2canvas(printRef.current, { scale: 2, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth - 40;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 20;

    pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight + 20;
      pdf.addPage();
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    const fileName = `RawStock_${item ? item.name.replace(/\s+/g, "_") : "Item"}_${startDate}_to_${endDate}.pdf`;
    pdf.save(fileName);
  }

  if (!companyId) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] p-8">
        <div className="mx-auto max-w-md rounded-lg border border-[#E6E2D8] bg-white p-8 text-center text-sm text-gray-500 shadow-sm">
          No company context found. Please select a company first.
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF7] p-8 font-sans text-[#1B2430] print:bg-white print:p-0">
      <div className="mb-5 rounded-xl border border-[#E6E2D8] bg-white p-6 shadow-sm print:hidden">
        <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
          Reporting
        </span>
        <h1 className="mb-4 text-2xl font-bold tracking-tight">Raw Stock Report</h1>

        {!financialYearId && (
          <div className="mb-4 max-w-md rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-600">
            No financial year selected. Please pick one to generate a report.
          </div>
        )}

        <div className="flex flex-wrap items-end gap-4">
          <ItemSearch companyId={companyId} value={item} onSelect={setItem} />

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Department</label>
            <select
              className="w-48 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              value={departmentId}
              onChange={(e) => setDepartmentId(e.target.value)}
            >
              <option value="">All departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.department_name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Start date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={startDateText}
              onChange={(e) => {
                const v = e.target.value;
                setStartDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setStartDate(displayToIso(v));
              }}
              onBlur={() => setStartDateText(isoToDisplay(startDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">End date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20"
              type="text"
              value={endDateText}
              onChange={(e) => {
                const v = e.target.value;
                setEndDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setEndDate(displayToIso(v));
              }}
              onBlur={() => setEndDateText(isoToDisplay(endDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <button
            className="rounded-lg bg-[#1B2430] px-5 py-2.5 text-sm font-semibold text-white transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
            onClick={() => generateReport()}
            disabled={loading}
          >
            {loading ? "Generating…" : "Generate"}
          </button>

          <button
            className="rounded-lg border border-[#B08A2E] bg-white px-5 py-2.5 text-sm font-semibold text-[#B08A2E] transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
            onClick={handleToggleAllItems}
            disabled={!financialYearId}
          >
            {showAllItems ? "Hide All Items" : "Show All Items"}
          </button>
        </div>

        {showAllItems && (
          <div className="mt-4 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7]">
            <div className="flex items-center justify-between border-b border-[#E6E2D8] px-4 py-2.5">
              <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                Items currently holding raw stock{departmentId
                  ? ` — ${departments.find((d) => String(d.id) === String(departmentId))?.department_name || ""}`
                  : ""}
              </span>
              <button
                className="text-xs font-semibold text-slate-500 hover:text-[#1B2430]"
                onClick={() => setShowAllItems(false)}
              >
                Close
              </button>
            </div>

            {stockLoading && (
              <div className="px-4 py-6 text-center text-sm text-slate-500">Loading stock…</div>
            )}

            {!stockLoading && stockItems.length === 0 && (
              <div className="px-4 py-6 text-center text-sm text-slate-500">
                No items currently have raw stock on hand.
              </div>
            )}

            {!stockLoading && stockItems.length > 0 && (
              <div className="max-h-80 overflow-y-auto">
                <table className="w-full border-collapse text-sm">
                  <thead>
                    <tr className="bg-[#F4F2EC] text-left text-[11px] font-bold uppercase tracking-wide text-slate-500">
                      <th className="px-4 py-2">Item</th>
                      <th className="px-4 py-2 text-right">Code</th>
                      <th className="px-4 py-2 text-right">Pieces</th>
                      <th className="px-4 py-2 text-right">Net Wt</th>
                      <th className="px-4 py-2"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {stockItems.map((si) => (
                      <tr
                        key={si.code}
                        className="cursor-pointer odd:bg-white even:bg-[#F4F2EC] hover:bg-[#F3ECD9]"
                        onClick={() => handleStockItemSelect(si)}
                      >
                        <td className="px-4 py-2">{si.name}</td>
                        <td className="px-4 py-2 text-right font-mono text-xs tabular-nums text-slate-500">
                          {si.code}
                        </td>
                        <td className="px-4 py-2 text-right tabular-nums">{si.pieces}</td>
                        <td className="px-4 py-2 text-right tabular-nums">{formatNumber(si.net_weight)}</td>
                        <td className="px-4 py-2 text-right text-xs font-semibold text-[#B08A2E]">View lots →</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {report && (
          <div className="mt-4 flex gap-2.5 border-t border-[#E6E2D8] pt-4">
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handlePrint}
            >
              Print
            </button>
            <button
              className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px"
              onClick={handleExportPdf}
            >
              Export PDF
            </button>
          </div>
        )}
      </div>

      {report && (
        <div
          ref={printRef}
          className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none"
        >
          <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
            <div>
              <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                Raw Stock Statement
              </span>
              <h2 className="text-2xl font-bold">{item?.name}</h2>
              <span className="mt-1 block font-mono text-xs tabular-nums text-slate-500">
                Item Code: {item?.code}
                {departmentId && departments.find((d) => String(d.id) === String(departmentId))
                  ? ` • ${departments.find((d) => String(d.id) === String(departmentId)).department_name}`
                  : ""}
              </span>
            </div>
            <div className="text-sm font-semibold tabular-nums text-slate-500">
              <span>{isoToDisplay(report.start_date)}</span>
              <span className="mx-2 text-[#B08A2E]">to</span>
              <span>{isoToDisplay(report.end_date)}</span>
            </div>
          </div>

          <div className="mb-5 grid grid-cols-4 gap-3">
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Opening stock (net wt)
              </span>
              <span className="text-lg font-bold tabular-nums">{formatNumber(report.opening_net_weight)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Period pieces (lots)
              </span>
              <span className="text-lg font-bold tabular-nums">{report.total_pieces}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#F4F2EC] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Period remaining (net wt)
              </span>
              <span className="text-lg font-bold tabular-nums">{formatNumber(report.total_net_weight)}</span>
            </div>
            <div className="flex flex-col gap-1 rounded-lg bg-[#EFE6CE] px-3.5 py-3">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Closing stock (net wt)
              </span>
              <span className="text-lg font-bold tabular-nums">{formatNumber(report.closing_net_weight)}</span>
            </div>
          </div>

          <table className="w-full border-collapse text-[13.5px]">
            <thead>
              <tr>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  S.No
                </th>
                <th className="sticky top-0 whitespace-nowrap bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                  Date
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  GRN No
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white">
                  Department
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Purchased
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Issued
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Returned
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Sold
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Remaining
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-right text-[11px] font-bold uppercase tracking-wide text-white">
                  Running
                </th>
                <th className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-center text-[11px] font-bold uppercase tracking-wide text-white">
                  Status
                </th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-y border-[#1B2430] bg-[#F3ECD9] font-bold">
                <td colSpan={8} className="px-3 py-2.5 text-center">
                  Opening Stock
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatNumber(report.opening_net_weight)}</td>
                <td colSpan={2} />
              </tr>
              {report.rows.map((r) => (
                <tr
                  key={r.s_no}
                  className="odd:bg-white even:bg-[#F4F2EC]"
                  onDoubleClick={() => handleRowDoubleClick(r)}
                  title="Double-click to open this GRN"
                >
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">{r.s_no}</td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5">
                    {isoToDisplay(r.date)}
                  </td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {r.doc_no}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5">{r.department_name}</td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums">
                    {formatNumber(r.net_weight)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums text-slate-500">
                    {formatNumber(r.issued_weight)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums text-slate-500">
                    {formatNumber(r.returned_weight)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right tabular-nums text-slate-500">
                    {formatNumber(r.sold_weight)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right font-semibold tabular-nums">
                    {formatNumber(r.remaining_net_weight)}
                  </td>
                  <td className="border-b border-[#E6E2D8] px-3 py-2.5 text-right font-bold tabular-nums">
                    {formatNumber(r.running_net_weight)}
                  </td>
                  <td className="whitespace-nowrap border-b border-[#E6E2D8] px-3 py-2.5 text-center">
                    <span
                      className={`inline-block min-w-[22px] rounded-full px-2 py-0.5 text-[11px] font-bold text-white ${stockBadgeClass(r.stocks)}`}
                    >
                      {r.stocks}
                    </span>
                  </td>
                </tr>
              ))}
              <tr className="border-y border-[#1B2430] bg-[#F3ECD9] font-bold">
                <td colSpan={7} className="px-3 py-2.5 text-center">
                  Total
                </td>
                <td />
                <td className="px-3 py-2.5 text-right tabular-nums">{formatNumber(report.total_net_weight)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatNumber(report.closing_net_weight)}</td>
                <td />
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}