import React, { useState, useEffect, useMemo, useRef } from 'react';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';
import api from '../../../services/api';

const DOC_TYPE_OPTIONS = [
    { value: 'voucher', label: 'Voucher' },
    { value: 'purchase', label: 'Purchase' },
    { value: 'purchasereturn', label: 'Purchase Return' },
    { value: 'sales', label: 'Sales' },
    { value: 'salesreturn', label: 'Sales Return' },
];

const isoToDisplayDate = (iso) => {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    if (!y || !m || !d) return '';
    return `${d}-${m}-${y}`;
};
const displayDateToIso = (display) => {
    if (!display) return '';
    const parts = display.split('-');
    if (parts.length !== 3) return '';
    const [d, m, y] = parts;
    if (!d || !m || !y || y.length !== 4) return '';
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
};
const todayStr = () => new Date().toISOString().slice(0, 10);

// Generic checkbox multi-select dropdown - used for both Users and Doc Types.
const MultiSelectDropdown = ({ label, options, valueKey, labelKey, selected, onChange, disabled, placeholder }) => {
    const [open, setOpen] = useState(false);
    const ref = useRef(null);

    useEffect(() => {
        const handler = (e) => {
            if (ref.current && !ref.current.contains(e.target)) setOpen(false);
        };
        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, []);

    const toggleOption = (val) => {
        if (selected.includes(val)) {
            onChange(selected.filter((v) => v !== val));
        } else {
            onChange([...selected, val]);
        }
    };

    const summaryText = disabled
        ? (options.find((o) => String(o[valueKey]) === String(selected[0])) || {})[labelKey] || placeholder
        : selected.length === 0
            ? placeholder
            : selected.length === options.length
                ? 'All selected'
                : `${selected.length} selected`;

    return (
        <div ref={ref} className="relative">
            <label className="block text-xs font-medium text-gray-600 mb-0.5">{label}</label>
            <button
                type="button"
                onClick={() => !disabled && setOpen((o) => !o)}
                disabled={disabled}
                className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm text-left bg-white focus:ring-2 focus:ring-blue-400 disabled:bg-gray-100 disabled:text-gray-500"
            >
                {summaryText}
            </button>
            {open && !disabled && (
                <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-56 overflow-y-auto z-20">
                    {options.map((opt) => {
                        const val = String(opt[valueKey]);
                        const checked = selected.includes(val);
                        return (
                            <label
                                key={val}
                                className="flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-blue-50 cursor-pointer"
                            >
                                <input
                                    type="checkbox"
                                    checked={checked}
                                    onChange={() => toggleOption(val)}
                                />
                                {opt[labelKey]}
                            </label>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

const DOC_TYPE_LABELS = {
    voucher: 'Voucher',
    purchase: 'Purchase',
    purchasereturn: 'Purchase Return',
    sales: 'Sales',
    salesreturn: 'Sales Return',
};

function UserEntriesReport({ onBack }) {
    const {
        companyId: rawCompanyId,
        financialYearId: rawFinancialYearId,
        user,
    } = useSelector((state) => state.company);

    const companyId = rawCompanyId ? Number(rawCompanyId) : null;
    const financialYearId = rawFinancialYearId ? Number(rawFinancialYearId) : null;
    const isAdmin = user?.role === 'Admin';
    const currentUsername = user?.username || user?.name || '';

    const [companyUsers, setCompanyUsers] = useState([]);
    const [selectedUsernames, setSelectedUsernames] = useState(isAdmin ? [] : [currentUsername]);
    const [selectedDocTypes, setSelectedDocTypes] = useState([]);
    const [startDate, setStartDate] = useState(isoToDisplayDate(todayStr()));
    const [endDate, setEndDate] = useState(isoToDisplayDate(todayStr()));

    const [isLoadingUsers, setIsLoadingUsers] = useState(false);
    const [isGenerating, setIsGenerating] = useState(false);
    const [report, setReport] = useState(null); // { summary, entries }

    useEffect(() => {
        if (!companyId || !isAdmin) return;
        setIsLoadingUsers(true);
        api.get(`/user-entries-report/users/${companyId}`)
            .then((res) => setCompanyUsers(Array.isArray(res.data) ? res.data : []))
            .catch(() => toast.error('Failed to load users'))
            .finally(() => setIsLoadingUsers(false));
    }, [companyId, isAdmin]);

    const userOptions = useMemo(
        () => companyUsers.map((u) => ({ username: u.username, label: `${u.username} (${u.role})` })),
        [companyUsers]
    );

    const handleGenerate = async (e) => {
        e.preventDefault();
        if (!companyId) {
            toast.error('No company context found');
            return;
        }
        if (isAdmin && selectedUsernames.length === 0) {
            toast.error('Select at least one user');
            return;
        }
        if (selectedDocTypes.length === 0) {
            toast.error('Select at least one document type');
            return;
        }
        const startIso = displayDateToIso(startDate);
        const endIso = displayDateToIso(endDate);
        if (!startIso || !endIso) {
            toast.error('Dates must be in dd-mm-yyyy format');
            return;
        }
        if (startIso > endIso) {
            toast.error('Start date must be before end date');
            return;
        }

        setIsGenerating(true);
        try {
            const res = await api.post('/user-entries-report/entries', {
                company_id: companyId,
                financialyear_id: financialYearId, // omit/send null to cover all years
                requested_by: currentUsername,
                role: user?.role,
                usernames: isAdmin ? selectedUsernames : [currentUsername],
                start_date: startIso,
                end_date: endIso,
                doc_types: selectedDocTypes,
            });
            setReport(res.data);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to generate report');
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className="bg-gray-50 p-4">
            {onBack && (
                <button
                    type="button"
                    onClick={onBack}
                    className="mb-2 flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700"
                >
                    ← Back
                </button>
            )}
            <h1 className="text-xl font-bold text-gray-800 mb-3">User Entries Report</h1>

            <div className="max-w-5xl mx-auto bg-white rounded-xl shadow-sm border border-gray-200 p-4">
                <form onSubmit={handleGenerate} className="grid grid-cols-2 sm:grid-cols-4 gap-3 items-end mb-4">
                    <MultiSelectDropdown
                        label="User"
                        options={isAdmin ? userOptions : [{ username: currentUsername, label: currentUsername }]}
                        valueKey="username"
                        labelKey="label"
                        selected={isAdmin ? selectedUsernames : [currentUsername]}
                        onChange={setSelectedUsernames}
                        disabled={!isAdmin || isLoadingUsers}
                        placeholder={isLoadingUsers ? 'Loading...' : 'Select user(s)'}
                    />

                    <div>
                        <label className="block text-xs font-medium text-gray-600 mb-0.5">Start Date</label>
                        <input
                            type="text"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                            placeholder="dd-mm-yyyy"
                            className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400"
                        />
                    </div>

                    <div>
                        <label className="block text-xs font-medium text-gray-600 mb-0.5">End Date</label>
                        <input
                            type="text"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                            placeholder="dd-mm-yyyy"
                            className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400"
                        />
                    </div>

                    <MultiSelectDropdown
                        label="Document Type"
                        options={DOC_TYPE_OPTIONS}
                        valueKey="value"
                        labelKey="label"
                        selected={selectedDocTypes}
                        onChange={setSelectedDocTypes}
                        placeholder="Select type(s)"
                    />

                    <div className="col-span-2 sm:col-span-4 flex justify-end">
                        <button
                            type="submit"
                            disabled={isGenerating}
                            className="px-5 py-1.5 bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium rounded-md disabled:opacity-60"
                        >
                            {isGenerating ? 'Generating...' : 'Generate Report'}
                        </button>
                    </div>
                </form>

                {report && (
                    <>
                        <div className="border-t border-gray-200 pt-3 mb-4">
                            <h3 className="text-sm font-semibold text-gray-700 mb-2">Summary</h3>
                            {report.summary.length === 0 ? (
                                <div className="text-xs text-gray-400 py-2 text-center">No entries found for this selection.</div>
                            ) : (
                                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                                        <thead className="bg-gray-50">
                                            <tr>
                                                <th className="px-3 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">User</th>
                                                <th className="px-3 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Document Type</th>
                                                <th className="px-3 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Count</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-100">
                                            {report.summary.map((row, i) => (
                                                <tr key={i}>
                                                    <td className="px-3 py-1.5">{row.username}</td>
                                                    <td className="px-3 py-1.5">{DOC_TYPE_LABELS[row.doc_type] || row.doc_type}</td>
                                                    <td className="px-3 py-1.5 text-right font-semibold">{row.count}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>

                        <div className="border-t border-gray-200 pt-3">
                            <h3 className="text-sm font-semibold text-gray-700 mb-2">
                                Entries ({report.entries.length})
                            </h3>
                            {report.entries.length === 0 ? (
                                <div className="text-xs text-gray-400 py-2 text-center">No entries.</div>
                            ) : (
                                <div className="overflow-x-auto border border-gray-200 rounded-lg max-h-96 overflow-y-auto">
                                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                                        <thead className="bg-gray-50 sticky top-0">
                                            <tr>
                                                <th className="px-3 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Type</th>
                                                <th className="px-3 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Doc No</th>
                                                <th className="px-3 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Date</th>
                                                <th className="px-3 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Party</th>
                                                <th className="px-3 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Amount</th>
                                                <th className="px-3 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Entered By</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-100">
                                            {report.entries.map((row) => (
                                                <tr key={`${row.doc_type}-${row.id}`} className="hover:bg-gray-50">
                                                    <td className="px-3 py-1.5">{DOC_TYPE_LABELS[row.doc_type] || row.doc_type}</td>
                                                    <td className="px-3 py-1.5 font-mono">{row.document_no}</td>
                                                    <td className="px-3 py-1.5">{isoToDisplayDate(row.document_date)}</td>
                                                    <td className="px-3 py-1.5">{row.party_name || '-'}</td>
                                                    <td className="px-3 py-1.5 text-right">
                                                        {row.amount !== null ? Number(row.amount).toFixed(2) : '-'}
                                                    </td>
                                                    <td className="px-3 py-1.5">{row.created_by || 'Unknown'}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}

export default UserEntriesReport;