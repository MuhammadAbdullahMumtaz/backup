import React, { useState, useEffect, useRef, useCallback } from "react";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { ChevronDown, ChevronRight } from "lucide-react";
import api from "../../../services/api";

/**
 * Stock Report page — three views on the same opening / current-period /
 * closing pattern used by Ledger.jsx and TrialBalance.jsx:
 *
 *   1. Item Wise   -> flat list, one row per item
 *   2. Account Wise-> items grouped under the GL (Chart of Account) code
 *                     recorded on their SubItem (GL_purchase)
 *   3. Stock Mgmt  -> MainItem -> SubItem -> ItemDetail drill-down, same
 *                     shape as Trial Balance's BalanceSheet -> MainCode ->
 *                     SubCode -> ChartOfAccount, but for physical stock.
 *
 * Every column set is the same everywhere: Opening / In / Out / Closing,
 * each broken into Pieces, Weight and Amount.
 *
 * Endpoints (see StockReportRoutes.js):
 *   GET /api/stock-report/financial-year?company_id=&financialyear_id=
 *   GET /api/stock-report/item-wise?company_id=&financialyear_id=&start_date=&end_date=
 *   GET /api/stock-report/account-wise?company_id=&financialyear_id=&start_date=&end_date=
 *   GET /api/stock-report/management?company_id=&financialyear_id=&start_date=&end_date=
 */

const API = { stockReport: "/stock-report" };

const TABS = [
  { key: "item", label: "Item Wise" },
  { key: "account", label: "Account Wise" },
  { key: "management", label: "General Stock" },
];

// ---------------------------------------------------------------------------
// Date helpers — same plain string manipulation as Ledger.jsx / TrialBalance.jsx
// so no timezone shift ever touches a date.
// ---------------------------------------------------------------------------
function pad2(n) {
  return String(n).padStart(2, "0");
}
function isoToDisplay(iso) {
  if (!iso) return "";
  const [y, m, d] = String(iso).slice(0, 10).split("-");
  return `${d}-${m}-${y}`;
}
function displayToIso(display) {
  if (!display) return "";
  const [d, m, y] = display.split("-");
  return `${y}-${pad2(m)}-${pad2(d)}`;
}
function formatMoney(v) {
  const num = Number(v) || 0;
  if (num === 0) return "0";
  const abs = Math.abs(num).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return num < 0 ? `(${abs})` : abs;
}
function formatQty(v) {
  const num = Number(v) || 0;
  if (num === 0) return "0";
  const abs = Math.abs(num).toLocaleString("en-US", { maximumFractionDigits: 0 });
  return num < 0 ? `(${abs})` : abs;
}

// ---------------------------------------------------------------------------
// Shared numeric-column header — Pieces / Weight / Amount under each of
// Opening / In / Out / Closing.
// ---------------------------------------------------------------------------
function StockTableHead({ labelColSpan = 2 }) {
  const group = (title) => (
    <th
      colSpan={3}
      className="sticky top-0 border-l border-white/20 bg-[#1B2430] px-3 py-2.5 text-center text-[11px] font-bold uppercase tracking-wide text-white"
    >
      {title}
    </th>
  );
  const sub = (label) => (
    <th className="sticky top-0 bg-[#293241] px-3 py-1.5 text-right text-[10.5px] font-semibold uppercase text-white/80">
      {label}
    </th>
  );
  return (
    <thead>
      <tr>
        <th
          colSpan={labelColSpan}
          className="sticky top-0 bg-[#1B2430] px-3 py-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-white"
        >
          Description
        </th>
        {group("Opening stock")}
        {group("Received (In)")}
        {group("Issued (Out)")}
        {group("Closing stock")}
      </tr>
      <tr>
        {Array.from({ length: labelColSpan }).map((_, i) => (
          <th key={i} className="sticky top-0 bg-[#293241] px-3 py-1.5" />
        ))}
        {sub("Pcs")}{sub("Weight")}{sub("Amount")}
        {sub("Pcs")}{sub("Weight")}{sub("Amount")}
        {sub("Pcs")}{sub("Weight")}{sub("Amount")}
        {sub("Pcs")}{sub("Weight")}{sub("Amount")}
      </tr>
    </thead>
  );
}

function StockNumberCells({ stat }) {
  return (
    <>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatQty(stat.opening_pieces)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(stat.opening_weight)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(stat.opening_amount)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatQty(stat.in_pieces)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(stat.in_weight)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(stat.in_amount)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatQty(stat.out_pieces)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(stat.out_weight)}</td>
      <td className="px-3 py-1.5 text-right tabular-nums">{formatMoney(stat.out_amount)}</td>
      <td className="px-3 py-1.5 text-right font-semibold tabular-nums">{formatQty(stat.closing_pieces)}</td>
      <td className="px-3 py-1.5 text-right font-semibold tabular-nums">{formatMoney(stat.closing_weight)}</td>
      <td className="px-3 py-1.5 text-right font-semibold tabular-nums">{formatMoney(stat.closing_amount)}</td>
    </>
  );
}

function GroupHeaderRow({ level, code, details, isOpen, onToggle, colSpan }) {
  const styles = {
    1: "bg-[#1B2430] text-white text-[13px] font-bold uppercase tracking-wide",
    2: "bg-[#33404F] text-white text-[12.5px] font-semibold",
  };
  const paddingLeft = { 1: "pl-3", 2: "pl-8" };
  return (
    <tr className={`${styles[level]} print:break-inside-avoid`}>
      <td colSpan={colSpan} className={`px-3 py-2 ${paddingLeft[level]}`}>
        <button type="button" onClick={onToggle} className="flex items-center gap-1.5 print:pointer-events-none">
          {isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          {code ? <span className="font-mono tabular-nums">{code}</span> : null}
          <span>{details}</span>
        </button>
      </td>
    </tr>
  );
}

function GroupTotalRow({ label, totals, emphasise }) {
  return (
    <tr
      className={`border-y font-bold ${emphasise ? "border-[#1B2430] bg-[#EFE6CE] text-[13px]" : "border-[#E6E2D8] bg-[#F4F2EC] text-[12.5px]"
        }`}
    >
      <td className="px-3 py-1.5 text-right italic text-slate-500" colSpan={2}>{label}</td>
      <StockNumberCells stat={totals} />
    </tr>
  );
}

function ItemLeafRow({ item, colSpanLabel = 2, indent = "pl-14", onDoubleClick }) {
  return (
    <tr
      className="odd:bg-white even:bg-[#FAFAF7] text-[13px] cursor-pointer"
      onDoubleClick={onDoubleClick}
      title={onDoubleClick ? "Double-click to see item movements" : undefined}
    >
      <td className={`border-b border-[#E6E2D8] px-3 py-1.5 ${indent} font-mono text-xs tabular-nums text-slate-500`}>
        {item.item_code || item.code}
      </td>
      <td className="border-b border-[#E6E2D8] px-3 py-1.5">{item.item_name || item.details}</td>
      {colSpanLabel === 1 ? null : null}
      {["opening_pieces","opening_weight","opening_amount","in_pieces","in_weight","in_amount",
        "out_pieces","out_weight","out_amount","closing_pieces","closing_weight","closing_amount"]
        .map((k, i) => {
          const isMoney = k.endsWith("weight") || k.endsWith("amount");
          const isClosing = k.startsWith("closing");
          const val = isMoney ? formatMoney(item[k]) : formatQty(item[k]);
          return (
            <td key={k} className={`border-b border-[#E6E2D8] px-3 py-1.5 text-right tabular-nums ${isClosing ? "font-semibold" : ""}`}>
              {val}
            </td>
          );
        })}
    </tr>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------
export default function StockReport({ onNavigate }) {
  const { companyId: rawCompanyId, financialYearId: rawFinancialYearId } = useSelector((state) => state.company);
  const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== "" ? Number(rawCompanyId) : null;
  const financialYearId =
    rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== "" ? Number(rawFinancialYearId) : null;

  const [activeTab, setActiveTab] = useState("item");

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [startDateText, setStartDateText] = useState("");
  const [endDateText, setEndDateText] = useState("");

  const [report, setReport] = useState(null); // holds whichever report's data is currently generated
  const [reportTab, setReportTab] = useState(null); // which tab the current `report` belongs to
  const [loading, setLoading] = useState(false);
  const [fyLoading, setFyLoading] = useState(false);

  const [collapsed, setCollapsed] = useState(() => new Set());

  const printRef = useRef(null);

  useEffect(() => {
    setReport(null);
    setReportTab(null);
    setCollapsed(new Set());

    if (!companyId || !financialYearId) {
      setStartDate(""); setEndDate(""); setStartDateText(""); setEndDateText("");
      return;
    }

    let cancelled = false;
    setFyLoading(true);
    api
      .get(`${API.stockReport}/financial-year`, { params: { company_id: companyId, financialyear_id: financialYearId } })
      .then((res) => {
        if (cancelled) return;
        const fy = res.data?.data;
        if (fy) {
          setStartDate(fy.start_date);
          setEndDate(fy.end_date);
          setStartDateText(isoToDisplay(fy.start_date));
          setEndDateText(isoToDisplay(fy.end_date));
        }
      })
      .catch((error) => {
        if (!cancelled) toast.error(error?.response?.data?.message || "Failed to load financial year dates");
      })
      .finally(() => { if (!cancelled) setFyLoading(false); });

    return () => { cancelled = true; };
  }, [companyId, financialYearId]);

  // Switching tabs clears a report generated for a different tab, so users
  // don't see stale data rendered under the wrong headings.
  function handleTabChange(tab) {
    setActiveTab(tab);
    if (reportTab && reportTab !== tab) {
      setReport(null);
      setReportTab(null);
      setCollapsed(new Set());
    }
  }

  async function generateReport() {
    if (!financialYearId) { toast.error("Please select a financial year first."); return; }
    if (!startDate || !endDate) { toast.error("Please choose a start and end date."); return; }

    const endpointByTab = { item: "item-wise", account: "account-wise", management: "management" };

    setLoading(true);
    try {
      const res = await api.get(`${API.stockReport}/${endpointByTab[activeTab]}`, {
        params: { company_id: companyId, financialyear_id: financialYearId, start_date: startDate, end_date: endDate },
      });
      if (res.data?.success) {
        setReport(res.data.data);
        setReportTab(activeTab);
        setCollapsed(new Set());
      } else {
        toast.error(res.data?.message || "Failed to generate stock report.");
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || "Could not reach the server. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function handleItemDoubleClick(item) {
    if (!onNavigate || !report) return;
    onNavigate("item-ledger", {
      item_code: item.item_code || item.code,
      item_name: item.item_name || item.details,
      start_date: report.start_date,
      end_date: report.end_date,
    });
  }

  const toggle = useCallback((key) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  }, []);

  function expandAll() { setCollapsed(new Set()); }

  function collapseAll() {
    if (!report) return;
    const keys = new Set();
    if (reportTab === "account") {
      report.accounts.forEach((a) => keys.add(`acc-${a.account_code || "UNASSIGNED"}`));
    } else if (reportTab === "management") {
      report.mainitems.forEach((mi) => {
        keys.add(`mi-${mi.id}`);
        mi.subitems.forEach((si) => keys.add(`si-${si.id}`));
      });
    }
    setCollapsed(keys);
  }

  function handlePrint() { window.print(); }

  async function handleExportPdf() {
    if (!printRef.current) return;
    const canvas = await html2canvas(printRef.current, { scale: 2, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth - 40;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 20;
    pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
    while (heightLeft > 0) {
      position = heightLeft - imgHeight + 20;
      pdf.addPage();
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    const tabLabel = TABS.find((t) => t.key === reportTab)?.label || "Stock_Report";
    pdf.save(`${tabLabel.replace(/\s+/g, "_")}_${startDate}_to_${endDate}.pdf`);
  }

  if (!companyId) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] p-8">
        <div className="mx-auto max-w-md rounded-lg border border-[#E6E2D8] bg-white p-8 text-center text-sm text-gray-500 shadow-sm">
          No company context found. Please select a company first.
        </div>
      </div>
    );
  }

  const showingReport = report && reportTab === activeTab;

  return (
    <div className="min-h-screen bg-[#FAFAF7] p-8 font-sans text-[#1B2430] print:bg-white print:p-0">
      <div className="mb-5 rounded-xl border border-[#E6E2D8] bg-white p-6 shadow-sm print:hidden">
        <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
          Reporting
        </span>
        <h1 className="mb-4 text-2xl font-bold tracking-tight">Stock Report</h1>

        <div className="mb-4 flex gap-2 border-b border-[#E6E2D8]">
          {TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => handleTabChange(t.key)}
              className={`-mb-px border-b-2 px-4 py-2 text-sm font-semibold transition ${
                activeTab === t.key
                  ? "border-[#B08A2E] text-[#1B2430]"
                  : "border-transparent text-slate-400 hover:text-[#1B2430]"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {!financialYearId && (
          <div className="mb-4 max-w-md rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-600">
            No financial year selected. Please pick one first.
          </div>
        )}

        <div className="flex flex-wrap items-end gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">Start date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20 disabled:cursor-not-allowed disabled:opacity-60"
              type="text"
              value={startDateText}
              disabled={fyLoading || !financialYearId}
              onChange={(e) => {
                const v = e.target.value;
                setStartDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setStartDate(displayToIso(v));
              }}
              onBlur={() => setStartDateText(isoToDisplay(startDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500">End date</label>
            <input
              className="w-36 rounded-lg border border-[#E6E2D8] bg-[#FAFAF7] px-3 py-2.5 text-sm tabular-nums text-[#1B2430] outline-none transition focus:border-[#B08A2E] focus:ring-2 focus:ring-[#B08A2E]/20 disabled:cursor-not-allowed disabled:opacity-60"
              type="text"
              value={endDateText}
              disabled={fyLoading || !financialYearId}
              onChange={(e) => {
                const v = e.target.value;
                setEndDateText(v);
                if (/^\d{2}-\d{2}-\d{4}$/.test(v)) setEndDate(displayToIso(v));
              }}
              onBlur={() => setEndDateText(isoToDisplay(endDate))}
              placeholder="DD-MM-YYYY"
            />
          </div>

          <button
            className="rounded-lg bg-[#1B2430] px-5 py-2.5 text-sm font-semibold text-white transition active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60"
            onClick={generateReport}
            disabled={loading || fyLoading}
          >
            {loading ? "Generating…" : "Generate"}
          </button>

          {showingReport && activeTab !== "item" && (
            <div className="flex gap-2.5">
              <button className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px" onClick={expandAll}>
                Expand all
              </button>
              <button className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px" onClick={collapseAll}>
                Collapse all
              </button>
            </div>
          )}
        </div>

        {showingReport && (
          <div className="mt-4 flex gap-2.5 border-t border-[#E6E2D8] pt-4">
            <button className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px" onClick={handlePrint}>
              Print
            </button>
            <button className="rounded-lg border border-[#E6E2D8] bg-white px-4 py-2.5 text-sm font-semibold text-[#1B2430] transition active:translate-y-px" onClick={handleExportPdf}>
              Export PDF
            </button>
          </div>
        )}
      </div>

      {showingReport && (
        <div ref={printRef} className="rounded-xl border border-[#E6E2D8] bg-white p-7 shadow-sm print:border-none print:p-0 print:shadow-none">
          <div className="mb-5 flex items-end justify-between border-b-2 border-[#1B2430] pb-4">
            <div>
              <span className="mb-1 inline-block text-[11px] font-semibold uppercase tracking-widest text-[#B08A2E]">
                Stock Report
              </span>
              <h2 className="text-2xl font-bold">{TABS.find((t) => t.key === activeTab)?.label}</h2>
            </div>
            <div className="text-sm font-semibold tabular-nums text-slate-500">
              <span>{isoToDisplay(report.start_date)}</span>
              <span className="mx-2 text-[#B08A2E]">to</span>
              <span>{isoToDisplay(report.end_date)}</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[1500px] border-collapse text-[13.5px]">
              {activeTab === "item" && (
                <>
                  <StockTableHead />
                  <tbody>
                    {report.rows.map((item) => (
                      <ItemLeafRow key={item.item_id} item={item} indent="" onDoubleClick={() => handleItemDoubleClick(item)} />
                    ))}
                    <tr className="border-y-2 border-[#1B2430] bg-[#1B2430] text-[13.5px] font-bold text-white">
                      <td className="px-3 py-2.5 text-right" colSpan={2}>Grand Total</td>
                      <StockNumberCells stat={report.grand_total} />
                    </tr>
                  </tbody>
                </>
              )}

              {activeTab === "account" && (
                <>
                  <StockTableHead />
                  <tbody>
                    {report.accounts.map((acc) => {
                      const key = `acc-${acc.account_code || "UNASSIGNED"}`;
                      const isOpen = !collapsed.has(key);
                      return (
                        <React.Fragment key={key}>
                          <GroupHeaderRow
                            level={2}
                            code={acc.account_code}
                            details={acc.account_name}
                            isOpen={isOpen}
                            onToggle={() => toggle(key)}
                            colSpan={14}
                          />
                          {isOpen && acc.items.map((item) => (
                            <ItemLeafRow key={item.item_id} item={item} onDoubleClick={() => handleItemDoubleClick(item)} />
                          ))}
                          {isOpen && <GroupTotalRow label={`Total — ${acc.account_name}`} totals={acc.totals} emphasise />}
                        </React.Fragment>
                      );
                    })}
                    <tr className="border-y-2 border-[#1B2430] bg-[#1B2430] text-[13.5px] font-bold text-white">
                      <td className="px-3 py-2.5 text-right" colSpan={2}>Grand Total</td>
                      <StockNumberCells stat={report.grand_total} />
                    </tr>
                  </tbody>
                </>
              )}

              {activeTab === "management" && (
                <>
                  <StockTableHead />
                  <tbody>
                    {report.mainitems.map((mi) => {
                      const miKey = `mi-${mi.id}`;
                      const miOpen = !collapsed.has(miKey);
                      return (
                        <React.Fragment key={miKey}>
                          <GroupHeaderRow level={1} code={mi.code} details={mi.details} isOpen={miOpen} onToggle={() => toggle(miKey)} colSpan={14} />
                          {miOpen && mi.subitems.map((si) => {
                            const siKey = `si-${si.id}`;
                            const siOpen = !collapsed.has(siKey);
                            return (
                              <React.Fragment key={siKey}>
                                <GroupHeaderRow level={2} code={si.code} details={si.details} isOpen={siOpen} onToggle={() => toggle(siKey)} colSpan={14} />
                                {siOpen && si.items.map((item) => (
                                  <ItemLeafRow key={item.id} item={item} onDoubleClick={() => handleItemDoubleClick(item)} />
                                ))}
                                {siOpen && <GroupTotalRow label={`Total — ${si.details}`} totals={si.totals} />}
                              </React.Fragment>
                            );
                          })}
                          {miOpen && <GroupTotalRow label={`Total — ${mi.details}`} totals={mi.totals} emphasise />}
                        </React.Fragment>
                      );
                    })}
                    <tr className="border-y-2 border-[#1B2430] bg-[#1B2430] text-[13.5px] font-bold text-white">
                      <td className="px-3 py-2.5 text-right" colSpan={2}>Grand Total</td>
                      <StockNumberCells stat={report.grand_total} />
                    </tr>
                  </tbody>
                </>
              )}
            </table>
          </div>
        </div>
      )}
    </div>
  );
}