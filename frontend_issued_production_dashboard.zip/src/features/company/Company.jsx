import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { useDispatch, useSelector } from 'react-redux';
import api from '../../services/api';
import { setSystemNameIp } from '../../store/slices/companySlice';
import { fetchClientSystemInfo } from '../../utils/getSystemInfo';

import addIcon from '../../assets/add.png';
import editIcon from '../../assets/edit.png';
import deleteIcon from '../../assets/delete.png';

const EMPTY_FORM = {
  company_name: '',
  NTN_No: '',
  Business_Name: '',
  Province: '',
  Address: '',
};

const Company = () => {
  const [companies, setCompanies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' | 'edit'
  const [formData, setFormData] = useState(EMPTY_FORM);
  const [selectedCompany, setSelectedCompany] = useState(null);

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const dispatch = useDispatch();
  const { user, systemNameIp } = useSelector((state) => state.company);

  useEffect(() => {
    fetchCompanies();
    if (!systemNameIp) {
      fetchClientSystemInfo().then((ip) => {
        if (ip) dispatch(setSystemNameIp(ip));
      });
    }
  }, []);

  // Small helper — spread into every write payload
  const withMeta = (body = {}) => ({
    ...body,
    performed_by: user?.username || user?.name || 'Unknown',
    system_name_ip: systemNameIp,
  });

  const fetchCompanies = async () => {
    setIsLoading(true);
    try {
      const res = await api.get('/company');
      setCompanies(res.data?.data || []);
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to load companies');
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenAddModal = () => {
    setModalMode('add');
    setFormData(EMPTY_FORM);
    setSelectedCompany(null);
    setShowModal(true);
  };

  const handleOpenEditModal = (company) => {
    setModalMode('edit');
    setSelectedCompany(company);
    setFormData({
      company_name: company.company_name || '',
      NTN_No: company.NTN_No || '',
      Business_Name: company.Business_Name || '',
      Province: company.Province || '',
      Address: company.Address || '',
    });
    setShowModal(true);
  };

  const handleCloseModal = () => {
    if (isSubmitting) return;
    setShowModal(false);
    setFormData(EMPTY_FORM);
    setSelectedCompany(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.company_name.trim()) {
      toast.error('Company name is required');
      return;
    }

    setIsSubmitting(true);
    try {
      if (modalMode === 'add') {
        await api.post('/company/add', withMeta(formData));
        toast.success('Company added successfully');
      } else {
        const id = selectedCompany.id;
        await api.put(`/company/update/${id}`, withMeta(formData));
        toast.success('Company updated successfully');
      }
      handleCloseModal();
      fetchCompanies();
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Something went wrong, please try again');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteClick = (company) => {
    setDeleteTarget(company);
  };

  const handleCancelDelete = () => {
    if (isDeleting) return;
    setDeleteTarget(null);
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const id = deleteTarget.id;

    setIsDeleting(true);
    try {
      await api.delete(`/company/delete/${id}`, { data: withMeta() });
      setCompanies((prev) => prev.filter((c) => c.id !== id));
      toast.success('Company deleted successfully');
      setDeleteTarget(null);
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to delete company');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-2xl font-semibold text-gray-800">Companies</h2>

        <button
          onClick={handleOpenAddModal}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-md transition-colors"
        >
          <img src={addIcon} alt="" className="w-4 h-4" />
          Add Company
        </button>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16 text-gray-500">
          Loading companies...
        </div>
      ) : companies.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <p className="text-gray-600 text-lg font-medium">No companies yet</p>
          <p className="text-gray-400 text-sm mt-1">
            Add your first company to get started.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto border border-gray-200 rounded-lg">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Company Name
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Business Name
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  NTN No.
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Province
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Address
                </th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-100">
              {companies.map((company) => (
                <tr key={company.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">
                    {company.company_name}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {company.Business_Name}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {company.NTN_No}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {company.Province}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {company.Address}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-3">
                      <button
                        onClick={() => handleOpenEditModal(company)}
                        className="focus:outline-none"
                        title="Edit"
                      >
                        <img
                          src={editIcon}
                          alt="Edit"
                          className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity"
                        />
                      </button>
                      <button
                        onClick={() => handleDeleteClick(company)}
                        className="focus:outline-none"
                        title="Delete"
                      >
                        <img
                          src={deleteIcon}
                          alt="Delete"
                          className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity"
                        />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[70]">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md mx-4 p-6 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              {modalMode === 'add' ? 'Add Company' : 'Edit Company'}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Company Name
                </label>
                <input
                  type="text"
                  name="company_name"
                  value={formData.company_name}
                  onChange={handleChange}
                  autoFocus
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter company name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  NTN No.
                </label>
                <input
                  type="text"
                  name="NTN_No"
                  value={formData.NTN_No}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter NTN No."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Business Name
                </label>
                <input
                  type="text"
                  name="Business_Name"
                  value={formData.Business_Name}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter business name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Province
                </label>
                <input
                  type="text"
                  name="Province"
                  value={formData.Province}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter province"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Address
                </label>
                <input
                  type="text"
                  name="Address"
                  value={formData.Address}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter address"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors disabled:opacity-60"
                >
                  {isSubmitting
                    ? 'Saving...'
                    : modalMode === 'add'
                      ? 'Add Company'
                      : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[70]">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-sm mx-4 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">
              Delete Company
            </h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to delete{' '}
              <span className="font-medium text-gray-800">
                {deleteTarget.company_name}
              </span>
              ? This action cannot be undone.
            </p>

            <div className="flex justify-end gap-3">
              <button
                onClick={handleCancelDelete}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors disabled:opacity-60"
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Company;