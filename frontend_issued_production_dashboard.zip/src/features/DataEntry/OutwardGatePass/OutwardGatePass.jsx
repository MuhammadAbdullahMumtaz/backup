import React, { useState, useEffect, useMemo, useRef } from 'react';
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from 'react-redux';
import api from '../../../services/api'
import { setSystemNameIp } from '../../../store/slices/companySlice';
import { fetchClientSystemInfo } from '../../../utils/getSystemInfo';

import editIcon from '../../../assets/edit.png';
import deleteIcon from '../../../assets/delete.png';

const CONFIG = {
    title: 'Outward Gate Pass Entry',
    mainApi: '/outward-gate-pass-main',
    detailApi: '/outward-gate-pass-detail',
    detailByMainPath: (mainId) => `/outward-gate-pass-detail/outward/${mainId}`,
    numberField: 'outward_no',
    dateField: 'outward_date',
    numberLabel: 'Outward No',
    dateLabel: 'Outward Date',
    newLabel: '+ New Outward',
    searchPlaceholder: 'New Outward',
    detailMainIdKey: 'outwardgatepassmain_id',
    docNoun: 'outward gate pass',
};

const LOOKUP_API = {
    chartOfAccount: '/chart-of-account',
    itemDetail: '/item-detail',
    subItem: '/sub-item',
    department: '/department',
    productionMain: '/production-main',
    salesContractMain: '/sales-contract-main',
};

const todayStr = () => new Date().toISOString().slice(0, 10);

const isoToDisplayDate = (iso) => {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    if (!y || !m || !d) return '';
    return `${d}-${m}-${y}`;
};

const displayDateToIso = (display) => {
    if (!display) return '';
    const parts = display.split('-');
    if (parts.length !== 3) return '';
    const [d, m, y] = parts;
    if (!d || !m || !y || y.length !== 4) return '';
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
};

const dbDateToIso = (raw) => {
    if (!raw) return '';
    const str = String(raw);
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
    const d = new Date(raw);
    if (isNaN(d.getTime())) return str.slice(0, 10);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
};

const EMPTY_MAIN_FORM = {
    doc_date: isoToDisplayDate(todayStr()),
    department_id: '',
    account_code: '',
    vehicle_no: '',
    vehicle_type: '',
    driver_name: '',
    driver_phone_no: '',
    contract_no: '',
    production_no: '',
    freight: 0,
    remarks: '',
};

// OutwardGatePassDetail has no `rate` column - amount is entered directly,
// same simplification used by Inward Gate Pass for pieces/net_weight.
const EMPTY_DETAIL_FORM = {
    subitem_code: '', // transient - only filters the Item Name field, never sent to the backend
    Item_code: '',
    pieces: 0,
    net_weight: 0,
};

const focusAndSelect = (ref) => {
    if (!ref || !ref.current) return;
    ref.current.focus();
    if (typeof ref.current.select === 'function') {
        ref.current.select();
    }
};

const makeEnterToNext = (nextRef) => (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    focusAndSelect(nextRef);
};

// Same searchable-field pattern used across Purchase/Sales/Inward Entry.
const SearchField = React.forwardRef(({ label, value, onChange, options, codeKey, labelKey, subLabelKey, placeholder, disabled, showAllOnFocus, onEnterNext, wide }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = term
        ? options
            .filter(
                (opt) =>
                    String(opt[labelKey] ?? '').toLowerCase().includes(term) ||
                    String(opt[codeKey] ?? '').includes(term)
            )
            .slice(0, 8)
        : (showAllOnFocus ? options.slice(0, 8) : []);

    const matched = options.find((opt) => String(opt[codeKey]) === term);

    useEffect(() => {
        setHighlightedIndex(suggestions.length > 0 ? 0 : -1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectSuggestion = (opt) => {
        onChange(String(opt[codeKey]));
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (showSuggestions && suggestions.length > 0 && highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
                selectSuggestion(suggestions[highlightedIndex]);
            } else {
                setShowSuggestions(false);
            }
            onEnterNext && onEnterNext();
            return;
        }
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev + 1) % suggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div>
            {label && <label className="block text-xs font-medium text-gray-600 mb-0.5">{label}</label>}
            <div className="relative">
                <input
                    ref={ref}
                    type="text"
                    value={value ?? ''}
                    disabled={disabled}
                    onChange={(e) => {
                        onChange(e.target.value);
                        setShowSuggestions(true);
                    }}
                    onFocus={(e) => {
                        if ((value ?? '').toString().trim() || showAllOnFocus) setShowSuggestions(true);
                        e.target.select();
                    }}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-400"
                    placeholder={placeholder || 'Search'}
                />
                {matched && (
                    <div className="text-[11px] text-blue-800 font-bold mt-0.5 truncate px-2 py-0.5 rounded">→ {matched[labelKey]}</div>
                )}
                {showSuggestions && suggestions.length > 0 && (
                    <div className={`absolute left-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-20 ${wide ? 'w-[200%]' : 'right-0'}`}>
                        {suggestions.map((opt, index) => (
                            <div
                                key={opt[codeKey]}
                                className={`px-2.5 py-1.5 cursor-pointer text-sm flex items-center justify-between border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-100' : 'hover:bg-blue-50'}`}
                                onMouseEnter={() => setHighlightedIndex(index)}
                                onMouseDown={() => selectSuggestion(opt)}
                            >
                                <span className="font-medium">{opt[labelKey]}</span>
                                {subLabelKey && opt[subLabelKey] && (
                                    <span className="text-xs text-gray-400">{opt[subLabelKey]}</span>
                                )}
                                {codeKey !== labelKey && (
                                    <span className="text-xs font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded ml-4">
                                        {opt[codeKey]}
                                    </span>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
});

// Doc-No field for loading an existing outward gate pass - same pattern as
// Inward Gate Pass's DocSearchField (pins "+ New" at top).
const DocSearchField = React.forwardRef(({ value, onChange, options, onSelectExisting, onSelectNew, numberKey, newLabel, placeholder, onEnterNext }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = options
        .filter(
            (opt) =>
                String(opt[numberKey] ?? '').toLowerCase().includes(term) ||
                String(opt.account_name ?? '').toLowerCase().includes(term) ||
                String(opt.doc_date_display ?? '').toLowerCase().includes(term)
        )
        .slice(0, 8);

    useEffect(() => {
        setHighlightedIndex(-1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectNew = () => {
        onSelectNew();
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };
    const selectExisting = (opt) => {
        onSelectExisting(opt);
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (!showSuggestions) {
            if (e.key === 'Enter') {
                e.preventDefault();
                onEnterNext && onEnterNext();
            }
            return;
        }
        const minIndex = -1;
        const maxIndex = suggestions.length - 1;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev >= maxIndex ? minIndex : prev + 1));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev <= minIndex ? maxIndex : prev - 1));
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightedIndex === -1) selectNew();
            else if (highlightedIndex >= 0 && highlightedIndex < suggestions.length) selectExisting(suggestions[highlightedIndex]);
            onEnterNext && onEnterNext();
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div className="relative">
            <input
                ref={ref}
                type="text"
                value={value ?? ''}
                onChange={(e) => {
                    onChange(e.target.value);
                    setShowSuggestions(true);
                }}
                onFocus={(e) => {
                    setShowSuggestions(true);
                    e.target.select();
                }}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                onKeyDown={handleKeyDown}
                className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                placeholder={placeholder}
            />
            {showSuggestions && (
                <div className="absolute left-0 mt-1 w-[420px] max-w-[90vw] bg-white border border-gray-200 rounded-lg shadow-lg max-h-56 overflow-y-auto z-30">
                    <div
                        className={`px-2.5 py-1.5 cursor-pointer text-sm font-semibold text-blue-600 border-b border-gray-100 ${highlightedIndex === -1 ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                        onMouseEnter={() => setHighlightedIndex(-1)}
                        onMouseDown={selectNew}
                    >
                        {newLabel}
                    </div>
                    {suggestions.map((opt, index) => (
                        <div
                            key={opt.id}
                            className={`px-2.5 py-1.5 cursor-pointer text-sm grid grid-cols-3 gap-2 border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                            onMouseEnter={() => setHighlightedIndex(index)}
                            onMouseDown={() => selectExisting(opt)}
                        >
                            <span className="font-medium truncate">{opt[numberKey]}</span>
                            <span className="text-gray-600 truncate">{opt.account_name}</span>
                            <span className="text-gray-400 text-xs">{opt.doc_date_display}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
});

// Reference-picker field for Production No / Contract No: dropdown-only
// (no "+ New" row, since these are optional references to a document raised
// elsewhere, not a doc this page creates). `secondaryKey` is optional
// (e.g. customer name for a contract; omitted for production).
const RefDocSearchField = React.forwardRef(({ value, onChange, options, numberKey, secondaryKey, placeholder, onEnterNext }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = options
        .filter(
            (opt) =>
                String(opt[numberKey] ?? '').toLowerCase().includes(term) ||
                (secondaryKey && String(opt[secondaryKey] ?? '').toLowerCase().includes(term)) ||
                String(opt.doc_date_display ?? '').toLowerCase().includes(term)
        )
        .slice(0, 8);

    useEffect(() => {
        setHighlightedIndex(suggestions.length > 0 ? 0 : -1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectExisting = (opt) => {
        onChange(String(opt[numberKey]));
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (showSuggestions && suggestions.length > 0 && highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
                selectExisting(suggestions[highlightedIndex]);
            } else {
                setShowSuggestions(false);
            }
            onEnterNext && onEnterNext();
            return;
        }
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev + 1) % suggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div className="relative">
            <input
                ref={ref}
                type="text"
                value={value ?? ''}
                onChange={(e) => {
                    onChange(e.target.value);
                    setShowSuggestions(true);
                }}
                onFocus={(e) => {
                    setShowSuggestions(true);
                    e.target.select();
                }}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                onKeyDown={handleKeyDown}
                className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                placeholder={placeholder}
            />
            {showSuggestions && suggestions.length > 0 && (
                <div className="absolute left-0 mt-1 w-[380px] max-w-[90vw] bg-white border border-gray-200 rounded-lg shadow-lg max-h-56 overflow-y-auto z-30">
                    {suggestions.map((opt, index) => (
                        <div
                            key={opt.id}
                            className={`px-2.5 py-1.5 cursor-pointer text-sm grid ${secondaryKey ? 'grid-cols-3' : 'grid-cols-2'} gap-2 border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                            onMouseEnter={() => setHighlightedIndex(index)}
                            onMouseDown={() => selectExisting(opt)}
                        >
                            <span className="font-medium truncate">{opt[numberKey]}</span>
                            {secondaryKey && <span className="text-gray-600 truncate">{opt[secondaryKey]}</span>}
                            <span className="text-gray-400 text-xs">{opt.doc_date_display}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
});

function OutwardGatePassEntry({ onBack }) {
    const dispatch = useDispatch();
    const {
        companyId: rawCompanyId,
        financialYearId: rawFinancialYearId,
        user,
        systemNameIp,
    } = useSelector((state) => state.company);

    useEffect(() => {
        if (!systemNameIp) {
            fetchClientSystemInfo().then((ip) => {
                if (ip) dispatch(setSystemNameIp(ip));
            });
        }
    }, []);

    const withMeta = (body = {}) => ({
        ...body,
        performed_by: user?.username || user?.name || 'Unknown',
        system_name_ip: systemNameIp,
    });

    const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== ''
        ? Number(rawCompanyId)
        : null;
    const financialYearId = rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ''
        ? Number(rawFinancialYearId)
        : null;

    const config = CONFIG;

    // ---- Main doc (Outward Gate Pass) ----
    const [mainForm, setMainForm] = useState(EMPTY_MAIN_FORM);
    const [mainId, setMainId] = useState(null);
    const [docNo, setDocNo] = useState('');
    const [isSavingMain, setIsSavingMain] = useState(false);

    const [existingMains, setExistingMains] = useState([]);
    const [isLoadingMains, setIsLoadingMains] = useState(false);

    // ---- Departments ----
    const [departments, setDepartments] = useState([]);
    const [departmentsLoaded, setDepartmentsLoaded] = useState(false);

    // ---- Chart Of Account ----
    const [chartOfAccounts, setChartOfAccounts] = useState([]);
    const [chartOfAccountsLoaded, setChartOfAccountsLoaded] = useState(false);

    // ---- Sub Item / Item ----
    const [subItems, setSubItems] = useState([]);
    const [subItemsLoaded, setSubItemsLoaded] = useState(false);
    const [items, setItems] = useState([]);
    const [itemsLoaded, setItemsLoaded] = useState(false);

    // ---- Reference docs for Production No / Contract No ----
    const [productionMains, setProductionMains] = useState([]);
    const [productionMainsLoaded, setProductionMainsLoaded] = useState(false);
    const [salesContractMains, setSalesContractMains] = useState([]);
    const [salesContractMainsLoaded, setSalesContractMainsLoaded] = useState(false);

    // ---- Details ----
    const [details, setDetails] = useState([]);
    const [isLoadingDetails, setIsLoadingDetails] = useState(false);
    const [detailForm, setDetailForm] = useState(EMPTY_DETAIL_FORM);
    const [editingDetailId, setEditingDetailId] = useState(null);
    const [isSavingDetail, setIsSavingDetail] = useState(false);

    // ---- Refs ----
    const docNoRef = useRef(null);
    const mainDateRef = useRef(null);
    const mainDepartmentRef = useRef(null);
    const mainAccountRef = useRef(null);
    const mainVehicleNoRef = useRef(null);
    const mainVehicleTypeRef = useRef(null);
    const mainDriverNameRef = useRef(null);
    const mainDriverPhoneRef = useRef(null);
    const mainContractNoRef = useRef(null);
    const mainProductionNoRef = useRef(null);
    const mainFreightRef = useRef(null);
    const mainRemarksRef = useRef(null);
    const mainSubmitRef = useRef(null);

    const itemSubRef = useRef(null);
    const itemNameRef = useRef(null);
    const piecesRef = useRef(null);
    const netWeightRef = useRef(null);
    const detailSubmitRef = useRef(null);

    // =============================================================================
    // Lookups
    // =============================================================================
    const fetchDepartments = async () => {
        const res = await api.get(`${LOOKUP_API.department}`);
        setDepartments(res.data?.data || []);
        setDepartmentsLoaded(true);
    };
    const ensureDepartmentsLoaded = async () => (departmentsLoaded ? departments : fetchDepartments());

    const fetchChartOfAccounts = async () => {
        const res = await api.get(`${LOOKUP_API.chartOfAccount}/`);
        setChartOfAccounts(res.data?.data || []);
        setChartOfAccountsLoaded(true);
    };
    const ensureChartOfAccountsLoaded = async () => (chartOfAccountsLoaded ? chartOfAccounts : fetchChartOfAccounts());

    const fetchSubItems = async () => {
        const res = await api.get(`${LOOKUP_API.subItem}/`);
        setSubItems(res.data?.data || []);
        setSubItemsLoaded(true);
    };
    const ensureSubItemsLoaded = async () => (subItemsLoaded ? subItems : fetchSubItems());

    const fetchItems = async () => {
        const res = await api.get(`${LOOKUP_API.itemDetail}/`);
        const data = res.data?.data || res.data || [];
        setItems(Array.isArray(data) ? data : []);
        setItemsLoaded(true);
    };
    const ensureItemsLoaded = async () => (itemsLoaded ? items : fetchItems());

    const fetchProductionMains = async () => {
        const res = await api.get(`${LOOKUP_API.productionMain}/`);
        const data = Array.isArray(res.data) ? res.data : (res.data?.data || []);
        setProductionMains(data);
        setProductionMainsLoaded(true);
    };
    const ensureProductionMainsLoaded = async () => (productionMainsLoaded ? productionMains : fetchProductionMains());

    const fetchSalesContractMains = async () => {
        const res = await api.get(`${LOOKUP_API.salesContractMain}/`);
        const data = Array.isArray(res.data) ? res.data : (res.data?.data || []);
        setSalesContractMains(data);
        setSalesContractMainsLoaded(true);
    };
    const ensureSalesContractMainsLoaded = async () => (salesContractMainsLoaded ? salesContractMains : fetchSalesContractMains());

    const companyDepartments = useMemo(
        () => departments.filter((dep) => Number(dep.company_id) === Number(companyId)),
        [departments, companyId]
    );
    const companyAccounts = useMemo(
        () => chartOfAccounts.filter((coa) => coa.company_id === companyId),
        [chartOfAccounts, companyId]
    );
    const companySubItems = useMemo(
        () => subItems.filter((si) => si.company_id === companyId),
        [subItems, companyId]
    );
    const companyItems = useMemo(
        () => items.filter((item) => item.company_id === companyId),
        [items, companyId]
    );

    const selectedSubItem = useMemo(
        () => companySubItems.find((si) => String(si.code) === String(detailForm.subitem_code).trim()),
        [companySubItems, detailForm.subitem_code]
    );
    const itemOptionsForSubItem = useMemo(
        () => (selectedSubItem
            ? companyItems.filter((item) => Number(item.subitem_id) === Number(selectedSubItem.id))
            : []),
        [companyItems, selectedSubItem]
    );

    // Production reference options, filtered to this company/FY, formatted
    // exactly like existingMainsForSearch below (number + display date).
    const companyProductionOptions = useMemo(
        () =>
            productionMains
                .filter(
                    (p) =>
                        Number(p.company_id) === Number(companyId) &&
                        Number(p.financialyear_id) === Number(financialYearId)
                )
                .map((p) => ({
                    ...p,
                    doc_date_display: p.production_date ? isoToDisplayDate(dbDateToIso(p.production_date)) : '',
                })),
        [productionMains, companyId, financialYearId]
    );

    // Contract reference options - adds the customer name, resolved from
    // Chart of Accounts, alongside the display date.
    const companyContractOptions = useMemo(
        () =>
            salesContractMains
                .filter(
                    (c) =>
                        Number(c.company_id) === Number(companyId) &&
                        Number(c.financialyear_id) === Number(financialYearId)
                )
                .map((c) => {
                    const account = companyAccounts.find((a) => String(a.code) === String(c.account_code));
                    return {
                        ...c,
                        customer_name: account?.account_name || c.account_code,
                        doc_date_display: c.contract_date ? isoToDisplayDate(dbDateToIso(c.contract_date)) : '',
                    };
                }),
        [salesContractMains, companyId, financialYearId, companyAccounts]
    );

    const existingMainsForSearch = useMemo(
        () =>
            existingMains.map((m) => {
                const account = companyAccounts.find((a) => String(a.code) === String(m.account_code));
                const rawDate = m[config.dateField];
                return {
                    ...m,
                    account_name: account?.account_name || m.account_name || m.account_code,
                    doc_date_display: rawDate ? isoToDisplayDate(String(rawDate).slice(0, 10)) : '',
                };
            }),
        [existingMains, companyAccounts, config.dateField]
    );

    useEffect(() => {
        if (!companyId) return;
        ensureDepartmentsLoaded();
        ensureChartOfAccountsLoaded();
        ensureSubItemsLoaded();
        ensureItemsLoaded();
        ensureProductionMainsLoaded();
        ensureSalesContractMainsLoaded();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    useEffect(() => {
        if (!companyId) return;
        handleNewMain();
        fetchExistingMains();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId, financialYearId]);

    // =============================================================================
    // Main doc
    // =============================================================================
    const fetchExistingMains = async () => {
        if (!companyId || !financialYearId) return;
        setIsLoadingMains(true);
        try {
            const res = await api.get(`${config.mainApi}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            const filtered = list
                .filter(
                    (m) =>
                        Number(m.company_id) === Number(companyId) &&
                        Number(m.financialyear_id) === Number(financialYearId)
                )
                .sort((a, b) => {
                    const numA = parseInt(String(a[config.numberField]).split('-').pop() || a[config.numberField] || '0');
                    const numB = parseInt(String(b[config.numberField]).split('-').pop() || b[config.numberField] || '0');
                    return numB - numA;
                });
            setExistingMains(filtered);
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to load ${config.docNoun}s`);
        } finally {
            setIsLoadingMains(false);
        }
    };

    const handleNewMain = () => {
        setMainId(null);
        setDocNo('');
        setMainForm(EMPTY_MAIN_FORM);
        setDetails([]);
        resetDetailForm();
    };

    const handleOpenMain = (m) => {
        setMainId(Number(m.id));
        setDocNo(m[config.numberField]);
        const rawDate = m[config.dateField];
        setMainForm({
            doc_date: rawDate ? isoToDisplayDate(String(rawDate).slice(0, 10)) : '',
            department_id: m.department_id || '',
            account_code: m.account_code || '',
            vehicle_no: m.vehicle_no || '',
            vehicle_type: m.vehicle_type || '',
            driver_name: m.driver_name || '',
            driver_phone_no: m.driver_phone_no || '',
            contract_no: m.contract_no || '',
            production_no: m.production_no || '',
            freight: m.freight || 0,
            remarks: m.remarks || '',
        });
        resetDetailForm();
        fetchDetails(Number(m.id));
    };

    const handleSaveMain = async (e) => {
        e.preventDefault();

        if (!mainForm.doc_date) {
            toast.error(`Please select a ${config.dateLabel.toLowerCase()}`);
            return;
        }
        if (!mainForm.department_id) {
            toast.error('Please select a department');
            return;
        }
        if (!mainForm.account_code) {
            toast.error('Please select an account');
            return;
        }
        if (!mainForm.vehicle_no.trim()) {
            toast.error('Please enter a vehicle number');
            return;
        }
        if (!financialYearId) {
            toast.error('No financial year selected');
            return;
        }

        const docDateIso = displayDateToIso(mainForm.doc_date);
        if (!docDateIso) {
            toast.error(`${config.dateLabel} must be in dd-mm-yyyy format`);
            return;
        }

        setIsSavingMain(true);
        try {
            const payload = {
                company_id: companyId,
                financialyear_id: financialYearId,
                department_id: mainForm.department_id,
                [config.dateField]: docDateIso,
                account_code: mainForm.account_code,
                vehicle_no: mainForm.vehicle_no.trim(),
                vehicle_type: mainForm.vehicle_type || null,
                driver_name: mainForm.driver_name || null,
                driver_phone_no: mainForm.driver_phone_no || null,
                contract_no: mainForm.contract_no || null,
                production_no: mainForm.production_no || null,
                freight: mainForm.freight || 0,
                remarks: mainForm.remarks || null,
            };

            if (mainId) {
                await api.put(`${config.mainApi}/${mainId}`, withMeta({
                    ...payload,
                    [config.numberField]: docNo,
                }));
                toast.success(`${config.title.replace(' Entry', '')} updated`);
            } else {
                const res = await api.post(`${config.mainApi}/`, withMeta(payload));
                const newId = Number(res.data?.id);
                const assignedNo = res.data?.[config.numberField];
                setMainId(newId);
                setDocNo(assignedNo);
                toast.success(`${config.numberLabel} #${assignedNo} created`);
            }
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to save ${config.docNoun}`);
        } finally {
            setIsSavingMain(false);
        }
    };

    const handleDeleteMain = async () => {
        if (!mainId) return;
        if (!window.confirm(`Delete ${config.docNoun} "${docNo}" and all of its entries?`)) return;
        try {
            const res = await api.get(config.detailByMainPath(mainId));
            const list = Array.isArray(res.data) ? res.data : [];
            for (const d of list) {
                // eslint-disable-next-line no-await-in-loop
                await api.delete(`${config.detailApi}/${d.id}`, { data: withMeta() });
            }
            await api.delete(`${config.mainApi}/${mainId}`, { data: withMeta() });
            toast.success(`${config.title.replace(' Entry', '')} deleted`);
            handleNewMain();
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to delete ${config.docNoun}`);
        }
    };

    // =============================================================================
    // Details
    // =============================================================================
    const fetchDetails = async (id) => {
        setIsLoadingDetails(true);
        try {
            const res = await api.get(config.detailByMainPath(id));
            const list = Array.isArray(res.data) ? res.data : [];
            setDetails(list.sort((a, b) => a.entry_no - b.entry_no));
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load entries');
        } finally {
            setIsLoadingDetails(false);
        }
    };

    const resetDetailForm = () => {
        setDetailForm(EMPTY_DETAIL_FORM);
        setEditingDetailId(null);
    };

    const resetDetailFormKeepSubitem = () => {
        setDetailForm((prev) => ({ ...EMPTY_DETAIL_FORM, subitem_code: prev.subitem_code }));
        setEditingDetailId(null);
    };

    const handleEditDetailRow = (row) => {
        const item = companyItems.find((i) => String(i.code) === String(row.Item_code));
        const subitem = item ? companySubItems.find((si) => Number(si.id) === Number(item.subitem_id)) : null;

        setEditingDetailId(row.id);
        setDetailForm({
            subitem_code: subitem ? subitem.code : '',
            Item_code: row.Item_code ?? '',
            pieces: row.pieces || 0,
            net_weight: row.net_weight || 0,
        });
    };

    const detailsTotals = useMemo(() => {
        return details.reduce(
            (acc, row) => {
                acc.pieces += Number(row.pieces) || 0;
                acc.net_weight += Number(row.net_weight) || 0;
                return acc;
            },
            { pieces: 0, net_weight: 0 }
        );
    }, [details]);

    const handleSaveDetail = async (e) => {
        e.preventDefault();

        if (!mainId) {
            toast.error(`Save the ${config.docNoun} details first`);
            return;
        }
        if (!detailForm.Item_code) {
            toast.error('Select or enter an item');
            return;
        }

        const nextEntryNo = editingDetailId
            ? details.find((d) => d.id === editingDetailId)?.entry_no
            : (details.length > 0 ? Math.max(...details.map((d) => d.entry_no)) + 1 : 1);

        const payload = {
            company_id: companyId,
            [config.detailMainIdKey]: mainId,
            Item_code: detailForm.Item_code,
            entry_no: nextEntryNo,
            pieces: detailForm.pieces || 0,
            net_weight: detailForm.net_weight || 0,
        };

        setIsSavingDetail(true);
        try {
            if (editingDetailId) {
                await api.put(`${config.detailApi}/${editingDetailId}`, withMeta(payload));
                toast.success('Entry updated');
            } else {
                await api.post(`${config.detailApi}/`, withMeta(payload));
                toast.success('Entry added');
            }
            resetDetailFormKeepSubitem();
            await fetchDetails(mainId);
            focusAndSelect(itemSubRef);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save entry');
        } finally {
            setIsSavingDetail(false);
        }
    };

    const handleDeleteDetail = async (row) => {
        if (!window.confirm(`Delete entry #${row.entry_no}?`)) return;
        try {
            await api.delete(`${config.detailApi}/${row.id}`, { data: withMeta() });
            toast.success('Entry deleted');
            await fetchDetails(mainId);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete entry');
        }
    };

    // =============================================================================
    // Render
    // =============================================================================
    return (
        <div className="bg-gray-50 p-4">
            {onBack && (
                <button
                    type="button"
                    onClick={onBack}
                    className="mb-2 flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700"
                >
                    ← Back
                </button>
            )}

            <div className="flex items-center justify-between mb-2">
                <h1 className="text-xl font-bold text-gray-800">{config.title}</h1>
            </div>

            <div className="max-w-6xl mx-auto">
                {!companyId ? (
                    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 text-center text-gray-500 text-sm">
                        No company context found. Please select a company first.
                    </div>
                ) : (
                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">

                        {/* Main form */}
                        <form onSubmit={handleSaveMain} className="pb-3 mb-3">
                            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 mb-2">
                                <div>
                                    <div className="flex items-center justify-between mb-0.5">
                                        <label className="block text-xs font-medium text-gray-600">{config.numberLabel}</label>
                                        {mainId && (
                                            <button type="button" onClick={handleDeleteMain} title={`Delete this ${config.docNoun}`} className="hover:opacity-70">
                                                <img src={deleteIcon} alt="Delete" className="w-3.5 h-3.5" />
                                            </button>
                                        )}
                                    </div>
                                    <DocSearchField
                                        ref={docNoRef}
                                        value={docNo}
                                        onChange={(val) => setDocNo(val)}
                                        options={existingMainsForSearch}
                                        numberKey={config.numberField}
                                        newLabel={config.newLabel}
                                        placeholder={config.searchPlaceholder}
                                        onSelectExisting={(m) => handleOpenMain(m)}
                                        onSelectNew={() => handleNewMain()}
                                        onEnterNext={() => focusAndSelect(mainDateRef)}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">{config.dateLabel}</label>
                                    <input
                                        ref={mainDateRef}
                                        type="text"
                                        value={mainForm.doc_date}
                                        onChange={(e) => setMainForm({ ...mainForm, doc_date: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainDepartmentRef)}
                                        placeholder="dd-mm-yyyy"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>

                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Department</label>
                                    <select
                                        ref={mainDepartmentRef}
                                        value={mainForm.department_id}
                                        onChange={(e) => setMainForm({ ...mainForm, department_id: e.target.value })}
                                        onKeyDown={makeEnterToNext(mainAccountRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    >
                                        <option value="">Select department</option>
                                        {companyDepartments.map((dep) => (
                                            <option key={dep.id} value={dep.id}>
                                                {dep.department_name}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                <div className="sm:col-span-2">
                                    <SearchField
                                        ref={mainAccountRef}
                                        label="Account"
                                        value={mainForm.account_code}
                                        onChange={(val) => setMainForm({ ...mainForm, account_code: val })}
                                        options={companyAccounts}
                                        codeKey="code"
                                        labelKey="account_name"
                                        placeholder="Search account"
                                        showAllOnFocus
                                        onEnterNext={() => focusAndSelect(mainVehicleNoRef)}
                                    />
                                </div>

                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Vehicle No</label>
                                    <input
                                        ref={mainVehicleNoRef}
                                        type="text"
                                        value={mainForm.vehicle_no}
                                        onChange={(e) => setMainForm({ ...mainForm, vehicle_no: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainVehicleTypeRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 mb-2">
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Vehicle Type</label>
                                    <input
                                        ref={mainVehicleTypeRef}
                                        type="text"
                                        value={mainForm.vehicle_type}
                                        onChange={(e) => setMainForm({ ...mainForm, vehicle_type: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainDriverNameRef)}
                                        placeholder="e.g. Truck, Trolley"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Driver Name</label>
                                    <input
                                        ref={mainDriverNameRef}
                                        type="text"
                                        value={mainForm.driver_name}
                                        onChange={(e) => setMainForm({ ...mainForm, driver_name: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainDriverPhoneRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Driver Phone</label>
                                    <input
                                        ref={mainDriverPhoneRef}
                                        type="text"
                                        value={mainForm.driver_phone_no}
                                        onChange={(e) => setMainForm({ ...mainForm, driver_phone_no: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainProductionNoRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>

                                {/* Production No - dropdown shows production_no + date, same visual
                                    format as the doc-number field above. */}
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Production No</label>
                                    <RefDocSearchField
                                        ref={mainProductionNoRef}
                                        value={mainForm.production_no}
                                        onChange={(val) => setMainForm({ ...mainForm, production_no: val })}
                                        options={companyProductionOptions}
                                        numberKey="production_no"
                                        placeholder="Optional - search production"
                                        onEnterNext={() => focusAndSelect(mainContractNoRef)}
                                    />
                                </div>

                                {/* Contract No - dropdown shows contract_no + customer + date */}
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Contract No</label>
                                    <RefDocSearchField
                                        ref={mainContractNoRef}
                                        value={mainForm.contract_no}
                                        onChange={(val) => setMainForm({ ...mainForm, contract_no: val })}
                                        options={companyContractOptions}
                                        numberKey="contract_no"
                                        secondaryKey="customer_name"
                                        placeholder="Optional - search contract"
                                        onEnterNext={() => focusAndSelect(mainFreightRef)}
                                    />
                                </div>

                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Freight</label>
                                    <input
                                        ref={mainFreightRef}
                                        type="number"
                                        value={mainForm.freight}
                                        onChange={(e) => setMainForm({ ...mainForm, freight: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainRemarksRef)}
                                        min="0"
                                        step="0.01"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
                                <div className="sm:col-span-2">
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Remarks</label>
                                    <input
                                        ref={mainRemarksRef}
                                        type="text"
                                        value={mainForm.remarks}
                                        onChange={(e) => setMainForm({ ...mainForm, remarks: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainSubmitRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    {/* Invisible label keeps the button's top aligned with the row
                                        even when a neighboring field (e.g. Account) grows taller
                                        because of its "→ matched name" hint line underneath. */}
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5 invisible">Action</label>
                                    <button
                                        ref={mainSubmitRef}
                                        type="submit"
                                        disabled={isSavingMain}
                                        className="w-full px-4 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 bg-blue-500 hover:bg-blue-600"
                                    >
                                        {isSavingMain ? 'Saving...' : mainId ? 'Update' : 'Create'}
                                    </button>
                                </div>
                            </div>
                        </form>

                        {/* Detail entries */}
                        {mainId && (
                            <>
                                <div className="border-t border-gray-200 pt-3 mb-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">
                                        {editingDetailId ? 'Edit Entry' : 'Add Entry'}
                                    </h3>
                                    <form onSubmit={handleSaveDetail} className="space-y-2">
                                        <div className="grid grid-cols-6 gap-2 items-end">
                                            <div className="col-span-1">
                                                <SearchField
                                                    ref={itemSubRef}
                                                    label="Item Sub"
                                                    value={detailForm.subitem_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, subitem_code: val, Item_code: '' })}
                                                    options={companySubItems}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder="Search"
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(itemNameRef)}
                                                />
                                            </div>

                                            <div className="col-span-2">
                                                <SearchField
                                                    ref={itemNameRef}
                                                    label="Item Name"
                                                    value={detailForm.Item_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, Item_code: val })}
                                                    options={itemOptionsForSubItem}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder={selectedSubItem ? 'Search item' : 'Pick item sub first'}
                                                    disabled={!selectedSubItem}
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(piecesRef)}
                                                />
                                            </div>

                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Pieces</label>
                                                <input
                                                    ref={piecesRef}
                                                    type="number"
                                                    value={detailForm.pieces}
                                                    onChange={(e) => setDetailForm({ ...detailForm, pieces: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(netWeightRef)}
                                                    min="0"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>

                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Net Weight</label>
                                                <input
                                                    ref={netWeightRef}
                                                    type="number"
                                                    value={detailForm.net_weight}
                                                    onChange={(e) => setDetailForm({ ...detailForm, net_weight: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(detailSubmitRef)}
                                                    min="0"
                                                    step="0.01"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>

                                            <div className="col-span-1 flex items-end gap-2">
                                                <button
                                                    ref={detailSubmitRef}
                                                    type="submit"
                                                    disabled={isSavingDetail}
                                                    className="w-full px-3 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 disabled:cursor-not-allowed bg-blue-500 hover:bg-blue-600"
                                                >
                                                    {isSavingDetail ? 'Saving...' : editingDetailId ? 'Update' : 'Save'}
                                                </button>
                                                {editingDetailId && (
                                                    <button
                                                        type="button"
                                                        onClick={resetDetailForm}
                                                        title="Cancel edit"
                                                        className="text-sm text-gray-500 hover:text-gray-700"
                                                    >
                                                        ✕
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                {/* Entries table */}
                                <div className="border-t border-gray-200 pt-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">Entries</h3>
                                    {isLoadingDetails ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">Loading...</div>
                                    ) : details.length === 0 ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">No entries yet</div>
                                    ) : (
                                        <div className="overflow-x-auto border border-gray-200 rounded-lg">
                                            <table className="min-w-full divide-y divide-gray-200 text-sm">
                                                <thead className="bg-gray-50">
                                                    <tr>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Entry No</th>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Item</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Pieces</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Net Weight</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="bg-white divide-y divide-gray-100">
                                                    {details.map((row) => (
                                                        <tr key={row.id} className="hover:bg-gray-50">
                                                            <td className="px-2.5 py-1.5 text-gray-600">{row.entry_no}</td>
                                                            <td className="px-2.5 py-1.5 text-gray-800">{row.item_name || row.Item_code}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.pieces}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.net_weight}</td>
                                                            <td className="px-2.5 py-1.5">
                                                                <div className="flex items-center justify-end gap-2">
                                                                    <button onClick={() => handleEditDetailRow(row)} title="Edit">
                                                                        <img src={editIcon} alt="Edit" className="w-4 h-4" />
                                                                    </button>
                                                                    <button onClick={() => handleDeleteDetail(row)} title="Delete">
                                                                        <img src={deleteIcon} alt="Delete" className="w-4 h-4" />
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                                <tfoot className="bg-gray-50 border-t-2 border-gray-200">
                                                    <tr>
                                                        <td className="px-2.5 py-1.5 font-semibold text-gray-700" colSpan={2}>
                                                            Total
                                                        </td>
                                                        <td className="px-2.5 py-1.5 text-right font-semibold text-gray-800">
                                                            {detailsTotals.pieces}
                                                        </td>
                                                        <td className="px-2.5 py-1.5 text-right font-semibold text-gray-800">
                                                            {detailsTotals.net_weight}
                                                        </td>
                                                        <td className="px-2.5 py-1.5"></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

export default OutwardGatePassEntry;