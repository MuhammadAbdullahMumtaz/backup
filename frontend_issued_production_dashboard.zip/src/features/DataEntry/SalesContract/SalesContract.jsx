import React, { useState, useEffect, useMemo, useRef } from 'react';
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from 'react-redux';
import api from '../../../services/api'
import { setSystemNameIp } from '../../../store/slices/companySlice';
import { fetchClientSystemInfo } from '../../../utils/getSystemInfo';

import editIcon from '../../../assets/edit.png';
import deleteIcon from '../../../assets/delete.png';

const ENDPOINTS = {
    main: '/sales-contract-main',
    detail: '/sales-contract-detail',
    detailByMainPath: (mainId) => `/sales-contract-detail/contract/${mainId}`,
};

const LOOKUP_API = {
    chartOfAccount: '/chart-of-account',
    itemDetail: '/item-detail',
    subItem: '/sub-item',
};

const todayStr = () => new Date().toISOString().slice(0, 10);

const isoToDisplayDate = (iso) => {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    if (!y || !m || !d) return '';
    return `${d}-${m}-${y}`;
};

const displayDateToIso = (display) => {
    if (!display) return '';
    const parts = display.split('-');
    if (parts.length !== 3) return '';
    const [d, m, y] = parts;
    if (!d || !m || !y || y.length !== 4) return '';
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
};

const dbDateToIso = (raw) => {
    if (!raw) return '';
    const str = String(raw);
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
    const d = new Date(raw);
    if (isNaN(d.getTime())) return str.slice(0, 10);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
};

const trailingNumber = (code) => {
    const match = String(code ?? '').match(/(\d+)(?!.*\d)/);
    return match ? parseInt(match[1], 10) : NaN;
};

const EMPTY_MAIN_FORM = {
    contract_date: isoToDisplayDate(todayStr()),
    account_code: '',
    delivery_date: '',
    remarks: '',
};

// gross_weight / tear_weight exist on SalesContractDetail but are not used
// here - net weight is entered directly, for now, same simplification as
// Production Entry.
const EMPTY_DETAIL_FORM = {
    subitem_code: '',
    Item_code: '',
    details: '',
    pieces: 0,
    net_weight: 0,
    rate: 0,
    gst_percent: 0,
    further_percent: 0,
    other_tax: 0,
};

const focusAndSelect = (ref) => {
    if (!ref || !ref.current) return;
    ref.current.focus();
    if (typeof ref.current.select === 'function') {
        ref.current.select();
    }
};

const makeEnterToNext = (nextRef) => (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    focusAndSelect(nextRef);
};

// Same SearchField pattern used across Purchase/Sales/Issued/Production Entry.
const SearchField = React.forwardRef(({ label, value, onChange, options, codeKey, labelKey, placeholder, disabled, showAllOnFocus, onEnterNext }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = term
        ? options
            .filter(
                (opt) =>
                    String(opt[labelKey] ?? '').toLowerCase().includes(term) ||
                    String(opt[codeKey] ?? '').includes(term)
            )
            .slice(0, 8)
        : (showAllOnFocus ? options.slice(0, 8) : []);

    const matched = options.find((opt) => String(opt[codeKey]) === term);

    useEffect(() => {
        setHighlightedIndex(suggestions.length > 0 ? 0 : -1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectSuggestion = (opt) => {
        onChange(String(opt[codeKey]));
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (showSuggestions && suggestions.length > 0 && highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
                selectSuggestion(suggestions[highlightedIndex]);
            } else {
                setShowSuggestions(false);
            }
            onEnterNext && onEnterNext();
            return;
        }
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev + 1) % suggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div>
            {label && <label className="block text-xs font-medium text-gray-600 mb-0.5">{label}</label>}
            <div className="relative">
                <input
                    ref={ref}
                    type="text"
                    value={value ?? ''}
                    disabled={disabled}
                    onChange={(e) => {
                        onChange(e.target.value);
                        setShowSuggestions(true);
                    }}
                    onFocus={(e) => {
                        if ((value ?? '').toString().trim() || showAllOnFocus) setShowSuggestions(true);
                        e.target.select();
                    }}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-400"
                    placeholder={placeholder || 'Search'}
                />
                {matched && (
                    <div className="text-[11px] text-blue-800 font-bold mt-0.5 truncate px-2 py-0.5 rounded">→ {matched[labelKey]}</div>
                )}
                {showSuggestions && suggestions.length > 0 && (
                    <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-20">
                        {suggestions.map((opt, index) => (
                            <div
                                key={opt[codeKey]}
                                className={`px-2.5 py-1.5 cursor-pointer text-sm flex items-center justify-between border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-100' : 'hover:bg-blue-50'}`}
                                onMouseEnter={() => setHighlightedIndex(index)}
                                onMouseDown={() => selectSuggestion(opt)}
                            >
                                <span className="font-medium">{opt[labelKey]}</span>
                                {codeKey !== labelKey && (
                                    <span className="text-xs font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded ml-4">
                                        {opt[codeKey]}
                                    </span>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
});

// Doc-No field for loading an existing sales contract, same pattern as
// Purchase/Sales/Issued/Production Entry's DocSearchField.
const DocSearchField = React.forwardRef(({ value, onChange, options, onSelectExisting, onSelectNew, numberKey, newLabel, placeholder, onEnterNext }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = options
        .filter(
            (opt) =>
                String(opt[numberKey] ?? '').toLowerCase().includes(term) ||
                String(opt.account_name ?? '').toLowerCase().includes(term) ||
                String(opt.doc_date_display ?? '').toLowerCase().includes(term)
        )
        .slice(0, 8);

    useEffect(() => {
        setHighlightedIndex(-1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectNew = () => {
        onSelectNew();
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };
    const selectExisting = (opt) => {
        onSelectExisting(opt);
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (!showSuggestions) {
            if (e.key === 'Enter') {
                e.preventDefault();
                onEnterNext && onEnterNext();
            }
            return;
        }
        const minIndex = -1;
        const maxIndex = suggestions.length - 1;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev >= maxIndex ? minIndex : prev + 1));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev <= minIndex ? maxIndex : prev - 1));
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightedIndex === -1) selectNew();
            else if (highlightedIndex >= 0 && highlightedIndex < suggestions.length) selectExisting(suggestions[highlightedIndex]);
            onEnterNext && onEnterNext();
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div className="relative">
            <input
                ref={ref}
                type="text"
                value={value ?? ''}
                onChange={(e) => {
                    onChange(e.target.value);
                    setShowSuggestions(true);
                }}
                onFocus={(e) => {
                    setShowSuggestions(true);
                    e.target.select();
                }}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                onKeyDown={handleKeyDown}
                className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                placeholder={placeholder}
            />
            {showSuggestions && (
                <div className="absolute left-0 mt-1 w-[420px] max-w-[90vw] bg-white border border-gray-200 rounded-lg shadow-lg max-h-56 overflow-y-auto z-30">
                    <div
                        className={`px-2.5 py-1.5 cursor-pointer text-sm font-semibold text-blue-600 border-b border-gray-100 ${highlightedIndex === -1 ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                        onMouseEnter={() => setHighlightedIndex(-1)}
                        onMouseDown={selectNew}
                    >
                        {newLabel}
                    </div>
                    {suggestions.map((opt, index) => (
                        <div
                            key={opt.id}
                            className={`px-2.5 py-1.5 cursor-pointer text-sm grid grid-cols-3 gap-2 border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                            onMouseEnter={() => setHighlightedIndex(index)}
                            onMouseDown={() => selectExisting(opt)}
                        >
                            <span className="font-medium truncate">{opt[numberKey]}</span>
                            <span className="text-gray-600 truncate">{opt.account_name}</span>
                            <span className="text-gray-400 text-xs">{opt.doc_date_display}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
});

function SalesContractEntry({ navPayload, onNavPayloadConsumed, onBack }) {
    const dispatch = useDispatch();
    const {
        companyId: rawCompanyId,
        financialYearId: rawFinancialYearId,
        user,
        systemNameIp,
    } = useSelector((state) => state.company);

    useEffect(() => {
        if (!systemNameIp) {
            fetchClientSystemInfo().then((ip) => {
                if (ip) dispatch(setSystemNameIp(ip));
            });
        }
    }, []);

    const withMeta = (body = {}) => ({
        ...body,
        performed_by: user?.username || user?.name || 'Unknown',
        system_name_ip: systemNameIp,
    });

    const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== ''
        ? Number(rawCompanyId)
        : null;
    const financialYearId = rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ''
        ? Number(rawFinancialYearId)
        : null;

    // ---- Main doc ----
    const [mainForm, setMainForm] = useState(EMPTY_MAIN_FORM);
    const [mainId, setMainId] = useState(null);
    const [contractNo, setContractNo] = useState('');
    const [isSavingMain, setIsSavingMain] = useState(false);

    const [existingMains, setExistingMains] = useState([]);
    const [isLoadingMains, setIsLoadingMains] = useState(false);

    // ---- Chart Of Account (customers) ----
    const [chartOfAccounts, setChartOfAccounts] = useState([]);
    const [chartOfAccountsLoaded, setChartOfAccountsLoaded] = useState(false);

    // ---- Sub Item / Item lookups ----
    const [subItems, setSubItems] = useState([]);
    const [subItemsLoaded, setSubItemsLoaded] = useState(false);
    const [items, setItems] = useState([]);
    const [itemsLoaded, setItemsLoaded] = useState(false);

    // ---- Details ----
    const [details, setDetails] = useState([]);
    const [isLoadingDetails, setIsLoadingDetails] = useState(false);
    const [detailForm, setDetailForm] = useState(EMPTY_DETAIL_FORM);
    const [editingDetailId, setEditingDetailId] = useState(null);
    const [isSavingDetail, setIsSavingDetail] = useState(false);
    const [showGst, setShowGst] = useState(false);

    // ---- Refs ----
    const docNoRef = useRef(null);
    const mainDateRef = useRef(null);
    const mainAccountRef = useRef(null);
    const mainDeliveryDateRef = useRef(null);
    const mainRemarksRef = useRef(null);
    const mainSubmitRef = useRef(null);

    const itemSubRef = useRef(null);
    const itemNameRef = useRef(null);
    const detailsRef = useRef(null);
    const piecesRef = useRef(null);
    const netWeightRef = useRef(null);
    const rateRef = useRef(null);
    const gstToggleRef = useRef(null);
    const gstPercentRef = useRef(null);
    const furtherPercentRef = useRef(null);
    const otherTaxRef = useRef(null);
    const detailSubmitRef = useRef(null);

    const lastNavPayloadRef = useRef(null);

    useEffect(() => {
        if (!navPayload) return;
        if (lastNavPayloadRef.current === navPayload) return;
        const targetNo = navPayload.contract_no;
        if (!targetNo || existingMains.length === 0) return;
        const m = existingMains.find((r) => String(r.contract_no) === String(targetNo));
        if (m) {
            handleOpenMain(m);
            lastNavPayloadRef.current = navPayload;
            onNavPayloadConsumed && onNavPayloadConsumed();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [existingMains, navPayload]);

    // =============================================================================
    // Lookups
    // =============================================================================
    const fetchChartOfAccounts = async () => {
        const res = await api.get(`${LOOKUP_API.chartOfAccount}/`);
        const data = res.data?.data || [];
        setChartOfAccounts(data);
        setChartOfAccountsLoaded(true);
    };
    const ensureChartOfAccountsLoaded = async () => (chartOfAccountsLoaded ? chartOfAccounts : fetchChartOfAccounts());

    const fetchSubItems = async () => {
        const res = await api.get(`${LOOKUP_API.subItem}/`);
        const data = res.data?.data || [];
        setSubItems(data);
        setSubItemsLoaded(true);
    };
    const ensureSubItemsLoaded = async () => (subItemsLoaded ? subItems : fetchSubItems());

    const fetchItems = async () => {
        const res = await api.get(`${LOOKUP_API.itemDetail}/`);
        const data = res.data?.data || res.data || [];
        setItems(Array.isArray(data) ? data : []);
        setItemsLoaded(true);
    };
    const ensureItemsLoaded = async () => (itemsLoaded ? items : fetchItems());

    const companyAccounts = useMemo(
        () => chartOfAccounts.filter((coa) => coa.company_id === companyId),
        [chartOfAccounts, companyId]
    );
    const companySubItems = useMemo(
        () => subItems.filter((si) => si.company_id === companyId),
        [subItems, companyId]
    );
    const companyItems = useMemo(
        () => items.filter((item) => item.company_id === companyId),
        [items, companyId]
    );

    const selectedSubItem = useMemo(
        () => companySubItems.find((si) => String(si.code) === String(detailForm.subitem_code).trim()),
        [companySubItems, detailForm.subitem_code]
    );

    const usedItemCodes = useMemo(
        () => new Set(
            details
                .filter((d) => !editingDetailId || d.id !== editingDetailId)
                .map((d) => String(d.Item_code))
        ),
        [details, editingDetailId]
    );
    const itemOptionsForSubItem = useMemo(
        () => (selectedSubItem
            ? companyItems.filter(
                (item) =>
                    Number(item.subitem_id) === Number(selectedSubItem.id) &&
                    !usedItemCodes.has(String(item.code))
            )
            : []),
        [companyItems, selectedSubItem, usedItemCodes]
    );

    const existingMainsForSearch = useMemo(
        () =>
            existingMains.map((m) => {
                const account = companyAccounts.find((a) => String(a.code) === String(m.account_code));
                return {
                    ...m,
                    account_name: account?.account_name || m.account_name || m.account_code,
                    doc_date_display: m.contract_date ? isoToDisplayDate(dbDateToIso(m.contract_date)) : '',
                };
            }),
        [existingMains, companyAccounts]
    );

    useEffect(() => {
        if (!companyId) return;
        ensureChartOfAccountsLoaded();
        ensureSubItemsLoaded();
        ensureItemsLoaded();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    useEffect(() => {
        if (!companyId) return;
        handleNewMain();
        fetchExistingMains();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId, financialYearId]);

    // =============================================================================
    // Main doc
    // =============================================================================
    const fetchExistingMains = async () => {
        if (!companyId || !financialYearId) return;
        setIsLoadingMains(true);
        try {
            const res = await api.get(`${ENDPOINTS.main}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            const filtered = list
                .filter(
                    (m) =>
                        Number(m.company_id) === Number(companyId) &&
                        Number(m.financialyear_id) === Number(financialYearId)
                )
                .sort((a, b) => {
                    const numA = trailingNumber(a.contract_no);
                    const numB = trailingNumber(b.contract_no);
                    if (!Number.isNaN(numA) && !Number.isNaN(numB) && numA !== numB) return numB - numA;
                    return new Date(b.contract_date) - new Date(a.contract_date);
                });
            setExistingMains(filtered);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load sales contracts');
        } finally {
            setIsLoadingMains(false);
        }
    };

    const handleNewMain = () => {
        setMainId(null);
        setContractNo('');
        setMainForm(EMPTY_MAIN_FORM);
        setDetails([]);
        resetDetailForm();
    };

    const handleOpenMain = (m) => {
        setMainId(Number(m.id));
        setContractNo(m.contract_no);
        setMainForm({
            contract_date: m.contract_date ? isoToDisplayDate(dbDateToIso(m.contract_date)) : '',
            account_code: m.account_code || '',
            delivery_date: m.delivery_date ? isoToDisplayDate(dbDateToIso(m.delivery_date)) : '',
            remarks: m.remarks || '',
        });
        resetDetailForm();
        fetchDetails(Number(m.id));
    };

    const handleSaveMain = async (e) => {
        e.preventDefault();

        if (!mainForm.contract_date) {
            toast.error('Please select a contract date');
            return;
        }
        if (!mainForm.account_code) {
            toast.error('Please select a customer');
            return;
        }
        if (!financialYearId) {
            toast.error('No financial year selected');
            return;
        }

        const contractDateIso = displayDateToIso(mainForm.contract_date);
        if (!contractDateIso) {
            toast.error('Contract date must be in dd-mm-yyyy format');
            return;
        }
        const deliveryDateIso = mainForm.delivery_date ? displayDateToIso(mainForm.delivery_date) : null;
        if (mainForm.delivery_date && !deliveryDateIso) {
            toast.error('Delivery date must be in dd-mm-yyyy format');
            return;
        }

        const payload = {
            company_id: companyId,
            financialyear_id: financialYearId,
            contract_date: contractDateIso,
            account_code: mainForm.account_code,
            delivery_date: deliveryDateIso,
            remarks: mainForm.remarks || null,
        };

        setIsSavingMain(true);
        try {
            if (mainId) {
                await api.put(`${ENDPOINTS.main}/${mainId}`, withMeta(payload));
                toast.success('Sales contract updated');
            } else {
                const res = await api.post(`${ENDPOINTS.main}/`, withMeta(payload));
                const newId = Number(res.data?.id);
                const assignedNo = res.data?.contract_no;
                setMainId(newId);
                setContractNo(assignedNo);
                toast.success(`Contract #${assignedNo} created`);
            }
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save sales contract');
        } finally {
            setIsSavingMain(false);
        }
    };

    const handleDeleteMain = async () => {
        if (!mainId) return;
        if (!window.confirm(`Delete sales contract "${contractNo}" and all of its entries?`)) return;
        try {
            const res = await api.get(ENDPOINTS.detailByMainPath(mainId));
            const list = Array.isArray(res.data) ? res.data : [];
            for (const d of list) {
                // eslint-disable-next-line no-await-in-loop
                await api.delete(`${ENDPOINTS.detail}/${d.id}`, { data: withMeta() });
            }
            await api.delete(`${ENDPOINTS.main}/${mainId}`, { data: withMeta() });
            toast.success('Sales contract deleted');
            handleNewMain();
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete sales contract');
        }
    };

    // =============================================================================
    // Details
    // =============================================================================
    const fetchDetails = async (id) => {
        setIsLoadingDetails(true);
        try {
            const res = await api.get(ENDPOINTS.detailByMainPath(id));
            const list = Array.isArray(res.data) ? res.data : [];
            setDetails(list.sort((a, b) => a.entry_no - b.entry_no));
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load entries');
        } finally {
            setIsLoadingDetails(false);
        }
    };

    const resetDetailForm = () => {
        setDetailForm(EMPTY_DETAIL_FORM);
        setEditingDetailId(null);
        setShowGst(false);
    };

    const resetDetailFormKeepSubitem = () => {
        setDetailForm((prev) => ({ ...EMPTY_DETAIL_FORM, subitem_code: prev.subitem_code }));
        setEditingDetailId(null);
        setShowGst(false);
    };

    const handleEditDetailRow = (row) => {
        const item = companyItems.find((i) => String(i.code) === String(row.Item_code));
        const subitem = item ? companySubItems.find((si) => Number(si.id) === Number(item.subitem_id)) : null;

        setEditingDetailId(row.id);
        setDetailForm({
            subitem_code: subitem ? subitem.code : '',
            Item_code: row.Item_code ?? '',
            details: row.details ?? '',
            pieces: row.pieces || 0,
            net_weight: row.net_weight || 0,
            rate: row.rate || 0,
            gst_percent: row.gst_percent || 0,
            further_percent: row.further_percent || 0,
            other_tax: row.other_tax || 0,
        });
        setShowGst((row.gst_percent || row.further_percent || row.other_tax) ? true : false);
    };

    // Live preview of amount/gst/further-tax/total for the entry being
    // typed - purely informational, the backend recomputes the authoritative
    // values on save.
    const detailPreview = useMemo(() => {
        const netWeight = Number(detailForm.net_weight) || 0;
        const rate = Number(detailForm.rate) || 0;
        const amount = netWeight * rate;

        const gstAmount = amount * (Number(detailForm.gst_percent) || 0) / 100;
        const furtherAmount = amount * (Number(detailForm.further_percent) || 0) / 100;
        const otherTax = Number(detailForm.other_tax) || 0;

        return {
            amount,
            gstAmount,
            furtherAmount,
            total: amount + gstAmount + furtherAmount + otherTax,
        };
    }, [detailForm]);

    const detailsTotals = useMemo(() => {
        return details.reduce(
            (acc, row) => {
                acc.amount += Number(row.amount) || 0;
                acc.gst_amount += Number(row.gst_amount) || 0;
                acc.total += Number(row.total) || 0;
                return acc;
            },
            { amount: 0, gst_amount: 0, total: 0 }
        );
    }, [details]);

    const handleSaveDetail = async (e) => {
        e.preventDefault();

        if (!mainId) {
            toast.error('Save the sales contract details first');
            return;
        }
        if (!detailForm.Item_code) {
            toast.error('Select or enter an item');
            return;
        }
        if (!detailForm.net_weight || Number(detailForm.net_weight) <= 0) {
            toast.error('Net weight must be greater than zero');
            return;
        }

        const payload = withMeta({
            company_id: companyId,
            salescontractmain_id: mainId,
            Item_code: detailForm.Item_code,
            details: detailForm.details || null,
            pieces: detailForm.pieces || 0,
            net_weight: detailForm.net_weight || 0,
            rate: detailForm.rate || 0,
            gst_percent: detailForm.gst_percent || 0,
            further_percent: detailForm.further_percent || 0,
            other_tax: detailForm.other_tax || 0,
        });

        setIsSavingDetail(true);
        try {
            if (editingDetailId) {
                const editPayload = {
                    ...payload,
                    entry_no: details.find((d) => d.id === editingDetailId)?.entry_no,
                };
                await api.put(`${ENDPOINTS.detail}/${editingDetailId}`, editPayload);
                toast.success('Entry updated');
            } else {
                await api.post(`${ENDPOINTS.detail}/`, payload);
                toast.success('Entry added');
            }
            resetDetailFormKeepSubitem();
            await fetchDetails(mainId);
            focusAndSelect(itemSubRef);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save entry');
        } finally {
            setIsSavingDetail(false);
        }
    };

    const handleDeleteDetail = async (row) => {
        if (!window.confirm(`Delete entry #${row.entry_no}?`)) return;
        try {
            await api.delete(`${ENDPOINTS.detail}/${row.id}`, { data: withMeta() });
            toast.success('Entry deleted');
            await fetchDetails(mainId);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete entry');
        }
    };

    // =============================================================================
    // Render
    // =============================================================================
    return (
        <div className="bg-gray-50 p-3">
            {onBack && (
                <button
                    type="button"
                    onClick={onBack}
                    className="mb-2 flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700"
                >
                    ← Back
                </button>
            )}

            <div className="flex items-center justify-between mb-2">
                <h1 className="text-xl font-bold text-gray-800">Sales Contract Entry</h1>
            </div>

            <div className="max-w-5xl mx-auto">
                {!companyId ? (
                    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 text-center text-gray-500 text-sm">
                        No company context found. Please select a company first.
                    </div>
                ) : (
                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">

                        {/* Main form */}
                        <form onSubmit={handleSaveMain} className="pb-3 mb-3">
                            <div className="grid grid-cols-2 sm:grid-cols-8 gap-2 mb-2">
                                <div>
                                    <div className="flex items-center justify-between mb-0.5">
                                        <label className="block text-xs font-medium text-gray-600">Contract No</label>
                                        {mainId && (
                                            <button type="button" onClick={handleDeleteMain} title="Delete this sales contract" className="hover:opacity-70">
                                                <img src={deleteIcon} alt="Delete" className="w-3.5 h-3.5" />
                                            </button>
                                        )}
                                    </div>
                                    <DocSearchField
                                        ref={docNoRef}
                                        value={contractNo}
                                        onChange={(val) => setContractNo(val)}
                                        options={existingMainsForSearch}
                                        numberKey="contract_no"
                                        newLabel="+ New Contract"
                                        placeholder="New Contract"
                                        onSelectExisting={(m) => handleOpenMain(m)}
                                        onSelectNew={() => handleNewMain()}
                                        onEnterNext={() => focusAndSelect(mainDateRef)}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Contract Date</label>
                                    <input
                                        ref={mainDateRef}
                                        type="text"
                                        value={mainForm.contract_date}
                                        onChange={(e) => setMainForm({ ...mainForm, contract_date: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainAccountRef)}
                                        placeholder="dd-mm-yyyy"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div className="sm:col-span-2">
                                    <SearchField
                                        ref={mainAccountRef}
                                        label="Customer"
                                        value={mainForm.account_code}
                                        onChange={(val) => setMainForm({ ...mainForm, account_code: val })}
                                        options={companyAccounts}
                                        codeKey="code"
                                        labelKey="account_name"
                                        placeholder="Search customer"
                                        showAllOnFocus
                                        onEnterNext={() => focusAndSelect(mainDeliveryDateRef)}
                                    />
                                </div>
                                <div className="sm:col-span-2">
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Remarks</label>
                                    <input
                                        ref={mainRemarksRef}
                                        type="text"
                                        value={mainForm.remarks}
                                        onChange={(e) => setMainForm({ ...mainForm, remarks: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainSubmitRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Delivery Date</label>
                                    <input
                                        ref={mainDeliveryDateRef}
                                        type="text"
                                        value={mainForm.delivery_date}
                                        onChange={(e) => setMainForm({ ...mainForm, delivery_date: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainRemarksRef)}
                                        placeholder="dd-mm-yyyy"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5 invisible">Action</label>
                                    <button
                                        ref={mainSubmitRef}
                                        type="submit"
                                        disabled={isSavingMain}
                                        className="w-full px-4 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 bg-blue-500 hover:bg-blue-600"
                                    >
                                        {isSavingMain ? 'Saving...' : mainId ? 'Update' : 'Create'}
                                    </button>
                                </div>
                            </div>
                        </form>

                        {/* Detail entries */}
                        {mainId && (
                            <>
                                <div className="border-t border-gray-200 pt-3 mb-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">
                                        {editingDetailId ? 'Edit Entry' : 'Add Entry'}
                                    </h3>
                                    <form onSubmit={handleSaveDetail} className="space-y-2">
                                        <div className="grid grid-cols-6 gap-2 items-end">
                                            <div className="col-span-1">
                                                <SearchField
                                                    ref={itemSubRef}
                                                    label="Item Sub"
                                                    value={detailForm.subitem_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, subitem_code: val, Item_code: '' })}
                                                    options={companySubItems}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder="Search"
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(itemNameRef)}
                                                />
                                            </div>
                                            <div className="col-span-2">
                                                <SearchField
                                                    ref={itemNameRef}
                                                    label="Item Name"
                                                    value={detailForm.Item_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, Item_code: val })}
                                                    options={itemOptionsForSubItem}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder={selectedSubItem ? 'Search item' : 'Pick item sub first'}
                                                    disabled={!selectedSubItem}
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(detailsRef)}
                                                />
                                            </div>
                                            <div className="col-span-3">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Details</label>
                                                <input
                                                    ref={detailsRef}
                                                    type="text"
                                                    value={detailForm.details}
                                                    onChange={(e) => setDetailForm({ ...detailForm, details: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(piecesRef)}
                                                    placeholder="Optional line description"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>

                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Pieces</label>
                                                <input
                                                    ref={piecesRef}
                                                    type="number"
                                                    value={detailForm.pieces}
                                                    onChange={(e) => setDetailForm({ ...detailForm, pieces: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(netWeightRef)}
                                                    min="0"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Net Weight</label>
                                                <input
                                                    ref={netWeightRef}
                                                    type="number"
                                                    value={detailForm.net_weight}
                                                    onChange={(e) => setDetailForm({ ...detailForm, net_weight: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(rateRef)}
                                                    min="0"
                                                    step="0.01"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Rate</label>
                                                <input
                                                    ref={rateRef}
                                                    type="number"
                                                    value={detailForm.rate}
                                                    onChange={(e) => setDetailForm({ ...detailForm, rate: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(gstToggleRef)}
                                                    min="0"
                                                    step="0.01"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Total</label>
                                                <input
                                                    type="text"
                                                    value={detailPreview.total.toFixed(2)}
                                                    disabled
                                                    className="w-full px-2 py-1.5 border border-gray-200 bg-gray-50 rounded-md text-sm text-right text-gray-600"
                                                />
                                            </div>
                                            <div className="col-span-2 flex items-end gap-2">
                                                <button
                                                    ref={gstToggleRef}
                                                    type="button"
                                                    onClick={() => { setShowGst(true); focusAndSelect(gstPercentRef); }}
                                                    onKeyDown={(e) => {
                                                        if (e.key === 'Enter') {
                                                            e.preventDefault();
                                                            setShowGst(true);
                                                            setTimeout(() => focusAndSelect(gstPercentRef), 0);
                                                        }
                                                    }}
                                                    className="text-xs font-medium text-blue-600 hover:text-blue-700 underline underline-offset-2 pb-2"
                                                >
                                                    {showGst ? 'GST ▾' : 'GST ▸'}
                                                </button>
                                                <button
                                                    ref={detailSubmitRef}
                                                    type="submit"
                                                    disabled={isSavingDetail}
                                                    className="w-full px-3 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 disabled:cursor-not-allowed bg-blue-500 hover:bg-blue-600"
                                                >
                                                    {isSavingDetail ? 'Saving...' : editingDetailId ? 'Update' : 'Save'}
                                                </button>
                                                {editingDetailId && (
                                                    <button
                                                        type="button"
                                                        onClick={resetDetailForm}
                                                        title="Cancel edit"
                                                        className="text-sm text-gray-500 hover:text-gray-700"
                                                    >
                                                        ✕
                                                    </button>
                                                )}
                                            </div>
                                        </div>

                                        {/* Collapsible GST row, revealed via the "GST ▸" link after Rate */}
                                        {showGst && (
                                            <div className="grid grid-cols-8 gap-2 items-end mt-2">
                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">GST %</label>
                                                    <input
                                                        ref={gstPercentRef}
                                                        type="number"
                                                        value={detailForm.gst_percent}
                                                        onChange={(e) => setDetailForm({ ...detailForm, gst_percent: e.target.value })}
                                                        onFocus={(e) => e.target.select()}
                                                        onKeyDown={makeEnterToNext(furtherPercentRef)}
                                                        min="0" step="0.01"
                                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm"
                                                    />
                                                </div>
                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Further %</label>
                                                    <input
                                                        ref={furtherPercentRef}
                                                        type="number"
                                                        value={detailForm.further_percent}
                                                        onChange={(e) => setDetailForm({ ...detailForm, further_percent: e.target.value })}
                                                        onFocus={(e) => e.target.select()}
                                                        onKeyDown={makeEnterToNext(otherTaxRef)}
                                                        min="0" step="0.01"
                                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm"
                                                    />
                                                </div>
                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Other Tax</label>
                                                    <input
                                                        ref={otherTaxRef}
                                                        type="number"
                                                        value={detailForm.other_tax}
                                                        onChange={(e) => setDetailForm({ ...detailForm, other_tax: e.target.value })}
                                                        onFocus={(e) => e.target.select()}
                                                        onKeyDown={makeEnterToNext(detailSubmitRef)}
                                                        min="0" step="0.01"
                                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm"
                                                    />
                                                </div>
                                                <div className="col-span-2">
                                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">GST / Further Amt (preview)</label>
                                                    <div className="text-sm text-gray-600 px-2 py-1.5">
                                                        {detailPreview.gstAmount.toFixed(2)} / {detailPreview.furtherAmount.toFixed(2)}
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                    </form>
                                </div>

                                {/* Entries table */}
                                <div className="border-t border-gray-200 pt-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">Entries</h3>
                                    {isLoadingDetails ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">Loading...</div>
                                    ) : details.length === 0 ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">No entries yet</div>
                                    ) : (
                                        <div className="overflow-x-auto border border-gray-200 rounded-lg">
                                            <table className="min-w-full divide-y divide-gray-200 text-sm">
                                                <thead className="bg-gray-50">
                                                    <tr>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Entry No</th>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Item</th>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Details</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Pieces</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Net Weight</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Rate</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Total</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="bg-white divide-y divide-gray-100">
                                                    {details.map((row) => (
                                                        <tr key={row.id} className="hover:bg-gray-50">
                                                            <td className="px-2.5 py-1.5 text-gray-600">{row.entry_no}</td>
                                                            <td className="px-2.5 py-1.5 text-gray-800">{row.item_name || row.Item_code}</td>
                                                            <td className="px-2.5 py-1.5 text-gray-600">{row.details || '-'}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.pieces}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.net_weight}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.rate}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800 font-semibold">{row.total}</td>
                                                            <td className="px-2.5 py-1.5">
                                                                <div className="flex items-center justify-end gap-2">
                                                                    <button onClick={() => handleEditDetailRow(row)} title="Edit">
                                                                        <img src={editIcon} alt="Edit" className="w-4 h-4" />
                                                                    </button>
                                                                    <button onClick={() => handleDeleteDetail(row)} title="Delete">
                                                                        <img src={deleteIcon} alt="Delete" className="w-4 h-4" />
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                                <tfoot className="bg-gray-50 border-t-2 border-gray-200">
                                                    <tr>
                                                        <td className="px-2.5 py-1.5 font-semibold text-gray-700" colSpan={5}>
                                                            Total
                                                        </td>
                                                        <td className="px-2.5 py-1.5 text-right font-semibold text-gray-800">
                                                            {detailsTotals.total.toFixed(2)}
                                                        </td>
                                                        <td className="px-2.5 py-1.5"></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

export default SalesContractEntry;