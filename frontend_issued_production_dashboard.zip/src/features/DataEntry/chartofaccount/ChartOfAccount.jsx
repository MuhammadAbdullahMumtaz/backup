import { useState, useEffect, useMemo, useRef } from 'react';
import Modal from 'react-modal';
import { toast } from 'react-toastify';
import { useDispatch, useSelector } from 'react-redux';
import { setSystemNameIp } from '../../../store/slices/companySlice';
import { fetchClientSystemInfo } from '../../../utils/getSystemInfo';
import api from '../../../services/api'

import addIcon from '../../../assets/add.png';
import editIcon from '../../../assets/edit.png';
import searchIcon from '../../../assets/search.png';
import openIcon from '../../../assets/open.png';
import limitIcon from '../../../assets/limit.png';
import deleteIcon from '../../../assets/delete.png';

Modal.setAppElement('#root');

// =============================================================================
// API base URLs
// =============================================================================
const API = {
    financialYear: '/financial-year',
    balanceSheet: '/balance-sheet',
    mainCode: '/main-code',
    subCode: '/sub-code',
    chartOfAccount: '/chart-of-account',
    chartDetail: '/chart-detail',
    openingBalance: '/opening-balance',
};

function ChartOfAccount() {
    const dispatch = useDispatch();
    const {
        companyId: rawCompanyId,
        companyName,
        financialYearId: rawFinancialYearId,
        financialYearName,
        user,
        systemNameIp,
    } = useSelector((state) => state.company);

    const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== ''
        ? Number(rawCompanyId)
        : null;
    const financialYearId = rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ''
        ? Number(rawFinancialYearId)
        : null;

    // ---- Level 1: Balance Sheets - the ONLY thing fetched on mount --------
    const [balanceSheets, setBalanceSheets] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    const [mainCodesByBS, setMainCodesByBS] = useState({});
    const [subCodesByMC, setSubCodesByMC] = useState({});
    const [chartAccountsBySC, setChartAccountsBySC] = useState({});

    const [expandedKeys, setExpandedKeys] = useState(new Set());
    const [loadingKeys, setLoadingKeys] = useState(new Set());

    const [financialYears, setFinancialYears] = useState([]);
    const [financialYearsLoaded, setFinancialYearsLoaded] = useState(false);

    const [searchIndexLoaded, setSearchIndexLoaded] = useState(false);
    const [searchIndexLoading, setSearchIndexLoading] = useState(false);

    const [searchTerm, setSearchTerm] = useState('');
    const [searchSuggestions, setSearchSuggestions] = useState([]);
    const [highlightedParty, setHighlightedParty] = useState(null);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedSuggestionIndex, setHighlightedSuggestionIndex] = useState(-1);

    const [modalIsOpen, setModalIsOpen] = useState(false);
    const [modalType, setModalType] = useState('');
    const [selectedPartyId, setSelectedPartyId] = useState(null);
    const [entryFinancialYearId, setEntryFinancialYearId] = useState(null);
    const [partyOpeningBalances, setPartyOpeningBalances] = useState([]);
    const [partyChartDetail, setPartyChartDetail] = useState(null);
    const emptyDetails = { businessName: '', address: '', province: '', city: '', cellNo: '', incomeTaxNo: '', groupNo: '' };
    const [modalData, setModalData] = useState({ debit: 0, credit: 0, limit: 0, details: emptyDetails });

    // Refs for every rendered tree row, keyed by "type-id" (e.g.
    // "chart-of-account-14"). Used so we can scroll a highlighted row into
    // view - whether it got highlighted via search selection or because it
    // was just created and landed somewhere in the alphabetical list.
    const nodeRefs = useRef({});

    const fetchBalanceSheets = async () => {
        const res = await api.get(`${API.balanceSheet}/`, { params: { company_id: companyId } });
        const filtered = (res.data?.data || []).filter((bs) => bs.company_id === companyId);
        setBalanceSheets(filtered);
        return filtered;
    };

    useEffect(() => {
        if (!systemNameIp) {
            fetchClientSystemInfo().then((ip) => {
                if (ip) dispatch(setSystemNameIp(ip));
            });
        }
    }, []);

    // Small helper — spread this into every write payload
    const withMeta = (body = {}) => ({
        ...body,
        performed_by: user?.username || user?.name || 'Unknown',
        system_name_ip: systemNameIp,
    });

    useEffect(() => {
        if (!companyId) {
            setIsLoading(false);
            return;
        }
        (async () => {
            setIsLoading(true);
            try {
                await fetchBalanceSheets();
            } catch (error) {
                toast.error(error?.response?.data?.message || 'Failed to load Balance Sheet');
            } finally {
                setIsLoading(false);
            }
        })();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    const withLoadingKey = async (key, fn) => {
        setLoadingKeys((prev) => new Set(prev).add(key));
        try {
            return await fn();
        } finally {
            setLoadingKeys((prev) => {
                const next = new Set(prev);
                next.delete(key);
                return next;
            });
        }
    };

    const fetchMainCodesForBalanceSheet = async (bsId) => {
        return await withLoadingKey(`balance-sheet-${bsId}`, async () => {
            try {
                const res = await api.get(`${API.mainCode}/`, { params: { company_id: companyId, balancesheet_id: bsId } });
                const filtered = (res.data?.data || []).filter((mc) => mc.company_id === companyId && mc.balancesheet_id === bsId);
                setMainCodesByBS((prev) => ({ ...prev, [bsId]: filtered }));
                return filtered;
            } catch (error) {
                toast.error(error?.response?.data?.message || 'Failed to load Main Codes');
                return [];
            }
        });
    };

    const fetchSubCodesForMainCode = async (mcId) => {
        return await withLoadingKey(`main-code-${mcId}`, async () => {
            try {
                const res = await api.get(`${API.subCode}/`, { params: { company_id: companyId, maincode_id: mcId } });
                const filtered = (res.data?.data || []).filter((sc) => sc.company_id === companyId && sc.maincode_id === mcId);
                setSubCodesByMC((prev) => ({ ...prev, [mcId]: filtered }));
                return filtered;
            } catch (error) {
                toast.error(error?.response?.data?.message || 'Failed to load Sub Codes');
                return [];
            }
        });
    };

    const fetchChartAccountsForSubCode = async (scId, yearId) => {
        const cacheKey = `${scId}-${yearId}`;
        return await withLoadingKey(`sub-code-${scId}`, async () => {
            try {
                const res = await api.get(`${API.chartOfAccount}/`, {
                    params: { company_id: companyId, subcode_id: scId, financialyear_id: yearId },
                });
                const filtered = (res.data?.data || []).filter(
                    (coa) => coa.company_id === companyId && coa.subcode_id === scId && coa.financialyear_id === yearId
                );
                setChartAccountsBySC((prev) => ({ ...prev, [cacheKey]: filtered }));
                return filtered;
            } catch (error) {
                toast.error(error?.response?.data?.message || 'Failed to load Accounts');
                return [];
            }
        });
    };

    const toggleExpand = async (node) => {
        const key = `${node.type}-${node.id}`;
        if (expandedKeys.has(key)) {
            setExpandedKeys((prev) => {
                const next = new Set(prev);
                next.delete(key);
                return next;
            });
            return;
        }
        setExpandedKeys((prev) => new Set(prev).add(key));

        if (node.type === 'balance-sheet' && mainCodesByBS[node.id] === undefined) {
            await fetchMainCodesForBalanceSheet(node.id);
        } else if (node.type === 'main-code' && subCodesByMC[node.id] === undefined) {
            await fetchSubCodesForMainCode(node.id);
        } else if (node.type === 'sub-code' && financialYearId) {
            const cacheKey = `${node.id}-${financialYearId}`;
            if (chartAccountsBySC[cacheKey] === undefined) {
                await fetchChartAccountsForSubCode(node.id, financialYearId);
            }
        }
    };

    const getChildrenForNode = (node) => {
        if (node.type === 'balance-sheet') {
            const list = mainCodesByBS[node.id];
            if (list === undefined) return undefined;
            return list.map((mc) => ({ type: 'main-code', id: mc.id, name: mc.details, code: mc.code, raw: mc }));
        }
        if (node.type === 'main-code') {
            const list = subCodesByMC[node.id];
            if (list === undefined) return undefined;
            // No alphabetical sort here anymore - keep insertion/code order
            return list.map((sc) => ({ type: 'sub-code', id: sc.id, name: sc.details, code: sc.code, raw: sc }));
        }
        if (node.type === 'sub-code') {
            if (!financialYearId) return [];
            const list = chartAccountsBySC[`${node.id}-${financialYearId}`];
            if (list === undefined) return undefined;
            // Alphabetical sort applies ONLY here, on Chart Of Account.account_name
            return [...list]
                .sort((a, b) => a.account_name.localeCompare(b.account_name))
                .map((coa) => ({ type: 'chart-of-account', id: coa.id, name: coa.account_name, code: coa.code, raw: coa }));
        }
        return [];
    };

    const treeData = useMemo(
        () => balanceSheets.map((bs) => ({ type: 'balance-sheet', id: bs.id, name: bs.details, code: bs.code, raw: bs })),
        [balanceSheets]
    );

    const fetchFinancialYearsIfNeeded = async () => {
        if (financialYearsLoaded) return financialYears;
        try {
            const res = await api.get(`${API.financialYear}/`, { params: { company_id: companyId } });
            const filtered = (res.data?.data || []).filter((fy) => Number(fy.company_id) === companyId);
            setFinancialYears(filtered);
            setFinancialYearsLoaded(true);
            return filtered;
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load Financial Years');
            return [];
        }
    };

        const handleAdd = async (parentNode, newName) => {
        const name = newName.trim();
        if (!name) return;
        if (!companyId) { toast.error('Select a company first'); return; }

        try {
            if (!parentNode) {
                await api.post(`${API.balanceSheet}/`, withMeta({ company_id: companyId, details: name }));
                toast.success('Balance Sheet item added');
                await fetchBalanceSheets();
            } else if (parentNode.type === 'balance-sheet') {
                await api.post(`${API.mainCode}/`, withMeta({
                    company_id: companyId,
                    balancesheet_id: parentNode.id,
                    details: name,
                }));
                toast.success('Main Code added');
                await fetchMainCodesForBalanceSheet(parentNode.id);
                setExpandedKeys((prev) => new Set(prev).add(`balance-sheet-${parentNode.id}`));
            } else if (parentNode.type === 'main-code') {
                await api.post(`${API.subCode}/`, withMeta({
                    company_id: companyId,
                    maincode_id: parentNode.id,
                    details: name,
                }));
                toast.success('Sub Code added');
                await fetchSubCodesForMainCode(parentNode.id);
                setExpandedKeys((prev) => new Set(prev).add(`main-code-${parentNode.id}`));
            } else if (parentNode.type === 'sub-code') {
                if (!financialYearId) { toast.error('Select a financial year first'); return; }
                const cacheKey = `${parentNode.id}-${financialYearId}`;
                const previousAccounts = chartAccountsBySC[cacheKey] || [];
                const previousIds = new Set(previousAccounts.map((a) => a.id));

                await api.post(`${API.chartOfAccount}/`, withMeta({
                    company_id: companyId,
                    subcode_id: parentNode.id,
                    financialyear_id: financialYearId,
                    account_name: name,
                    budget: 0,
                }));
                toast.success('Account added');
                const updatedAccounts = await fetchChartAccountsForSubCode(parentNode.id, financialYearId);
                setExpandedKeys((prev) => new Set(prev).add(`sub-code-${parentNode.id}`));
                const newAccount = (updatedAccounts || []).find((a) => !previousIds.has(a.id));
                if (newAccount) setHighlightedParty(newAccount.id);
            }
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to add item');
        }
    };

        const handleUpdate = async (node, newName) => {
        const name = newName.trim();
        if (!name || name === node.name) return;

        try {
            if (node.type === 'balance-sheet') {
                await api.put(`${API.balanceSheet}/${node.id}`, withMeta({
                    company_id: node.raw.company_id,
                    details: name,
                }));
                await fetchBalanceSheets();
            } else if (node.type === 'main-code') {
                await api.put(`${API.mainCode}/${node.id}`, withMeta({
                    company_id: node.raw.company_id,
                    balancesheet_id: node.raw.balancesheet_id,
                    details: name,
                }));
                await fetchMainCodesForBalanceSheet(node.raw.balancesheet_id);
            } else if (node.type === 'sub-code') {
                await api.put(`${API.subCode}/${node.id}`, withMeta({
                    company_id: node.raw.company_id,
                    maincode_id: node.raw.maincode_id,
                    details: name,
                }));
                await fetchSubCodesForMainCode(node.raw.maincode_id);
            } else if (node.type === 'chart-of-account') {
                await api.put(`${API.chartOfAccount}/${node.id}`, withMeta({
                    company_id: node.raw.company_id,
                    subcode_id: node.raw.subcode_id,
                    financialyear_id: node.raw.financialyear_id,
                    account_name: name,
                    budget: node.raw.budget || 0,
                }));
                await fetchChartAccountsForSubCode(node.raw.subcode_id, node.raw.financialyear_id);
            }
            toast.success('Updated successfully');
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to update item');
        }
    };

    const handleDelete = async (node) => {
        if (!window.confirm(`Are you sure you want to delete "${node.name}?"`)) return;
        const urlByType = {
            'balance-sheet': API.balanceSheet,
            'main-code': API.mainCode,
            'sub-code': API.subCode,
            'chart-of-account': API.chartOfAccount,
        };

        try {
            await api.delete(`${urlByType[node.type]}/${node.id}`, { data: withMeta() });
            toast.success('Deleted successfully');
            if (node.type === 'balance-sheet') {
                await fetchBalanceSheets();
                setMainCodesByBS((prev) => {
                    const next = { ...prev };
                    delete next[node.id];
                    return next;
                });
            } else if (node.type === 'main-code') {
                await fetchMainCodesForBalanceSheet(node.raw.balancesheet_id);
                setSubCodesByMC((prev) => {
                    const next = { ...prev };
                    delete next[node.id];
                    return next;
                });
            } else if (node.type === 'sub-code') {
                await fetchSubCodesForMainCode(node.raw.maincode_id);
                setChartAccountsBySC((prev) => {
                    const next = { ...prev };
                    Object.keys(next).forEach((k) => {
                        if (k.startsWith(`${node.id}-`)) delete next[k];
                    });
                    return next;
                });
            } else if (node.type === 'chart-of-account') {
                await fetchChartAccountsForSubCode(node.raw.subcode_id, node.raw.financialyear_id);
            }
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete item');
        }
    };

    const loadSearchIndexIfNeeded = async () => {
        if (searchIndexLoaded || searchIndexLoading || !companyId) return;
        setSearchIndexLoading(true);
        try {
            const [mcRes, scRes, coaRes] = await Promise.all([
                api.get(`${API.mainCode}/`, { params: { company_id: companyId } }),
                api.get(`${API.subCode}/`, { params: { company_id: companyId } }),
                financialYearId
                    ? api.get(`${API.chartOfAccount}/`, { params: { company_id: companyId, financialyear_id: financialYearId } })
                    : Promise.resolve({ data: { data: [] } }),
            ]);

            const allMC = (mcRes.data?.data || []).filter((mc) => mc.company_id === companyId);
            const allSC = (scRes.data?.data || []).filter((sc) => sc.company_id === companyId);
            const allCOA = financialYearId
                ? (coaRes.data?.data || []).filter((coa) => coa.company_id === companyId && coa.financialyear_id === financialYearId)
                : [];

            setMainCodesByBS((prev) => {
                const next = { ...prev };
                balanceSheets.forEach((bs) => { next[bs.id] = []; });
                allMC.forEach((mc) => {
                    next[mc.balancesheet_id] = next[mc.balancesheet_id] || [];
                    next[mc.balancesheet_id].push(mc);
                });
                return next;
            });

            setSubCodesByMC((prev) => {
                const next = { ...prev };
                allMC.forEach((mc) => { next[mc.id] = []; });
                allSC.forEach((sc) => {
                    next[sc.maincode_id] = next[sc.maincode_id] || [];
                    next[sc.maincode_id].push(sc);
                });
                return next;
            });

            if (financialYearId) {
                setChartAccountsBySC((prev) => {
                    const next = { ...prev };
                    allSC.forEach((sc) => { next[`${sc.id}-${financialYearId}`] = []; });
                    allCOA.forEach((coa) => {
                        const key = `${coa.subcode_id}-${coa.financialyear_id}`;
                        next[key] = next[key] || [];
                        next[key].push(coa);
                    });
                    return next;
                });
            }

            setSearchIndexLoaded(true);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load search results');
        } finally {
            setSearchIndexLoading(false);
        }
    };

    const getAllParties = () => {
        const parties = [];
        balanceSheets.forEach((bs) => {
            const mcs = mainCodesByBS[bs.id] || [];
            mcs.forEach((mc) => {
                const scs = subCodesByMC[mc.id] || [];
                scs.forEach((sc) => {
                    const coas = chartAccountsBySC[`${sc.id}-${financialYearId}`] || [];
                    coas.forEach((coa) => {
                        parties.push({
                            id: coa.id,
                            name: coa.account_name,
                            code: coa.code,
                            path: [bs.details, mc.details, sc.details, coa.account_name],
                        });
                    });
                });
            });
        });
        return parties;
    };

    const expandPathToParty = (partyId) => {
        for (const bs of balanceSheets) {
            const mcs = mainCodesByBS[bs.id] || [];
            for (const mc of mcs) {
                const scs = subCodesByMC[mc.id] || [];
                for (const sc of scs) {
                    const coas = chartAccountsBySC[`${sc.id}-${financialYearId}`] || [];
                    if (coas.some((c) => c.id === partyId)) {
                        setExpandedKeys((prev) => {
                            const next = new Set(prev);
                            next.add(`balance-sheet-${bs.id}`);
                            next.add(`main-code-${mc.id}`);
                            next.add(`sub-code-${sc.id}`);
                            return next;
                        });
                        return;
                    }
                }
            }
        }
    };

    const selectSearchSuggestion = (party) => { // NEW
        setSearchTerm(party.name);
        setHighlightedParty(party.id);
        setShowSuggestions(false);
        setHighlightedSuggestionIndex(-1);
        expandPathToParty(party.id);
    };

    const handleSearchKeyDown = (e) => { // NEW
        if (!showSuggestions || searchSuggestions.length === 0) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedSuggestionIndex((prev) => (prev + 1) % searchSuggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedSuggestionIndex((prev) => (prev - 1 + searchSuggestions.length) % searchSuggestions.length);
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightedSuggestionIndex >= 0 && highlightedSuggestionIndex < searchSuggestions.length) {
                selectSearchSuggestion(searchSuggestions[highlightedSuggestionIndex]);
            }
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    useEffect(() => {
        if (searchTerm.trim() === '') {
            setSearchSuggestions([]);
            setShowSuggestions(false);
            return;
        }
        if (!searchIndexLoaded) {
            loadSearchIndexIfNeeded();
            return;
        }
        const allParties = getAllParties();
        const term = searchTerm.toLowerCase();
        const filtered = allParties.filter(
            (party) =>
                party.name.toLowerCase().includes(term) ||
                (party.code && party.code.toLowerCase().includes(term))
        );
        setSearchSuggestions(filtered);
        setShowSuggestions(true);
        setHighlightedParty(filtered.length > 0 ? filtered[0].id : null);
        setHighlightedSuggestionIndex(filtered.length > 0 ? 0 : -1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchTerm, searchIndexLoaded, mainCodesByBS, subCodesByMC, chartAccountsBySC, balanceSheets]);

    useEffect(() => {
        if (searchTerm.trim() === '') {
            setHighlightedParty(null);
        }
    }, [searchTerm]);

    useEffect(() => {
        if (!highlightedParty) return;
        const key = `chart-of-account-${highlightedParty}`;
        const timer = setTimeout(() => {
            nodeRefs.current[key]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 150);
        return () => clearTimeout(timer);
    }, [highlightedParty, expandedKeys, chartAccountsBySC]);

    const findChartOfAccountById = (id) => {
        for (const key of Object.keys(chartAccountsBySC)) {
            const found = chartAccountsBySC[key].find((c) => c.id === id);
            if (found) return found;
        }
        return null;
    };

    const fetchOpeningBalancesForParty = async (partyId) => {
        try {
            const res = await api.get(`${API.openingBalance}/`, { params: { chartofaccount_id: partyId } });
            const filtered = (res.data?.data || []).filter((ob) => ob.chartofaccount_id === partyId);
            setPartyOpeningBalances(filtered);
            return filtered;
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load opening balances');
            return [];
        }
    };

    const fetchChartDetailForParty = async (partyId) => {
        try {
            const res = await api.get(`${API.chartDetail}/`, { params: { chartofaccount_id: partyId } });
            const found = (res.data?.data || []).find((cd) => cd.chartofaccount_id === partyId) || null;
            setPartyChartDetail(found);
            return found;
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load party details');
            return null;
        }
    };

    const openModal = async (partyId, type) => {
        const account = findChartOfAccountById(partyId);
        setSelectedPartyId(partyId);
        setModalType(type);
        setModalData({ debit: 0, credit: 0, limit: 0, details: emptyDetails });
        setModalIsOpen(true);

        if (type === 'transaction') {
            await fetchFinancialYearsIfNeeded();
            setEntryFinancialYearId(financialYearId);
            const balances = await fetchOpeningBalancesForParty(partyId);
            const existingForYear = balances.find((ob) => ob.financialyear_id === financialYearId);
            setModalData({
                debit: existingForYear?.debit || 0,
                credit: existingForYear?.credit || 0,
                limit: 0,
                details: emptyDetails,
            });
        } else if (type === 'limit') {
            setModalData({ debit: 0, credit: 0, limit: account?.budget || 0, details: emptyDetails });
        } else if (type === 'details') {
            const detail = await fetchChartDetailForParty(partyId);
            setModalData({
                debit: 0,
                credit: 0,
                limit: 0,
                details: {
                    businessName: detail?.business_name || '',
                    address: detail?.address || '',
                    province: detail?.province || '',
                    city: detail?.city || '',
                    cellNo: detail?.cell_no || '',
                    incomeTaxNo: detail?.income_tax_no || '',
                    groupNo: detail?.group_no || '',
                },
            });
        }
    };

    const closeModal = () => {
        setModalIsOpen(false);
        setSelectedPartyId(null);
        setModalType('');
        setEntryFinancialYearId(null);
        setPartyOpeningBalances([]);
        setPartyChartDetail(null);
    };

    const loadBalanceForYear = (partyId, yearId) => {
        setEntryFinancialYearId(yearId);
        const existing = partyOpeningBalances.find((ob) => ob.financialyear_id === yearId);
        setModalData((prev) => ({ ...prev, debit: existing?.debit || 0, credit: existing?.credit || 0 }));
    };

    const handleDeleteBalanceEntry = async (entry) => {
        if (!window.confirm(`Delete the ${entry.year_detail} entry?`)) return;
        try {
            await api.delete(`${API.openingBalance}/${entry.id}`, { data: withMeta() });
            toast.success('Entry deleted');
            await fetchOpeningBalancesForParty(selectedPartyId);
            if (entry.financialyear_id === entryFinancialYearId) {
                setModalData((prev) => ({ ...prev, debit: 0, credit: 0 }));
            }
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete entry');
        }
    };

    const handleModalSave = async () => {
        if (!selectedPartyId) return;

        try {
            if (modalType === 'transaction') {
                const { debit, credit } = modalData;
                if (debit > 0 && credit > 0) {
                    toast.error('You can only enter either Debit or Credit, not both!');
                    return;
                }
                if (!entryFinancialYearId) {
                    toast.error('Select a financial year first');
                    return;
                }
                const existingBalance = partyOpeningBalances.find((ob) => ob.financialyear_id === entryFinancialYearId);
                const payload = withMeta({
                    company_id: companyId,
                    chartofaccount_id: selectedPartyId,
                    financialyear_id: entryFinancialYearId,
                    debit,
                    credit,
                });
                if (existingBalance) {
                    await api.put(`${API.openingBalance}/${existingBalance.id}`, payload);
                } else {
                    await api.post(`${API.openingBalance}/`, payload);
                }
                await fetchOpeningBalancesForParty(selectedPartyId);
                toast.success('Opening balance saved');
            } else if (modalType === 'limit') {
                const account = findChartOfAccountById(selectedPartyId);
                if (!account) return;
                await api.put(`${API.chartOfAccount}/${selectedPartyId}`, withMeta({
                    company_id: account.company_id,
                    subcode_id: account.subcode_id,
                    financialyear_id: account.financialyear_id,
                    account_name: account.account_name,
                    budget: modalData.limit,
                }));
                await fetchChartAccountsForSubCode(account.subcode_id, account.financialyear_id);
                toast.success('Limit saved');
            } else if (modalType === 'details') {
                const payload = withMeta({
                    company_id: companyId,
                    chartofaccount_id: selectedPartyId,
                    business_name: modalData.details.businessName,
                    address: modalData.details.address,
                    province: modalData.details.province,
                    city: modalData.details.city,
                    cell_no: modalData.details.cellNo,
                    income_tax_no: modalData.details.incomeTaxNo,
                    group_no: modalData.details.groupNo,
                });
                if (partyChartDetail) {
                    await api.put(`${API.chartDetail}/${partyChartDetail.id}`, payload);
                } else {
                    await api.post(`${API.chartDetail}/`, payload);
                }
                await fetchChartDetailForParty(selectedPartyId);
                toast.success('Party details saved');
            }
            if (modalType !== 'transaction') closeModal();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save, please try again');
        }
    };

    const handleModalDelete = async () => {
        if (!selectedPartyId) return;
        if (!window.confirm('Are you sure you want to delete this data?')) return;

        try {
            if (modalType === 'transaction') {
                const existingBalance = partyOpeningBalances.find((ob) => ob.financialyear_id === entryFinancialYearId);
                if (existingBalance) {
                    await api.delete(`${API.openingBalance}/${existingBalance.id}`, { data: withMeta() });
                    await fetchOpeningBalancesForParty(selectedPartyId);
                }
                setModalData((prev) => ({ ...prev, debit: 0, credit: 0 }));
            } else if (modalType === 'limit') {
                const account = findChartOfAccountById(selectedPartyId);
                if (account) {
                    await api.put(`${API.chartOfAccount}/${selectedPartyId}`, withMeta({
                        company_id: account.company_id,
                        subcode_id: account.subcode_id,
                        financialyear_id: account.financialyear_id,
                        account_name: account.account_name,
                        budget: 0,
                    }));
                    await fetchChartAccountsForSubCode(account.subcode_id, account.financialyear_id);
                }
            } else if (modalType === 'details') {
                if (partyChartDetail) {
                    await api.delete(`${API.chartDetail}/${partyChartDetail.id}`, { data: withMeta() });
                    setPartyChartDetail(null);
                }
            }
            toast.success('Deleted successfully');
            if (modalType !== 'transaction') closeModal();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete, please try again');
        }
    };

    const TreeNode = ({ node, level = 0 }) => {
        const [isAdding, setIsAdding] = useState(false);
        const [newName, setNewName] = useState('');
        const [isEditing, setIsEditing] = useState(false);
        const [editName, setEditName] = useState(node.name);

        const isPartyLevel = node.type === 'chart-of-account';
        const isTopLevel = node.type === 'balance-sheet';
        const canExpand = !isPartyLevel;

        const nodeKey = `${node.type}-${node.id}`;
        const isExpanded = expandedKeys.has(nodeKey);
        const isLoadingChildren = loadingKeys.has(nodeKey);
        const children = canExpand ? getChildrenForNode(node) : [];
        const hasManyParties = node.type === 'sub-code' && children && children.length >= 3;

        const handleAddSubmit = (e) => {
            e.preventDefault();
            if (newName.trim()) {
                handleAdd(node, newName);
                setNewName('');
                setIsAdding(false);
            }
        };

        const handleUpdateSubmit = (e) => {
            e.preventDefault();
            if (editName.trim() && editName !== node.name) {
                handleUpdate(node, editName);
            }
            setIsEditing(false);
        };

        const handleKeyDown = (e) => {
            if (e.key === 'Escape') {
                setIsAdding(false);
                setIsEditing(false);
                setNewName('');
                setEditName(node.name);
            }
        };

        const isHighlighted = highlightedParty === node.id && isPartyLevel;

        const getSearchHighlight = (name) => {
            if (!searchTerm.trim()) return name;
            const index = name.toLowerCase().indexOf(searchTerm.toLowerCase());
            if (index === -1) return name;
            const before = name.substring(0, index);
            const match = name.substring(index, index + searchTerm.length);
            const after = name.substring(index + searchTerm.length);
            return (
                <>
                    {before}
                    <span className="bg-yellow-200 px-0.5 rounded">{match}</span>
                    {after}
                </>
            );
        };

        return (
            <div className="relative">
                <div
                    ref={(el) => {
                        if (el) nodeRefs.current[nodeKey] = el;
                        else delete nodeRefs.current[nodeKey];
                    }}
                    className={`flex items-center py-1.5 hover:bg-gray-50 rounded transition-colors ${isHighlighted ? 'bg-yellow-100 border-l-4 border-yellow-400' : ''
                        }`}
                    style={{ paddingLeft: `${Math.min(level * 20, 80)}px` }}
                >
                    {canExpand && (
                        <button
                            onClick={() => toggleExpand(node)}
                            className="mr-1 text-gray-400 hover:text-gray-600 focus:outline-none"
                        >
                            {isLoadingChildren ? (
                                <svg className="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                </svg>
                            ) : (
                                <svg
                                    className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                </svg>
                            )}
                        </button>
                    )}

                    {isEditing ? (
                        <form onSubmit={handleUpdateSubmit} className="flex items-center flex-1">
                            <input
                                type="text"
                                value={editName}
                                onChange={(e) => setEditName(e.target.value)}
                                onBlur={handleUpdateSubmit}
                                onKeyDown={handleKeyDown}
                                className="border border-blue-400 rounded px-2 py-0.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300 flex-1 max-w-xs"
                                autoFocus
                            />
                        </form>
                    ) : (
                        <>
                            <span className={`text-sm ${isTopLevel ? 'font-semibold text-gray-800' : 'text-gray-700'}`}>
                                {node.code ? `${node.code} - ` : ''}
                                {isHighlighted ? getSearchHighlight(node.name) : node.name}
                            </span>

                            <div className="flex items-center ml-2 space-x-1">
                                {!isPartyLevel && (
                                    <button
                                        onClick={() => setIsAdding(true)}
                                        className="p-1 hover:bg-gray-200 rounded transition-colors"
                                        title="Add new item"
                                    >
                                        <img src={addIcon} alt="Add" className="w-4 h-4" />
                                    </button>
                                )}

                                {/* Icon order for account_name (party) rows:
                                    edit -> search/account details -> opening
                                    balance (open) -> limit/budget -> delete */}
                                <button
                                    onClick={() => setIsEditing(true)}
                                    className="p-1 hover:bg-gray-200 rounded transition-colors"
                                    title="Update"
                                >
                                    <img src={editIcon} alt="Update" className="w-4 h-4" />
                                </button>

                                {isPartyLevel && (
                                    <>
                                        <button
                                            onClick={() => openModal(node.id, 'details')}
                                            className="p-1 hover:bg-gray-200 rounded transition-colors"
                                            title="Search - Party Details"
                                        >
                                            <img src={searchIcon} alt="Search" className="w-4 h-4" />
                                        </button>
                                        <button
                                            onClick={() => openModal(node.id, 'transaction')}
                                            className="p-1 hover:bg-gray-200 rounded transition-colors"
                                            title="Open - Debit/Credit"
                                        >
                                            <img src={openIcon} alt="Open" className="w-4 h-4" />
                                        </button>
                                        <button
                                            onClick={() => openModal(node.id, 'limit')}
                                            className="p-1 hover:bg-gray-200 rounded transition-colors"
                                            title="Limit (Budget)"
                                        >
                                            <img src={limitIcon} alt="Limit" className="w-4 h-4" />
                                        </button>
                                    </>
                                )}

                                <button
                                    onClick={() => handleDelete(node)}
                                    className="p-1 hover:bg-gray-200 rounded transition-colors"
                                    title="Delete"
                                >
                                    <img src={deleteIcon} alt="Delete" className="w-4 h-4" />
                                </button>
                            </div>
                        </>
                    )}
                </div>

                {isAdding && (
                    <div className="mt-1" style={{ paddingLeft: `${Math.min((level + 1) * 20, 100)}px` }}>
                        <form onSubmit={handleAddSubmit} className="flex items-center">
                            <input
                                type="text"
                                value={newName}
                                onChange={(e) => setNewName(e.target.value)}
                                onBlur={handleAddSubmit}
                                onKeyDown={handleKeyDown}
                                placeholder="Enter name..."
                                className="border border-blue-400 rounded px-2 py-0.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300 w-48"
                                autoFocus
                            />
                        </form>
                    </div>
                )}

                {isExpanded && canExpand && (
                    <div className="ml-4">
                        {node.type === 'sub-code' && !financialYearId ? (
                            <div className="text-xs text-amber-600 py-1" style={{ paddingLeft: `${Math.min((level + 1) * 20, 100)}px` }}>
                                Select a financial year to view accounts.
                            </div>
                        ) : isLoadingChildren || children === undefined ? (
                            <div className="text-xs text-gray-400 py-1" style={{ paddingLeft: `${Math.min((level + 1) * 20, 100)}px` }}>
                                Loading...
                            </div>
                        ) : children.length === 0 ? (
                            <div className="text-xs text-gray-400 py-1" style={{ paddingLeft: `${Math.min((level + 1) * 20, 100)}px` }}>
                                No items yet.
                            </div>
                        ) : (
                            <div className={hasManyParties ? 'max-h-48 overflow-y-auto scrollbar-thin' : ''}>
                                {children.map((child) => (
                                    <TreeNode key={`${child.type}-${child.id}`} node={child} level={level + 1} />
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="bg-gray-50 p-4">
            <div className="max-w-5xl mx-auto">
                <div className="mb-2">
                    <h1 className="text-2xl font-bold text-gray-800">Chart Of Account</h1>
                </div>
                {!companyId ? (
                    <div className="bg-white rounded-lg shadow-sm p-8 border border-gray-200 text-center text-gray-500 text-sm">
                        No company context found. Please select a company first.
                    </div>
                ) : (
                    <>
                        {!financialYearId && (
                            <div className="mb-4 text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-md px-3 py-2 max-w-md">
                                No financial year selected. Balance Sheet / Main Code / Sub Code items are
                                shared across years, but accounts (the party level) need a financial year.
                            </div>
                        )}

                        <div className="mb-2 relative">
                            <div className="max-w-md mx-auto">
                                <div className="relative">
                                    <input
                                        type="text"
                                        placeholder="Search for parties..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        onFocus={(e) => {
                                            searchTerm.trim() && setShowSuggestions(true);
                                            e.target.select();
                                        }}
                                        onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                                        onKeyDown={handleSearchKeyDown}
                                        className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none"
                                    />
                                    <svg className="absolute left-3 top-2.5 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                    </svg>
                                </div>

                                {searchIndexLoading && (
                                    <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg p-3 text-sm text-gray-500 text-center mx-auto max-w-md">
                                        Searching...
                                    </div>
                                )}

                                {!searchIndexLoading && showSuggestions && searchSuggestions.length > 0 && (
                                    <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto z-10 mx-auto max-w-md">
                                        {searchSuggestions.map((party, index) => (
                                            <div
                                                key={party.id}
                                                className={`px-4 py-2 cursor-pointer flex items-center text-sm border-b border-gray-100 last:border-0 ${index === highlightedSuggestionIndex ? 'bg-blue-100' : 'hover:bg-blue-50'
                                                    }`} 
                                                onMouseEnter={() => setHighlightedSuggestionIndex(index)} 
                                                onClick={() => selectSearchSuggestion(party)} 
                                            >
                                                <span className="font-medium">
                                                    {party.code ? `${party.code} - ` : ''}
                                                    {party.name}
                                                </span>
                                                <span className="ml-2 text-xs text-gray-400">{party.path.slice(0, -1).join(' → ')}</span>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                {!searchIndexLoading && showSuggestions && searchSuggestions.length === 0 && searchTerm.trim() && (
                                    <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg p-3 text-sm text-gray-500 text-center mx-auto max-w-md">
                                        No parties found
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                            {isLoading ? (
                                <div className="py-12 text-center text-gray-500 text-sm">Loading Balance Sheet...</div>
                            ) : (
                                <>
                                    {treeData.map((node) => (
                                        <TreeNode key={`${node.type}-${node.id}`} node={node} level={0} />
                                    ))}

                                    <div className="mt-4 pt-4 border-t border-gray-200">
                                        <button
                                            onClick={() => {
                                                const newName = prompt('Enter new Item Main name:');
                                                if (newName && newName.trim()) {
                                                    handleAdd(null, newName.trim());
                                                }
                                            }}
                                            className="flex items-center text-blue-500 hover:text-blue-600 transition-colors py-1 px-2 rounded hover:bg-blue-50"
                                            title="Add new Item Main"
                                        >
                                            <img src={addIcon} alt="Add" className="w-4 h-4 mr-1" />
                                            <span className="text-sm font-medium">Add Item Main</span>
                                        </button>
                                    </div>
                                </>
                            )}
                        </div>
                    </>
                )}
            </div>

            <Modal
                isOpen={modalIsOpen}
                onRequestClose={closeModal}
                contentLabel="Party Data Entry"
                className="fixed inset-0 flex items-center justify-center z-50"
                overlayClassName="fixed inset-0 bg-black bg-opacity-50 z-40"
                style={{
                    content: {
                        position: 'fixed',
                        inset: '0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        background: 'transparent',
                        border: 'none',
                        padding: '0',
                    },
                    overlay: {
                        position: 'fixed',
                        inset: '0',
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: '40',
                    }
                }}
            >
                <div className="bg-white rounded-lg shadow-2xl max-w-md w-full mx-4 p-6 relative">
                    <h2 className="text-xl font-bold mb-4 text-gray-800">
                        {modalType === 'transaction' && 'Debit / Credit Entry'}
                        {modalType === 'limit' && 'Set Limit (Budget)'}
                        {modalType === 'details' && 'Party Details'}
                    </h2>

                    {modalType === 'transaction' && (
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Financial Year</label>
                                <select
                                    value={entryFinancialYearId ?? ''}
                                    onChange={(e) => loadBalanceForYear(selectedPartyId, Number(e.target.value))}
                                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                                >
                                    <option value="">Select a financial year</option>
                                    {financialYears.map((fy) => (
                                        <option key={fy.id} value={fy.id}>
                                            {fy.year_detail}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Debit Amount</label>
                                <input
                                    type="number"
                                    value={modalData.debit || ''}
                                    onChange={(e) => {
                                        const value = parseFloat(e.target.value) || 0;
                                        setModalData({ ...modalData, debit: value, credit: value > 0 ? 0 : modalData.credit });
                                    }}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter debit amount"
                                    min="0"
                                    step="0.01"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Credit Amount</label>
                                <input
                                    type="number"
                                    value={modalData.credit || ''}
                                    onChange={(e) => {
                                        const value = parseFloat(e.target.value) || 0;
                                        setModalData({ ...modalData, credit: value, debit: value > 0 ? 0 : modalData.debit });
                                    }}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter credit amount"
                                    min="0"
                                    step="0.01"
                                />
                            </div>
                            <div className="text-xs text-gray-500">* Only one field can have a value at a time</div>

                            {partyOpeningBalances.length > 0 && (
                                <div className="border-t border-gray-200 pt-3">
                                    <p className="text-xs font-semibold text-gray-500 mb-2">Existing entries</p>
                                    <div className="space-y-1 max-h-32 overflow-y-auto">
                                        {partyOpeningBalances.map((entry) => (
                                            <div
                                                key={entry.id}
                                                className={`flex items-center justify-between text-sm px-2 py-1 rounded cursor-pointer ${entry.financialyear_id === entryFinancialYearId
                                                    ? 'bg-blue-50 text-blue-700'
                                                    : 'hover:bg-gray-50 text-gray-600'
                                                    }`}
                                                onClick={() => loadBalanceForYear(selectedPartyId, entry.financialyear_id)}
                                            >
                                                <span>{entry.year_detail}</span>
                                                <span className="flex items-center gap-2">
                                                    <span>
                                                        {entry.debit > 0 ? `Dr ${entry.debit}` : entry.credit > 0 ? `Cr ${entry.credit}` : '-'}
                                                    </span>
                                                    <button
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleDeleteBalanceEntry(entry);
                                                        }}
                                                        className="text-red-500 hover:text-red-700 text-xs"
                                                        title="Delete this entry"
                                                    >
                                                        ✕
                                                    </button>
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    {modalType === 'limit' && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Limit / Budget Amount</label>
                            <input
                                type="number"
                                value={modalData.limit || ''}
                                onChange={(e) => setModalData({ ...modalData, limit: parseFloat(e.target.value) || 0 })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                placeholder="Enter limit amount"
                                min="0"
                                step="0.01"
                            />
                            <p className="text-xs text-gray-400 mt-1">
                                Stored on the account's <code>budget</code> column - there's no dedicated limit table.
                            </p>
                        </div>
                    )}

                    {modalType === 'details' && (
                        <div className="space-y-3 max-h-80 overflow-y-auto">
                            {[
                                ['businessName', 'Business Name'],
                                ['address', 'Address'],
                                ['province', 'Province'],
                                ['city', 'City'],
                                ['cellNo', 'Cell No.'],
                                ['incomeTaxNo', 'Income Tax No.'],
                                ['groupNo', 'Group No.'],
                            ].map(([key, label]) => (
                                <div key={key}>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
                                    <input
                                        type="text"
                                        value={modalData.details[key] || ''}
                                        onChange={(e) =>
                                            setModalData({ ...modalData, details: { ...modalData.details, [key]: e.target.value } })
                                        }
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                        placeholder={`Enter ${label.toLowerCase()}`}
                                    />
                                </div>
                            ))}
                        </div>
                    )}

                    <div className="flex justify-end space-x-3 mt-6 pt-4 border-t border-gray-200">
                        <button
                            onClick={handleModalDelete}
                            className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-md transition-colors flex items-center"
                        >
                            <img src={deleteIcon} alt="Delete" className="w-4 h-4 inline mr-1" />
                            Delete
                        </button>
                        <button onClick={closeModal} className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md transition-colors">
                            Cancel
                        </button>
                        <button
                            onClick={handleModalSave}
                            className="px-4 py-2 bg-blue-500 text-white hover:bg-blue-600 rounded-md transition-colors"
                        >
                            Save
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
}

export default ChartOfAccount;