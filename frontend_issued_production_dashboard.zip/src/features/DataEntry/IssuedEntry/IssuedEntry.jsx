import React, { useState, useEffect, useMemo, useRef } from 'react';
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from 'react-redux';
import api from '../../../services/api'
import { setSystemNameIp } from '../../../store/slices/companySlice';
import { fetchClientSystemInfo } from '../../../utils/getSystemInfo';

import editIcon from '../../../assets/edit.png';
import deleteIcon from '../../../assets/delete.png';

const ENDPOINTS = {
    main: '/issued-main',
    detail: '/issued-detail',
    detailByMainPath: (mainId) => `/issued-detail/issued/${mainId}`,
    availableStock: '/issued-detail/available-stock',
};

const LOOKUP_API = {
    itemDetail: '/item-detail',
    subItem: '/sub-item',
    department: '/department',
};

const todayStr = () => new Date().toISOString().slice(0, 10);

const isoToDisplayDate = (iso) => {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    if (!y || !m || !d) return '';
    return `${d}-${m}-${y}`;
};

const displayDateToIso = (display) => {
    if (!display) return '';
    const parts = display.split('-');
    if (parts.length !== 3) return '';
    const [d, m, y] = parts;
    if (!d || !m || !y || y.length !== 4) return '';
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
};

const dbDateToIso = (raw) => {
    if (!raw) return '';
    const str = String(raw);
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
    const d = new Date(raw);
    if (isNaN(d.getTime())) return str.slice(0, 10);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
};

const trailingNumber = (code) => {
    const match = String(code ?? '').match(/(\d+)(?!.*\d)/);
    return match ? parseInt(match[1], 10) : NaN;
};

const EMPTY_MAIN_FORM = {
    issued_date: isoToDisplayDate(todayStr()),
    department_id: '',
    remarks: '',
};

// NOTE: gross_weight / tear_weight exist on IssuedDetail but are not used
// yet - intentionally left out of this form so they stay hidden until
// they're actually needed.
const EMPTY_DETAIL_FORM = {
    subitem_code: '',
    Item_code: '',
    pieces: 0,
    net_weight: 0,
};

const focusAndSelect = (ref) => {
    if (!ref || !ref.current) return;
    ref.current.focus();
    if (typeof ref.current.select === 'function') {
        ref.current.select();
    }
};

const makeEnterToNext = (nextRef) => (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    focusAndSelect(nextRef);
};

// Same SearchField pattern used across Purchase/Sales Entry.
const SearchField = React.forwardRef(({ label, value, onChange, options, codeKey, labelKey, placeholder, disabled, showAllOnFocus, onEnterNext }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = term
        ? options
            .filter(
                (opt) =>
                    String(opt[labelKey] ?? '').toLowerCase().includes(term) ||
                    String(opt[codeKey] ?? '').includes(term)
            )
            .slice(0, 8)
        : (showAllOnFocus ? options.slice(0, 8) : []);

    const matched = options.find((opt) => String(opt[codeKey]) === term);

    useEffect(() => {
        setHighlightedIndex(suggestions.length > 0 ? 0 : -1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectSuggestion = (opt) => {
        onChange(String(opt[codeKey]));
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (showSuggestions && suggestions.length > 0 && highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
                selectSuggestion(suggestions[highlightedIndex]);
            } else {
                setShowSuggestions(false);
            }
            onEnterNext && onEnterNext();
            return;
        }
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev + 1) % suggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div>
            {label && <label className="block text-xs font-medium text-gray-600 mb-0.5">{label}</label>}
            <div className="relative">
                <input
                    ref={ref}
                    type="text"
                    value={value ?? ''}
                    disabled={disabled}
                    onChange={(e) => {
                        onChange(e.target.value);
                        setShowSuggestions(true);
                    }}
                    onFocus={(e) => {
                        if ((value ?? '').toString().trim() || showAllOnFocus) setShowSuggestions(true);
                        e.target.select();
                    }}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-400"
                    placeholder={placeholder || 'Search'}
                />
                {matched && (
                    <div className="text-[11px] text-blue-800 font-bold mt-0.5 truncate px-2 py-0.5 rounded">→ {matched[labelKey]}</div>
                )}
                {showSuggestions && suggestions.length > 0 && (
                    <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-20">
                        {suggestions.map((opt, index) => (
                            <div
                                key={opt[codeKey]}
                                className={`px-2.5 py-1.5 cursor-pointer text-sm flex items-center justify-between border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-100' : 'hover:bg-blue-50'}`}
                                onMouseEnter={() => setHighlightedIndex(index)}
                                onMouseDown={() => selectSuggestion(opt)}
                            >
                                <span className="font-medium">{opt[labelKey]}</span>
                                {codeKey !== labelKey && (
                                    <span className="text-xs font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded ml-4">
                                        {opt[codeKey]}
                                    </span>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
});

// Doc-No field for loading an existing issued entry, same pattern as
// Purchase/Sales Entry's DocSearchField.
const DocSearchField = React.forwardRef(({ value, onChange, options, onSelectExisting, onSelectNew, numberKey, newLabel, placeholder, onEnterNext }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = options
        .filter(
            (opt) =>
                String(opt[numberKey] ?? '').toLowerCase().includes(term) ||
                String(opt.department_name ?? '').toLowerCase().includes(term) ||
                String(opt.doc_date_display ?? '').toLowerCase().includes(term)
        )
        .slice(0, 8);

    useEffect(() => {
        setHighlightedIndex(-1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectNew = () => {
        onSelectNew();
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };
    const selectExisting = (opt) => {
        onSelectExisting(opt);
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (!showSuggestions) {
            if (e.key === 'Enter') {
                e.preventDefault();
                onEnterNext && onEnterNext();
            }
            return;
        }
        const minIndex = -1;
        const maxIndex = suggestions.length - 1;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev >= maxIndex ? minIndex : prev + 1));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev <= minIndex ? maxIndex : prev - 1));
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightedIndex === -1) selectNew();
            else if (highlightedIndex >= 0 && highlightedIndex < suggestions.length) selectExisting(suggestions[highlightedIndex]);
            onEnterNext && onEnterNext();
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div className="relative">
            <input
                ref={ref}
                type="text"
                value={value ?? ''}
                onChange={(e) => {
                    onChange(e.target.value);
                    setShowSuggestions(true);
                }}
                onFocus={(e) => {
                    setShowSuggestions(true);
                    e.target.select();
                }}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                onKeyDown={handleKeyDown}
                className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                placeholder={placeholder}
            />
            {showSuggestions && (
                <div className="absolute left-0 mt-1 w-[420px] max-w-[90vw] bg-white border border-gray-200 rounded-lg shadow-lg max-h-56 overflow-y-auto z-30">
                    <div
                        className={`px-2.5 py-1.5 cursor-pointer text-sm font-semibold text-blue-600 border-b border-gray-100 ${highlightedIndex === -1 ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                        onMouseEnter={() => setHighlightedIndex(-1)}
                        onMouseDown={selectNew}
                    >
                        {newLabel}
                    </div>
                    {suggestions.map((opt, index) => (
                        <div
                            key={opt.id}
                            className={`px-2.5 py-1.5 cursor-pointer text-sm grid grid-cols-3 gap-2 border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                            onMouseEnter={() => setHighlightedIndex(index)}
                            onMouseDown={() => selectExisting(opt)}
                        >
                            <span className="font-medium truncate">{opt[numberKey]}</span>
                            <span className="text-gray-600 truncate">{opt.department_name}</span>
                            <span className="text-gray-400 text-xs">{opt.doc_date_display}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
});

function IssuedEntry({ navPayload, onNavPayloadConsumed, onBack }) {
    const dispatch = useDispatch();
    const {
        companyId: rawCompanyId,
        financialYearId: rawFinancialYearId,
        user,
        systemNameIp,
    } = useSelector((state) => state.company);

    useEffect(() => {
        if (!systemNameIp) {
            fetchClientSystemInfo().then((ip) => {
                if (ip) dispatch(setSystemNameIp(ip));
            });
        }
    }, []);

    const withMeta = (body = {}) => ({
        ...body,
        performed_by: user?.username || user?.name || 'Unknown',
        system_name_ip: systemNameIp,
    });

    const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== ''
        ? Number(rawCompanyId)
        : null;
    const financialYearId = rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ''
        ? Number(rawFinancialYearId)
        : null;

    // ---- Main doc ----
    const [mainForm, setMainForm] = useState(EMPTY_MAIN_FORM);
    const [mainId, setMainId] = useState(null);
    const [issuedNo, setIssuedNo] = useState('');
    const [isSavingMain, setIsSavingMain] = useState(false);

    const [existingMains, setExistingMains] = useState([]);
    const [isLoadingMains, setIsLoadingMains] = useState(false);

    // ---- Departments ----
    const [departments, setDepartments] = useState([]);
    const [departmentsLoaded, setDepartmentsLoaded] = useState(false);

    // ---- Sub Item / Item lookups ----
    const [subItems, setSubItems] = useState([]);
    const [subItemsLoaded, setSubItemsLoaded] = useState(false);
    const [items, setItems] = useState([]);
    const [itemsLoaded, setItemsLoaded] = useState(false);

    // ---- Details ----
    const [details, setDetails] = useState([]);
    const [isLoadingDetails, setIsLoadingDetails] = useState(false);
    const [detailForm, setDetailForm] = useState(EMPTY_DETAIL_FORM);
    const [editingDetailId, setEditingDetailId] = useState(null);
    const [isSavingDetail, setIsSavingDetail] = useState(false);

    const [availableLots, setAvailableLots] = useState([]);
    const [isLoadingLots, setIsLoadingLots] = useState(false);
    const [showStockDetails, setShowStockDetails] = useState(false);

    useEffect(() => {
        setShowStockDetails(false);
    }, [detailForm.Item_code]);

    // ---- Refs ----
    const docNoRef = useRef(null);
    const mainDateRef = useRef(null);
    const mainDepartmentRef = useRef(null);
    const mainRemarksRef = useRef(null);
    const mainSubmitRef = useRef(null);

    const itemSubRef = useRef(null);
    const itemNameRef = useRef(null);
    const piecesRef = useRef(null);
    const netWeightRef = useRef(null);
    const detailSubmitRef = useRef(null);

    const lastNavPayloadRef = useRef(null);

    useEffect(() => {
        if (!navPayload) return;
        if (lastNavPayloadRef.current === navPayload) return;
        const targetNo = navPayload.issued_no;
        if (!targetNo || existingMains.length === 0) return;
        const m = existingMains.find((r) => String(r.issued_no) === String(targetNo));
        if (m) {
            handleOpenMain(m);
            lastNavPayloadRef.current = navPayload;
            onNavPayloadConsumed && onNavPayloadConsumed();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [existingMains, navPayload]);

    // =============================================================================
    // Lookups
    // =============================================================================
    const fetchDepartments = async () => {
        const res = await api.get(`${LOOKUP_API.department}`);
        const data = res.data?.data || [];
        setDepartments(data);
        setDepartmentsLoaded(true);
    };
    const ensureDepartmentsLoaded = async () => (departmentsLoaded ? departments : fetchDepartments());

    const fetchSubItems = async () => {
        const res = await api.get(`${LOOKUP_API.subItem}/`);
        const data = res.data?.data || [];
        setSubItems(data);
        setSubItemsLoaded(true);
    };
    const ensureSubItemsLoaded = async () => (subItemsLoaded ? subItems : fetchSubItems());

    const fetchItems = async () => {
        const res = await api.get(`${LOOKUP_API.itemDetail}/`);
        const data = res.data?.data || res.data || [];
        setItems(Array.isArray(data) ? data : []);
        setItemsLoaded(true);
    };
    const ensureItemsLoaded = async () => (itemsLoaded ? items : fetchItems());

    const companyDepartments = useMemo(
        () => departments.filter((dep) => Number(dep.company_id) === Number(companyId)),
        [departments, companyId]
    );
    const companySubItems = useMemo(
        () => subItems.filter((si) => si.company_id === companyId),
        [subItems, companyId]
    );
    const companyItems = useMemo(
        () => items.filter((item) => item.company_id === companyId),
        [items, companyId]
    );

    const selectedSubItem = useMemo(
        () => companySubItems.find((si) => String(si.code) === String(detailForm.subitem_code).trim()),
        [companySubItems, detailForm.subitem_code]
    );

    // Item already added to this issued entry drops out of the Item Name
    // suggestions (same behaviour as Purchase Entry), unless it's the row
    // currently being edited.
    const usedItemCodes = useMemo(
        () => new Set(
            details
                .filter((d) => !editingDetailId || d.id !== editingDetailId)
                .map((d) => String(d.Item_code))
        ),
        [details, editingDetailId]
    );
    const itemOptionsForSubItem = useMemo(
        () => (selectedSubItem
            ? companyItems.filter(
                (item) =>
                    Number(item.subitem_id) === Number(selectedSubItem.id) &&
                    !usedItemCodes.has(String(item.code))
              )
            : []),
        [companyItems, selectedSubItem, usedItemCodes]
    );

    const existingMainsForSearch = useMemo(
        () =>
            existingMains.map((m) => {
                const dep = companyDepartments.find((d) => Number(d.id) === Number(m.department_id));
                return {
                    ...m,
                    department_name: dep?.department_name || m.department_name || '',
                    doc_date_display: m.issued_date ? isoToDisplayDate(dbDateToIso(m.issued_date)) : '',
                };
            }),
        [existingMains, companyDepartments]
    );

    const lotAllocationPreview = useMemo(() => {
        const requested = Number(detailForm.net_weight) || 0;
        let remaining = requested;
        return availableLots.map((lot) => {
            const take = remaining > 0 ? Math.min(lot.remaining_net_weight, remaining) : 0;
            remaining -= take;
            return { ...lot, taken: take, willUse: take > 0 };
        });
    }, [availableLots, detailForm.net_weight]);

    const totalAvailable = useMemo(
        () => availableLots.reduce((s, l) => s + Number(l.remaining_net_weight), 0),
        [availableLots]
    );
    const insufficientStock = (Number(detailForm.net_weight) || 0) > totalAvailable;

    useEffect(() => {
        if (!companyId) return;
        ensureDepartmentsLoaded();
        ensureSubItemsLoaded();
        ensureItemsLoaded();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    useEffect(() => {
        if (!companyId) return;
        handleNewMain();
        fetchExistingMains();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId, financialYearId]);

    useEffect(() => {
        const fetchLots = async () => {
            if (!detailForm.Item_code || !companyId) {
                setAvailableLots([]);
                return;
            }
            setIsLoadingLots(true);
            try {
                const res = await api.get(ENDPOINTS.availableStock, {
                    params: { company_id: companyId, item_code: detailForm.Item_code },
                });
                setAvailableLots(res.data || []);
            } catch {
                setAvailableLots([]);
            } finally {
                setIsLoadingLots(false);
            }
        };
        fetchLots();
    }, [detailForm.Item_code, companyId, mainId]);

    // =============================================================================
    // Main doc
    // =============================================================================
    const fetchExistingMains = async () => {
        if (!companyId || !financialYearId) return;
        setIsLoadingMains(true);
        try {
            const res = await api.get(`${ENDPOINTS.main}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            const filtered = list
                .filter(
                    (m) =>
                        Number(m.company_id) === Number(companyId) &&
                        Number(m.financialyear_id) === Number(financialYearId)
                )
                .sort((a, b) => {
                    const numA = trailingNumber(a.issued_no);
                    const numB = trailingNumber(b.issued_no);
                    if (!Number.isNaN(numA) && !Number.isNaN(numB) && numA !== numB) return numB - numA;
                    return new Date(b.issued_date) - new Date(a.issued_date);
                });
            setExistingMains(filtered);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load issued entries');
        } finally {
            setIsLoadingMains(false);
        }
    };

    const handleNewMain = () => {
        setMainId(null);
        setIssuedNo('');
        setMainForm(EMPTY_MAIN_FORM);
        setDetails([]);
        resetDetailForm();
    };

    const handleOpenMain = (m) => {
        setMainId(Number(m.id));
        setIssuedNo(m.issued_no);
        setMainForm({
            issued_date: m.issued_date ? isoToDisplayDate(dbDateToIso(m.issued_date)) : '',
            department_id: m.department_id || '',
            remarks: m.remarks || '',
        });
        resetDetailForm();
        fetchDetails(Number(m.id));
    };

    const handleSaveMain = async (e) => {
        e.preventDefault();

        if (!mainForm.issued_date) {
            toast.error('Please select an issued date');
            return;
        }
        if (!mainForm.department_id) {
            toast.error('Please select a department');
            return;
        }
        if (!financialYearId) {
            toast.error('No financial year selected');
            return;
        }

        const issuedDateIso = displayDateToIso(mainForm.issued_date);
        if (!issuedDateIso) {
            toast.error('Issued date must be in dd-mm-yyyy format');
            return;
        }

        const payload = {
            company_id: companyId,
            department_id: mainForm.department_id,
            financialyear_id: financialYearId,
            issued_date: issuedDateIso,
            remarks: mainForm.remarks || null,
        };

        setIsSavingMain(true);
        try {
            if (mainId) {
                await api.put(`${ENDPOINTS.main}/${mainId}`, withMeta(payload));
                toast.success('Issued entry updated');
            } else {
                const res = await api.post(`${ENDPOINTS.main}/`, withMeta(payload));
                const newId = Number(res.data?.id);
                const assignedNo = res.data?.issued_no;
                setMainId(newId);
                setIssuedNo(assignedNo);
                toast.success(`Issued #${assignedNo} created`);
            }
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save issued entry');
        } finally {
            setIsSavingMain(false);
        }
    };

    const handleDeleteMain = async () => {
        if (!mainId) return;
        if (!window.confirm(`Delete issued entry "${issuedNo}" and all of its entries?`)) return;
        try {
            const res = await api.get(ENDPOINTS.detailByMainPath(mainId));
            const list = Array.isArray(res.data) ? res.data : [];
            for (const d of list) {
                // eslint-disable-next-line no-await-in-loop
                await api.delete(`${ENDPOINTS.detail}/${d.id}`, { data: withMeta() });
            }
            await api.delete(`${ENDPOINTS.main}/${mainId}`, { data: withMeta() });
            toast.success('Issued entry deleted');
            handleNewMain();
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete issued entry');
        }
    };

    // =============================================================================
    // Details
    // =============================================================================
    const fetchDetails = async (id) => {
        setIsLoadingDetails(true);
        try {
            const res = await api.get(ENDPOINTS.detailByMainPath(id));
            const list = Array.isArray(res.data) ? res.data : [];
            setDetails(list.sort((a, b) => a.entry_no - b.entry_no));
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load entries');
        } finally {
            setIsLoadingDetails(false);
        }
    };

    const resetDetailForm = () => {
        setDetailForm(EMPTY_DETAIL_FORM);
        setEditingDetailId(null);
    };

    const resetDetailFormKeepSubitem = () => {
        setDetailForm((prev) => ({ ...EMPTY_DETAIL_FORM, subitem_code: prev.subitem_code }));
        setEditingDetailId(null);
    };

    const handleEditDetailRow = (row) => {
        const item = companyItems.find((i) => String(i.code) === String(row.Item_code));
        const subitem = item ? companySubItems.find((si) => Number(si.id) === Number(item.subitem_id)) : null;

        setEditingDetailId(row.id);
        setDetailForm({
            subitem_code: subitem ? subitem.code : '',
            Item_code: row.Item_code ?? '',
            pieces: row.pieces || 0,
            net_weight: row.net_weight || 0,
        });
    };

    const detailsTotals = useMemo(() => {
        return details.reduce(
            (acc, row) => {
                acc.pieces += Number(row.pieces) || 0;
                acc.net_weight += Number(row.net_weight) || 0;
                return acc;
            },
            { pieces: 0, net_weight: 0 }
        );
    }, [details]);

    const handleSaveDetail = async (e) => {
        e.preventDefault();

        if (!mainId) {
            toast.error('Save the issued entry details first');
            return;
        }
        if (!detailForm.Item_code) {
            toast.error('Select or enter an item');
            return;
        }
        if (insufficientStock) {
            toast.error('Not enough stock for this item.');
            return;
        }

        const payload = withMeta({
            company_id: companyId,
            issuedmain_id: mainId,
            Item_code: detailForm.Item_code,
            pieces: detailForm.pieces || 0,
            net_weight: detailForm.net_weight || 0,
        });

        setIsSavingDetail(true);
        try {
            if (editingDetailId) {
                const editPayload = {
                    ...payload,
                    entry_no: details.find((d) => d.id === editingDetailId)?.entry_no,
                };
                await api.put(`${ENDPOINTS.detail}/${editingDetailId}`, editPayload);
                toast.success('Entry updated');
            } else {
                const { data } = await api.post(`${ENDPOINTS.detail}/`, payload);
                if (data.entriesCreated > 1) {
                    toast.success(`${data.entriesCreated} entries created (item split across ${data.entriesCreated} purchase lots).`);
                } else {
                    toast.success('Entry added');
                }
            }
            resetDetailFormKeepSubitem();
            await fetchDetails(mainId);
            focusAndSelect(itemSubRef);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save entry');
        } finally {
            setIsSavingDetail(false);
        }
    };

    const handleDeleteDetail = async (row) => {
        if (!window.confirm(`Delete entry #${row.entry_no}?`)) return;
        try {
            await api.delete(`${ENDPOINTS.detail}/${row.id}`, { data: withMeta() });
            toast.success('Entry deleted');
            await fetchDetails(mainId);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete entry');
        }
    };

    // =============================================================================
    // Render
    // =============================================================================
    return (
        <div className="bg-gray-50 p-3">
            {onBack && (
                <button
                    type="button"
                    onClick={onBack}
                    className="mb-2 flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700"
                >
                    ← Back
                </button>
            )}

            <div className="flex items-center justify-between mb-2">
                <h1 className="text-xl font-bold text-gray-800">Issued Entry</h1>
            </div>

            <div className="max-w-5xl mx-auto">
                {!companyId ? (
                    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 text-center text-gray-500 text-sm">
                        No company context found. Please select a company first.
                    </div>
                ) : (
                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">

                        {/* Main form */}
                        <form onSubmit={handleSaveMain} className="pb-3 mb-3">
                            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-2">
                                <div>
                                    <div className="flex items-center justify-between mb-0.5">
                                        <label className="block text-xs font-medium text-gray-600">Issued No</label>
                                        {mainId && (
                                            <button type="button" onClick={handleDeleteMain} title="Delete this issued entry" className="hover:opacity-70">
                                                <img src={deleteIcon} alt="Delete" className="w-3.5 h-3.5" />
                                            </button>
                                        )}
                                    </div>
                                    <DocSearchField
                                        ref={docNoRef}
                                        value={issuedNo}
                                        onChange={(val) => setIssuedNo(val)}
                                        options={existingMainsForSearch}
                                        numberKey="issued_no"
                                        newLabel="+ New Issued"
                                        placeholder="New Issued"
                                        onSelectExisting={(m) => handleOpenMain(m)}
                                        onSelectNew={() => handleNewMain()}
                                        onEnterNext={() => focusAndSelect(mainDateRef)}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Issued Date</label>
                                    <input
                                        ref={mainDateRef}
                                        type="text"
                                        value={mainForm.issued_date}
                                        onChange={(e) => setMainForm({ ...mainForm, issued_date: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainDepartmentRef)}
                                        placeholder="dd-mm-yyyy"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>

                                {/* Department - plain dropdown, the user picks it directly */}
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Department</label>
                                    <select
                                        ref={mainDepartmentRef}
                                        value={mainForm.department_id}
                                        onChange={(e) => setMainForm({ ...mainForm, department_id: e.target.value })}
                                        onKeyDown={makeEnterToNext(mainRemarksRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    >
                                        <option value="">Select department</option>
                                        {companyDepartments.map((dep) => (
                                            <option key={dep.id} value={dep.id}>
                                                {dep.department_name}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                <div className="sm:col-span-1">
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Remarks</label>
                                    <input
                                        ref={mainRemarksRef}
                                        type="text"
                                        value={mainForm.remarks}
                                        onChange={(e) => setMainForm({ ...mainForm, remarks: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainSubmitRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div className="flex items-end">
                                    <button
                                        ref={mainSubmitRef}
                                        type="submit"
                                        disabled={isSavingMain}
                                        className="w-full px-4 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 bg-blue-500 hover:bg-blue-600"
                                    >
                                        {isSavingMain ? 'Saving...' : mainId ? 'Update' : 'Create'}
                                    </button>
                                </div>
                            </div>
                        </form>

                        {/* Detail entries */}
                        {mainId && (
                            <>
                                <div className="border-t border-gray-200 pt-3 mb-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">
                                        {editingDetailId ? 'Edit Entry' : 'Add Entry'}
                                    </h3>
                                    <form onSubmit={handleSaveDetail} className="space-y-2">
                                        <div className="grid grid-cols-6 gap-2 items-end">
                                            <div className="col-span-1">
                                                <SearchField
                                                    ref={itemSubRef}
                                                    label="Item Sub"
                                                    value={detailForm.subitem_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, subitem_code: val, Item_code: '' })}
                                                    options={companySubItems}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder="Search"
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(itemNameRef)}
                                                />
                                            </div>
                                            <div className="col-span-2">
                                                <SearchField
                                                    ref={itemNameRef}
                                                    label="Item Name"
                                                    value={detailForm.Item_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, Item_code: val })}
                                                    options={itemOptionsForSubItem}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder={selectedSubItem ? 'Search item' : 'Pick item sub first'}
                                                    disabled={!selectedSubItem}
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(piecesRef)}
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Pieces</label>
                                                <input
                                                    ref={piecesRef}
                                                    type="number"
                                                    value={detailForm.pieces}
                                                    onChange={(e) => setDetailForm({ ...detailForm, pieces: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(netWeightRef)}
                                                    min="0"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Net Weight</label>
                                                <input
                                                    ref={netWeightRef}
                                                    type="number"
                                                    value={detailForm.net_weight}
                                                    onChange={(e) => setDetailForm({ ...detailForm, net_weight: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(detailSubmitRef)}
                                                    min="0"
                                                    step="0.01"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <button
                                                    ref={detailSubmitRef}
                                                    type="submit"
                                                    disabled={isSavingDetail}
                                                    className="w-full px-3 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 disabled:cursor-not-allowed bg-blue-500 hover:bg-blue-600"
                                                >
                                                    {isSavingDetail ? 'Saving...' : editingDetailId ? 'Update' : 'Save'}
                                                </button>
                                                {editingDetailId && (
                                                    <button
                                                        type="button"
                                                        onClick={resetDetailForm}
                                                        title="Cancel edit"
                                                        className="text-sm text-gray-500 hover:text-gray-700 ml-1"
                                                    >
                                                        ✕
                                                    </button>
                                                )}
                                            </div>
                                        </div>

                                        {detailForm.Item_code && (
                                            <div className="mt-2">
                                                <button
                                                    type="button"
                                                    onClick={() => setShowStockDetails((prev) => !prev)}
                                                    disabled={isLoadingLots || availableLots.length === 0}
                                                    className="w-full flex items-center justify-between px-2.5 py-1.5 border border-gray-200 rounded-md text-xs bg-gray-50 hover:bg-gray-100 disabled:opacity-70 disabled:cursor-default"
                                                >
                                                    <span className="font-semibold text-gray-600">
                                                        Available Stock (FIFO)
                                                        {!isLoadingLots && availableLots.length > 0 && (
                                                            <span className="font-normal text-gray-500 ml-1">
                                                                · {availableLots.length} lot{availableLots.length > 1 ? 's' : ''} · {totalAvailable} total
                                                            </span>
                                                        )}
                                                    </span>
                                                    {isLoadingLots ? (
                                                        <span className="text-gray-400">Loading...</span>
                                                    ) : availableLots.length === 0 ? (
                                                        <span className="text-red-500">No stock available</span>
                                                    ) : (
                                                        <span className="text-gray-400">{showStockDetails ? '▲ Hide' : '▼ Show'}</span>
                                                    )}
                                                </button>

                                                {showStockDetails && availableLots.length > 0 && (
                                                    <div className="mt-1 border border-gray-200 rounded overflow-hidden">
                                                        <div className="max-h-40 overflow-y-auto">
                                                            <table className="min-w-full text-xs">
                                                                <thead className="bg-gray-50 sticky top-0">
                                                                    <tr>
                                                                        <th className="px-2 py-1 text-left">✓</th>
                                                                        <th className="px-2 py-1 text-left">GRN</th>
                                                                        <th className="px-2 py-1 text-left">Entry No</th>
                                                                        <th className="px-2 py-1 text-right">Pieces</th>
                                                                        <th className="px-2 py-1 text-right">Net Weight (Available)</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {lotAllocationPreview.map((lot) => (
                                                                        <tr key={lot.source_detail_id} className={lot.willUse ? 'bg-blue-50' : ''}>
                                                                            <td className="px-2 py-1">{lot.willUse ? '☑' : '☐'}</td>
                                                                            <td className="px-2 py-1">{lot.label}</td>
                                                                            <td className="px-2 py-1">{lot.entry_no}</td>
                                                                            <td className="px-2 py-1 text-right">{lot.remaining_pieces}</td>
                                                                            <td className="px-2 py-1 text-right">{lot.remaining_net_weight}</td>
                                                                        </tr>
                                                                    ))}
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                )}

                                                {insufficientStock && (
                                                    <div className="text-xs text-red-600 font-semibold mt-1">
                                                        ⚠ Requested net weight exceeds available stock ({totalAvailable}).
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </form>
                                </div>

                                {/* Entries table */}
                                <div className="border-t border-gray-200 pt-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">Entries</h3>
                                    {isLoadingDetails ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">Loading...</div>
                                    ) : details.length === 0 ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">No entries yet</div>
                                    ) : (
                                        <div className="overflow-x-auto border border-gray-200 rounded-lg">
                                            <table className="min-w-full divide-y divide-gray-200 text-sm">
                                                <thead className="bg-gray-50">
                                                    <tr>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Entry No</th>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Item</th>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Source GRN</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Pieces</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Net Weight</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="bg-white divide-y divide-gray-100">
                                                    {details.map((row) => (
                                                        <tr key={row.id} className="hover:bg-gray-50">
                                                            <td className="px-2.5 py-1.5 text-gray-600">{row.entry_no}</td>
                                                            <td className="px-2.5 py-1.5 text-gray-800">{row.item_name || row.Item_code}</td>
                                                            <td className="px-2.5 py-1.5 text-gray-500">{row.grn_no || '-'}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.pieces}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.net_weight}</td>
                                                            <td className="px-2.5 py-1.5">
                                                                <div className="flex items-center justify-end gap-2">
                                                                    <button onClick={() => handleEditDetailRow(row)} title="Edit">
                                                                        <img src={editIcon} alt="Edit" className="w-4 h-4" />
                                                                    </button>
                                                                    <button onClick={() => handleDeleteDetail(row)} title="Delete">
                                                                        <img src={deleteIcon} alt="Delete" className="w-4 h-4" />
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                                <tfoot className="bg-gray-50 border-t-2 border-gray-200">
                                                    <tr>
                                                        <td className="px-2.5 py-1.5 font-semibold text-gray-700" colSpan={3}>
                                                            Total
                                                        </td>
                                                        <td className="px-2.5 py-1.5 text-right font-semibold text-gray-800">
                                                            {detailsTotals.pieces}
                                                        </td>
                                                        <td className="px-2.5 py-1.5 text-right font-semibold text-gray-800">
                                                            {detailsTotals.net_weight}
                                                        </td>
                                                        <td className="px-2.5 py-1.5"></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

export default IssuedEntry;