import React, { useState, useEffect, useMemo, useRef } from 'react';
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from 'react-redux';
import api from '../../../services/api'
import { setSystemNameIp } from '../../../store/slices/companySlice';
import { fetchClientSystemInfo } from '../../../utils/getSystemInfo';

import editIcon from '../../../assets/edit.png';
import deleteIcon from '../../../assets/delete.png';

// ==========================================================================
// Config - kept as a single object (rather than the Purchase/Purchase Return
// pair) since Inward Gate Pass only has one mode. Mirrors the same shape so
// the rest of the component reads exactly like PurchaseEntry.
// ==========================================================================
const CONFIG = {
    title: 'Inward Gate Pass Entry',
    mainApi: '/inward-gate-pass-main',
    detailApi: '/inward-gate-pass-detail',
    detailByMainPath: (mainId) => `/inward-gate-pass-detail/inward/${mainId}`,
    numberField: 'inward_no',
    dateField: 'inward_date',
    numberLabel: 'Inward No',
    dateLabel: 'Inward Date',
    newLabel: '+ New Inward',
    searchPlaceholder: 'New Inward',
    detailMainIdKey: 'inwardgatepassmain_id',
    docNoun: 'inward gate pass',
};

// Lookup APIs
const LOOKUP_API = {
    chartOfAccount: '/chart-of-account',
    itemDetail: '/item-detail',
    subItem: '/sub-item',
    department: '/department',
};

const todayStr = () => new Date().toISOString().slice(0, 10);

// dd-mm-yyyy (what the user sees) <-> yyyy-mm-dd (what the backend/DB expects)
const isoToDisplayDate = (iso) => {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    if (!y || !m || !d) return '';
    return `${d}-${m}-${y}`;
};

const displayDateToIso = (display) => {
    if (!display) return '';
    const parts = display.split('-');
    if (parts.length !== 3) return '';
    const [d, m, y] = parts;
    if (!d || !m || !y || y.length !== 4) return '';
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
};

const EMPTY_MAIN_FORM = {
    doc_date: isoToDisplayDate(todayStr()),
    department_id: '',
    challan_no: '',
    vehicle_no: '',
    account_code: '',
    driver_name: '',
    driver_phone_no: '',
    freight: 0,
    remarks: '',
};

const EMPTY_DETAIL_FORM = {
    subitem_code: '', // transient - only used to filter the Item Name field, never sent to the backend
    Item_code: '',
    pieces: 0,
    net_weight: 0,
};

// Focuses a field (input DOM node) and selects its text, so the next
// keystroke replaces the whole value (or a single Backspace clears it).
const focusAndSelect = (ref) => {
    if (!ref || !ref.current) return;
    ref.current.focus();
    if (typeof ref.current.select === 'function') {
        ref.current.select();
    }
};

// Generic "Enter moves to next field" keydown handler for plain <input>
// elements (i.e. ones that don't have their own suggestion dropdown).
const makeEnterToNext = (nextRef) => (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    focusAndSelect(nextRef);
};

// Simple searchable field - same pattern used in Purchase Entry / Voucher
// Entry, generalized to match against any `codeKey`/`labelKey` pair.
const SearchField = React.forwardRef(({ label, value, onChange, options, codeKey, labelKey, subLabelKey, placeholder, disabled, showAllOnFocus, onEnterNext, wide }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = term
        ? options
            .filter(
                (opt) =>
                    String(opt[labelKey] ?? '').toLowerCase().includes(term) ||
                    String(opt[codeKey] ?? '').includes(term)
            )
            .slice(0, 8)
        : (showAllOnFocus ? options.slice(0, 8) : []);

    const matched = options.find((opt) => String(opt[codeKey]) === term);

    useEffect(() => {
        setHighlightedIndex(suggestions.length > 0 ? 0 : -1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectSuggestion = (opt) => {
        onChange(String(opt[codeKey]));
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (showSuggestions && suggestions.length > 0 && highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
                selectSuggestion(suggestions[highlightedIndex]);
            } else {
                setShowSuggestions(false);
            }
            onEnterNext && onEnterNext();
            return;
        }

        if (!showSuggestions || suggestions.length === 0) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev + 1) % suggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };
    return (
        <div>
            {label && <label className="block text-xs font-medium text-gray-600 mb-0.5">{label}</label>}
            <div className="relative">
                <input
                    ref={ref}
                    type="text"
                    value={value ?? ''}
                    disabled={disabled}
                    onChange={(e) => {
                        onChange(e.target.value);
                        setShowSuggestions(true);
                    }}
                    onFocus={(e) => {
                        if ((value ?? '').toString().trim() || showAllOnFocus) setShowSuggestions(true);
                        e.target.select();
                    }}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-400"
                    placeholder={placeholder || 'Search'}
                />
                {matched && (
                    <div className="text-[11px] text-blue-800 font-bold mt-0.5 truncate px-2 py-0.5 rounded">→ {matched[labelKey]}</div>
                )}
                {showSuggestions && suggestions.length > 0 && (
                    <div className={`absolute left-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-20 ${wide ? 'w-[200%]' : 'right-0'}`}>
                        {suggestions.map((opt, index) => (
                            <div
                                key={opt[codeKey]}
                                className={`px-2.5 py-1.5 cursor-pointer text-sm flex items-center justify-between border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-100' : 'hover:bg-blue-50'}`}
                                onMouseEnter={() => setHighlightedIndex(index)}
                                onMouseDown={() => selectSuggestion(opt)}
                            >
                                <span className="font-medium">{opt[labelKey]}</span>
                                {subLabelKey && opt[subLabelKey] && (
                                    <span className="text-xs text-gray-400">{opt[subLabelKey]}</span>
                                )}
                                {codeKey !== labelKey && (
                                    <span className="text-xs font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded ml-4">
                                        {opt[codeKey]}
                                    </span>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
});

// Doc-No field that doubles as the "load an existing inward gate pass"
// search. Dropdown shows Inward No / Account / Date in three columns, pins a
// "+ New Inward" row at top. Typing filters by any of the three, but
// selecting (click / Enter) always resolves to the doc.
const DocSearchField = React.forwardRef(({ value, onChange, options, onSelectExisting, onSelectNew, disabled, numberKey, newLabel, placeholder, onEnterNext }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = options
        .filter(
            (opt) =>
                String(opt[numberKey] ?? '').toLowerCase().includes(term) ||
                String(opt.account_name ?? '').toLowerCase().includes(term) ||
                String(opt.doc_date_display ?? '').toLowerCase().includes(term)
        )
        .slice(0, 8);

    useEffect(() => {
        setHighlightedIndex(-1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectNew = () => {
        onSelectNew();
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const selectExisting = (opt) => {
        onSelectExisting(opt);
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (!showSuggestions) {
            if (e.key === 'Enter') {
                e.preventDefault();
                onEnterNext && onEnterNext();
            }
            return;
        }
        const minIndex = -1;
        const maxIndex = suggestions.length - 1;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev >= maxIndex ? minIndex : prev + 1));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev <= minIndex ? maxIndex : prev - 1));
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightedIndex === -1) selectNew();
            else if (highlightedIndex >= 0 && highlightedIndex < suggestions.length) selectExisting(suggestions[highlightedIndex]);
            onEnterNext && onEnterNext();
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div className="relative">
            <input
                ref={ref}
                type="text"
                value={value ?? ''}
                disabled={disabled}
                onChange={(e) => {
                    onChange(e.target.value);
                    setShowSuggestions(true);
                }}
                onFocus={(e) => {
                    setShowSuggestions(true);
                    e.target.select();
                }}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                onKeyDown={handleKeyDown}
                className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-400"
                placeholder={placeholder}
            />
            {showSuggestions && (
                <div className="absolute left-0 mt-1 w-[420px] max-w-[90vw] bg-white border border-gray-200 rounded-lg shadow-lg max-h-56 overflow-y-auto z-30">
                    <div
                        className={`px-2.5 py-1.5 cursor-pointer text-sm font-semibold text-blue-600 border-b border-gray-100 ${highlightedIndex === -1 ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                        onMouseEnter={() => setHighlightedIndex(-1)}
                        onMouseDown={selectNew}
                    >
                        {newLabel}
                    </div>
                    {suggestions.map((opt, index) => (
                        <div
                            key={opt.id}
                            className={`px-2.5 py-1.5 cursor-pointer text-sm grid grid-cols-3 gap-2 border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                            onMouseEnter={() => setHighlightedIndex(index)}
                            onMouseDown={() => selectExisting(opt)}
                        >
                            <span className="font-medium truncate">{opt[numberKey]}</span>
                            <span className="text-gray-600 truncate">{opt.account_name}</span>
                            <span className="text-gray-400 text-xs">{opt.doc_date_display}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
});

function InwardGatePassEntry({ onBack }) {
    const dispatch = useDispatch();
    const {
        companyId: rawCompanyId,
        financialYearId: rawFinancialYearId,
        user,
        systemNameIp,
    } = useSelector((state) => state.company);

    useEffect(() => {
        if (!systemNameIp) {
            fetchClientSystemInfo().then((ip) => {
                if (ip) dispatch(setSystemNameIp(ip));
            });
        }
    }, []);

    const withMeta = (body = {}) => ({
        ...body,
        performed_by: user?.username || user?.name || 'Unknown',
        system_name_ip: systemNameIp,
    });

    const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== ''
        ? Number(rawCompanyId)
        : null;
    const financialYearId = rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ''
        ? Number(rawFinancialYearId)
        : null;

    const config = CONFIG;

    // ---- Main doc (Inward Gate Pass) ----
    const [mainForm, setMainForm] = useState(EMPTY_MAIN_FORM);
    const [mainId, setMainId] = useState(null);
    const [docNo, setDocNo] = useState('');
    const [isSavingMain, setIsSavingMain] = useState(false);

    const [existingMains, setExistingMains] = useState([]);
    const [isLoadingMains, setIsLoadingMains] = useState(false);

    // ---- Departments (plain dropdown - see handleChange below) ----
    const [departments, setDepartments] = useState([]);
    const [departmentsLoaded, setDepartmentsLoaded] = useState(false);

    // ---- Chart Of Account (parties on the gate pass) ----
    const [chartOfAccounts, setChartOfAccounts] = useState([]);
    const [chartOfAccountsLoaded, setChartOfAccountsLoaded] = useState(false);

    // ---- Sub Item (item sub-category, used only to narrow the Item Name search) ----
    const [subItems, setSubItems] = useState([]);
    const [subItemsLoaded, setSubItemsLoaded] = useState(false);

    // ---- Item Detail (items) ----
    const [items, setItems] = useState([]);
    const [itemsLoaded, setItemsLoaded] = useState(false);

    // ---- Details (line entries under the current main doc) ----
    const [details, setDetails] = useState([]);
    const [isLoadingDetails, setIsLoadingDetails] = useState(false);
    const [detailForm, setDetailForm] = useState(EMPTY_DETAIL_FORM);
    const [editingDetailId, setEditingDetailId] = useState(null);
    const [isSavingDetail, setIsSavingDetail] = useState(false);

    // ---- Field refs, used purely to drive "Enter moves to the next field"
    // navigation across both the main-doc form and the detail-entry form.
    const docNoRef = useRef(null);
    const mainDateRef = useRef(null);
    const mainDepartmentRef = useRef(null);
    const mainAccountRef = useRef(null);
    const mainChallanNoRef = useRef(null);
    const mainVehicleNoRef = useRef(null);
    const mainDriverNameRef = useRef(null);
    const mainDriverPhoneRef = useRef(null);
    const mainRemarksRef = useRef(null);
    const mainSubmitRef = useRef(null);
    const mainFreightRef = useRef(null);

    const itemSubRef = useRef(null);
    const itemNameRef = useRef(null);
    const piecesRef = useRef(null);
    const netWeightRef = useRef(null);
    const detailSubmitRef = useRef(null);

    // =============================================================================
    // Lookups
    // =============================================================================
    const fetchDepartments = async () => {
        const res = await api.get(`${LOOKUP_API.department}`);
        const data = res.data?.data || [];
        setDepartments(data);
        setDepartmentsLoaded(true);
    };
    const ensureDepartmentsLoaded = async () => (departmentsLoaded ? departments : fetchDepartments());

    const fetchChartOfAccounts = async () => {
        const res = await api.get(`${LOOKUP_API.chartOfAccount}/`);
        const data = res.data?.data || [];
        setChartOfAccounts(data);
        setChartOfAccountsLoaded(true);
    };
    const ensureChartOfAccountsLoaded = async () => (chartOfAccountsLoaded ? chartOfAccounts : fetchChartOfAccounts());

    const fetchSubItems = async () => {
        const res = await api.get(`${LOOKUP_API.subItem}/`);
        const data = res.data?.data || [];
        setSubItems(data);
        setSubItemsLoaded(true);
    };
    const ensureSubItemsLoaded = async () => (subItemsLoaded ? subItems : fetchSubItems());

    const fetchItems = async () => {
        const res = await api.get(`${LOOKUP_API.itemDetail}/`);
        const data = res.data?.data || res.data || [];
        setItems(Array.isArray(data) ? data : []);
        setItemsLoaded(true);
    };
    const ensureItemsLoaded = async () => (itemsLoaded ? items : fetchItems());

    const companyDepartments = useMemo(
        () => departments.filter((dep) => Number(dep.company_id) === Number(companyId)),
        [departments, companyId]
    );
    const companyAccounts = useMemo(
        () => chartOfAccounts.filter((coa) => coa.company_id === companyId),
        [chartOfAccounts, companyId]
    );
    const companySubItems = useMemo(
        () => subItems.filter((si) => si.company_id === companyId),
        [subItems, companyId]
    );
    const companyItems = useMemo(
        () => items.filter((item) => item.company_id === companyId),
        [items, companyId]
    );

    const selectedSubItem = useMemo(
        () => companySubItems.find((si) => String(si.code) === String(detailForm.subitem_code).trim()),
        [companySubItems, detailForm.subitem_code]
    );
    const itemOptionsForSubItem = useMemo(
        () => (selectedSubItem
            ? companyItems.filter((item) => Number(item.subitem_id) === Number(selectedSubItem.id))
            : []),
        [companyItems, selectedSubItem]
    );

    // Adds account_name + a display-formatted date to each doc, purely for
    // the DocSearchField dropdown/search - doesn't touch existingMains itself.
    const existingMainsForSearch = useMemo(
        () =>
            existingMains.map((m) => {
                const account = companyAccounts.find((a) => String(a.code) === String(m.account_code));
                const rawDate = m[config.dateField];
                return {
                    ...m,
                    account_name: account?.account_name || m.account_name || m.account_code,
                    doc_date_display: rawDate ? isoToDisplayDate(String(rawDate).slice(0, 10)) : '',
                };
            }),
        [existingMains, companyAccounts, config.dateField]
    );

    useEffect(() => {
        if (!companyId) return;
        ensureDepartmentsLoaded();
        ensureChartOfAccountsLoaded();
        ensureSubItemsLoaded();
        ensureItemsLoaded();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    useEffect(() => {
        if (!companyId) return;
        handleNewMain();
        fetchExistingMains();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId, financialYearId]);

    // =============================================================================
    // Main doc (Inward Gate Pass)
    // =============================================================================
    const fetchExistingMains = async () => {
        if (!companyId || !financialYearId) return;
        setIsLoadingMains(true);
        try {
            const res = await api.get(`${config.mainApi}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            const filtered = list
                .filter(
                    (m) =>
                        Number(m.company_id) === Number(companyId) &&
                        Number(m.financialyear_id) === Number(financialYearId)
                )
                .sort((a, b) => {
                    const numA = parseInt(String(a[config.numberField]).split('-').pop() || a[config.numberField] || '0');
                    const numB = parseInt(String(b[config.numberField]).split('-').pop() || b[config.numberField] || '0');
                    return numB - numA;
                });
            setExistingMains(filtered);
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to load ${config.docNoun}s`);
        } finally {
            setIsLoadingMains(false);
        }
    };

    const handleNewMain = () => {
        setMainId(null);
        setDocNo('');
        setMainForm(EMPTY_MAIN_FORM);
        setDetails([]);
        resetDetailForm();
    };

    const handleOpenMain = (m) => {
        setMainId(Number(m.id));
        setDocNo(m[config.numberField]);
        const rawDate = m[config.dateField];
        setMainForm({
            doc_date: rawDate ? isoToDisplayDate(String(rawDate).slice(0, 10)) : '',
            department_id: m.department_id || '',
            challan_no: m.challan_no || '',
            vehicle_no: m.vehicle_no || '',
            account_code: m.account_code || '',
            driver_name: m.driver_name || '',
            driver_phone_no: m.driver_phone_no || '',
            freight: m.freight || '',
            remarks: m.remarks || '',
        });
        resetDetailForm();
        fetchDetails(Number(m.id));
    };

    const handleSaveMain = async (e) => {
        e.preventDefault();

        if (!mainForm.doc_date) {
            toast.error(`Please select a ${config.dateLabel.toLowerCase()}`);
            return;
        }
        if (!mainForm.department_id) {
            toast.error('Please select a department');
            return;
        }
        if (!mainForm.account_code) {
            toast.error('Please select an account');
            return;
        }
        if (!mainForm.challan_no.trim()) {
            toast.error('Please enter a challan number');
            return;
        }
        if (!mainForm.vehicle_no.trim()) {
            toast.error('Please enter a vehicle number');
            return;
        }
        if (!financialYearId) {
            toast.error('No financial year selected');
            return;
        }

        const docDateIso = displayDateToIso(mainForm.doc_date);
        if (!docDateIso) {
            toast.error(`${config.dateLabel} must be in dd-mm-yyyy format`);
            return;
        }

        setIsSavingMain(true);
        try {
            const payload = {
                company_id: companyId,
                financialyear_id: financialYearId,
                department_id: mainForm.department_id,
                [config.dateField]: docDateIso,
                challan_no: mainForm.challan_no.trim(),
                vehicle_no: mainForm.vehicle_no.trim(),
                account_code: mainForm.account_code,
                driver_name: mainForm.driver_name || null,
                driver_phone_no: mainForm.driver_phone_no || null,
                freight: mainForm.freight || 0,
                remarks: mainForm.remarks || null,
            };

            if (mainId) {
                await api.put(`${config.mainApi}/${mainId}`, withMeta({
                    ...payload,
                    [config.numberField]: docNo,
                }));
                toast.success(`${config.title.replace(' Entry', '')} updated`);
            } else {
                const res = await api.post(`${config.mainApi}/`, withMeta(payload));
                const newId = Number(res.data?.id);
                const assignedNo = res.data?.[config.numberField];
                setMainId(newId);
                setDocNo(assignedNo);
                toast.success(`${config.numberLabel} #${assignedNo} created`);
            }
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to save ${config.docNoun}`);
        } finally {
            setIsSavingMain(false);
        }
    };

    const handleDeleteMain = async () => {
        if (!mainId) return;
        if (!window.confirm(`Delete ${config.docNoun} "${docNo}" and all of its entries?`)) return;
        try {
            const res = await api.get(config.detailByMainPath(mainId));
            const list = Array.isArray(res.data) ? res.data : [];
            for (const d of list) {
                // eslint-disable-next-line no-await-in-loop
                await api.delete(`${config.detailApi}/${d.id}`, { data: withMeta() });
            }
            await api.delete(`${config.mainApi}/${mainId}`, { data: withMeta() });
            toast.success(`${config.title.replace(' Entry', '')} deleted`);
            handleNewMain();
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to delete ${config.docNoun}`);
        }
    };

    // =============================================================================
    // Details
    // =============================================================================
    const fetchDetails = async (id) => {
        setIsLoadingDetails(true);
        try {
            const res = await api.get(config.detailByMainPath(id));
            const list = Array.isArray(res.data) ? res.data : [];
            setDetails(list.sort((a, b) => a.entry_no - b.entry_no));
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load entries');
        } finally {
            setIsLoadingDetails(false);
        }
    };

    const resetDetailForm = () => {
        setDetailForm(EMPTY_DETAIL_FORM);
        setEditingDetailId(null);
    };

    // Same as resetDetailForm, but keeps the previously used Item Sub in
    // place, so the user can just keep typing to move on, or hit Backspace
    // to change it.
    const resetDetailFormKeepSubitem = () => {
        setDetailForm((prev) => ({ ...EMPTY_DETAIL_FORM, subitem_code: prev.subitem_code }));
        setEditingDetailId(null);
    };

    const handleEditDetailRow = (row) => {
        const item = companyItems.find((i) => String(i.code) === String(row.Item_code));
        const subitem = item ? companySubItems.find((si) => Number(si.id) === Number(item.subitem_id)) : null;

        setEditingDetailId(row.id);
        setDetailForm({
            subitem_code: subitem ? subitem.code : '',
            Item_code: row.Item_code ?? '',
            pieces: row.pieces || 0,
            net_weight: row.net_weight || 0, 
        });
    };

    // Live preview of the total - purely informational, mirrors the
    // backend's default (amount + freight) when Total isn't sent explicitly.
    const detailPreview = useMemo(() => {
        const amount = Number(detailForm.amount) || 0;
        const freight = Number(detailForm.freight) || 0;
        return { total: amount + freight };
    }, [detailForm]);

    const detailsTotals = useMemo(() => {
        return details.reduce(
            (acc, row) => {
                acc.pieces += Number(row.pieces) || 0;
                acc.net_weight += Number(row.net_weight) || 0;
                return acc;
            },
            { pieces: 0, net_weight: 0 }
        );
    }, [details]);

    const handleSaveDetail = async (e) => {
        e.preventDefault();

        if (!mainId) {
            toast.error(`Save the ${config.docNoun} details first`);
            return;
        }
        if (!detailForm.Item_code) {
            toast.error('Select or enter an item');
            return;
        }

        const nextEntryNo = editingDetailId
            ? details.find((d) => d.id === editingDetailId)?.entry_no
            : (details.length > 0 ? Math.max(...details.map((d) => d.entry_no)) + 1 : 1);

        const payload = {
            company_id: companyId,
            [config.detailMainIdKey]: mainId,
            Item_code: detailForm.Item_code,
            entry_no: nextEntryNo,
            pieces: detailForm.pieces || 0,
            net_weight: detailForm.net_weight || 0,
        };

        setIsSavingDetail(true);
        try {
            if (editingDetailId) {
                await api.put(`${config.detailApi}/${editingDetailId}`, withMeta(payload));
                toast.success('Entry updated');
            } else {
                await api.post(`${config.detailApi}/`, withMeta(payload));
                toast.success('Entry added');
            }
            resetDetailForm();
            await fetchDetails(mainId);
            focusAndSelect(itemSubRef);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save entry');
        } finally {
            setIsSavingDetail(false);
        }
    };

    const handleDeleteDetail = async (row) => {
        if (!window.confirm(`Delete entry #${row.entry_no}?`)) return;
        try {
            await api.delete(`${config.detailApi}/${row.id}`, { data: withMeta() });
            toast.success('Entry deleted');
            await fetchDetails(mainId);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete entry');
        }
    };

    // =============================================================================
    // Print
    // =============================================================================
    const handlePrint = () => {
        if (!mainId) return;

        const account = companyAccounts.find((a) => String(a.code) === String(mainForm.account_code));
        const accountName = account?.account_name || mainForm.account_code || '';
        const department = companyDepartments.find((d) => String(d.id) === String(mainForm.department_id));

        const escapeHtml = (val) =>
            String(val ?? '').replace(/[&<>"']/g, (c) => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
            }[c]));

        const rowsHtml = details.map((row, idx) => `
            <tr>
                <td>${idx + 1}</td>
                <td>${escapeHtml(row.item_name || row.Item_code)}</td>
                <td class="num">${escapeHtml(row.pieces)}</td>
                <td class="num">${escapeHtml(row.net_weight)}</td>
                <td class="num">${escapeHtml(Number(row.total ?? row.amount ?? 0).toFixed(2))}</td>
            </tr>
        `).join('');

        const totalAmount = details.reduce((sum, row) => sum + (Number(row.total ?? row.amount) || 0), 0);

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8" />
                <style>
                    * { box-sizing: border-box; }
                    body { font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #111; padding: 24px; }
                    .header { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 4px; }
                    .header div { flex: 1; min-width: 140px; }
                    .header .label { color: #555; font-size: 11px; }
                    .header .value { font-weight: 600; font-size: 14px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 16px; }
                    th, td { border: 1px solid #999; padding: 5px 8px; font-size: 12px; }
                    th { background: #f0f0f0; text-align: left; }
                    td.num, th.num { text-align: right; }
                    tfoot td { font-weight: 700; background: #f7f7f7; }
                    @media print {
                        body { padding: 0; }
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <div><div class="label">${escapeHtml(config.numberLabel)}</div><div class="value">${escapeHtml(docNo)}</div></div>
                    <div><div class="label">Account</div><div class="value">${escapeHtml(accountName)}</div></div>
                    <div><div class="label">${escapeHtml(config.dateLabel)}</div><div class="value">${escapeHtml(mainForm.doc_date)}</div></div>
                    <div><div class="label">Department</div><div class="value">${escapeHtml(department?.department_name || '')}</div></div>
                    <div><div class="label">Vehicle No</div><div class="value">${escapeHtml(mainForm.vehicle_no)}</div></div>
                    <div><div class="label">Challan No</div><div class="value">${escapeHtml(mainForm.challan_no)}</div></div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th style="width:40px;">Sr.</th>
                            <th>Item Name</th>
                            <th class="num">Pieces</th>
                            <th class="num">Net Weight</th>
                            <th class="num">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsHtml || '<tr><td colspan="5" style="text-align:center;color:#888;">No entries</td></tr>'}
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" style="text-align:right;">Total</td>
                            <td class="num">${totalAmount.toFixed(2)}</td>
                        </tr>
                    </tfoot>
                </table>
            </body>
            </html>
        `;

        const printWindow = window.open('', '_blank', 'width=850,height=650');
        if (!printWindow) {
            toast.error('Please allow pop-ups to print');
            return;
        }
        printWindow.document.open();
        printWindow.document.write(html);
        printWindow.document.close();
        printWindow.focus();
        printWindow.onload = () => {
            printWindow.print();
        };
    };

    // =============================================================================
    // Render
    // =============================================================================
    return (
        <div className="bg-gray-50 p-4">
            {onBack && (
                <button
                    type="button"
                    onClick={onBack}
                    className="mb-2 flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700"
                >
                    ← Back
                </button>
            )}

            <div className="flex items-center justify-between mb-2">
                <h1 className="text-xl font-bold text-gray-800">{config.title}</h1>
            </div>

            <div className="max-w-6xl mx-auto">
                {!companyId ? (
                    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 text-center text-gray-500 text-sm">
                        No company context found. Please select a company first.
                    </div>
                ) : (
                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">

                        {/* Main form */}
                        <form onSubmit={handleSaveMain} className="pb-3 mb-3">
                            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 mb-2">
                                <div>
                                    <div className="flex items-center justify-between mb-0.5">
                                        <label className="block text-xs font-medium text-gray-600">{config.numberLabel}</label>
                                        <div className="flex items-center gap-2">
                                            {mainId && (
                                                <button
                                                    type="button"
                                                    onClick={handlePrint}
                                                    title={`Print ${config.docNoun}`}
                                                    className="hover:opacity-70 text-sm"
                                                >
                                                    🖨️
                                                </button>
                                            )}
                                            {mainId && (
                                                <button type="button" onClick={handleDeleteMain} title={`Delete this ${config.docNoun}`} className="hover:opacity-70">
                                                    <img src={deleteIcon} alt="Delete" className="w-3.5 h-3.5" />
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                    <DocSearchField
                                        ref={docNoRef}
                                        value={docNo}
                                        onChange={(val) => setDocNo(val)}
                                        options={existingMainsForSearch}
                                        numberKey={config.numberField}
                                        newLabel={config.newLabel}
                                        placeholder={config.searchPlaceholder}
                                        onSelectExisting={(m) => handleOpenMain(m)}
                                        onSelectNew={() => handleNewMain()}
                                        onEnterNext={() => focusAndSelect(mainDateRef)}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">{config.dateLabel}</label>
                                    <input
                                        ref={mainDateRef}
                                        type="text"
                                        value={mainForm.doc_date}
                                        onChange={(e) => setMainForm({ ...mainForm, doc_date: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainDepartmentRef)}
                                        placeholder="dd-mm-yyyy"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>

                                {/* Department - plain dropdown listing every department for this company */}
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Department</label>
                                    <select
                                        ref={mainDepartmentRef}
                                        value={mainForm.department_id}
                                        onChange={(e) => setMainForm({ ...mainForm, department_id: e.target.value })}
                                        onKeyDown={makeEnterToNext(mainAccountRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    >
                                        <option value="">Select department</option>
                                        {companyDepartments.map((dep) => (
                                            <option key={dep.id} value={dep.id}>
                                                {dep.department_name}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                <div className="sm:col-span-2">
                                    <SearchField
                                        ref={mainAccountRef}
                                        label="Account"
                                        value={mainForm.account_code}
                                        onChange={(val) => setMainForm({ ...mainForm, account_code: val })}
                                        options={companyAccounts}
                                        codeKey="code"
                                        labelKey="account_name"
                                        placeholder="Search account"
                                        showAllOnFocus
                                        onEnterNext={() => focusAndSelect(mainChallanNoRef)}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Challan No</label>
                                    <input
                                        ref={mainChallanNoRef}
                                        type="text"
                                        value={mainForm.challan_no}
                                        onChange={(e) => setMainForm({ ...mainForm, challan_no: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainVehicleNoRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Vehicle No</label>
                                    <input
                                        ref={mainVehicleNoRef}
                                        type="text"
                                        value={mainForm.vehicle_no}
                                        onChange={(e) => setMainForm({ ...mainForm, vehicle_no: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainDriverNameRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Driver Name</label>
                                    <input
                                        ref={mainDriverNameRef}
                                        type="text"
                                        value={mainForm.driver_name}
                                        onChange={(e) => setMainForm({ ...mainForm, driver_name: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainDriverPhoneRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Driver Phone</label>
                                    <input
                                        ref={mainDriverPhoneRef}
                                        type="text"
                                        value={mainForm.driver_phone_no}
                                        onChange={(e) => setMainForm({ ...mainForm, driver_phone_no: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainRemarksRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Freight</label>
                                    <input
                                        ref={mainFreightRef}
                                        type="text"
                                        value={mainForm.freight}
                                        onChange={(e) => setMainForm({ ...mainForm, freight: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainFreightRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div className="sm:col-span-1">
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Remarks</label>
                                    <input
                                        ref={mainRemarksRef}
                                        type="text"
                                        value={mainForm.remarks}
                                        onChange={(e) => setMainForm({ ...mainForm, remarks: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainSubmitRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div className="flex items-end">
                                    <button
                                        ref={mainSubmitRef}
                                        type="submit"
                                        disabled={isSavingMain}
                                        className="w-full px-4 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 bg-blue-500 hover:bg-blue-600"
                                    >
                                        {isSavingMain ? 'Saving...' : mainId ? 'Update' : 'Create'}
                                    </button>
                                </div>
                            </div>
                        </form>

                        {/* Detail entries - only once the main doc exists */}
                        {mainId && (
                            <>
                                <div className="border-t border-gray-200 pt-3 mb-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">
                                        {editingDetailId ? 'Edit Entry' : 'Add Entry'}
                                    </h3>
                                    <form onSubmit={handleSaveDetail} className="space-y-2">
                                        <div className="grid grid-cols-6 gap-2 items-end">
                                            <div className="col-span-1">
                                                <SearchField
                                                    ref={itemSubRef}
                                                    label="Item Sub"
                                                    value={detailForm.subitem_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, subitem_code: val, Item_code: '' })}
                                                    options={companySubItems}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder="Search"
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(itemNameRef)}
                                                />
                                            </div>

                                            <div className="col-span-2">
                                                <SearchField
                                                    ref={itemNameRef}
                                                    label="Item Name"
                                                    value={detailForm.Item_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, Item_code: val })}
                                                    options={itemOptionsForSubItem}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder={selectedSubItem ? 'Search item' : 'Pick item sub first'}
                                                    disabled={!selectedSubItem}
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(piecesRef)}
                                                />
                                            </div>

                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Pieces</label>
                                                <input
                                                    ref={piecesRef}
                                                    type="number"
                                                    value={detailForm.pieces}
                                                    onChange={(e) => setDetailForm({ ...detailForm, pieces: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(netWeightRef)}
                                                    min="0"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>

                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Net Wt.</label>
                                                <input
                                                    ref={netWeightRef}
                                                    type="number"
                                                    value={detailForm.net_weight}
                                                    onChange={(e) => setDetailForm({ ...detailForm, net_weight: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(detailSubmitRef)}
                                                    min="0"
                                                    step="0.01"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <button
                                                    ref={detailSubmitRef}
                                                    type="submit"
                                                    disabled={isSavingDetail}
                                                    className="w-full px-3 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 disabled:cursor-not-allowed bg-blue-500 hover:bg-blue-600"
                                                >
                                                    {isSavingDetail ? 'Saving...' : editingDetailId ? 'Update' : 'Save'}
                                                </button>
                                                {editingDetailId && (
                                                    <button
                                                        type="button"
                                                        onClick={resetDetailForm}
                                                        title="Cancel edit"
                                                        className="text-sm text-gray-500 hover:text-gray-700 ml-1"
                                                    >
                                                        ✕
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                {/* Entries table */}
                                <div className="border-t border-gray-200 pt-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">Entries</h3>
                                    {isLoadingDetails ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">Loading...</div>
                                    ) : details.length === 0 ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">No entries yet</div>
                                    ) : (
                                        <div className="overflow-x-auto border border-gray-200 rounded-lg">
                                            <table className="min-w-full divide-y divide-gray-200 text-sm">
                                                <thead className="bg-gray-50">
                                                    <tr>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Entry No</th>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Item</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Pieces</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Net Weight</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="bg-white divide-y divide-gray-100">
                                                    {details.map((row) => (
                                                        <tr key={row.id} className="hover:bg-gray-50">
                                                            <td className="px-2.5 py-1.5 text-gray-600">{row.entry_no}</td>
                                                            <td className="px-2.5 py-1.5 text-gray-800">{row.item_name || row.Item_code}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.pieces}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.net_weight}</td>
                                                            <td className="px-2.5 py-1.5">
                                                                <div className="flex items-center justify-end gap-2">
                                                                    <button onClick={() => handleEditDetailRow(row)} title="Edit">
                                                                        <img src={editIcon} alt="Edit" className="w-4 h-4" />
                                                                    </button>
                                                                    <button onClick={() => handleDeleteDetail(row)} title="Delete">
                                                                        <img src={deleteIcon} alt="Delete" className="w-4 h-4" />
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                                <tfoot className="bg-gray-50 border-t-2 border-gray-200">
                                                    <tr>
                                                        <td className="px-2.5 py-1.5 font-semibold text-gray-700" colSpan={2}>
                                                            Total
                                                        </td>
                                                        <td className="px-2.5 py-1.5 text-right font-semibold text-gray-800">
                                                            {detailsTotals.pieces}
                                                        </td>
                                                        <td className="px-2.5 py-1.5 text-right font-semibold text-gray-800">
                                                            {detailsTotals.net_weight}
                                                        </td>
                                                        <td className="px-2.5 py-1.5"></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

export default InwardGatePassEntry;