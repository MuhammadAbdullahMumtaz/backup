import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { useDispatch, useSelector } from 'react-redux';
import api from '../../services/api';
import { setSystemNameIp } from '../../store/slices/companySlice';
import { fetchClientSystemInfo } from '../../utils/getSystemInfo';

import addIcon from '../../assets/add.png';
import editIcon from '../../assets/edit.png';
import deleteIcon from '../../assets/delete.png';

const EMPTY_FORM = {
  company_id: '',
  department_name: '',
};

const Department = () => {
  const [departments, setDepartments] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' | 'edit'
  const [formData, setFormData] = useState(EMPTY_FORM);
  const [selectedDepartment, setSelectedDepartment] = useState(null);

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const dispatch = useDispatch();
  const { user, systemNameIp } = useSelector((state) => state.company);

  useEffect(() => {
    fetchDepartments();
    fetchCompanies();
    if (!systemNameIp) {
      fetchClientSystemInfo().then((ip) => {
        if (ip) dispatch(setSystemNameIp(ip));
      });
    }
  }, []);

  // Small helper — spread into every write payload
  const withMeta = (body = {}) => ({
    ...body,
    performed_by: user?.username || user?.name || 'Unknown',
    system_name_ip: systemNameIp,
  });

  const fetchDepartments = async () => {
    setIsLoading(true);
    try {
      const res = await api.get('/department');
      setDepartments(res.data?.data || []);
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to load departments');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCompanies = async () => {
    try {
      const res = await api.get('/company');
      setCompanies(res.data?.data || []);
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to load companies');
    }
  };

  const handleOpenAddModal = () => {
    setModalMode('add');
    setFormData(EMPTY_FORM);
    setSelectedDepartment(null);
    setShowModal(true);
  };

  const handleOpenEditModal = (department) => {
    setModalMode('edit');
    setSelectedDepartment(department);
    setFormData({
      company_id: department.company_id || '',
      department_name: department.department_name || '',
    });
    setShowModal(true);
  };

  const handleCloseModal = () => {
    if (isSubmitting) return;
    setShowModal(false);
    setFormData(EMPTY_FORM);
    setSelectedDepartment(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.company_id) {
      toast.error('Company is required');
      return;
    }

    if (!formData.department_name.trim()) {
      toast.error('Department name is required');
      return;
    }

    setIsSubmitting(true);
    try {
      if (modalMode === 'add') {
        await api.post('/department/add', withMeta(formData));
        toast.success('Department added successfully');
      } else {
        const id = selectedDepartment.id;
        await api.put(`/department/update/${id}`, withMeta(formData));
        toast.success('Department updated successfully');
      }
      handleCloseModal();
      fetchDepartments();
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Something went wrong, please try again');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteClick = (department) => {
    setDeleteTarget(department);
  };

  const handleCancelDelete = () => {
    if (isDeleting) return;
    setDeleteTarget(null);
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const id = deleteTarget.id;

    setIsDeleting(true);
    try {
      await api.delete(`/department/delete/${id}`, { data: withMeta() });
      setDepartments((prev) => prev.filter((d) => d.id !== id));
      toast.success('Department deleted successfully');
      setDeleteTarget(null);
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to delete department');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-2xl font-semibold text-gray-800">Departments</h2>

        <button
          onClick={handleOpenAddModal}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-md transition-colors"
        >
          <img src={addIcon} alt="" className="w-4 h-4" />
          Add Department
        </button>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16 text-gray-500">
          Loading departments...
        </div>
      ) : departments.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <p className="text-gray-600 text-lg font-medium">No departments yet</p>
          <p className="text-gray-400 text-sm mt-1">
            Add your first department to get started.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto border border-gray-200 rounded-lg">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Department Name
                </th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-100">
              {departments.map((department) => (
                <tr key={department.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {department.company_name}
                  </td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">
                    {department.department_name}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-3">
                      <button
                        onClick={() => handleOpenEditModal(department)}
                        className="focus:outline-none"
                        title="Edit"
                      >
                        <img
                          src={editIcon}
                          alt="Edit"
                          className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity"
                        />
                      </button>
                      <button
                        onClick={() => handleDeleteClick(department)}
                        className="focus:outline-none"
                        title="Delete"
                      >
                        <img
                          src={deleteIcon}
                          alt="Delete"
                          className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity"
                        />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[70]">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md mx-4 p-6 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              {modalMode === 'add' ? 'Add Department' : 'Edit Department'}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Company
                </label>
                <select
                  name="company_id"
                  value={formData.company_id}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select company</option>
                  {companies.map((company) => (
                    <option key={company.id} value={company.id}>
                      {company.company_name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Department Name
                </label>
                <input
                  type="text"
                  name="department_name"
                  value={formData.department_name}
                  onChange={handleChange}
                  autoFocus
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter department name"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors disabled:opacity-60"
                >
                  {isSubmitting
                    ? 'Saving...'
                    : modalMode === 'add'
                      ? 'Add Department'
                      : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[70]">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-sm mx-4 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">
              Delete Department
            </h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to delete{' '}
              <span className="font-medium text-gray-800">
                {deleteTarget.department_name}
              </span>
              ? This action cannot be undone.
            </p>

            <div className="flex justify-end gap-3">
              <button
                onClick={handleCancelDelete}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors disabled:opacity-60"
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Department;