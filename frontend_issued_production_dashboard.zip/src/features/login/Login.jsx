import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from 'react-redux';
import api from '../../services/api';
import { fetchClientSystemInfo } from '../../utils/GetSystemInfo';
import { setSystemNameIp } from '../../store/slices/companySlice';

import addIcon from '../../assets/add.png';
import editIcon from '../../assets/edit.png';
import deleteIcon from '../../assets/delete.png';

const EMPTY_FORM = {
  company_id: '',
  username: '',
  password: '',
  role: 'User',
};

const Login = () => {
  const [logins, setLogins] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingRecord, setIsLoadingRecord] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState('add');
  const [formData, setFormData] = useState(EMPTY_FORM);
  const [selectedLogin, setSelectedLogin] = useState(null);
  const [companies, setCompanies] = useState([]);

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const dispatch = useDispatch();
  const { user, companyId, companyName, systemNameIp } = useSelector((state) => state.company);
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    fetchLogins();
    if (companyName === 'AAM Tech Solutions') {
      fetchCompanies();
    }
    if (!systemNameIp) {
      fetchClientSystemInfo().then((ip) => {
        if (ip) dispatch(setSystemNameIp(ip));
      });
    }
  }, []);

  const fetchCompanies = async () => {
    try {
      const res = await api.get('/company');
      setCompanies(res.data?.data || []);
    } catch (error) {
      toast.error('Failed to load companies');
    }
  };

  const fetchLogins = async () => {
    setIsLoading(true);
    try {
      const res = await api.get('/login');
      let allLogins = res.data?.data || [];

      // Filter logins based on company name
      if (companyName === 'AAM Tech Solutions') {
        // Show all logins for AAM Tech Solutions
        setLogins(allLogins);
      } else {
        // Show only logins for the current company
        const filteredLogins = allLogins.filter(login => login.company_name === companyName);
        setLogins(filteredLogins);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to load logins');
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenAddModal = () => {
    setModalMode('add');
    setFormData({
      ...EMPTY_FORM,
      company_id: companyName === 'AAM Tech Solutions' ? '' : (companyId || '')
    });
    setSelectedLogin(null);
    setShowModal(true);
  };
  // Fetches the full record (including password) via getLoginById so the
  // form can be pre-filled, since the list endpoint omits the password.
  const handleOpenEditModal = async (login) => {
    setModalMode('edit');
    setSelectedLogin(login);
    setShowModal(true);
    setIsLoadingRecord(true);
    try {
      const res = await api.get(`/login/${login.id}`);
      const record = res.data?.data;
      setFormData({
        company_id: record?.company_id || '',
        username: record?.username || '',
        password: record?.password || '',
        role: record?.role || 'User',
      });
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to load login details');
      setShowModal(false);
    } finally {
      setIsLoadingRecord(false);
    }
  };

  const handleCloseModal = () => {
    if (isSubmitting) return;
    setShowModal(false);
    setFormData(EMPTY_FORM);
    setSelectedLogin(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.company_id) { toast.error('Please select a company'); return; }
    if (!formData.username.trim()) { toast.error('Username is required'); return; }
    if (!formData.password.trim()) { toast.error('Password is required'); return; }
    if (!formData.role) { toast.error('Please select a role'); return; }

    setIsSubmitting(true);
    try {
      const payload = {
        ...formData,
        performed_by: user?.username || user?.name || 'Unknown',
        system_name_ip: systemNameIp,
      };

      if (modalMode === 'add') {
        await api.post('/login/add', payload);
        toast.success('Login added successfully');
      } else {
        const id = selectedLogin.id;
        await api.put(`/login/update/${id}`, payload);
        toast.success('Login updated successfully');
      }
      handleCloseModal();
      fetchLogins();
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Something went wrong, please try again');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteClick = (login) => {
    setDeleteTarget(login);
  };

  const handleCancelDelete = () => {
    if (isDeleting) return;
    setDeleteTarget(null);
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const id = deleteTarget.id;

    setIsDeleting(true);
    try {
      await api.delete(`/login/delete/${id}`, {
        data: {
          performed_by: user?.username || user?.name || 'Unknown',
          system_name_ip: systemNameIp,
          target_username: deleteTarget.username,
        },
      });
      setLogins((prev) => prev.filter((l) => l.id !== id));
      toast.success('Login deleted successfully');
      setDeleteTarget(null);
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to delete login');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-2xl font-semibold text-gray-800">Logins</h2>

        <button
          onClick={handleOpenAddModal}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-md transition-colors"
        >
          <img src={addIcon} alt="" className="w-4 h-4" />
          Add Login
        </button>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16 text-gray-500">
          Loading logins...
        </div>
      ) : logins.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <p className="text-gray-600 text-lg font-medium">No logins yet</p>
          <p className="text-gray-400 text-sm mt-1">
            Add a login to get started.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto border border-gray-200 rounded-lg">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Username
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Role
                </th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-100">
              {logins.map((login) => (
                <tr key={login.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">
                    {login.company_name}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{login.username}</td>
                  <td className="px-4 py-3 text-sm">
                    <span
                      className={`px-2 py-0.5 rounded-full text-xs font-semibold ${login.role === 'Admin'
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-gray-100 text-gray-600'
                        }`}
                    >
                      {login.role}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-3">
                      <button
                        onClick={() => handleOpenEditModal(login)}
                        className="focus:outline-none"
                        title="Edit"
                      >
                        <img
                          src={editIcon}
                          alt="Edit"
                          className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity"
                        />
                      </button>
                      <button
                        onClick={() => handleDeleteClick(login)}
                        className="focus:outline-none"
                        title="Delete"
                      >
                        <img
                          src={deleteIcon}
                          alt="Delete"
                          className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity"
                        />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[70]">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md mx-4 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              {modalMode === 'add' ? 'Add Login' : 'Edit Login'}
            </h3>

            {isLoadingRecord ? (
              <div className="py-10 text-center text-gray-500 text-sm">
                Loading login details...
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Company
                  </label>
                  {companyName === 'AAM Tech Solutions' ? (
                    modalMode === 'add' ? (
                      <select
                        name="company_id"
                        value={formData.company_id}
                        onChange={handleChange}
                        className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select a company</option>
                        {companies.map((c) => (
                          <option key={c.id} value={c.id}>{c.company_name}</option>
                        ))}
                      </select>
                    ) : (
                      <div className="w-full border border-gray-200 bg-gray-50 rounded-md px-3 py-2 text-sm text-gray-700">
                        {selectedLogin?.company_name}
                      </div>
                    )
                  ) : (
                    <div className="w-full border border-gray-200 bg-gray-50 rounded-md px-3 py-2 text-sm text-gray-700">
                      {companyName}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Username
                  </label>
                  <input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter username"
                    autoComplete="off"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Password
                  </label>
                  <input
                    type="text"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter password"
                    autoComplete="new-password"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Role
                  </label>
                  <select
                    name="role"
                    value={formData.role}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Admin">Admin</option>
                    <option value="User">User</option>
                  </select>
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleCloseModal}
                    disabled={isSubmitting}
                    className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors disabled:opacity-60"
                  >
                    {isSubmitting
                      ? 'Saving...'
                      : modalMode === 'add'
                        ? 'Add Login'
                        : 'Save Changes'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[70]">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-sm mx-4 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">
              Delete Login
            </h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to delete{' '}
              <span className="font-medium text-gray-800">
                {deleteTarget.username}
              </span>{' '}
              for{' '}
              <span className="font-medium text-gray-800">
                {deleteTarget.company_name}
              </span>
              ? This action cannot be undone.
            </p>

            <div className="flex justify-end gap-3">
              <button
                onClick={handleCancelDelete}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors disabled:opacity-60"
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Login;