import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { useDispatch, useSelector } from 'react-redux';
import { setCurrentMonth, setSystemNameIp } from '../../store/slices/companySlice';
import api from '../../services/api';
import { fetchClientSystemInfo } from '../../utils/GetSystemInfo';

import addIcon from '../../assets/add.png';
import editIcon from '../../assets/edit.png';
import deleteIcon from '../../assets/delete.png';

const EMPTY_FORM = {
  company_id: '',
  year_detail: '',
  current_month: '',
  status: 'Inactive',
  start_date: '',
  end_date: '',
};

// Format date to dd/mm/yyyy
const formatDateToDisplay = (dateString) => {
  if (!dateString) return '';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return '';
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

// Parse dd/mm/yyyy to yyyy-mm-dd for backend
const parseDisplayDateToBackend = (dateString) => {
  if (!dateString) return '';
  const parts = dateString.split('/');
  if (parts.length !== 3) return '';
  const day = parts[0].padStart(2, '0');
  const month = parts[1].padStart(2, '0');
  const year = parts[2];
  return `${year}-${month}-${day}`;
};

// Validate date format dd/mm/yyyy
const isValidDateFormat = (dateString) => {
  if (!dateString) return false;
  const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  if (!regex.test(dateString)) return false;

  const [, day, month, year] = dateString.match(regex);
  const date = new Date(`${year}-${month}-${day}`);
  return !isNaN(date.getTime());
};

// Convert backend date to display format
const toDisplayDate = (value) => {
  if (!value) return '';
  return formatDateToDisplay(value);
};

const FinancialYear = () => {
  const [financialYears, setFinancialYears] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add' | 'edit'
  const [formData, setFormData] = useState(EMPTY_FORM);
  const [selectedYear, setSelectedYear] = useState(null);

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const dispatch = useDispatch();
  const { companyId, user, companyName, financialYearId, systemNameIp } = useSelector((state) => state.company);
  const isAdmin = user?.role === 'Admin';

  useEffect(() => {
    fetchFinancialYears();
    fetchCompanies();
    if (!systemNameIp) {
      fetchClientSystemInfo().then((ip) => {
        if (ip) dispatch(setSystemNameIp(ip));
      });
    }
  }, []);

  const fetchFinancialYears = async () => {
    setIsLoading(true);
    try {
      let url = '/financial-year';

      if (companyId && companyName !== 'AAM Tech Solutions') {
        url = `/financial-year/company/${companyId}`;
      }

      const res = await api.get(url);
      let allYears = res.data?.data || [];

      if (!url.includes('/company/') && companyName !== 'AAM Tech Solutions') {
        const filteredYears = allYears.filter(year => year.company_name === companyName);
        setFinancialYears(filteredYears);
      } else {
        setFinancialYears(allYears);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to load financial years');
      setFinancialYears([]);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCompanies = async () => {
    try {
      const res = await api.get('/company');
      let allCompanies = res.data?.data || [];

      if (companyName === 'AAM Tech Solutions') {
        setCompanies(allCompanies);
      } else {
        const currentCompany = allCompanies.filter(comp => comp.company_name === companyName);
        setCompanies(currentCompany);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Failed to load companies');
    }
  };

  const handleOpenAddModal = () => {
    setModalMode('add');
    setFormData({
      ...EMPTY_FORM,
      company_id:
        companyName !== 'AAM Tech Solutions' && companies.length > 0
          ? companies[0].id
          : '',
      current_month: '',
      status: 'Inactive'
    });
    setSelectedYear(null);
    setShowModal(true);
  };

  const handleOpenEditModal = (year) => {
    setModalMode('edit');
    setSelectedYear(year);
    setFormData({
      company_id: year.company_id || '',
      year_detail: year.year_detail || '',
      current_month: year.current_month || '',
      status: year.is_current ? 'Active' : (year.status || 'Inactive'), // Map 'Current' to 'Active' for editing
      start_date: toDisplayDate(year.start_date),
      end_date: toDisplayDate(year.end_date),
    });
    setShowModal(true);
  };

  const handleCloseModal = () => {
    if (isSubmitting) return;
    setShowModal(false);
    setFormData(EMPTY_FORM);
    setSelectedYear(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleDateChange = (e) => {
    const { name, value } = e.target;
    // Allow only numbers and slashes
    const sanitizedValue = value.replace(/[^0-9/]/g, '');

    // Auto-add slashes
    let formattedValue = sanitizedValue;
    if (sanitizedValue.length === 2 && !sanitizedValue.includes('/')) {
      formattedValue = sanitizedValue + '/';
    } else if (sanitizedValue.length === 5 && sanitizedValue.split('/').length === 2) {
      const parts = sanitizedValue.split('/');
      if (parts[0].length === 2 && parts[1].length === 2) {
        formattedValue = sanitizedValue + '/';
      }
    }

    setFormData((prev) => ({ ...prev, [name]: formattedValue }));
  };

  const handleDateBlur = (e) => {
    const { name, value } = e.target;
    if (value && !isValidDateFormat(value)) {
      toast.error('Please enter date in dd/mm/yyyy format');
      setFormData((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.company_id) {
      toast.error('Please select a company');
      return;
    }
    if (!formData.year_detail.trim()) {
      toast.error('Year detail is required');
      return;
    }
    if (!formData.start_date || !formData.end_date) {
      toast.error('Start date and end date are required');
      return;
    }

    if (!formData.current_month) {
      toast.error('Current month is required');
      return;
    }

    // Validate date format
    if (!isValidDateFormat(formData.start_date)) {
      toast.error('Start date must be in dd/mm/yyyy format');
      return;
    }
    if (!isValidDateFormat(formData.end_date)) {
      toast.error('End date must be in dd/mm/yyyy format');
      return;
    }

    // Convert dates to backend format
    const startDateBackend = parseDisplayDateToBackend(formData.start_date);
    const endDateBackend = parseDisplayDateToBackend(formData.end_date);

    if (!startDateBackend || !endDateBackend) {
      toast.error('Invalid date format');
      return;
    }

    const startDate = new Date(startDateBackend);
    const endDate = new Date(endDateBackend);

    if (endDate <= startDate) {
      toast.error('End date must be after start date');
      return;
    }

    // Validate year format
    const yearPattern = /^\d{4}-\d{4}$/;
    if (!yearPattern.test(formData.year_detail.trim())) {
      toast.error('Year detail should be in format YYYY-YYYY (e.g., 2025-2026)');
      return;
    }

    const submitData = {
      ...formData,
      current_month: formData.current_month,
      start_date: startDateBackend,
      end_date: endDateBackend,
      performed_by: user?.username || user?.name || 'Unknown',
      system_name_ip: systemNameIp,
    };


    setIsSubmitting(true);
    try {
      if (modalMode === 'add') {
        await api.post('/financial-year/add', submitData);
        toast.success('Financial year added successfully');
      } else {
        const id = selectedYear.id;
        await api.put(`/financial-year/update/${id}`, submitData);
        toast.success('Financial year updated successfully');

        if (String(id) === String(financialYearId)) {
          try {
            const monthResponse = await api.get(`/financial-year/current-month/${id}`);
            if (monthResponse.data?.success) {
              dispatch(setCurrentMonth(monthResponse.data.data.current_month));
            }
          } catch (monthError) {
            console.error('Error syncing current month to navbar:', monthError);
          }
        }
      }
      handleCloseModal();
      fetchFinancialYears();
    } catch (error) {
      toast.error(error?.response?.data?.message || 'Something went wrong, please try again');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteClick = (year) => {
    setDeleteTarget(year);
  };

  const handleCancelDelete = () => {
    if (isDeleting) return;
    setDeleteTarget(null);
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const id = deleteTarget.id;

    setIsDeleting(true);
    try {
      await api.delete(`/financial-year/delete/${id}`, {
        data: {
          performed_by: user?.username || user?.name || 'Unknown',
          system_name_ip: systemNameIp,
          target_year_detail: deleteTarget.year_detail,
        },
      });
      setFinancialYears((prev) => prev.filter((fy) => fy.id !== id));
      toast.success('Financial year deleted successfully');
      setDeleteTarget(null);
    } catch (error) {
      const errorMessage = error?.response?.data?.message || 'Failed to delete financial year';
      toast.error(errorMessage);
    } finally {
      setIsDeleting(false);
    }
  };

  const getStatusBadgeColor = (status, isCurrent = false) => {
    if (isCurrent) return 'bg-blue-100 text-blue-700';
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-700';
      case 'Inactive':
        return 'bg-gray-100 text-gray-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  const getStatusDisplay = (year) => {
    if (year.is_current) return 'Current';
    return year.status || 'Inactive';
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-2xl font-semibold text-gray-800">Financial Years</h2>

        <button
          onClick={handleOpenAddModal}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-md transition-colors"
        >
          <img src={addIcon} alt="" className="w-4 h-4" />
          Add Financial Year
        </button>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16 text-gray-500">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            Loading financial years...
          </div>
        </div>
      ) : financialYears.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center border border-gray-200 rounded-lg bg-gray-50">
          <p className="text-gray-600 text-lg font-medium">No financial years yet</p>
          <p className="text-gray-400 text-sm mt-1">
            Add a financial year to get started.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto border border-gray-200 rounded-lg">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Year Detail
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Current Month
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Start Date
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  End Date
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-100">
              {financialYears.map((year) => (
                <tr key={year.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">
                    {year.company_name}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{year.year_detail}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {year.current_month || '-'}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {toDisplayDate(year.start_date)}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {toDisplayDate(year.end_date)}
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <span
                      className={`px-2 py-0.5 rounded-full text-xs font-semibold ${getStatusBadgeColor(
                        year.status,
                        year.is_current
                      )}`}
                    >
                      {getStatusDisplay(year)}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-3">
                      {/* FIX 1: Allow editing even for current year */}
                      <button
                        onClick={() => handleOpenEditModal(year)}
                        className="focus:outline-none"
                        title="Edit"
                        // Remove the disabled condition for editing
                      >
                        <img
                          src={editIcon}
                          alt="Edit"
                          className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity"
                        />
                      </button>
                      
                      {/* FIX 2: Allow deletion even for current year (with warning) */}
                      <button
                        onClick={() => handleDeleteClick(year)}
                        className="focus:outline-none"
                        title="Delete"
                        // Remove the disabled condition for deletion
                      >
                        <img
                          src={deleteIcon}
                          alt="Delete"
                          className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity"
                        />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[70]">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md mx-4 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              {modalMode === 'add' ? 'Add Financial Year' : 'Edit Financial Year'}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Company <span className="text-red-500">*</span>
                </label>
                <select
                  name="company_id"
                  value={formData.company_id}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  disabled={modalMode === 'edit'}
                >
                  <option value="">Select a company</option>
                  {companies.map((company) => (
                    <option key={company.id} value={company.id}>
                      {company.company_name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Year Detail <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="year_detail"
                  value={formData.year_detail}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g. 2025-2026"
                  disabled={modalMode === 'edit' && selectedYear?.is_current}
                />
                <p className="text-xs text-gray-400 mt-1">Format: YYYY-YYYY (e.g., 2025-2026)</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Current Month <span className="text-red-500">*</span>
                </label>

                {/* FIX 3: Current month dropdown is now always enabled */}
                <select
                  name="current_month"
                  value={formData.current_month}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Month</option>
                  <option value="January">January</option>
                  <option value="February">February</option>
                  <option value="March">March</option>
                  <option value="April">April</option>
                  <option value="May">May</option>
                  <option value="June">June</option>
                  <option value="July">July</option>
                  <option value="August">August</option>
                  <option value="September">September</option>
                  <option value="October">October</option>
                  <option value="November">November</option>
                  <option value="December">December</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Start Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="start_date"
                    value={formData.start_date}
                    onChange={handleDateChange}
                    onBlur={handleDateBlur}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 [&::-webkit-calendar-picker-indicator]:hidden"
                    placeholder="dd/mm/yyyy"
                    maxLength="10"
                    disabled={modalMode === 'edit' && selectedYear?.is_current}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    End Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="end_date"
                    value={formData.end_date}
                    onChange={handleDateChange}
                    onBlur={handleDateBlur}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 [&::-webkit-calendar-picker-indicator]:hidden"
                    placeholder="dd/mm/yyyy"
                    maxLength="10"
                    disabled={modalMode === 'edit' && selectedYear?.is_current}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
                {selectedYear?.is_current && modalMode === 'edit' && (
                  <p className="text-xs text-blue-600 mt-1">
                    Note: Current year will be updated from 'Current' to 'Active' status
                  </p>
                )}
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors disabled:opacity-60"
                >
                  {isSubmitting
                    ? 'Saving...'
                    : modalMode === 'add'
                      ? 'Add Financial Year'
                      : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-[20]">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-sm mx-4 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">
              Delete Financial Year
            </h3>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to delete{' '}
              <span className="font-medium text-gray-800">
                {deleteTarget.year_detail}
              </span>{' '}
              for{' '}
              <span className="font-medium text-gray-800">
                {deleteTarget.company_name}
              </span>
              ? This action cannot be undone.
            </p>

            {deleteTarget.is_current && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 mb-4">
                <p className="text-sm text-yellow-700">
                  ⚠️ This is the current financial year. Deleting it may affect existing transactions.
                </p>
              </div>
            )}

            <div className="flex justify-end gap-3">
              <button
                onClick={handleCancelDelete}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors disabled:opacity-60"
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FinancialYear;