import React, { useState } from 'react';
import sideImg from '../assets/side.png';

const Sidebar = ({
  isOpen,
  isNavbarOpen,
  toggleSidebar,
  onAccountsClick,
  onItemEntryClick,
  onInwardGatePassEntryClick,
  onVoucherEntryClick,
  onPurchaseEntryClick,
  onIssuedEntryClick,
  onProductionEntryClick,
  onSalesContractEntryClick,
  onOutwardGatePassEntryClick,
  onSalesEntryClick,
  onLedgerClick,
  onTrialBalanceClick,
  onAgingReportClick,
  onSalesReportClick,
  onPurchaseReportClick,
  onIssuedReportClick,
  onProductionReportClick,
  onGatepassReportClick,
  onRawStockReportClick,
  onFinishedStockReportClick,
  onStockReportClick,
  onUserEntriesReportClick,
  onProfitlossReportClick,
}) => {
  const [activeLink, setActiveLink] = useState(null);
  // 'dataEntry' (default) or 'reports' - controls which heading looks
  // active and which panel is slid into view.
  const [activeTab, setActiveTab] = useState('dataEntry');

  const handleLinkClick = (linkName, onClickHandler) => {
    setActiveLink(linkName);
    if (onClickHandler) {
      onClickHandler();
    }
  };

  return (
    <>
      {/* Sidebar Panel */}
      <div
        className={`fixed left-0 h-[calc(100vh-4rem)] w-64 bg-white shadow-lg transition-all duration-300 ${isNavbarOpen ? 'top-16' : 'top-0 h-screen'
          } ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        {/* Header row with toggle icon, separate from the list */}
        <div className="flex items-center absolute justify-between pl-52 pt-2 pointer-events-none">
          <button
            onClick={toggleSidebar}
            className="p-1 rounded-md hover:bg-gray-100 transition-colors pointer-events-auto"
          >
            <img
              src={sideImg}
              alt="Collapse Sidebar"
              className="w-4 h-4"
            />
          </button>
        </div>

        <div className="px-6 pb-2 h-[calc(100%-0.5rem)] flex flex-col">
          {/* Tab headings: Data Entry / Reports side by side. The inactive
              one is shown in a light color and, when clicked, becomes
              active and the panels slide to reveal its links. */}
          <div className="flex items-center gap-4 border-b pb-2 flex-shrink-0">
            <h2
              onClick={() => setActiveTab('dataEntry')}
              className={`text-lg font-bold cursor-pointer transition-colors ${activeTab === 'dataEntry' ? 'text-gray-800' : 'text-gray-300 hover:text-gray-400'
                }`}
            >
              Data Entry
            </h2>
            <h2
              onClick={() => setActiveTab('reports')}
              className={`text-lg font-bold cursor-pointer transition-colors ${activeTab === 'reports' ? 'text-gray-800' : 'text-gray-300 hover:text-gray-400'
                }`}
            >
              Reports
            </h2>
          </div>

          {/* Sliding viewport: two full-width panels sit side by side inside
              a track twice as wide as the viewport; translating the track by
              -50% brings the Reports panel into view and vice versa. */}
          <div className="relative flex-1 overflow-y-auto overflow-x-hidden mt-4">
            <div
              className={`flex w-[200%] transition-transform duration-300 ease-in-out ${activeTab === 'reports' ? '-translate-x-1/2' : 'translate-x-0'
                }`}
            >
              {/* ---- Data Entry panel ---- */}
              <div className="w-1/2 flex-shrink-0 pr-2">
                <ul className="space-y-3 border-l border-gray-200 pl-4">
                  <li>
                    <span
                      onClick={() => handleLinkClick('accounts', onAccountsClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'accounts' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Accounts
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('voucher', onVoucherEntryClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'voucher' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Voucher
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('item', onItemEntryClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'item' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Item
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('sales-contract-entry', onSalesContractEntryClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'sales-contract-entry' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Sales Contract
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('inward-gate-pass-entry', onInwardGatePassEntryClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'inward-gate-pass-entry' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Inward Gate Pass
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('purchase', onPurchaseEntryClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'purchase' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Purchase
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('issued-entry', onIssuedEntryClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'issued-entry' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Issued
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('production-entry', onProductionEntryClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'production-entry' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Production
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('outward-gate-pass-entry', onOutwardGatePassEntryClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'outward-gate-pass-entry' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Outward Gate Pass
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('sales', onSalesEntryClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'sales' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Sales
                    </span>
                  </li>
                </ul>
              </div>

              {/* ---- Reports panel ---- */}
              <div className="w-1/2 flex-shrink-0 pl-2">
                <ul className="space-y-3 border-l border-gray-200 pl-4">
                  <li>
                    <span
                      onClick={() => handleLinkClick('ledger', onLedgerClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'ledger' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Ledger
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('aging-report', onAgingReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'aging-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Aging
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('sales-report', onSalesReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'sales-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Sales
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('purchase-report', onPurchaseReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'purchase-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Purchase
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('user-entries-report', onUserEntriesReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'user-entries-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      User Entries
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('issued-report', onIssuedReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'issued-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Issued
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('production-report', onProductionReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'production-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Production
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('gatepass-report', onGatepassReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'gatepass-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Gate Pass
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('raw-stock-report', onRawStockReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'raw-stock-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Raw Stocks
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('finished-stock-report', onFinishedStockReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'finished-stock-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Finished Stocks
                    </span>
                  </li>
                  {/* <li>
                    <span
                      onClick={() => handleLinkClick('stock-report', onStockReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'stock-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Stocks
                    </span>
                  </li> */}
                  <li>
                    <span
                      onClick={() => handleLinkClick('profit-loss-report', onProfitlossReportClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'profit-loss-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Profit & Loss
                    </span>
                  </li>
                  <li>
                    <span
                      onClick={() => handleLinkClick('trial-balance', onTrialBalanceClick)}
                      className={`text-gray-800 cursor-pointer relative inline-block
                        after:content-[''] after:absolute after:w-full after:h-[2px] 
                        after:bottom-0 after:left-0 after:bg-gray-600 
                        after:transition-transform after:duration-300 
                        hover:after:scale-x-100 hover:after:origin-bottom-left 
                        hover:text-gray-600 transition-colors
                        ${activeLink === 'trial-balance' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                    >
                      Trail Balance
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating reopen tab, only visible when sidebar is closed */}
      {!isOpen && (
        <button
          onClick={toggleSidebar}
          className={`fixed left-0 z-40 bg-white py-3 px-1 rounded-r-lg shadow-md hover:shadow-lg transition-shadow ${isNavbarOpen ? 'top-20' : 'top-4'
            }`}
        >
          <img
            src={sideImg}
            alt="Expand Sidebar"
            className="w-4 h-4 rotate-180"
          />
        </button>
      )}
    </>
  );
};

export default Sidebar;