export const fetchClientSystemInfo = async () => {
  try {
    const res = await fetch('https://api.ipify.org?format=json');
    const data = await res.json();
    return data?.ip || null;
  } catch (err) {
    console.error('Failed to fetch client IP:', err);
    return null;
  }
};