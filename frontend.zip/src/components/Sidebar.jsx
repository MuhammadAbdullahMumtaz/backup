import React, { useState } from 'react';

const Sidebar = ({ isOpen, toggleSidebar, onAccountsClick, onItemEntryClick, onVoucherEntryClick }) => {
  const [activeLink, setActiveLink] = useState(null);

  const handleLinkClick = (linkName, onClickHandler) => {
    setActiveLink(linkName);
    if (onClickHandler) {
      onClickHandler();
    }
  };

  return (
    <>
      {/* Sidebar Panel */}
      <div
        className={`fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-white shadow-lg transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Header row with toggle icon, separate from the list */}
        <div className="flex items-center absolute justify-between pl-52 pt-2">
          <button
            onClick={toggleSidebar}
            className="p-1 rounded-md hover:bg-gray-100 transition-colors"
          >
            <img
              src="/src/assets/side.png"
              alt="Collapse Sidebar"
              className="w-4 h-4"
            />
          </button>
        </div>

        <div className="px-6 pb-2 overflow-y-auto h-[calc(100%-0.5rem)]">
          <div className="mb-8">
            <h2 className="text-lg font-bold text-gray-800 border-b pb-2">Data Entry</h2>
            <ul className="mt-4 space-y-3 border-l border-gray-200 pl-4">
              <li>
                <span
                  onClick={() => handleLinkClick('accounts', onAccountsClick)}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'accounts' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Accounts
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('voucher', onVoucherEntryClick)}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'voucher' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Voucher
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('item', onItemEntryClick)}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'item' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Item
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('purchase')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'purchase' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Purchase
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('sales')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'sales' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Sales
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('gatepass')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'gatepass' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Gate Pass
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="text-lg font-bold text-gray-800 border-b pb-2">Reports</h2>
            <ul className="mt-4 space-y-3 border-l border-gray-200 pl-4">
              <li>
                <span
                  onClick={() => handleLinkClick('ledger')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'ledger' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Ledger
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('aging')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'aging' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Aging
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('purchase-report')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'purchase-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Purchase
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('sales-report')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'sales-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Sales
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('gatepass-report')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'gatepass-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Gate Pass
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('trialbalance')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'trialbalance' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Trial balance
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('stocks')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'stocks' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Stocks
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('item-report')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'item-report' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Item
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('cashbook')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'cashbook' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Cash book
                </span>
              </li>
              <li>
                <span
                  onClick={() => handleLinkClick('finalaccounts')}
                  className={`text-gray-800 cursor-pointer relative inline-block
                    after:content-[''] after:absolute after:w-full after:h-[2px] 
                    after:bottom-0 after:left-0 after:bg-gray-600 
                    after:transition-transform after:duration-300 
                    hover:after:scale-x-100 hover:after:origin-bottom-left 
                    hover:text-gray-600 transition-colors
                    ${activeLink === 'finalaccounts' ? 'after:scale-x-100' : 'after:scale-x-0'}`}
                >
                  Final accounts
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Floating reopen tab, only visible when sidebar is closed */}
      {!isOpen && (
        <button
          onClick={toggleSidebar}
          className="fixed left-0 top-20 z-40 bg-white py-3 px-1 rounded-r-lg shadow-md hover:shadow-lg transition-shadow"
        >
          <img
            src="/src/assets/side.png"
            alt="Expand Sidebar"
            className="w-4 h-4 rotate-180"
          />
        </button>
      )}
    </>
  );
};

export default Sidebar;