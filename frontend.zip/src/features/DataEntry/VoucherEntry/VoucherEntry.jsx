import React, { useState, useEffect, useMemo, useRef } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';

const API = {
    voucherType: 'http://localhost:5000/api/voucher-type',
    voucherMain: 'http://localhost:5000/api/voucher-main',
    voucherDetail: 'http://localhost:5000/api/voucher-detail',
    chartOfAccount: 'http://localhost:5000/api/chart-of-account',
};

const MONTHS = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];

const VOUCHER_DETAIL_STATUSES = ['Pending', 'Approved', 'Rejected', 'Posted', 'Cancelled'];

const STATUS_STYLES = {
    Pending: 'bg-amber-100 text-amber-700',
    Approved: 'bg-blue-100 text-blue-700',
    Rejected: 'bg-red-100 text-red-700',
    Posted: 'bg-green-100 text-green-700',
    Cancelled: 'bg-gray-100 text-gray-500',
};

// A small fixed palette we cycle through for arbitrary/free-text voucher
// type codes, so the pills still get some color variety without needing a
// fixed list of codes.
const TYPE_STYLE_PALETTE = [
    'border-purple-300 bg-purple-50 text-purple-700',
    'border-red-300 bg-red-50 text-red-700',
    'border-green-300 bg-green-50 text-green-700',
    'border-blue-300 bg-blue-50 text-blue-700',
    'border-orange-300 bg-orange-50 text-orange-700',
    'border-teal-300 bg-teal-50 text-teal-700',
    'border-pink-300 bg-pink-50 text-pink-700',
    'border-indigo-300 bg-indigo-50 text-indigo-700',
];
const styleForType = (code) => {
    if (!code) return 'border-gray-200 bg-gray-50 text-gray-600';
    let hash = 0;
    for (let i = 0; i < code.length; i++) hash = (hash * 31 + code.charCodeAt(i)) >>> 0;
    return TYPE_STYLE_PALETTE[hash % TYPE_STYLE_PALETTE.length];
};

const EMPTY_DETAIL_FORM = {
    accountcode: '',
    narration: '',
    debit: '',
    credit: '',
    cheque_no: '',
    cheque_date: '',
    status: 'Pending',
};

const EMPTY_TYPE_FORM = { type: '', details: '' };

const todayStr = () => new Date().toISOString().slice(0, 10);

// dd-mm-yyyy (what the user sees) <-> yyyy-mm-dd (what the backend/DB expects)
const isoToDisplayDate = (iso) => {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    if (!y || !m || !d) return '';
    return `${d}-${m}-${y}`;
};

const displayDateToIso = (display) => {
    if (!display) return '';
    const parts = display.split('-');
    if (parts.length !== 3) return '';
    const [d, m, y] = parts;
    if (!d || !m || !y || y.length !== 4) return '';
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
};

// Reads the month name out of a yyyy-mm-dd string without going through
// `new Date(...)`, which can shift the day depending on the browser's local
// timezone and silently report the wrong month near month boundaries.
const monthNameFromDateStr = (dateStr) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return '';
    const monthIndex = Number(parts[1]) - 1;
    return MONTHS[monthIndex] || '';
};

// Formats a raw numeric string as the user types it, inserting comma
// thousands separators while preserving anything after a decimal point
// (so "1000000" -> "1,000,000" and "1234.5" -> "1,234.5").
const formatAmountLive = (input) => {
    if (input === null || input === undefined) return '';
    let s = String(input).replace(/[^\d.]/g, '');
    const firstDot = s.indexOf('.');
    if (firstDot !== -1) {
        s = s.slice(0, firstDot + 1) + s.slice(firstDot + 1).replace(/\./g, '');
    }
    let [intPart, decPart] = s.split('.');
    intPart = intPart.replace(/^0+(?=\d)/, '');
    intPart = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return decPart !== undefined ? `${intPart}.${decPart.slice(0, 2)}` : intPart;
};

// Strips the comma separators back out so we get a plain number to send to
// the backend / use in calculations.
const parseAmount = (formatted) => {
    if (!formatted) return 0;
    const num = parseFloat(String(formatted).replace(/,/g, ''));
    return isNaN(num) ? 0 : num;
};

// =============================================================================
// Reusable searchable account field - same pattern used for the GL_* fields
// in Item Entry, but keyed on the Chart Of Account row's `id` (that's what
// VoucherDetail.accountcode is a foreign key to per the SQL join).
// Supports Arrow Up/Down to move through suggestions and Enter to pick the
// highlighted one, then hands focus off to whatever field comes next.
// =============================================================================
const AccountSearchField = ({ label, value, onChange, options, onSelected }) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = term
        ? options
            .filter(
                (coa) =>
                    coa.account_name.toLowerCase().includes(term) ||
                    String(coa.code).includes(term)
            )
            .slice(0, 8)
        : [];

    const matchedAccount = options.find((coa) => String(coa.code) === term);

    const selectAccount = (coa) => {
        onChange(String(coa.code));
        setShowSuggestions(false);
        setHighlightedIndex(-1);
        onSelected && onSelected();
    };

    const handleKeyDown = (e) => {
        if (!showSuggestions || suggestions.length === 0) return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((i) => (i + 1 >= suggestions.length ? 0 : i + 1));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((i) => (i - 1 < 0 ? suggestions.length - 1 : i - 1));
        } else if (e.key === 'Enter') {
            e.preventDefault();
            const pick = suggestions[highlightedIndex >= 0 ? highlightedIndex : 0];
            if (pick) selectAccount(pick);
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
            setHighlightedIndex(-1);
        }
    };

    return (
        <div>
            {label && <label className="block text-xs font-medium text-gray-600 mb-1">{label}</label>}
            <div className="relative">
                <input
                    type="text"
                    value={value ?? ''}
                    onChange={(e) => {
                        onChange(e.target.value);
                        setShowSuggestions(true);
                        setHighlightedIndex(-1);
                    }}
                    onKeyDown={handleKeyDown}
                    onFocus={(e) => {                                          // CHANGED
                        if ((value ?? '').toString().trim()) setShowSuggestions(true);
                        e.target.select();                                      // NEW
                    }}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                    placeholder="Search by account name & code..."
                />
                {matchedAccount && (
                    <div className="text-[11px] text-blue-800 mt-0.5 font-bold truncate px-2 py-0.5 rounded">
                        → {matchedAccount.account_name}
                    </div>
                )}
                {showSuggestions && suggestions.length > 0 && (
                    <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-20">
                        {suggestions.map((coa, idx) => (
                            <div
                                key={coa.code}
                                className={`px-3 py-2 cursor-pointer text-sm flex items-center border-b border-gray-100 last:border-0 ${idx === highlightedIndex ? 'bg-blue-100' : 'hover:bg-blue-50'
                                    }`}
                                onMouseDown={() => selectAccount(coa)}
                                onMouseEnter={() => setHighlightedIndex(idx)}
                            >
                                <span className="font-medium">{coa.account_name}</span>
                                <span className="text-xs font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded ml-6">
                                    {coa.code}
                                </span>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

function VoucherEntry() {
    const {
        companyId: rawCompanyId,
        financialYearId: rawFinancialYearId,
        currentMonth
    } = useSelector((state) => state.company);

    const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== ''
        ? Number(rawCompanyId)
        : null;
    const financialYearId = rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ''
        ? Number(rawFinancialYearId)
        : null;

    // The month a voucher belongs to is no longer something chosen on this
    // screen - it's always whatever FinancialYear.current_month is (from
    // Redux). The only thing the user controls is the voucher_date, and that
    // date's month must match this value or entry is blocked.
    const voucherMonth = currentMonth || '';

    // ---- Voucher Date for the voucher currently being created ----
    const [voucherDate, setVoucherDate] = useState(isoToDisplayDate(todayStr()));

    // ---- Voucher Date "update" popup (only used once a voucher is locked) ----
    const [dateModalOpen, setDateModalOpen] = useState(false);
    const [dateModalValue, setDateModalValue] = useState('');
    const [isSavingDate, setIsSavingDate] = useState(false);

    // ---- Voucher Types (top bar) ---------------------------------------------
    const [voucherTypes, setVoucherTypes] = useState([]);
    const [isLoadingTypes, setIsLoadingTypes] = useState(true);
    const [selectedType, setSelectedType] = useState(null);

    // Add/Edit Voucher Type popup
    const [typeModalOpen, setTypeModalOpen] = useState(false);
    const [typeModalMode, setTypeModalMode] = useState('add'); // 'add' | 'edit'
    const [typeModalForm, setTypeModalForm] = useState(EMPTY_TYPE_FORM);
    const [editingType, setEditingType] = useState(null);
    const [isSavingType, setIsSavingType] = useState(false);

    // ---- Voucher Main (the voucher itself, under the selected type) ---------
    // voucherNo/voucherMainId are ONLY assigned once the first entry is
    // actually saved - there is no upfront "next number" fetch anymore. The
    // dropdown below either points at an existing voucher (to keep adding
    // entries to it) or is empty, meaning "the next Add Entry click starts a
    // brand new voucher".
    const [voucherNo, setVoucherNo] = useState('');
    const [voucherMainId, setVoucherMainId] = useState(null);
    const [isSavingMain, setIsSavingMain] = useState(false);

    const [existingVouchers, setExistingVouchers] = useState([]);
    const [isLoadingVouchers, setIsLoadingVouchers] = useState(false);

    // ---- Unbalanced-voucher indicator / popup (company + financial year wide) ----
    const [unbalancedVouchers, setUnbalancedVouchers] = useState([]);
    const [isLoadingUnbalanced, setIsLoadingUnbalanced] = useState(false);
    const [unbalancedModalOpen, setUnbalancedModalOpen] = useState(false);

    // ---- Chart Of Account, for the account search field ----------------------
    const [chartOfAccounts, setChartOfAccounts] = useState([]);
    const [chartOfAccountsLoaded, setChartOfAccountsLoaded] = useState(false);

    // ---- Voucher Details (line entries under the current Voucher Main) ------
    const [details, setDetails] = useState([]);
    const [isLoadingDetails, setIsLoadingDetails] = useState(false);
    const [detailForm, setDetailForm] = useState(EMPTY_DETAIL_FORM);
    const [editingDetailId, setEditingDetailId] = useState(null);
    const [isSavingDetail, setIsSavingDetail] = useState(false);

    // ---- Auto Entry popup (mirrors all current entries onto another account,
    // swapping debit/credit, to balance the voucher in one shot) --------------
    const [autoEntryModalOpen, setAutoEntryModalOpen] = useState(false);
    const [autoEntryAccount, setAutoEntryAccount] = useState('');
    const [isSavingAutoEntry, setIsSavingAutoEntry] = useState(false);
    const [autoEntryProgress, setAutoEntryProgress] = useState({ done: 0, total: 0 });

    // ---- Search state for voucher type dropdown ----------------------------
    const [voucherTypeSearch, setVoucherTypeSearch] = useState('');
    const [showTypeSuggestions, setShowTypeSuggestions] = useState(false);

    // ---- Field refs, used to move focus through the entry form on Enter ----
    const narrationRef = useRef(null);
    const chequeNoRef = useRef(null);
    const chequeDateRef = useRef(null);
    const statusRef = useRef(null);
    const debitRef = useRef(null);
    const creditRef = useRef(null);

    const isUnlocked = !!selectedType;

    // =============================================================================
    // Voucher Types
    // =============================================================================
    const fetchVoucherTypes = async () => {
        const res = await axios.get(`${API.voucherType}/`);
        const list = Array.isArray(res.data) ? res.data : [];
        setVoucherTypes(list.filter((vt) => vt.company_id === companyId));
        return list;
    };

    useEffect(() => {
        if (!companyId) {
            setIsLoadingTypes(false);
            return;
        }
        (async () => {
            setIsLoadingTypes(true);
            try {
                await fetchVoucherTypes();
            } catch (error) {
                toast.error(error?.response?.data?.message || 'Failed to load Voucher Types');
            } finally {
                setIsLoadingTypes(false);
            }
        })();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    // Pull the company/financial-year wide unbalanced-voucher list once we
    // know who we are, so the indicator next to Voucher No is ready even
    // before a type is picked.
    useEffect(() => {
        if (companyId && financialYearId) fetchUnbalancedVouchers();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId, financialYearId]);

    const openAddTypeModal = () => {
        setTypeModalMode('add');
        setEditingType(null);
        setTypeModalForm(EMPTY_TYPE_FORM);
        setTypeModalOpen(true);
    };

    const openEditTypeModal = (vt) => {
        setTypeModalMode('edit');
        setEditingType(vt);
        setTypeModalForm({ type: vt.type, details: vt.details });
        setTypeModalOpen(true);
    };

    const closeTypeModal = () => {
        if (isSavingType) return;
        setTypeModalOpen(false);
        setTypeModalForm(EMPTY_TYPE_FORM);
        setEditingType(null);
    };

    const handleSubmitTypeModal = async (e) => {
        e.preventDefault();
        const typeCode = typeModalForm.type.trim();
        if (!typeCode) {
            toast.error('Enter a voucher type code');
            return;
        }
        if (!typeModalForm.details.trim()) {
            toast.error('Enter a description');
            return;
        }

        setIsSavingType(true);
        try {
            const payload = { company_id: companyId, type: typeCode, details: typeModalForm.details.trim() };
            if (typeModalMode === 'add') {
                await axios.post(`${API.voucherType}/`, payload);
                toast.success('Voucher Type added');
            } else {
                await axios.put(`${API.voucherType}/${editingType.id}`, payload);
                toast.success('Voucher Type updated');
                if (selectedType?.id === editingType.id) {
                    setSelectedType((prev) => ({ ...prev, ...payload }));
                }
            }
            await fetchVoucherTypes();
            closeTypeModal();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save Voucher Type');
        } finally {
            setIsSavingType(false);
        }
    };

    const handleDeleteType = async (type, e) => {
        e.stopPropagation();
        if (!window.confirm(`Delete voucher type "${type.type} - ${type.details}"?`)) return;
        try {
            await axios.delete(`${API.voucherType}/${type.id}`);
            toast.success('Voucher Type deleted');
            if (selectedType?.id === type.id) handleSelectType(null);
            await fetchVoucherTypes();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete Voucher Type');
        }
    };

    // Filtered voucher types based on search
    const filteredVoucherTypes = useMemo(() => {
        if (!voucherTypeSearch.trim()) return voucherTypes;
        const search = voucherTypeSearch.toLowerCase().trim();
        return voucherTypes.filter(
            (vt) =>
                vt.type.toLowerCase().includes(search) ||
                vt.details.toLowerCase().includes(search)
        );
    }, [voucherTypes, voucherTypeSearch]);

    // Selecting a type is what unlocks the rest of the form. Switching types
    // resets whatever voucher was in progress and loads that type's vouchers.
    const handleSelectType = (type) => {
        setSelectedType(type);
        setVoucherNo('');
        setVoucherMainId(null);
        setDetails([]);
        setDetailForm(EMPTY_DETAIL_FORM);
        setEditingDetailId(null);
        setExistingVouchers([]);
        setVoucherTypeSearch(type ? `${type.type} - ${type.details}` : '');
        setShowTypeSuggestions(false);
        setVoucherDate(isoToDisplayDate(todayStr()));
        if (type) {
            ensureChartOfAccountsLoaded();
            fetchExistingVouchers(type.id);
        }
    };

    // =============================================================================
    // Chart Of Account - lazy, for the account search field
    // =============================================================================
    const fetchChartOfAccounts = async () => {
        const res = await axios.get(`${API.chartOfAccount}/`);
        const data = res.data?.data || [];
        setChartOfAccounts(data);
        setChartOfAccountsLoaded(true);
        return data;
    };
    const ensureChartOfAccountsLoaded = async () => (chartOfAccountsLoaded ? chartOfAccounts : fetchChartOfAccounts());

    const companyChartOfAccounts = useMemo(
        () => chartOfAccounts.filter((coa) => coa.company_id === companyId),
        [chartOfAccounts, companyId]
    );

    // =============================================================================
    // Voucher Main
    // =============================================================================
    // Scoped to the current month (Redux) as well as company/FY/type, since
    // that's the set of vouchers relevant to "keep adding entries" right now.
    const fetchExistingVouchers = async (typeId) => {
        setIsLoadingVouchers(true);
        try {
            const res = await axios.get(`${API.voucherMain}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            const filtered = list
                .filter(
                    (vm) =>
                        Number(vm.company_id) === Number(companyId) &&
                        Number(vm.financialyear_id) === Number(financialYearId) &&
                        Number(vm.vouchertype_id) === Number(typeId) &&
                        vm.voucher_month === voucherMonth
                )
                .sort((a, b) => {
                    const numA = parseInt(a.voucher_no.split('-')[1] || a.voucher_no || '0');
                    const numB = parseInt(b.voucher_no.split('-')[1] || b.voucher_no || '0');
                    return numA - numB;
                });
            setExistingVouchers(filtered);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load vouchers');
        } finally {
            setIsLoadingVouchers(false);
        }
    };

    // Company + financial-year wide list of unbalanced vouchers (not limited
    // to the currently selected type/month), used for the red indicator next
    // to Voucher No and its popup.
    const fetchUnbalancedVouchers = async () => {
        if (!companyId || !financialYearId) return;
        setIsLoadingUnbalanced(true);
        try {
            const res = await axios.get(`${API.voucherMain}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            const unbalanced = list.filter(
                (vm) =>
                    Number(vm.company_id) === Number(companyId) &&
                    Number(vm.financialyear_id) === Number(financialYearId) &&
                    vm.isBalanced === 'Unbalanced'
            );
            setUnbalancedVouchers(unbalanced);
        } catch (error) {
            // Secondary indicator - fail quietly rather than spamming toasts
        } finally {
            setIsLoadingUnbalanced(false);
        }
    };

    // Re-pull the voucher list if the globally open month changes while this
    // screen is sitting open (e.g. an admin closes the month elsewhere).
    useEffect(() => {
        if (selectedType) {
            fetchExistingVouchers(selectedType.id);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [voucherMonth]);

    // Starts a fresh voucher under the current type: clears any loaded
    // voucher. No number is fetched here - one gets assigned the moment the
    // first entry is actually saved.
    const handleNewVoucher = () => {
        setVoucherMainId(null);
        setVoucherNo('');
        setDetails([]);
        resetDetailForm();
        setVoucherDate(isoToDisplayDate(todayStr()));
    };

    // Loads an existing voucher (and its entries) so it can keep being edited.
    const handleOpenVoucher = (vm) => {
        const mainId = Number(vm.id);
        setVoucherMainId(mainId);
        setVoucherNo(vm.voucher_no);
        setVoucherDate(vm.voucher_date ? isoToDisplayDate(String(vm.voucher_date).slice(0, 10)) : '');
        resetDetailForm();
        fetchVoucherDetails(mainId);
    };

    // The "Voucher No" dropdown itself: empty value = new voucher, otherwise
    // the value is a VoucherMain id.
    const handleVoucherNoSelect = (e) => {
        const value = e.target.value;
        if (!value) {
            handleNewVoucher();
            return;
        }
        const vm = existingVouchers.find((v) => Number(v.id) === Number(value));
        if (vm) handleOpenVoucher(vm);
    };

    const handleDeleteVoucherMain = async (vm) => {
        if (!window.confirm(`Delete voucher "${vm.voucher_no}" and all of its entries?`)) return;
        try {
            const res = await axios.get(`${API.voucherDetail}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            const toDelete = list.filter((d) => Number(d.vouchermain_id) === Number(vm.id));
            for (const d of toDelete) {
                // eslint-disable-next-line no-await-in-loop
                await axios.delete(`${API.voucherDetail}/${d.id}`);
            }
            await axios.delete(`${API.voucherMain}/${vm.id}`);
            toast.success('Voucher deleted');
            if (Number(voucherMainId) === Number(vm.id)) {
                handleNewVoucher();
            }
            await fetchExistingVouchers(selectedType.id);
            await fetchUnbalancedVouchers();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete voucher');
        }
    };

    // Creates the VoucherMain row the FIRST time an entry is saved for a new
    // voucher, pulling the next free voucher number at that exact moment
    // (not ahead of time). If a voucher is already open, this is a no-op.
    const ensureVoucherMainCreated = async () => {
        if (voucherMainId) return voucherMainId;

        if (!financialYearId) {
            toast.error('No financial year selected');
            return null;
        }
        if (!voucherDate) {
            toast.error('Please select a voucher date');
            return null;
        }
        if (!voucherMonth) {
            toast.error('No current month is set for this financial year. Contact an admin.');
            return null;
        }

        const voucherDateIso = displayDateToIso(voucherDate);
        if (!voucherDateIso) {
            toast.error('Voucher date must be in dd-mm-yyyy format');
            return null;
        }
        const enteredMonth = monthNameFromDateStr(voucherDateIso);
        if (enteredMonth !== voucherMonth) {
            toast.error(`Voucher date must fall within ${voucherMonth} (the currently open month).`);
            return null;
        }

        setIsSavingMain(true);
        try {
            const nextRes = await axios.get(
                `${API.voucherMain}/${companyId}/${financialYearId}/${selectedType.id}?month=${voucherMonth}`
            );
            const nextNumber = nextRes.data?.next_voucher_number;
            if (nextNumber === undefined || nextNumber === null) {
                toast.error('Failed to determine next voucher number');
                return null;
            }

            const res = await axios.post(`${API.voucherMain}/`, {
                company_id: companyId,
                vouchertype_id: selectedType.id,
                financialyear_id: financialYearId,
                voucher_no: String(nextNumber),
                voucher_date: voucherDateIso,
                voucher_month: voucherMonth,
            });
            const newId = Number(res.data?.id);
            setVoucherMainId(newId);
            setVoucherNo(String(nextNumber));
            toast.success(`Voucher #${nextNumber} created`);
            fetchExistingVouchers(selectedType.id);
            return newId;
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to create voucher');
            return null;
        } finally {
            setIsSavingMain(false);
        }
    };

    // =============================================================================
    // Voucher Date "update" popup (only relevant once the date field is locked)
    // =============================================================================
    const openDateModal = () => {
        setDateModalValue(voucherDate);
        setDateModalOpen(true);
    };

    const closeDateModal = () => {
        if (isSavingDate) return;
        setDateModalOpen(false);
    };

    const handleSaveDate = async (e) => {
        e.preventDefault();
        const iso = displayDateToIso(dateModalValue);
        if (!iso) {
            toast.error('Date must be in dd-mm-yyyy format');
            return;
        }
        if (monthNameFromDateStr(iso) !== voucherMonth) {
            toast.error(`Voucher date must fall within ${voucherMonth} (the currently open month).`);
            return;
        }

        setIsSavingDate(true);
        try {
            await axios.patch(`${API.voucherMain}/${voucherMainId}/date`, { voucher_date: iso });
            setVoucherDate(dateModalValue);
            toast.success('Voucher date updated');
            setDateModalOpen(false);
            if (selectedType) fetchExistingVouchers(selectedType.id);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to update voucher date');
        } finally {
            setIsSavingDate(false);
        }
    };

    // =============================================================================
    // Voucher Details
    // =============================================================================
    const fetchVoucherDetails = async (mainId) => {
        setIsLoadingDetails(true);
        try {
            const res = await axios.get(`${API.voucherDetail}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            setDetails(
                list
                    .filter((d) => Number(d.vouchermain_id) === Number(mainId))
                    .sort((a, b) => a.entry_no - b.entry_no)
            );
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load voucher entries');
        } finally {
            setIsLoadingDetails(false);
        }
    };

    const resetDetailForm = () => {
        setDetailForm(EMPTY_DETAIL_FORM);
        setEditingDetailId(null);
    };

    const handleEditDetailRow = (row) => {
        setEditingDetailId(row.id);
        setDetailForm({
            accountcode: row.accountcode ?? '',
            narration: row.narration ?? '',
            debit: row.debit ? formatAmountLive(String(row.debit)) : '',
            credit: row.credit ? formatAmountLive(String(row.credit)) : '',
            cheque_no: row.cheque_no ?? '',
            cheque_date: row.cheque_date ? isoToDisplayDate(String(row.cheque_date).slice(0, 10)) : '',
            status: row.status ?? 'Pending',
        });
    };

    const handleSaveDetail = async (e) => {
        e.preventDefault();

        const debitValue = parseAmount(detailForm.debit);
        const creditValue = parseAmount(detailForm.credit);

        // Don't touch the database at all for a click on an essentially empty
        // form - only proceed once the user has actually entered something.
        const hasAnyContent =
            !!detailForm.accountcode || !!detailForm.narration.trim() || debitValue > 0 || creditValue > 0;
        if (!hasAnyContent) {
            toast.error('Please fill in at least Account, Narration, Debit or Credit to add an entry.');
            return;
        }

        const missingFields = [];
        if (!detailForm.accountcode) missingFields.push('Account');
        if (debitValue <= 0 && creditValue <= 0) missingFields.push('Debit or Credit amount');

        if (missingFields.length > 0) {
            toast.error(`Please complete: ${missingFields.join(', ')}`);
            return;
        }

        if (!detailForm.accountcode) {
            toast.error('Select or enter an account name');
            return;
        }
        if (debitValue > 0 && creditValue > 0) {
            toast.error('Only one of Debit or Credit can be greater than zero');
            return;
        }
        // Mirrors the backend's cheque_no/cheque_date pairing rule
        if (detailForm.cheque_no && !detailForm.cheque_date) {
            toast.error('Cheque date is required when a cheque number is entered');
            return;
        }
        if (detailForm.cheque_date && !detailForm.cheque_no) {
            toast.error('Cheque number is required when a cheque date is entered');
            return;
        }
        // The voucher date must sit inside the currently open month - checked
        // again here (not just in ensureVoucherMainCreated) so the user sees
        // this immediately on Add Entry even before any network call fires.
        if (!voucherMonth) {
            toast.error('No current month is set for this financial year. Contact an admin.');
            return;
        }
        if (monthNameFromDateStr(displayDateToIso(voucherDate)) !== voucherMonth) {
            toast.error(`Voucher date must fall within ${voucherMonth} (the currently open month).`);
            return;
        }

        const mainId = await ensureVoucherMainCreated();
        if (!mainId) return;

        const nextEntryNo = editingDetailId
            ? details.find((d) => d.id === editingDetailId)?.entry_no
            : (details.length > 0 ? Math.max(...details.map((d) => d.entry_no)) + 1 : 1);

        const payload = {
            company_id: companyId,
            vouchermain_id: mainId,
            accountcode: Number(detailForm.accountcode),
            entry_no: nextEntryNo,
            narration: detailForm.narration || null,
            debit: debitValue,
            credit: creditValue,
            cheque_no: detailForm.cheque_no || null,
            cheque_date: detailForm.cheque_date ? displayDateToIso(detailForm.cheque_date) : null,
            status: detailForm.status,
        };

        setIsSavingDetail(true);
        try {
            if (editingDetailId) {
                await axios.put(`${API.voucherDetail}/${editingDetailId}`, payload);
                toast.success('Entry updated');
            } else {
                await axios.post(`${API.voucherDetail}/`, payload);
                toast.success('Entry added');
            }
            resetDetailForm();
            await fetchVoucherDetails(mainId);
            await fetchUnbalancedVouchers();
            if (selectedType) fetchExistingVouchers(selectedType.id);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save entry');
        } finally {
            setIsSavingDetail(false);
        }
    };

    const handleDeleteDetail = async (row) => {
        if (!window.confirm(`Delete entry #${row.entry_no}?`)) return;
        try {
            await axios.delete(`${API.voucherDetail}/${row.id}`);
            toast.success('Entry deleted');
            await fetchVoucherDetails(voucherMainId);
            await fetchUnbalancedVouchers();
            if (selectedType) fetchExistingVouchers(selectedType.id);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete entry');
        }
    };

    const totals = useMemo(() => {
        return details.reduce(
            (acc, d) => ({ debit: acc.debit + Number(d.debit || 0), credit: acc.credit + Number(d.credit || 0) }),
            { debit: 0, credit: 0 }
        );
    }, [details]);
    const isCurrentVoucherBalanced = details.length > 0 && totals.debit === totals.credit;

    // =============================================================================
    // Auto Entry
    // -----------------------------------------------------------------------------
    // Mirrors every existing entry in the table onto a newly chosen account:
    // same narration / cheque_no / cheque_date / status as the source row, but
    // with debit and credit swapped (so a debit row becomes a credit row and
    // vice versa). This is the fast way to balance a voucher that's currently
    // all on one side.
    // =============================================================================
    const openAutoEntryModal = () => {
        setAutoEntryAccount('');
        setAutoEntryModalOpen(true);
    };

    const closeAutoEntryModal = () => {
        if (isSavingAutoEntry) return;
        setAutoEntryModalOpen(false);
        setAutoEntryAccount('');
    };

    const handleAutoEntrySubmit = async (e) => {
        e.preventDefault();
        if (!autoEntryAccount) {
            toast.error('Select an account');
            return;
        }
        if (!voucherMainId) {
            toast.error('No voucher is open');
            return;
        }

        // Snapshot the current rows (in entry order) before we start posting -
        // the table will grow as we go, so we must not re-read `details`
        // inside the loop.
        const sourceRows = details.slice().sort((a, b) => a.entry_no - b.entry_no);
        if (sourceRows.length === 0) {
            toast.error('No entries to mirror yet');
            return;
        }

        let nextEntryNo = Math.max(...sourceRows.map((d) => d.entry_no)) + 1;

        setIsSavingAutoEntry(true);
        setAutoEntryProgress({ done: 0, total: sourceRows.length });
        try {
            for (let i = 0; i < sourceRows.length; i++) {
                const row = sourceRows[i];
                const debitVal = Number(row.debit || 0);
                const creditVal = Number(row.credit || 0);

                const payload = {
                    company_id: companyId,
                    vouchermain_id: voucherMainId,
                    accountcode: Number(autoEntryAccount),
                    entry_no: nextEntryNo,
                    narration: row.narration || null,
                    // Swap: whatever side the source was on, the mirrored
                    // entry goes on the opposite side.
                    debit: creditVal,
                    credit: debitVal,
                    cheque_no: row.cheque_no || null,
                    cheque_date: row.cheque_date ? String(row.cheque_date).slice(0, 10) : null,
                    status: row.status,
                };

                // eslint-disable-next-line no-await-in-loop
                await axios.post(`${API.voucherDetail}/`, payload);
                nextEntryNo += 1;
                setAutoEntryProgress({ done: i + 1, total: sourceRows.length });
            }

            toast.success('Auto entries added');
            setAutoEntryModalOpen(false);
            setAutoEntryAccount('');
            await fetchVoucherDetails(voucherMainId);
            await fetchUnbalancedVouchers();
            if (selectedType) fetchExistingVouchers(selectedType.id);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to add auto entries');
            // Refresh whatever did make it in before the failure so the table
            // reflects reality.
            await fetchVoucherDetails(voucherMainId);
            await fetchUnbalancedVouchers();
        } finally {
            setIsSavingAutoEntry(false);
            setAutoEntryProgress({ done: 0, total: 0 });
        }
    };

    // =============================================================================
    // Render
    // =============================================================================
    return (
        <div className="min-h-screen bg-gray-50 p-6">
            {/* Native date inputs put the clear ("x") and spinner buttons on the
                tab order as their own stops, so tabbing past a filled date field
                takes two presses instead of one. Hiding them keeps tab order to a
                single press per field. The calendar-picker-indicator icon is also
                hidden per design - the field itself is still clickable to open
                the native picker. */}
            <style>{`
                input.simple-date::-webkit-clear-button,
                input.simple-date::-webkit-inner-spin-button {
                    display: none;
                    -webkit-appearance: none;
                }
                input.simple-date::-webkit-calendar-picker-indicator {
                    display: none;
                    -webkit-appearance: none;
                    opacity: 0;
                }
                input.simple-date {
                    -moz-appearance: textfield;
                }
            `}</style>

            <div className="max-w-6xl mx-auto">

                {!companyId ? (
                    <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-200 text-center text-gray-500 text-sm">
                        No company context found. Please select a company first.
                    </div>
                ) : (
                    <>
                        {/* ============================ Voucher Entry Form ============================ */}
                        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                            {/* Voucher Type -> Voucher Date -> Voucher No (dropdown) */}
                            <div className="flex items-end gap-4 mb-5 flex-nowrap">

                                {/* Voucher Type (select/search) */}
                                <div className="w-60 shrink-0">
                                    <div className="flex items-center justify-between mb-1">
                                        <label className="block text-sm font-medium text-gray-700">
                                            Voucher Type
                                        </label>
                                        <button
                                            onClick={openAddTypeModal}
                                            className="flex items-center gap-1 text-blue-500 hover:text-blue-600 text-xs font-medium transition-colors"
                                            title="New Voucher Type"
                                        >
                                            <img src="/src/assets/add.png" alt="Add" className="w-3.5 h-3.5" />
                                            New
                                        </button>
                                    </div>
                                    {isLoadingTypes ? (
                                        <div className="text-xs text-gray-400 py-2">Loading...</div>
                                    ) : voucherTypes.length === 0 ? (
                                        <div className="text-xs text-gray-400 py-2 whitespace-nowrap">No types yet.</div>
                                    ) : (
                                        <div className="relative">
                                            <input
                                                type="text"
                                                value={voucherTypeSearch}
                                                onChange={(e) => {
                                                    setVoucherTypeSearch(e.target.value);
                                                    setShowTypeSuggestions(true);
                                                    if (!e.target.value.trim()) {
                                                        setSelectedType(null);
                                                        setVoucherNo('');
                                                        setVoucherMainId(null);
                                                        setDetails([]);
                                                        setExistingVouchers([]);
                                                    }
                                                }}
                                                onFocus={(e) => {
                                                    setShowTypeSuggestions(true);
                                                    e.target.select();
                                                }}
                                                onClick={(e) => {
                                                    e.target.select();
                                                }}
                                                onBlur={() => setTimeout(() => setShowTypeSuggestions(false), 200)}
                                                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                placeholder="Search or select type..."
                                            />
                                            {showTypeSuggestions && filteredVoucherTypes.length > 0 && (
                                                <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-30">
                                                    {filteredVoucherTypes.map((vt) => {
                                                        const isActive = selectedType?.id === vt.id;
                                                        return (
                                                            <div
                                                                key={vt.id}
                                                                className={`px-3 py-2 hover:bg-blue-50 cursor-pointer text-sm flex items-center justify-between border-b border-gray-100 last:border-0 ${isActive ? 'bg-blue-50' : ''
                                                                    }`}
                                                                onClick={() => handleSelectType(vt)}
                                                            >
                                                                <div className="flex items-center gap-2">
                                                                    <span className={`px-2 py-0.5 rounded-full text-xs font-mono font-bold ${styleForType(vt.type)}`}>
                                                                        {vt.type}
                                                                    </span>
                                                                    <span className="text-gray-600">{vt.details}</span>
                                                                </div>
                                                                <div className="flex items-center gap-1">
                                                                    <button
                                                                        onClick={(e) => {
                                                                            e.stopPropagation();
                                                                            openEditTypeModal(vt);
                                                                        }}
                                                                        className="p-1 hover:bg-gray-100 rounded"
                                                                        title="Edit"
                                                                    >
                                                                        <img src="/src/assets/edit.png" alt="Edit" className="w-3.5 h-3.5" />
                                                                    </button>
                                                                    <button
                                                                        onClick={(e) => handleDeleteType(vt, e)}
                                                                        className="p-1 hover:bg-gray-100 rounded"
                                                                        title="Delete"
                                                                    >
                                                                        <img src="/src/assets/delete.png" alt="Delete" className="w-3.5 h-3.5" />
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>

                                {/* Voucher Date - shows an update icon once locked, opening a popup
                                    that patches the date directly against the database. */}
                                <div className="w-40 shrink-0">
                                    <div className="flex items-center justify-between mb-1">
                                        <label className="block text-sm font-medium text-gray-700">Voucher Date</label>
                                        {isUnlocked && voucherMainId && (
                                            <button
                                                type="button"
                                                onClick={openDateModal}
                                                title="Update voucher date"
                                                className="text-blue-500 hover:text-blue-600"
                                            >
                                                <img src="/src/assets/edit.png" alt="Update date" className="w-3.5 h-3.5" />
                                            </button>
                                        )}
                                    </div>
                                    <input
                                        type="text"
                                        value={voucherDate}
                                        onChange={(e) => setVoucherDate(e.target.value)}
                                        placeholder="dd-mm-yyyy"
                                        disabled={!isUnlocked || !!voucherMainId}
                                        className="simple-date w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-500"
                                    />
                                </div>

                                {/* Voucher No - dropdown, only visible once a type is selected.
                                    Empty selection = "next Add Entry click starts a new voucher".
                                    Picking an existing number loads that voucher to keep adding to it.
                                    The red badge next to the label opens the unbalanced-vouchers list. */}
                                {isUnlocked && (
                                    <div className="w-52 shrink-0">
                                        <div className="flex items-center justify-between mb-1">
                                            <label className="block text-sm font-medium text-gray-700">Voucher No</label>
                                            {unbalancedVouchers.length > 0 && (
                                                <button
                                                    type="button"
                                                    onClick={() => setUnbalancedModalOpen(true)}
                                                    className="flex items-center gap-1 text-red-600 hover:text-red-700 text-xs font-semibold"
                                                    title="Unbalanced vouchers"
                                                >
                                                    <span className="w-2 h-2 rounded-full bg-red-500 inline-block" />
                                                    {unbalancedVouchers.length} unbalanced
                                                </button>
                                            )}
                                        </div>
                                        <select
                                            value={voucherMainId ?? ''}
                                            onChange={handleVoucherNoSelect}
                                            disabled={isSavingMain}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-500"
                                        >
                                            <option value="">-- New Voucher --</option>
                                            {isLoadingVouchers ? (
                                                <option disabled>Loading...</option>
                                            ) : (
                                                existingVouchers.map((vm) => (
                                                    <option key={vm.id} value={vm.id}>
                                                        {vm.voucher_no}
                                                    </option>
                                                ))
                                            )}
                                        </select>
                                    </div>
                                )}
                            </div>

                            {!isUnlocked ? (
                                <div className="py-16 text-center text-gray-400 text-sm">
                                    Select a Voucher Type above to start a voucher.
                                </div>
                            ) : (
                                <fieldset>
                                    <legend className="sr-only">Voucher Entry</legend>

                                    {/* Entry form - 7 fields, 5 per row */}
                                    <div className="border-t border-gray-200 pt-5 mb-5">
                                        <h3 className="text-sm font-semibold text-gray-700 mb-3">
                                            {editingDetailId ? 'Edit Entry' : 'Add Entry'}
                                        </h3>
                                        <form onSubmit={handleSaveDetail} className="space-y-3">
                                            <div className="grid grid-cols-2 sm:grid-cols-7 gap-1">
                                                <div className="col-span-2 sm:col-span-2">
                                                    <AccountSearchField
                                                        label="Account Name"
                                                        value={detailForm.accountcode}
                                                        onChange={(val) => setDetailForm({ ...detailForm, accountcode: val })}
                                                        options={companyChartOfAccounts}
                                                        onSelected={() => narrationRef.current?.focus()}
                                                    />
                                                </div>

                                                <div className="col-span-2 sm:col-span-2">
                                                    <label className="block text-xs font-medium text-gray-600 mb-1">Narration</label>
                                                    <input
                                                        ref={narrationRef}
                                                        type="text"
                                                        value={detailForm.narration}
                                                        onChange={(e) => setDetailForm({ ...detailForm, narration: e.target.value })}
                                                        onFocus={(e) => e.target.select()}
                                                        onKeyDown={(e) => {
                                                            if (e.key === 'Enter') {
                                                                e.preventDefault();
                                                                chequeNoRef.current?.focus();
                                                            }
                                                        }}
                                                        placeholder="Add narration to account name"
                                                        className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                    />
                                                </div>

                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-1">Cheque No</label>
                                                    <input
                                                        ref={chequeNoRef}
                                                        type="text"
                                                        value={detailForm.cheque_no}
                                                        onChange={(e) => setDetailForm({ ...detailForm, cheque_no: e.target.value })}
                                                        onFocus={(e) => e.target.select()}
                                                        onKeyDown={(e) => {
                                                            if (e.key === 'Enter') {
                                                                e.preventDefault();
                                                                chequeDateRef.current?.focus();
                                                            }
                                                        }}
                                                        placeholder="Add cheque no."
                                                        className="w-full px-2 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                    />
                                                </div>

                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-1">Cheque Date</label>
                                                    <input
                                                        ref={chequeDateRef}
                                                        type="text"
                                                        value={detailForm.cheque_date}
                                                        onChange={(e) => setDetailForm({ ...detailForm, cheque_date: e.target.value })}
                                                        onFocus={(e) => e.target.select()}
                                                        onKeyDown={(e) => {
                                                            if (e.key === 'Enter') {
                                                                e.preventDefault();
                                                                statusRef.current?.focus();
                                                            }
                                                        }}
                                                        placeholder="dd-mm-yyyy"
                                                        className="simple-date w-full px-2 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                    />
                                                </div>

                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-1">Status</label>
                                                    <select
                                                        ref={statusRef}
                                                        value={detailForm.status}
                                                        onChange={(e) => setDetailForm({ ...detailForm, status: e.target.value })}
                                                        onKeyDown={(e) => {
                                                            if (e.key === 'Enter') {
                                                                e.preventDefault();
                                                                debitRef.current?.focus();
                                                            }
                                                        }}
                                                        className="w-full px-2 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                    >
                                                        {VOUCHER_DETAIL_STATUSES.map((s) => (
                                                            <option key={s} value={s}>{s}</option>
                                                        ))}
                                                    </select>
                                                </div>

                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-1">Debit</label>
                                                    <input
                                                        ref={debitRef}
                                                        type="text"
                                                        inputMode="decimal"
                                                        value={detailForm.debit}
                                                        onFocus={(e) => e.target.select()}
                                                        onChange={(e) => {
                                                            const formatted = formatAmountLive(e.target.value);
                                                            const raw = parseAmount(formatted);
                                                            setDetailForm({
                                                                ...detailForm,
                                                                debit: formatted,
                                                                credit: raw > 0 ? '' : detailForm.credit,
                                                            });
                                                        }}
                                                        onKeyDown={(e) => {
                                                            if (e.key === 'Enter') {
                                                                e.preventDefault();
                                                                handleSaveDetail(e);
                                                            }
                                                        }}
                                                        placeholder="0.00"
                                                        className="w-full px-2 py-2 border border-gray-300 rounded-md text-sm text-right focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                    />
                                                </div>

                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-1">Credit</label>
                                                    <input
                                                        ref={creditRef}
                                                        type="text"
                                                        inputMode="decimal"
                                                        value={detailForm.credit}
                                                        onFocus={(e) => e.target.select()}
                                                        onChange={(e) => {
                                                            const formatted = formatAmountLive(e.target.value);
                                                            const raw = parseAmount(formatted);
                                                            setDetailForm({
                                                                ...detailForm,
                                                                credit: formatted,
                                                                debit: raw > 0 ? '' : detailForm.debit,
                                                            });
                                                        }}
                                                        onKeyDown={(e) => {
                                                            if (e.key === 'Enter') {
                                                                e.preventDefault();
                                                                handleSaveDetail(e);
                                                            }
                                                        }}
                                                        placeholder="0.00"
                                                        className="w-full px-2 py-2 border border-gray-300 rounded-md text-sm text-right focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                    />
                                                </div>

                                                <div className="col-span-2 sm:col-span-5 flex items-end justify-end gap-3">
                                                    <button
                                                        type="submit"
                                                        disabled={isSavingMain || isSavingDetail}
                                                        className="px-5 py-2 bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60"
                                                    >
                                                        {isSavingMain ? 'Saving voucher...' : isSavingDetail ? 'Saving entry...' : editingDetailId ? 'Update Entry' : 'Add Entry'}
                                                    </button>
                                                    {editingDetailId && (
                                                        <button
                                                            type="button"
                                                            onClick={resetDetailForm}
                                                            className="text-sm text-gray-500 hover:text-gray-700"
                                                        >
                                                            Cancel edit
                                                        </button>
                                                    )}
                                                    {/* Auto Entry: only shown once there's at least one entry in the
                                                        table AND the voucher isn't balanced yet. It disappears the
                                                        moment debit === credit. */}
                                                    {details.length > 0 && !isCurrentVoucherBalanced && (
                                                        <button
                                                            type="button"
                                                            onClick={openAutoEntryModal}
                                                            disabled={isSavingMain || isSavingDetail}
                                                            className="px-4 py-2 bg-white border border-blue-500 text-blue-600 hover:bg-blue-50 text-sm font-medium rounded-md transition-colors disabled:opacity-60"
                                                        >
                                                            Auto Entry
                                                        </button>
                                                    )}
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    {/* Entries table */}
                                    {voucherMainId && (
                                        <div className="border-t border-gray-200 pt-5">
                                            <div className="flex items-center justify-between mb-3">
                                                <h3 className="text-sm font-semibold text-gray-700">Entries</h3>
                                                {details.length > 0 && (
                                                    <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${isCurrentVoucherBalanced ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                                                        {isCurrentVoucherBalanced ? 'Balanced' : `Off by ${Math.abs(totals.debit - totals.credit).toFixed(2)}`}
                                                    </span>
                                                )}
                                            </div>
                                            {isLoadingDetails ? (
                                                <div className="text-xs text-gray-400 py-4 text-center">Loading...</div>
                                            ) : details.length === 0 ? (
                                                <div className="text-xs text-gray-400 py-4 text-center">No entries yet</div>
                                            ) : (
                                                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                                                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                                                        <thead className="bg-gray-50">
                                                            <tr>
                                                                <th className="px-3 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Voucher No</th>
                                                                <th className="px-3 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Entry No</th>
                                                                <th className="px-3 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Account</th>
                                                                <th className="px-3 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Narration</th>
                                                                <th className="px-3 py-2 text-right text-xs font-semibold text-gray-500 uppercase">Debit</th>
                                                                <th className="px-3 py-2 text-right text-xs font-semibold text-gray-500 uppercase">Credit</th>
                                                                <th className="px-3 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                                                                <th className="px-3 py-2 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody className="bg-white divide-y divide-gray-100">
                                                            {details.map((row) => (
                                                                <tr key={row.id} className="hover:bg-gray-50">
                                                                    <td className="px-3 py-2 font-mono text-xs font-bold text-gray-700">
                                                                        {row.voucher_no || voucherNo}
                                                                    </td>
                                                                    <td className="px-3 py-2 text-gray-600">{row.entry_no}</td>
                                                                    <td className="px-3 py-2 text-gray-800">{row.account_name || row.accountcode}</td>
                                                                    <td className="px-3 py-2 text-gray-600">{row.narration || '-'}</td>
                                                                    <td className="px-3 py-2 text-right text-gray-800">{row.debit > 0 ? Number(row.debit).toLocaleString('en-US', { minimumFractionDigits: 2 }) : '-'}</td>
                                                                    <td className="px-3 py-2 text-right text-gray-800">{row.credit > 0 ? Number(row.credit).toLocaleString('en-US', { minimumFractionDigits: 2 }) : '-'}</td>
                                                                    <td className="px-3 py-2">
                                                                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${STATUS_STYLES[row.status] || 'bg-gray-100 text-gray-600'}`}>
                                                                            {row.status}
                                                                        </span>
                                                                    </td>
                                                                    <td className="px-3 py-2">
                                                                        <div className="flex items-center justify-end gap-2">
                                                                            <button onClick={() => handleEditDetailRow(row)} title="Edit">
                                                                                <img src="/src/assets/edit.png" alt="Edit" className="w-4 h-4" />
                                                                            </button>
                                                                            <button onClick={() => handleDeleteDetail(row)} title="Delete">
                                                                                <img src="/src/assets/delete.png" alt="Delete" className="w-4 h-4" />
                                                                            </button>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                        <tfoot className="bg-gray-50">
                                                            <tr>
                                                                <td colSpan={4} className="px-3 py-2 text-right text-xs font-semibold text-gray-500">Totals</td>
                                                                <td className="px-3 py-2 text-right text-sm font-semibold text-gray-800">{totals.debit.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                                                                <td className="px-3 py-2 text-right text-sm font-semibold text-gray-800">{totals.credit.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                                                                <td colSpan={2}></td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </fieldset>
                            )}
                        </div>
                    </>
                )}
            </div>

            {/* ============================ Voucher Type popup ============================ */}
            {typeModalOpen && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm mx-4 p-6">
                        <h3 className="text-lg font-semibold text-gray-800 mb-4">
                            {typeModalMode === 'add' ? 'New Voucher Type' : 'Edit Voucher Type'}
                        </h3>
                        <form onSubmit={handleSubmitTypeModal} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Type Code</label>
                                <input
                                    type="text"
                                    value={typeModalForm.type}
                                    onChange={(e) => setTypeModalForm({ ...typeModalForm, type: e.target.value })}
                                    placeholder="e.g. JV, PV, PMT-01..."
                                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                                    autoFocus
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Details</label>
                                <input
                                    type="text"
                                    value={typeModalForm.details}
                                    onChange={(e) => setTypeModalForm({ ...typeModalForm, details: e.target.value })}
                                    placeholder="e.g. Journal Voucher"
                                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                                />
                            </div>
                            <div className="flex justify-end gap-3 pt-2">
                                <button
                                    type="button"
                                    onClick={closeTypeModal}
                                    disabled={isSavingType}
                                    className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={isSavingType}
                                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors disabled:opacity-60"
                                >
                                    {isSavingType ? 'Saving...' : typeModalMode === 'add' ? 'Add' : 'Save Changes'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* ============================ Voucher Date update popup ============================ */}
            {dateModalOpen && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-xs mx-4 p-6">
                        <h3 className="text-lg font-semibold text-gray-800 mb-4">Update Voucher Date</h3>
                        <form onSubmit={handleSaveDate} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Voucher Date</label>
                                <input
                                    type="text"
                                    value={dateModalValue}
                                    onChange={(e) => setDateModalValue(e.target.value)}
                                    placeholder="dd-mm-yyyy"
                                    autoFocus
                                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                                />
                            </div>
                            <div className="flex justify-end gap-3 pt-2">
                                <button
                                    type="button"
                                    onClick={closeDateModal}
                                    disabled={isSavingDate}
                                    className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={isSavingDate}
                                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors disabled:opacity-60"
                                >
                                    {isSavingDate ? 'Saving...' : 'Save'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* ============================ Auto Entry popup ============================ */}
            {autoEntryModalOpen && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm mx-4 p-6">
                        <h3 className="text-lg font-semibold text-gray-800 mb-1">Auto Entry</h3>
                        <p className="text-xs text-gray-500 mb-4">
                            Select an account. A mirrored entry will be created for every existing
                            row (same narration, cheque no., cheque date and status), with debit
                            and credit swapped, to help balance this voucher.
                        </p>
                        <form onSubmit={handleAutoEntrySubmit} className="space-y-4">
                            <AccountSearchField
                                label="Account Name"
                                value={autoEntryAccount}
                                onChange={(val) => setAutoEntryAccount(val)}
                                options={companyChartOfAccounts}
                            />

                            {isSavingAutoEntry && autoEntryProgress.total > 0 && (
                                <div className="text-xs text-gray-500">
                                    Adding entry {autoEntryProgress.done} of {autoEntryProgress.total}...
                                </div>
                            )}

                            <div className="flex justify-end gap-3 pt-2">
                                <button
                                    type="button"
                                    onClick={closeAutoEntryModal}
                                    disabled={isSavingAutoEntry}
                                    className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-md transition-colors"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={isSavingAutoEntry || !autoEntryAccount}
                                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors disabled:opacity-60"
                                >
                                    {isSavingAutoEntry ? 'Adding...' : 'Add'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* ============================ Unbalanced Vouchers popup ============================ */}
            {unbalancedModalOpen && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-md mx-4 p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-lg font-semibold text-gray-800">Unbalanced Vouchers</h3>
                            <button
                                onClick={() => setUnbalancedModalOpen(false)}
                                className="text-gray-400 hover:text-gray-600 text-sm"
                            >
                                ✕
                            </button>
                        </div>
                        {isLoadingUnbalanced ? (
                            <div className="text-xs text-gray-400 py-4 text-center">Loading...</div>
                        ) : unbalancedVouchers.length === 0 ? (
                            <div className="text-xs text-gray-400 py-4 text-center">All vouchers are balanced.</div>
                        ) : (
                            <div className="overflow-x-auto border border-gray-200 rounded-lg max-h-80 overflow-y-auto">
                                <table className="min-w-full divide-y divide-gray-200 text-sm">
                                    <thead className="bg-gray-50 sticky top-0">
                                        <tr>
                                            <th className="px-3 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Month</th>
                                            <th className="px-3 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Voucher Type</th>
                                            <th className="px-3 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Voucher No</th>
                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-100">
                                        {unbalancedVouchers
                                            .slice()
                                            .sort((a, b) => MONTHS.indexOf(a.voucher_month) - MONTHS.indexOf(b.voucher_month))
                                            .map((vm) => (
                                                <tr key={vm.id} className="hover:bg-red-50">
                                                    <td className="px-3 py-2 text-gray-700">{vm.voucher_month}</td>
                                                    <td className="px-3 py-2">
                                                        <span className={`px-2 py-0.5 rounded-full text-xs font-mono font-bold ${styleForType(vm.voucher_type_code)}`}>
                                                            {vm.voucher_type_code}
                                                        </span>
                                                    </td>
                                                    <td className="px-3 py-2 font-mono text-red-600 font-semibold">{vm.voucher_no}</td>
                                                </tr>
                                            ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default VoucherEntry;