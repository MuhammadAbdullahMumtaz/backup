import React, { useState, useEffect, useMemo, useRef } from 'react';
import axios from 'axios';
import Modal from 'react-modal';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';

// Set app element for accessibility - IMPORTANT for React Modal
Modal.setAppElement('#root');

// =============================================================================
// API base URLs
// =============================================================================
const API = {
    mainItem: 'http://localhost:5000/api/main-item',
    subItem: 'http://localhost:5000/api/sub-item',
    itemDetail: 'http://localhost:5000/api/item-detail',
    chartOfAccount: 'http://localhost:5000/api/chart-of-account',
    itemOpening: 'http://localhost:5000/api/item-opening',
    financialYear: 'http://localhost:5000/api/financial-year',
};

const GLAccountField = ({ label, value, onChange, options }) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1); // NEW

    const term = String(value ?? '').trim().toLowerCase();
    const suggestions = term
        ? options
            .filter(
                (coa) =>
                    coa.account_name.toLowerCase().includes(term) ||
                    (coa.code && coa.code.toLowerCase().includes(term))
            )
            .slice(0, 8)
        : [];

    // NEW: keep the highlighted row valid whenever the suggestion list changes
    useEffect(() => {
        setHighlightedIndex(suggestions.length > 0 ? 0 : -1);
    }, [term, options.length]); // eslint-disable-line react-hooks/exhaustive-deps

    const matchedAccount = options.find(
        (coa) => coa.code && coa.code.toLowerCase() === term
    );

    // NEW: select whichever suggestion is currently highlighted
    const selectSuggestion = (coa) => {
        onChange(coa.code);
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    // NEW: keyboard handler
    const handleKeyDown = (e) => {
        if (!showSuggestions || suggestions.length === 0) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev + 1) % suggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
                selectSuggestion(suggestions[highlightedIndex]);
            }
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
            <div className="flex items-center gap-2">
                <div className="relative flex-1">
                    <input
                        type="text"
                        value={value ?? ''}
                        onChange={(e) => {
                            onChange(e.target.value);
                            setShowSuggestions(true);
                        }}
                        onFocus={() => (value || '').trim() && setShowSuggestions(true)}
                        onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                        onKeyDown={handleKeyDown}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                        placeholder="Search by account name or code"
                    />
                    {showSuggestions && suggestions.length > 0 && (
                        <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-20">
                            {suggestions.map((coa, index) => (
                                <div
                                    key={coa.id}
                                    className={`px-3 py-2 cursor-pointer text-sm flex items-center border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-100' : 'hover:bg-blue-50'
                                        }`}
                                    onMouseEnter={() => setHighlightedIndex(index)}
                                    onClick={() => selectSuggestion(coa)}
                                >
                                    {coa.code && (
                                        <span className="text-xs font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded mr-2">
                                            {coa.code}
                                        </span>
                                    )}
                                    <span className="font-medium">{coa.account_name}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                {matchedAccount && (
                    <span className="text-xs text-gray-500 whitespace-nowrap">→ {matchedAccount.account_name}</span>
                )}
            </div>
        </div>
    );
};

function ItemEntry() {
    // ---- Company / Financial Year context comes straight from Redux ----
    const { companyId: rawCompanyId, financialYearId: rawFinancialYearId } = useSelector((state) => state.company);
    const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== ''
        ? Number(rawCompanyId)
        : null;
    const financialYearId = rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ''
        ? Number(rawFinancialYearId)
        : null;

    // ---- Level 1: Main Items - the ONLY thing fetched on mount -------------
    const [mainItems, setMainItems] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    // ---- Levels 2-3, loaded lazily and cached per-parent --------------------
    // subItemsByMain:     { [mainitemId]: SubItem[] }
    // itemDetailsBySub:   { [subitemId]: ItemDetail[] }
    // A missing key means "not fetched yet"; an empty array means "fetched, no rows".
    const [subItemsByMain, setSubItemsByMain] = useState({});
    const [itemDetailsBySub, setItemDetailsBySub] = useState({});

    // Chart Of Account list, for resolving/picking GL_* ids. Fetched lazily
    // the first time the Item Sub Details modal opens.
    const [chartOfAccounts, setChartOfAccounts] = useState([]);
    const [chartOfAccountsLoaded, setChartOfAccountsLoaded] = useState(false);

    // Which nodes are expanded / currently fetching their children.
    // Keys look like "main-item-3" or "sub-item-14".
    const [expandedKeys, setExpandedKeys] = useState(new Set());
    const [loadingKeys, setLoadingKeys] = useState(new Set());

    // Search index - a flattened, fully-loaded snapshot of sub items / item
    // details for this company, built once the person actually starts
    // searching. It reuses the very same caches the tree reads from, so
    // anything found via search is already sitting in cache when its branch
    // gets expanded.
    const [searchIndexLoaded, setSearchIndexLoaded] = useState(false);
    const [searchIndexLoading, setSearchIndexLoading] = useState(false);

    // Search state
    const [searchTerm, setSearchTerm] = useState('');
    const [searchSuggestions, setSearchSuggestions] = useState([]);
    const [highlightedItem, setHighlightedItem] = useState(null);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedSuggestionIndex, setHighlightedSuggestionIndex] = useState(-1); // NEW

    // Modal state
    const [modalIsOpen, setModalIsOpen] = useState(false);
    const [modalType, setModalType] = useState(''); // 'subDetails' or 'itemDetails'
    const [selectedItemId, setSelectedItemId] = useState(null);
    const [modalRaw, setModalRaw] = useState(null); // the raw row being edited, so saves don't clobber other fields
    const emptySubDetails = { glPurchase: '', glSale: '', glGst: '', glFurther: '' };
    const emptyItemDetails = { hsCode: '', unit: '', packingUnit: '', barcode: '', location: '', minLimit: 0, maxLimit: 0, image: '' };
    const [modalData, setModalData] = useState({ subDetails: emptySubDetails, itemDetails: emptyItemDetails });

    // ---- Item Opening modal state -------------------------------------------
    // Opened via the "open.png" icon on an Item Detail row. Company and
    // Financial Year always come from Redux - they are never editable fields
    // in this form. Since the backend only exposes getAll/getById/add/update/
    // delete (no "find by item+company+year" endpoint), we fetch all openings
    // and find the matching row client-side to decide Add vs Update.
    // OLD - remove openingRecordId
    const emptyOpeningDetails = { quantity: '', weight: '', rate: '', amount: '' };
    const [openingModalIsOpen, setOpeningModalIsOpen] = useState(false);
    const [openingNode, setOpeningNode] = useState(null);
    const [openingData, setOpeningData] = useState(emptyOpeningDetails);
    const [openingLoading, setOpeningLoading] = useState(false);
    const [openingSaving, setOpeningSaving] = useState(false);

    // NEW - financial-year-aware entries, same pattern as ChartOfAccount's opening balance
    const [financialYears, setFinancialYears] = useState([]);
    const [financialYearsLoaded, setFinancialYearsLoaded] = useState(false);
    const [entryFinancialYearId, setEntryFinancialYearId] = useState(null);
    const [itemOpeningEntries, setItemOpeningEntries] = useState([]);

    // File input ref (shared - only one modal is open at a time)
    const fileInputRef = useRef(null);

    // Refs for every rendered tree row, keyed by "type-id" (e.g.
    // "item-detail-14"). Used to scroll a highlighted row into view -
    // whether it got highlighted via search selection or because it was
    // just created and landed somewhere in the alphabetical list.
    const nodeRefs = useRef({});

    // =============================================================================
    // Level 1: Main Items - fetched once, filtered to this company
    // =============================================================================
    const fetchMainItems = async () => {
        const res = await axios.get(`${API.mainItem}/`, { params: { company_id: companyId } });
        const filtered = (res.data?.data || []).filter((mi) => mi.company_id === companyId);
        setMainItems(filtered);
        return filtered;
    };

    useEffect(() => {
        if (!companyId) {
            setIsLoading(false);
            return;
        }
        (async () => {
            setIsLoading(true);
            try {
                await fetchMainItems();
            } catch (error) {
                toast.error(error?.response?.data?.message || 'Failed to load Main Items');
            } finally {
                setIsLoading(false);
            }
        })();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    // =============================================================================
    // Chart Of Account - fetched lazily, only account_name + id are used here
    // =============================================================================
    const fetchChartOfAccounts = async () => {
        const res = await axios.get(`${API.chartOfAccount}/`);
        const data = res.data?.data || [];
        setChartOfAccounts(data);
        setChartOfAccountsLoaded(true);
        return data;
    };
    const ensureChartOfAccountsLoaded = async () => (chartOfAccountsLoaded ? chartOfAccounts : fetchChartOfAccounts());

    const fetchFinancialYearsIfNeeded = async () => {
        if (financialYearsLoaded) return financialYears;
        try {
            const res = await axios.get(`${API.financialYear}/`, { params: { company_id: companyId } });
            const filtered = (res.data?.data || []).filter((fy) => Number(fy.company_id) === companyId);
            setFinancialYears(filtered);
            setFinancialYearsLoaded(true);
            return filtered;
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load Financial Years');
            return [];
        }
    };

    // Accounts belonging to this company, for the GL_* datalist options.
    const companyChartOfAccounts = useMemo(
        () => chartOfAccounts.filter((coa) => coa.company_id === companyId),
        [chartOfAccounts, companyId]
    );

    // =============================================================================
    // Levels 2-3: fetched on demand, one parent at a time
    // =============================================================================
    const withLoadingKey = async (key, fn) => {
        setLoadingKeys((prev) => new Set(prev).add(key));
        try {
            return await fn();
        } finally {
            setLoadingKeys((prev) => {
                const next = new Set(prev);
                next.delete(key);
                return next;
            });
        }
    };

    const fetchSubItemsForMainItem = async (mainItemId) => {
        await withLoadingKey(`main-item-${mainItemId}`, async () => {
            try {
                const res = await axios.get(`${API.subItem}/`, { params: { company_id: companyId, mainitem_id: mainItemId } });
                const filtered = (res.data?.data || []).filter((si) => si.company_id === companyId && si.mainitem_id === mainItemId);
                setSubItemsByMain((prev) => ({ ...prev, [mainItemId]: filtered }));
            } catch (error) {
                toast.error(error?.response?.data?.message || 'Failed to load Item Subs');
            }
        });
    };

    const fetchItemDetailsForSubItem = async (subItemId) => {
        return await withLoadingKey(`sub-item-${subItemId}`, async () => {
            try {
                const res = await axios.get(`${API.itemDetail}/`, { params: { company_id: companyId, subitem_id: subItemId } });
                const filtered = (res.data?.data || []).filter((id_) => id_.company_id === companyId && id_.subitem_id === subItemId);
                setItemDetailsBySub((prev) => ({ ...prev, [subItemId]: filtered }));
                return filtered;
            } catch (error) {
                toast.error(error?.response?.data?.message || 'Failed to load Item Details');
                return [];
            }
        });
    };

    // Expand/collapse a node, fetching its children the first time it opens.
    const toggleExpand = async (node) => {
        const key = `${node.type}-${node.id}`;
        if (expandedKeys.has(key)) {
            setExpandedKeys((prev) => {
                const next = new Set(prev);
                next.delete(key);
                return next;
            });
            return;
        }
        setExpandedKeys((prev) => new Set(prev).add(key));

        if (node.type === 'main-item' && subItemsByMain[node.id] === undefined) {
            await fetchSubItemsForMainItem(node.id);
        } else if (node.type === 'sub-item' && itemDetailsBySub[node.id] === undefined) {
            await fetchItemDetailsForSubItem(node.id);
        }
    };

    // Builds a node's children straight from the caches above.
    // Returns `undefined` if that parent hasn't been fetched yet at all.
    // NOTE: only Item Details are alphabetized (by `details`). Item Subs keep
    // whatever order the backend returned them in, since their `code` was
    // generated sequentially in that same order.
    const getChildrenForNode = (node) => {
        if (node.type === 'main-item') {
            const list = subItemsByMain[node.id];
            if (list === undefined) return undefined;
            return list.map((si) => ({
                type: 'sub-item',
                id: si.id,
                name: si.details,
                code: si.code,
                raw: si,
            }));
        }
        if (node.type === 'sub-item') {
            const list = itemDetailsBySub[node.id];
            if (list === undefined) return undefined;
            return [...list]
                .sort((a, b) => a.details.localeCompare(b.details))
                .map((d) => ({
                    type: 'item-detail',
                    id: d.id,
                    name: d.details,
                    code: d.code,
                    raw: d,
                }));
        }
        return [];
    };

    // Root of the tree - just the Main Items, everything else is lazy.
    const treeData = useMemo(
        () => mainItems.map((mi) => ({ type: 'main-item', id: mi.id, name: mi.details, code: mi.code, raw: mi })),
        [mainItems]
    );

    // =============================================================================
    // Add / Update / Delete - each one only refreshes the cache slice it touched
    // =============================================================================
    const handleAdd = async (parentNode, newName) => {
        const name = newName.trim();
        if (!name) return;

        if (!companyId) {
            toast.error('Select a company first');
            return;
        }

        try {
            if (!parentNode) {
                await axios.post(`${API.mainItem}/`, { company_id: companyId, details: name });
                toast.success('Item Main added');
                await fetchMainItems();
            } else if (parentNode.type === 'main-item') {
                await axios.post(`${API.subItem}/`, { company_id: companyId, mainitem_id: parentNode.id, details: name });
                toast.success('Item Sub added');
                await fetchSubItemsForMainItem(parentNode.id);
                setExpandedKeys((prev) => new Set(prev).add(`main-item-${parentNode.id}`));
            } else if (parentNode.type === 'sub-item') {
                // Snapshot the ids we already know about, BEFORE the add, so we can
                // reliably spot the new row afterwards regardless of API response shape.
                const previousItems = itemDetailsBySub[parentNode.id] || [];
                const previousIds = new Set(previousItems.map((d) => d.id));

                await axios.post(`${API.itemDetail}/`, { company_id: companyId, subitem_id: parentNode.id, details: name });
                toast.success('Item Detail added');
                const updatedItems = await fetchItemDetailsForSubItem(parentNode.id);
                setExpandedKeys((prev) => new Set(prev).add(`sub-item-${parentNode.id}`));

                // The new row is whichever item wasn't there before the POST -
                // highlight it so the scroll effect (also used for search) carries
                // it into view, wherever alphabetical sorting placed it.
                const newItem = (updatedItems || []).find((d) => !previousIds.has(d.id));
                if (newItem) {
                    setHighlightedItem(newItem.id);
                }
            }
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to add item');
        }
    };

    const handleUpdate = async (node, newName) => {
        const name = newName.trim();
        if (!name || name === node.name) return;

        try {
            if (node.type === 'main-item') {
                await axios.put(`${API.mainItem}/${node.id}`, { company_id: node.raw.company_id, details: name });
                await fetchMainItems();
            } else if (node.type === 'sub-item') {
                await axios.put(`${API.subItem}/${node.id}`, {
                    company_id: node.raw.company_id,
                    mainitem_id: node.raw.mainitem_id,
                    details: name,
                    GL_purchase: node.raw.GL_purchase,
                    GL_sale: node.raw.GL_sale,
                    GL_gst: node.raw.GL_gst,
                    GL_further: node.raw.GL_further,
                });
                await fetchSubItemsForMainItem(node.raw.mainitem_id);
            } else if (node.type === 'item-detail') {
                await axios.put(`${API.itemDetail}/${node.id}`, {
                    company_id: node.raw.company_id,
                    subitem_id: node.raw.subitem_id,
                    details: name,
                    HSCode: node.raw.HSCode,
                    Unit: node.raw.Unit,
                    PackingUnit: node.raw.PackingUnit,
                    Barcode: node.raw.Barcode,
                    Image: node.raw.Image,
                    Location: node.raw.Location,
                    MinLimit: node.raw.MinLimit,
                    MaxLimit: node.raw.MaxLimit,
                });
                await fetchItemDetailsForSubItem(node.raw.subitem_id);
            }
            toast.success('Updated successfully');
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to update item');
        }
    };

    const handleDelete = async (node) => {
        if (!window.confirm(`Are you sure you want to delete "${node.name}" and all its children?`)) {
            return;
        }
        const urlByType = {
            'main-item': API.mainItem,
            'sub-item': API.subItem,
            'item-detail': API.itemDetail,
        };

        try {
            await axios.delete(`${urlByType[node.type]}/${node.id}`);
            toast.success('Deleted successfully');
            // Note: this deletes only this row. Rows underneath it
            // (SubItem/ItemDetail) are NOT cascade-deleted by these
            // controllers, so they'd become orphaned in the DB even though
            // they vanish from the tree here.
            if (node.type === 'main-item') {
                await fetchMainItems();
                setSubItemsByMain((prev) => {
                    const next = { ...prev };
                    delete next[node.id];
                    return next;
                });
            } else if (node.type === 'sub-item') {
                await fetchSubItemsForMainItem(node.raw.mainitem_id);
                setItemDetailsBySub((prev) => {
                    const next = { ...prev };
                    delete next[node.id];
                    return next;
                });
            } else if (node.type === 'item-detail') {
                await fetchItemDetailsForSubItem(node.raw.subitem_id);
            }
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete item');
        }
    };

    // =============================================================================
    // Search
    // -----------------------------------------------------------------------------
    // The tree is lazy, so a global search can't just scan already-rendered
    // nodes - most of them won't be loaded yet. The first time the person
    // actually types a search term, we pull one flat snapshot of every sub
    // item and item detail for this company and drop it straight into the
    // same caches the tree reads from. After that, search is instant, and
    // any branch opened afterwards is already warm.
    //
    // Matching is done against BOTH the `details` text and the `code` field.
    // =============================================================================
    const loadSearchIndexIfNeeded = async () => {
        if (searchIndexLoaded || searchIndexLoading || !companyId) return;
        setSearchIndexLoading(true);
        try {
            const [siRes, idRes] = await Promise.all([
                axios.get(`${API.subItem}/`, { params: { company_id: companyId } }),
                axios.get(`${API.itemDetail}/`, { params: { company_id: companyId } }),
            ]);

            const allSI = (siRes.data?.data || []).filter((si) => si.company_id === companyId);
            const allID = (idRes.data?.data || []).filter((d) => d.company_id === companyId);

            setSubItemsByMain((prev) => {
                const next = { ...prev };
                mainItems.forEach((mi) => { next[mi.id] = []; });
                allSI.forEach((si) => {
                    next[si.mainitem_id] = next[si.mainitem_id] || [];
                    next[si.mainitem_id].push(si);
                });
                return next;
            });

            setItemDetailsBySub((prev) => {
                const next = { ...prev };
                allSI.forEach((si) => { next[si.id] = []; });
                allID.forEach((d) => {
                    next[d.subitem_id] = next[d.subitem_id] || [];
                    next[d.subitem_id].push(d);
                });
                return next;
            });

            setSearchIndexLoaded(true);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load search results');
        } finally {
            setSearchIndexLoading(false);
        }
    };

    const getAllItemDetails = () => {
        const items = [];
        mainItems.forEach((mi) => {
            const subs = subItemsByMain[mi.id] || [];
            subs.forEach((si) => {
                const details = itemDetailsBySub[si.id] || [];
                details.forEach((d) => {
                    items.push({
                        id: d.id,
                        name: d.details,
                        code: d.code,
                        path: [mi.details, si.details, d.details],
                    });
                });
            });
        });
        return items;
    };

    // Reveal a found item in the tree by expanding its ancestor branches.
    const expandPathToItem = (itemId) => {
        for (const mi of mainItems) {
            const subs = subItemsByMain[mi.id] || [];
            for (const si of subs) {
                const details = itemDetailsBySub[si.id] || [];
                if (details.some((d) => d.id === itemId)) {
                    setExpandedKeys((prev) => {
                        const next = new Set(prev);
                        next.add(`main-item-${mi.id}`);
                        next.add(`sub-item-${si.id}`);
                        return next;
                    });
                    return;
                }
            }
        }
    };

    const selectSearchSuggestion = (item) => {
        setSearchTerm(item.name);
        setHighlightedItem(item.id);
        setShowSuggestions(false);
        setHighlightedSuggestionIndex(-1);
        expandPathToItem(item.id);
    };

    const handleSearchKeyDown = (e) => {
        if (!showSuggestions || searchSuggestions.length === 0) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedSuggestionIndex((prev) => (prev + 1) % searchSuggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedSuggestionIndex((prev) => (prev - 1 + searchSuggestions.length) % searchSuggestions.length);
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightedSuggestionIndex >= 0 && highlightedSuggestionIndex < searchSuggestions.length) {
                selectSearchSuggestion(searchSuggestions[highlightedSuggestionIndex]);
            }
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    useEffect(() => {
        if (searchTerm.trim() === '') {
            setSearchSuggestions([]);
            setShowSuggestions(false);
            return;
        }
        if (!searchIndexLoaded) {
            loadSearchIndexIfNeeded();
            return; // effect re-runs once the caches below update
        }
        const term = searchTerm.toLowerCase();
        const allItems = getAllItemDetails();
        const filtered = allItems.filter(
            (item) =>
                item.name.toLowerCase().includes(term) ||
                (item.code && item.code.toLowerCase().includes(term))
        );
        setSearchSuggestions(filtered);
        setShowSuggestions(true);
        setHighlightedItem(filtered.length > 0 ? filtered[0].id : null);
        setHighlightedSuggestionIndex(filtered.length > 0 ? 0 : -1);
        setShowSuggestions(true);
        setHighlightedItem(filtered.length > 0 ? filtered[0].id : null);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchTerm, searchIndexLoaded, subItemsByMain, itemDetailsBySub, mainItems]);

    // Clearing the highlight only belongs to the user actually emptying the
    // search box. Kept as its own effect keyed only on searchTerm - if it
    // depended on itemDetailsBySub/etc. too, adding a new item (which updates
    // those caches while searchTerm is still empty) would immediately null out
    // the highlight we just set for that new row.
    useEffect(() => {
        if (searchTerm.trim() === '') {
            setHighlightedItem(null);
        }
    }, [searchTerm]);

    // Whenever the highlighted item changes - from picking a search
    // suggestion, from typing a search term that auto-highlights the first
    // match, or from a brand-new item detail being created - scroll that row
    // into view once the tree has finished expanding/re-rendering.
    useEffect(() => {
        if (!highlightedItem) return;
        const key = `item-detail-${highlightedItem}`;
        const timer = setTimeout(() => {
            nodeRefs.current[key]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 150);
        return () => clearTimeout(timer);
    }, [highlightedItem, expandedKeys, itemDetailsBySub]);

    // =============================================================================
    // Modal: subDetails -> SubItem GL fields, itemDetails -> ItemDetail fields
    // =============================================================================
    const openModal = async (node, type) => {
        setSelectedItemId(node.id);
        setModalType(type);
        setModalRaw(node.raw);
        setModalIsOpen(true);

        if (type === 'subDetails') {
            await ensureChartOfAccountsLoaded();
            setModalData({
                subDetails: {
                    glPurchase: node.raw.GL_purchase ?? '',
                    glSale: node.raw.GL_sale ?? '',
                    glGst: node.raw.GL_gst ?? '',
                    glFurther: node.raw.GL_further ?? '',
                },
                itemDetails: emptyItemDetails,
            });
        } else if (type === 'itemDetails') {
            setModalData({
                subDetails: emptySubDetails,
                itemDetails: {
                    hsCode: node.raw.HSCode ?? '',
                    unit: node.raw.Unit ?? '',
                    packingUnit: node.raw.PackingUnit ?? '',
                    barcode: node.raw.Barcode ?? '',
                    location: node.raw.Location ?? '',
                    minLimit: node.raw.MinLimit ?? 0,
                    maxLimit: node.raw.MaxLimit ?? 0,
                    image: node.raw.Image ?? '',
                },
            });
        }
    };

    const closeModal = () => {
        setModalIsOpen(false);
        setSelectedItemId(null);
        setModalType('');
        setModalRaw(null);
        setModalData({ subDetails: emptySubDetails, itemDetails: emptyItemDetails });
    };

    const handleModalSave = async () => {
        if (!selectedItemId || !modalRaw) return;

        try {
            if (modalType === 'subDetails') {
                // Only the ids go to the backend, whether they were typed
                // directly or picked from the account-name datalist.
                await axios.put(`${API.subItem}/${selectedItemId}`, {
                    company_id: modalRaw.company_id,
                    mainitem_id: modalRaw.mainitem_id,
                    details: modalRaw.details,
                    GL_purchase: modalData.subDetails.glPurchase || null,
                    GL_sale: modalData.subDetails.glSale || null,
                    GL_gst: modalData.subDetails.glGst || null,
                    GL_further: modalData.subDetails.glFurther || null,
                });
                await fetchSubItemsForMainItem(modalRaw.mainitem_id);
                toast.success('Item Sub details saved');
            } else if (modalType === 'itemDetails') {
                await axios.put(`${API.itemDetail}/${selectedItemId}`, {
                    company_id: modalRaw.company_id,
                    subitem_id: modalRaw.subitem_id,
                    details: modalRaw.details,
                    HSCode: modalData.itemDetails.hsCode || null,
                    Unit: modalData.itemDetails.unit || null,
                    PackingUnit: modalData.itemDetails.packingUnit || null,
                    Barcode: modalData.itemDetails.barcode || null,
                    Image: modalData.itemDetails.image || null,
                    Location: modalData.itemDetails.location || null,
                    MinLimit: modalData.itemDetails.minLimit || 0,
                    MaxLimit: modalData.itemDetails.maxLimit || 0,
                });
                await fetchItemDetailsForSubItem(modalRaw.subitem_id);
                toast.success('Item details saved');
            }
            closeModal();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save, please try again');
        }
    };

    // Doesn't delete the row itself - just clears the extra fields back to
    // empty, same as the original behavior (the tree node stays put).
    const handleModalDelete = async () => {
        if (!selectedItemId || !modalRaw) return;
        if (!window.confirm('Are you sure you want to clear this data?')) return;

        try {
            if (modalType === 'subDetails') {
                await axios.put(`${API.subItem}/${selectedItemId}`, {
                    company_id: modalRaw.company_id,
                    mainitem_id: modalRaw.mainitem_id,
                    details: modalRaw.details,
                    GL_purchase: null,
                    GL_sale: null,
                    GL_gst: null,
                    GL_further: null,
                });
                await fetchSubItemsForMainItem(modalRaw.mainitem_id);
            } else if (modalType === 'itemDetails') {
                await axios.put(`${API.itemDetail}/${selectedItemId}`, {
                    company_id: modalRaw.company_id,
                    subitem_id: modalRaw.subitem_id,
                    details: modalRaw.details,
                    HSCode: null,
                    Unit: null,
                    PackingUnit: null,
                    Barcode: null,
                    Image: null,
                    Location: null,
                    MinLimit: 0,
                    MaxLimit: 0,
                });
                await fetchItemDetailsForSubItem(modalRaw.subitem_id);
            }
            toast.success('Cleared successfully');
            closeModal();
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to clear, please try again');
        }
    };

    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            setModalData((prev) => ({ ...prev, itemDetails: { ...prev.itemDetails, image: file.name } }));
        }
    };

    // =============================================================================
    // Item Opening: opened from the "open.png" icon on an Item Detail row.
    // company_id and financialyear_id are always pulled from Redux and are
    // never rendered as inputs. Since the backend has no "find one" endpoint
    // for (company, year, item), we fetch all openings and locate the match
    // client-side to know whether Save should POST /add or PUT /update/:id.
    // =============================================================================
    // Fetches ALL Item Opening rows for this item detail (across every financial
    // year) - same shape as ChartOfAccount's fetchOpeningBalancesForParty, since
    // the backend has no "find by item" endpoint either.
    const fetchItemOpeningEntriesForNode = async (itemDetailId) => {
        try {
            const res = await axios.get(`${API.itemOpening}/`, { params: { itemdetail_id: itemDetailId } });
            const filtered = (res.data?.data || []).filter(
                (o) => o.company_id === companyId && o.itemdetail_id === itemDetailId
            );
            setItemOpeningEntries(filtered);
            return filtered;
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load Item Opening');
            return [];
        }
    };

    const openOpeningModal = async (node) => {
        if (!companyId) {
            toast.error('Select a company first');
            return;
        }

        setOpeningNode(node);
        setItemOpeningEntries([]);
        setOpeningData(emptyOpeningDetails);
        setOpeningModalIsOpen(true);
        setOpeningLoading(true);

        try {
            await fetchFinancialYearsIfNeeded();
            const entries = await fetchItemOpeningEntriesForNode(node.id);
            setEntryFinancialYearId(financialYearId); // defaults to the currently active FY
            const existingForYear = entries.find((o) => o.financialyear_id === financialYearId);
            setOpeningData({
                quantity: existingForYear?.quantity ?? '',
                weight: existingForYear?.weight ?? '',
                rate: existingForYear?.rate ?? '',
                amount: existingForYear?.amount ?? '',
            });
        } finally {
            setOpeningLoading(false);
        }
    };

    const closeOpeningModal = () => {
        setOpeningModalIsOpen(false);
        setOpeningNode(null);
        setOpeningData(emptyOpeningDetails);
        setOpeningLoading(false);
        setOpeningSaving(false);
        setEntryFinancialYearId(null);
        setItemOpeningEntries([]);
    };

    const handleOpeningFieldChange = (field, value) => {
        setOpeningData((prev) => ({ ...prev, [field]: value }));
    };

    // Switch which year's entry is being viewed/edited - same as loadBalanceForYear
    const loadOpeningForYear = (yearId) => {
        setEntryFinancialYearId(yearId);
        const existing = itemOpeningEntries.find((o) => o.financialyear_id === yearId);
        setOpeningData({
            quantity: existing?.quantity ?? '',
            weight: existing?.weight ?? '',
            rate: existing?.rate ?? '',
            amount: existing?.amount ?? '',
        });
    };

    const handleOpeningSave = async () => {
        if (!openingNode || !companyId) return;
        if (!entryFinancialYearId) {
            toast.error('Select a financial year first');
            return;
        }

        const payload = {
            company_id: companyId,
            financialyear_id: entryFinancialYearId,
            itemdetail_id: openingNode.id,
            quantity: parseFloat(openingData.quantity) || 0,
            weight: parseFloat(openingData.weight) || 0,
            rate: parseFloat(openingData.rate) || 0,
            amount: parseFloat(openingData.amount) || 0,
        };

        const existingEntry = itemOpeningEntries.find((o) => o.financialyear_id === entryFinancialYearId);

        setOpeningSaving(true);
        try {
            if (existingEntry) {
                await axios.put(`${API.itemOpening}/update/${existingEntry.id}`, payload);
            } else {
                await axios.post(`${API.itemOpening}/add`, payload);
            }
            toast.success('Item Opening saved successfully');
            await fetchItemOpeningEntriesForNode(openingNode.id);
            // Modal stays open, same as the Opening Balance entry flow, so the
            // person can keep switching years and saving more entries.
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save Item Opening');
        } finally {
            setOpeningSaving(false);
        }
    };

    // Deletes the entry for whichever year is currently loaded in the form
    const handleOpeningDelete = async () => {
        const existingEntry = itemOpeningEntries.find((o) => o.financialyear_id === entryFinancialYearId);
        if (!existingEntry) return;
        if (!window.confirm('Are you sure you want to delete this Item Opening?')) return;

        setOpeningSaving(true);
        try {
            await axios.delete(`${API.itemOpening}/delete/${existingEntry.id}`);
            toast.success('Item Opening deleted successfully');
            await fetchItemOpeningEntriesForNode(openingNode.id);
            setOpeningData(emptyOpeningDetails);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete Item Opening');
        } finally {
            setOpeningSaving(false);
        }
    };

    // Deletes a specific entry directly from the "existing entries" list
    const handleOpeningDeleteEntry = async (entry) => {
        if (!window.confirm(`Delete the ${entry.year_detail} entry?`)) return;
        try {
            await axios.delete(`${API.itemOpening}/delete/${entry.id}`);
            toast.success('Entry deleted');
            await fetchItemOpeningEntriesForNode(openingNode.id);
            if (entry.financialyear_id === entryFinancialYearId) {
                setOpeningData(emptyOpeningDetails);
            }
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete entry');
        }
    };

    // =============================================================================
    // Recursive tree node
    // =============================================================================
    const TreeNode = ({ node, level = 0 }) => {
        const [isAdding, setIsAdding] = useState(false);
        const [newName, setNewName] = useState('');
        const [isEditing, setIsEditing] = useState(false);
        const [editName, setEditName] = useState(node.name);

        const isItemDetail = node.type === 'item-detail';
        const isTopLevel = node.type === 'main-item';
        const isItemSub = node.type === 'sub-item';
        const canExpand = !isItemDetail;

        const nodeKey = `${node.type}-${node.id}`;
        const isExpanded = expandedKeys.has(nodeKey);
        const isLoadingChildren = loadingKeys.has(nodeKey);
        const children = canExpand ? getChildrenForNode(node) : [];
        const hasManyItemDetails = isItemSub && children && children.length >= 3;

        const handleAddSubmit = (e) => {
            e.preventDefault();
            if (newName.trim()) {
                handleAdd(node, newName);
                setNewName('');
                setIsAdding(false);
            }
        };

        const handleUpdateSubmit = (e) => {
            e.preventDefault();
            if (editName.trim() && editName !== node.name) {
                handleUpdate(node, editName);
            }
            setIsEditing(false);
        };

        const handleKeyDown = (e) => {
            if (e.key === 'Escape') {
                setIsAdding(false);
                setIsEditing(false);
                setNewName('');
                setEditName(node.name);
            }
        };

        const isHighlighted = highlightedItem === node.id && isItemDetail;

        // Generic highlighter - used for both the `details` name and the
        // `code` badge, since search now matches either one.
        const getSearchHighlight = (text) => {
            if (!text || !searchTerm.trim()) return text;
            const index = text.toLowerCase().indexOf(searchTerm.toLowerCase());
            if (index === -1) return text;
            const before = text.substring(0, index);
            const match = text.substring(index, index + searchTerm.length);
            const after = text.substring(index + searchTerm.length);
            return (
                <>
                    {before}
                    <span className="bg-yellow-200 px-0.5 rounded">{match}</span>
                    {after}
                </>
            );
        };

        return (
            <div className="relative">
                <div
                    ref={(el) => {
                        if (el) nodeRefs.current[nodeKey] = el;
                        else delete nodeRefs.current[nodeKey];
                    }}
                    className={`flex items-center py-1.5 hover:bg-gray-50 rounded transition-colors ${isHighlighted ? 'bg-yellow-100 border-l-4 border-yellow-400' : ''
                        }`}
                    style={{ paddingLeft: `${Math.min(level * 20, 80)}px` }}
                >
                    {canExpand && (
                        <button
                            onClick={() => toggleExpand(node)}
                            className="mr-1 text-gray-400 hover:text-gray-600 focus:outline-none"
                        >
                            {isLoadingChildren ? (
                                <svg className="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                </svg>
                            ) : (
                                <svg
                                    className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                </svg>
                            )}
                        </button>
                    )}

                    {isEditing ? (
                        <form onSubmit={handleUpdateSubmit} className="flex items-center flex-1">
                            {node.code && (
                                <span className="text-xs font-mono text-gray-400 mr-2 bg-gray-100 px-1.5 py-0.5 rounded shrink-0">
                                    {node.code}
                                </span>
                            )}
                            <input
                                type="text"
                                value={editName}
                                onChange={(e) => setEditName(e.target.value)}
                                onBlur={handleUpdateSubmit}
                                onKeyDown={handleKeyDown}
                                className="border border-blue-400 rounded px-2 py-0.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300 flex-1 max-w-xs"
                                autoFocus
                            />
                        </form>
                    ) : (
                        <>
                            <span className={`text-sm ${isTopLevel ? 'font-semibold text-gray-800' : 'text-gray-700'}`}>
                                {/* Code badge shown just before the name/details */}
                                {node.code && (
                                    <span className="text-xs font-mono text-gray-400 mr-2 bg-gray-100 px-1.5 py-0.5 rounded">
                                        {isHighlighted ? getSearchHighlight(node.code) : node.code}
                                    </span>
                                )}
                                {isHighlighted ? getSearchHighlight(node.name) : node.name}
                            </span>

                            <div className="flex items-center ml-2 space-x-1">
                                {!isItemDetail && (
                                    <button
                                        onClick={() => setIsAdding(true)}
                                        className="p-1 hover:bg-gray-200 rounded transition-colors"
                                        title="Add new item"
                                    >
                                        <img src="/src/assets/add.png" alt="Add" className="w-4 h-4" />
                                    </button>
                                )}

                                {(isItemSub || isItemDetail) && (
                                    <button
                                        onClick={() => openModal(node, isItemSub ? 'subDetails' : 'itemDetails')}
                                        className="p-1 hover:bg-gray-200 rounded transition-colors"
                                        title={isItemSub ? 'Item Sub Details' : 'Item Details'}
                                    >
                                        <img src="/src/assets/search.png" alt="Details" className="w-4 h-4" />
                                    </button>
                                )}

                                {isItemDetail && (
                                    <button
                                        onClick={() => openOpeningModal(node)}
                                        className="p-1 hover:bg-gray-200 rounded transition-colors"
                                        title="Item Opening"
                                    >
                                        <img src="/src/assets/open.png" alt="Item Opening" className="w-4 h-4" />
                                    </button>
                                )}

                                <button
                                    onClick={() => setIsEditing(true)}
                                    className="p-1 hover:bg-gray-200 rounded transition-colors"
                                    title="Update"
                                >
                                    <img src="/src/assets/edit.png" alt="Update" className="w-4 h-4" />
                                </button>

                                <button
                                    onClick={() => handleDelete(node)}
                                    className="p-1 hover:bg-gray-200 rounded transition-colors"
                                    title="Delete"
                                >
                                    <img src="/src/assets/delete.png" alt="Delete" className="w-4 h-4" />
                                </button>
                            </div>
                        </>
                    )}
                </div>

                {isAdding && (
                    <div className="mt-1" style={{ paddingLeft: `${Math.min((level + 1) * 20, 100)}px` }}>
                        <form onSubmit={handleAddSubmit} className="flex items-center">
                            <input
                                type="text"
                                value={newName}
                                onChange={(e) => setNewName(e.target.value)}
                                onBlur={handleAddSubmit}
                                onKeyDown={handleKeyDown}
                                placeholder="Enter name..."
                                className="border border-blue-400 rounded px-2 py-0.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300 w-48"
                                autoFocus
                            />
                        </form>
                    </div>
                )}

                {isExpanded && canExpand && (
                    <div className="ml-4">
                        {isLoadingChildren || children === undefined ? (
                            <div className="text-xs text-gray-400 py-1" style={{ paddingLeft: `${Math.min((level + 1) * 20, 100)}px` }}>
                                Loading...
                            </div>
                        ) : children.length === 0 ? (
                            <div className="text-xs text-gray-400 py-1" style={{ paddingLeft: `${Math.min((level + 1) * 20, 100)}px` }}>
                                No items yet.
                            </div>
                        ) : (
                            <div className={hasManyItemDetails ? 'max-h-48 overflow-y-auto scrollbar-thin' : ''}>
                                {children.map((child) => (
                                    <TreeNode key={`${child.type}-${child.id}`} node={child} level={level + 1} />
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="min-h-screen bg-gray-50 p-8">
            <div className="max-w-5xl mx-auto">
                {/* Header */}
                <div className="mb-2">
                    <h1 className="text-2xl font-bold text-gray-800 mb-2">Item Entry</h1>
                </div>

                {!companyId ? (
                    <div className="bg-white rounded-lg shadow-sm p-8 border border-gray-200 text-center text-gray-500 text-sm">
                        No company context found. Please select a company first.
                    </div>
                ) : (
                    <>
                        {/* Search Bar */}
                        <div className="mb-2 relative">
                            <div className="max-w-md mx-auto">
                                <div className="relative">
                                    <input
                                        type="text"
                                        placeholder="Search by name or code..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        onFocus={() => searchTerm.trim() && setShowSuggestions(true)}
                                        onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                                        onKeyDown={handleSearchKeyDown}
                                        className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none"
                                    />
                                    <svg
                                        className="absolute left-3 top-2.5 w-5 h-5 text-gray-400"
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                    </svg>
                                </div>

                                {searchIndexLoading && (
                                    <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg p-3 text-sm text-gray-500 text-center mx-auto max-w-md">
                                        Searching...
                                    </div>
                                )}

                                {!searchIndexLoading && showSuggestions && searchSuggestions.length > 0 && (
                                    <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto z-10 mx-auto max-w-md">
                                        {searchSuggestions.map((item, index) => (
                                            <div
                                                key={item.id}
                                                className={`px-4 py-2 cursor-pointer flex items-center text-sm border-b border-gray-100 last:border-0 ${index === highlightedSuggestionIndex ? 'bg-blue-100' : 'hover:bg-blue-50'
                                                    }`}
                                                onMouseEnter={() => setHighlightedSuggestionIndex(index)}
                                                onClick={() => selectSearchSuggestion(item)}
                                            >
                                                {item.code && (
                                                    <span className="text-xs font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded mr-2">
                                                        {item.code}
                                                    </span>
                                                )}
                                                <span className="font-medium">{item.name}</span>
                                                <span className="ml-2 text-xs text-gray-400">
                                                    {item.path.slice(0, -1).join(' → ')}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                {!searchIndexLoading && showSuggestions && searchSuggestions.length === 0 && searchTerm.trim() && (
                                    <div className="absolute left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg p-3 text-sm text-gray-500 text-center mx-auto max-w-md">
                                        No items found
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Tree Container */}
                        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                            {isLoading ? (
                                <div className="py-12 text-center text-gray-500 text-sm">Loading Item Mains...</div>
                            ) : (
                                <>
                                    {treeData.map((node) => (
                                        <TreeNode key={`${node.type}-${node.id}`} node={node} level={0} />
                                    ))}

                                    {/* Add Item Main Button - at the bottom */}
                                    <div className="mt-4 pt-4 border-t border-gray-200">
                                        <button
                                            onClick={() => {
                                                const newName = prompt('Enter new Item Main name:');
                                                if (newName && newName.trim()) {
                                                    handleAdd(null, newName.trim());
                                                }
                                            }}
                                            className="flex items-center text-blue-500 hover:text-blue-600 transition-colors py-1 px-2 rounded hover:bg-blue-50"
                                            title="Add new Item Main"
                                        >
                                            <img src="/src/assets/add.png" alt="Add" className="w-4 h-4 mr-1" />
                                            <span className="text-sm font-medium">Add Item Main</span>
                                        </button>
                                    </div>
                                </>
                            )}
                        </div>
                    </>
                )}
            </div>

            {/* Modal for Item Sub Details and Item Details */}
            <Modal
                isOpen={modalIsOpen}
                onRequestClose={closeModal}
                contentLabel="Item Data Entry"
                className="fixed inset-0 flex items-center justify-center z-50"
                overlayClassName="fixed inset-0 bg-black bg-opacity-50 z-40"
                style={{
                    content: {
                        position: 'fixed',
                        inset: '0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        background: 'transparent',
                        border: 'none',
                        padding: '0',
                    },
                    overlay: {
                        position: 'fixed',
                        inset: '0',
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: '40',
                    }
                }}
            >
                <div className="bg-white rounded-lg shadow-2xl max-w-md w-full mx-4 p-6 relative">
                    <h2 className="text-xl font-bold mb-4 text-gray-800">
                        {modalType === 'subDetails' && 'Item Sub Details (GL Fields)'}
                        {modalType === 'itemDetails' && 'Item Details'}
                    </h2>

                    {modalType === 'subDetails' && (
                        <div className="space-y-4">
                            <GLAccountField
                                label="GL Purchase (Account)"
                                value={modalData.subDetails.glPurchase}
                                onChange={(val) => setModalData({ ...modalData, subDetails: { ...modalData.subDetails, glPurchase: val } })}
                                options={companyChartOfAccounts}
                            />
                            <GLAccountField
                                label="GL Sale (Account)"
                                value={modalData.subDetails.glSale}
                                onChange={(val) => setModalData({ ...modalData, subDetails: { ...modalData.subDetails, glSale: val } })}
                                options={companyChartOfAccounts}
                            />
                            <GLAccountField
                                label="GL GST (Account)"
                                value={modalData.subDetails.glGst}
                                onChange={(val) => setModalData({ ...modalData, subDetails: { ...modalData.subDetails, glGst: val } })}
                                options={companyChartOfAccounts}
                            />
                            <GLAccountField
                                label="GL Further (Account)"
                                value={modalData.subDetails.glFurther}
                                onChange={(val) => setModalData({ ...modalData, subDetails: { ...modalData.subDetails, glFurther: val } })}
                                options={companyChartOfAccounts}
                            />
                            <p className="text-xs text-gray-400">
                                Search by account name or type the code directly - the account's code is what gets saved.
                            </p>
                        </div>
                    )}

                    {modalType === 'itemDetails' && (
                        <div className="space-y-4 max-h-96 overflow-y-auto">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">HS Code</label>
                                <input
                                    type="text"
                                    value={modalData.itemDetails.hsCode || ''}
                                    onChange={(e) => setModalData({
                                        ...modalData,
                                        itemDetails: { ...modalData.itemDetails, hsCode: e.target.value },
                                    })}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter HS Code"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Unit</label>
                                <input
                                    type="text"
                                    value={modalData.itemDetails.unit || ''}
                                    onChange={(e) => setModalData({
                                        ...modalData,
                                        itemDetails: { ...modalData.itemDetails, unit: e.target.value },
                                    })}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Unit (e.g., KG, PCS, LTR)"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Packing Unit</label>
                                <input
                                    type="text"
                                    value={modalData.itemDetails.packingUnit || ''}
                                    onChange={(e) => setModalData({
                                        ...modalData,
                                        itemDetails: { ...modalData.itemDetails, packingUnit: e.target.value },
                                    })}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Packing Unit (e.g., Box of 12)"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Barcode</label>
                                <input
                                    type="text"
                                    value={modalData.itemDetails.barcode || ''}
                                    onChange={(e) => setModalData({
                                        ...modalData,
                                        itemDetails: { ...modalData.itemDetails, barcode: e.target.value },
                                    })}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Barcode"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                                <input
                                    type="text"
                                    value={modalData.itemDetails.location || ''}
                                    onChange={(e) => setModalData({
                                        ...modalData,
                                        itemDetails: { ...modalData.itemDetails, location: e.target.value },
                                    })}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Location"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Min Limit</label>
                                <input
                                    type="number"
                                    value={modalData.itemDetails.minLimit || ''}
                                    onChange={(e) => setModalData({
                                        ...modalData,
                                        itemDetails: { ...modalData.itemDetails, minLimit: parseFloat(e.target.value) || 0 },
                                    })}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Min Limit"
                                    min="0"
                                    step="0.01"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Max Limit</label>
                                <input
                                    type="number"
                                    value={modalData.itemDetails.maxLimit || ''}
                                    onChange={(e) => setModalData({
                                        ...modalData,
                                        itemDetails: { ...modalData.itemDetails, maxLimit: parseFloat(e.target.value) || 0 },
                                    })}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Max Limit"
                                    min="0"
                                    step="0.01"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Image</label>
                                <div className="flex items-center space-x-2">
                                    <input
                                        type="file"
                                        ref={fileInputRef}
                                        onChange={handleFileUpload}
                                        accept="image/*"
                                        className="hidden"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => fileInputRef.current?.click()}
                                        className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors text-sm"
                                    >
                                        Choose Image
                                    </button>
                                    {modalData.itemDetails.image && (
                                        <span className="text-sm text-gray-600">{modalData.itemDetails.image}</span>
                                    )}
                                </div>
                                <p className="text-xs text-gray-400 mt-1">Upload an image file (optional)</p>
                            </div>
                        </div>
                    )}

                    {/* Modal Actions */}
                    <div className="flex justify-end space-x-3 mt-6 pt-4 border-t border-gray-200">
                        <button
                            onClick={handleModalDelete}
                            className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-md transition-colors flex items-center"
                        >
                            <img src="/src/assets/delete.png" alt="Delete" className="w-4 h-4 inline mr-1" />
                            Delete
                        </button>
                        <button
                            onClick={closeModal}
                            className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleModalSave}
                            className="px-4 py-2 bg-blue-500 text-white hover:bg-blue-600 rounded-md transition-colors"
                        >
                            Save
                        </button>
                    </div>
                </div>
            </Modal>

            {/* Modal for Item Opening (quantity / weight / rate / amount) */}
            <Modal
                isOpen={openingModalIsOpen}
                onRequestClose={closeOpeningModal}
                contentLabel="Item Opening"
                className="fixed inset-0 flex items-center justify-center z-50"
                overlayClassName="fixed inset-0 bg-black bg-opacity-50 z-40"
                style={{
                    content: {
                        position: 'fixed',
                        inset: '0',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        background: 'transparent',
                        border: 'none',
                        padding: '0',
                    },
                    overlay: {
                        position: 'fixed',
                        inset: '0',
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: '40',
                    }
                }}
            >
                <div className="bg-white rounded-lg shadow-2xl max-w-md w-full mx-4 p-6 relative">
                    <h2 className="text-xl font-bold mb-1 text-gray-800">Item Opening</h2>
                    {openingNode && (
                        <p className="text-xs text-gray-400 mb-4">
                            {openingNode.code ? `${openingNode.code} - ` : ''}{openingNode.name}
                        </p>
                    )}

                    {openingLoading ? (
                        <div className="py-8 text-center text-sm text-gray-500">Loading...</div>
                    ) : (
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Financial Year</label>
                                <select
                                    value={entryFinancialYearId ?? ''}
                                    onChange={(e) => loadOpeningForYear(Number(e.target.value))}
                                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                                >
                                    <option value="">Select a financial year</option>
                                    {financialYears.map((fy) => (
                                        <option key={fy.id} value={fy.id}>
                                            {fy.year_detail}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                                <input
                                    type="number"
                                    value={openingData.quantity}
                                    onChange={(e) => handleOpeningFieldChange('quantity', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Quantity"
                                    step="0.01"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Weight</label>
                                <input
                                    type="number"
                                    value={openingData.weight}
                                    onChange={(e) => handleOpeningFieldChange('weight', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Weight"
                                    step="0.01"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Rate</label>
                                <input
                                    type="number"
                                    value={openingData.rate}
                                    onChange={(e) => handleOpeningFieldChange('rate', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Rate"
                                    step="0.01"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
                                <input
                                    type="number"
                                    value={openingData.amount}
                                    onChange={(e) => handleOpeningFieldChange('amount', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    placeholder="Enter Amount"
                                    step="0.01"
                                />
                            </div>

                            {itemOpeningEntries.length > 0 && (
                                <div className="border-t border-gray-200 pt-3">
                                    <p className="text-xs font-semibold text-gray-500 mb-2">Existing entries</p>
                                    <div className="space-y-1 max-h-32 overflow-y-auto">
                                        {itemOpeningEntries.map((entry) => (
                                            <div
                                                key={entry.id}
                                                className={`flex items-center justify-between text-sm px-2 py-1 rounded cursor-pointer ${entry.financialyear_id === entryFinancialYearId
                                                        ? 'bg-blue-50 text-blue-700'
                                                        : 'hover:bg-gray-50 text-gray-600'
                                                    }`}
                                                onClick={() => loadOpeningForYear(entry.financialyear_id)}
                                            >
                                                <span>{entry.year_detail}</span>
                                                <span className="flex items-center gap-2">
                                                    <span>Qty {entry.quantity}</span>
                                                    <button
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleOpeningDeleteEntry(entry);
                                                        }}
                                                        className="text-red-500 hover:text-red-700 text-xs"
                                                        title="Delete this entry"
                                                    >
                                                        ✕
                                                    </button>
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Modal Actions */}
                    <div className="flex justify-end space-x-3 mt-6 pt-4 border-t border-gray-200">
                        {itemOpeningEntries.some((o) => o.financialyear_id === entryFinancialYearId) && (
                            <button
                                onClick={handleOpeningDelete}
                                disabled={openingSaving}
                                className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-md transition-colors flex items-center disabled:opacity-50"
                            >
                                <img src="/src/assets/delete.png" alt="Delete" className="w-4 h-4 inline mr-1" />
                                Delete
                            </button>
                        )}
                        <button
                            onClick={closeOpeningModal}
                            disabled={openingSaving}
                            className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md transition-colors disabled:opacity-50"
                        >
                            Close
                        </button>
                        <button
                            onClick={handleOpeningSave}
                            disabled={openingSaving || openingLoading}
                            className="px-4 py-2 bg-blue-500 text-white hover:bg-blue-600 rounded-md transition-colors disabled:opacity-50"
                        >
                            {itemOpeningEntries.some((o) => o.financialyear_id === entryFinancialYearId) ? 'Update' : 'Save'}
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
}

export default ItemEntry;