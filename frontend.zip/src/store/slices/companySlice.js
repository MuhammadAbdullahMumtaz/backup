import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  companyId: null,
  companyName: null,
  financialYearId: null,
  financialYearName: null,
  currentMonth: null, 
  user: null,
  isAuthenticated: false,
};

const companySlice = createSlice({
  name: 'company',
  initialState,
  reducers: {
    setCompany: (state, action) => {
      state.companyId = action.payload.companyId;
      state.companyName = action.payload.companyName;
    },
    setFinancialYear: (state, action) => {
      state.financialYearId = action.payload.financialYearId;
      state.financialYearName = action.payload.financialYearName;
      state.currentMonth = action.payload.currentMonth || null;
      
      if (action.payload.currentMonth) {
        state.currentMonth = action.payload.currentMonth;
      }
    },
    setCurrentMonth: (state, action) => {
      state.currentMonth = action.payload;
    },
    setUser: (state, action) => {
      state.user = action.payload;
      state.isAuthenticated = true;
    },
    logout: (state) => {
      state.companyId = null;
      state.companyName = null;
      state.financialYearId = null;
      state.financialYearName = null;
      state.currentMonth = null;
      state.user = null;
      state.isAuthenticated = false;
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      localStorage.removeItem('persist:root');
    },
  },
});

export const { setCompany, setFinancialYear, setCurrentMonth, setUser, logout } = companySlice.actions;
export default companySlice.reducer;