import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import Navbar from '../components/Navbar';
import Sidebar from '../components/Sidebar';
import Company from '../features/company/Company';
import FinancialYear from '../features/financialyear/FinancialYear';
import Login from '../features/login/Login';
import ChartOfAccount from '../features/DataEntry/chartofaccount/ChartOfAccount';
import ItemEntry from '../features/DataEntry/ItemEntry/ItemEntry';
import VoucherEntry from '../features/DataEntry/VoucherEntry/VoucherEntry';

const Dashboard = () => {
  const { user } = useSelector((state) => state.company);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isNavbarOpen, setIsNavbarOpen] = useState(true);

  // 'home' | 'company' | 'financial-year' | 'login' | 'chart-of-account'
  const [activeView, setActiveView] = useState('home');

  const toggleSidebar = () => setIsSidebarOpen((prev) => !prev);
  const toggleNavbar = () => setIsNavbarOpen((prev) => !prev);

  return (
    <div className="relative min-h-screen">

      {/* Background Image */}
      <div
        className="fixed inset-0 bg-cover bg-center pointer-events-none -z-10"
        style={{
          backgroundColor: '#f9f9f9',
          backgroundImage: `repeating-linear-gradient(
    135deg,
    #e8e8e8 0px,
    #e8e8e8 2px,
    transparent 2px,
    transparent 7px
  )`,
          backgroundSize: 'auto'
        }}
      />

      <Navbar
        isOpen={isNavbarOpen}
        toggleNavbar={toggleNavbar}
        onLogoClick={() => setActiveView('home')}
        onCompanyClick={() => setActiveView('company')}
        onFinancialYearClick={() => setActiveView('financial-year')}
        onLoginClick={() => setActiveView('login')}
      />

      <Sidebar
        isOpen={isSidebarOpen}
        toggleSidebar={toggleSidebar}
        onAccountsClick={() => setActiveView('chart-of-account')}
        onItemEntryClick={() => setActiveView('item-entry')}
        onVoucherEntryClick={() => setActiveView('voucher-entry')}
      />

      {/* Main Content */}
      <div
        className={`relative z-5 transition-all duration-300 ${isSidebarOpen ? 'ml-64' : 'ml-0'
          } ${isNavbarOpen ? 'pt-16' : 'pt-0'}`}
      >
        <div className="p-5 min-h-[calc(100vh-72px)]">

          <div className="bg-white/95 rounded-xl shadow-md min-h-[calc(100vh-104px)] p-5">

            {activeView === 'company' ? (
              <Company />
            ) : activeView === 'financial-year' ? (
              <FinancialYear />
            ) : activeView === 'login' ? (
              <Login />
            ) : activeView === 'chart-of-account' ? (
              <ChartOfAccount />
            ) : activeView === 'item-entry' ? (
              <ItemEntry />
            ) : activeView === 'voucher-entry' ? (
              <VoucherEntry />
            ) : (
              <div className="flex flex-col items-center justify-center h-full py-12">

                <h2 className="text-3xl font-semibold text-gray-700 text-center">
                  Select from Sidebar to Proceed
                </h2>

                <p className="text-gray-500 mt-3 text-center">
                  Welcome{" "}
                  <span className="font-semibold">
                    {user?.username || "User"}
                  </span>
                  ! Choose an option from the sidebar to get started.
                </p>

              </div>
            )}

          </div>

        </div>
      </div>

    </div>
  );
};

export default Dashboard;