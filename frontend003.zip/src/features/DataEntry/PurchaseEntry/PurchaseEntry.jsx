import React, { useState, useEffect, useMemo, useRef } from 'react';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';
import api from '../../../services/api'

import editIcon from '../../../assets/edit.png';
import deleteIcon from '../../../assets/delete.png';

// ==========================================================================
// Mode configs - everything that differs between "Purchase Entry" and
// "Purchase Return Entry" lives here. Both modes share the exact same
// component/state/handlers below; only these values change.
// ==========================================================================
const PURCHASE_CONFIG = {
    key: 'purchase',
    title: 'Purchase Entry',
    toggleLabel: 'Purchase',
    mainApi: '/purchase-main',
    detailApi: '/purchase-detail',
    detailByMainPath: (mainId) => `/purchase-detail/purchase/${mainId}`,
    numberField: 'grn_no',      // column name on PurchaseMain
    dateField: 'grn_date',      // column name on PurchaseMain
    numberLabel: 'GRN No',
    dateLabel: 'GRN Date',
    newLabel: '+ New GRN',
    searchPlaceholder: 'New GRN',
    detailMainIdKey: 'purchasemain_id', // column name on PurchaseDetail 
    docNoun: 'purchase',
    linkedField: null
};

const PURCHASE_RETURN_CONFIG = {
    key: 'purchaseReturn',
    title: 'Purchase Return Entry',
    toggleLabel: 'Purchase Return',
    mainApi: '/purchase-return-main',
    detailApi: '/purchase-return-detail',
    detailByMainPath: (mainId) => `/purchase-return-detail/purchasereturn/${mainId}`,
    numberField: 'return_no',
    dateField: 'return_date',
    numberLabel: 'Return No',
    dateLabel: 'Return Date',
    newLabel: '+ New Return',
    searchPlaceholder: 'New Return',
    detailMainIdKey: 'purchasereturnmain_id',
    docNoun: 'purchase return',
    linkedField: 'purchase_grn',
    linkedNumberField: 'grn_no',
    linkedApi: '/purchase-main',
};

// Lookup APIs are shared between both modes - suppliers/items/sub-items
// don't change based on purchase vs. return.
const LOOKUP_API = {
    chartOfAccount: '/chart-of-account',
    itemDetail: '/item-detail',
    subItem: '/sub-item',
};

const todayStr = () => new Date().toISOString().slice(0, 10);

// dd-mm-yyyy (what the user sees) <-> yyyy-mm-dd (what the backend/DB expects)
const isoToDisplayDate = (iso) => {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    if (!y || !m || !d) return '';
    return `${d}-${m}-${y}`;
};

const displayDateToIso = (display) => {
    if (!display) return '';
    const parts = display.split('-');
    if (parts.length !== 3) return '';
    const [d, m, y] = parts;
    if (!d || !m || !y || y.length !== 4) return '';
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
};

const EMPTY_MAIN_FORM = {
    doc_date: isoToDisplayDate(todayStr()),
    gp_no: '',
    gp_date: '',
    supplier_code: '',
    invoice_no: '',
    invoice_date: isoToDisplayDate(todayStr()),
    freight: 0,
    purchase_grn: '',
};

const EMPTY_DETAIL_FORM = {
    subitem_code: '',  // transient - only used to filter the Item Name field, never sent to the backend
    Item_code: '',
    pieces: 0,
    net_weight: 0,
    rate: 0
};

// A GL code counts as "set" only if it's a non-empty, non-whitespace string.
const hasGlCode = (value) => value !== null && value !== undefined && String(value).trim() !== '';

// Focuses a field (input DOM node) and selects its text, so the next
// keystroke replaces the whole value (or a single Backspace clears it).
// Safe to call with refs pointing at plain <input> nodes or at buttons
// (buttons don't have .select(), so that part is skipped for them).
const focusAndSelect = (ref) => {
    if (!ref || !ref.current) return;
    ref.current.focus();
    if (typeof ref.current.select === 'function') {
        ref.current.select();
    }
};

// Generic "Enter moves to next field" keydown handler for plain <input>
// elements (i.e. ones that don't have their own suggestion dropdown).
const makeEnterToNext = (nextRef) => (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    focusAndSelect(nextRef);
};

// Simple searchable field - same pattern as the account search field used in
// Voucher Entry, generalized to match against any `codeKey`/`labelKey` pair.
// `onEnterNext` (optional) fires after Enter has been handled - i.e. after a
// suggestion has been picked (or, if nothing was highlighted, immediately) -
// so callers can move focus on to the next field in the form.
const SearchField = React.forwardRef(({ label, value, onChange, options, codeKey, labelKey, subLabelKey, placeholder, disabled, showAllOnFocus, onEnterNext, wide }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = term
        ? options
            .filter(
                (opt) =>
                    String(opt[labelKey] ?? '').toLowerCase().includes(term) ||
                    String(opt[codeKey] ?? '').includes(term)
            )
            .slice(0, 8)
        : (showAllOnFocus ? options.slice(0, 8) : []);

    const matched = options.find((opt) => String(opt[codeKey]) === term);

    useEffect(() => {
        setHighlightedIndex(suggestions.length > 0 ? 0 : -1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectSuggestion = (opt) => {
        onChange(String(opt[codeKey]));
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (showSuggestions && suggestions.length > 0 && highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
                selectSuggestion(suggestions[highlightedIndex]);
            } else {
                setShowSuggestions(false);
            }
            onEnterNext && onEnterNext();
            return;
        }

        if (!showSuggestions || suggestions.length === 0) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev + 1) % suggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };
    return (
        <div>
            {label && <label className="block text-xs font-medium text-gray-600 mb-0.5">{label}</label>}
            <div className="relative">
                <input
                    ref={ref}
                    type="text"
                    value={value ?? ''}
                    disabled={disabled}
                    onChange={(e) => {
                        onChange(e.target.value);
                        setShowSuggestions(true);
                    }}
                    onFocus={(e) => {
                        if ((value ?? '').toString().trim() || showAllOnFocus) setShowSuggestions(true);
                        e.target.select();
                    }}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-400"
                    placeholder={placeholder || 'Search'}
                />
                {matched && (
                    <div className="text-[11px] text-blue-800 font-bold mt-0.5 truncate px-2 py-0.5 rounded">→ {matched[labelKey]}</div>
                )}
                {showSuggestions && suggestions.length > 0 && (
                    <div className={`absolute left-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-20 ${wide ? 'w-[200%]' : 'right-0'}`}>
                        {suggestions.map((opt, index) => (
                            <div
                                key={opt[codeKey]}
                                className={`px-2.5 py-1.5 cursor-pointer text-sm flex items-center justify-between border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-100' : 'hover:bg-blue-50'}`}
                                onMouseEnter={() => setHighlightedIndex(index)}
                                onMouseDown={() => selectSuggestion(opt)}
                            >
                                <span className="font-medium">{opt[labelKey]}</span>
                                {subLabelKey && opt[subLabelKey] && (
                                    <span className="text-xs text-gray-400">{opt[subLabelKey]}</span>
                                )}
                                {codeKey !== labelKey && (
                                    <span className="text-xs font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded ml-4">
                                        {opt[codeKey]}
                                    </span>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
});

// Doc-No field that doubles as the "load an existing purchase / return"
// search. Dropdown shows Doc No / Supplier / Date in three columns, pins a
// "+ New ..." row at top. Typing filters by doc no, supplier name, OR date,
// but selecting (click / Enter) always resolves to the doc - no other
// field's value leaks into the input on selection. Fully generic over
// numberKey/dateDisplayKey so it works for both grn_no and return_no.
// `onEnterNext` (optional) fires right after Enter resolves to either the
// "+ New ..." row or a matched doc, so the caller can move focus onward.
const DocSearchField = React.forwardRef(({ value, onChange, options, onSelectExisting, onSelectNew, disabled, numberKey, newLabel, placeholder, onEnterNext }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = options
        .filter(
            (opt) =>
                String(opt[numberKey] ?? '').toLowerCase().includes(term) ||
                String(opt.supplier_name ?? '').toLowerCase().includes(term) ||
                String(opt.doc_date_display ?? '').toLowerCase().includes(term)
        )
        .slice(0, 8);

    useEffect(() => {
        setHighlightedIndex(-1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectNew = () => {
        onSelectNew();
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const selectExisting = (opt) => {
        onSelectExisting(opt);
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (!showSuggestions) {
            if (e.key === 'Enter') {
                e.preventDefault();
                onEnterNext && onEnterNext();
            }
            return;
        }
        const minIndex = -1;
        const maxIndex = suggestions.length - 1;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev >= maxIndex ? minIndex : prev + 1));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev <= minIndex ? maxIndex : prev - 1));
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightedIndex === -1) selectNew();
            else if (highlightedIndex >= 0 && highlightedIndex < suggestions.length) selectExisting(suggestions[highlightedIndex]);
            onEnterNext && onEnterNext();
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div className="relative">
            <input
                ref={ref}
                type="text"
                value={value ?? ''}
                disabled={disabled}
                onChange={(e) => {
                    onChange(e.target.value);
                    setShowSuggestions(true);
                }}
                onFocus={(e) => {
                    setShowSuggestions(true);
                    e.target.select();
                }}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                onKeyDown={handleKeyDown}
                className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-400"
                placeholder={placeholder}
            />
            {showSuggestions && (
                <div className="absolute left-0 mt-1 w-[420px] max-w-[90vw] bg-white border border-gray-200 rounded-lg shadow-lg max-h-56 overflow-y-auto z-30">
                    <div
                        className={`px-2.5 py-1.5 cursor-pointer text-sm font-semibold text-blue-600 border-b border-gray-100 ${highlightedIndex === -1 ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                        onMouseEnter={() => setHighlightedIndex(-1)}
                        onMouseDown={selectNew}
                    >
                        {newLabel}
                    </div>
                    {suggestions.map((opt, index) => (
                        <div
                            key={opt.id}
                            className={`px-2.5 py-1.5 cursor-pointer text-sm grid grid-cols-3 gap-2 border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                            onMouseEnter={() => setHighlightedIndex(index)}
                            onMouseDown={() => selectExisting(opt)}
                        >
                            <span className="font-medium truncate">{opt[numberKey]}</span>
                            <span className="text-gray-600 truncate">{opt.supplier_name}</span>
                            <span className="text-gray-400 text-xs">{opt.doc_date_display}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
});

function PurchaseEntry({ navPayload, onNavPayloadConsumed, onBack }) {
    const {
        companyId: rawCompanyId,
        financialYearId: rawFinancialYearId,
    } = useSelector((state) => state.company);

    const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== ''
        ? Number(rawCompanyId)
        : null;
    const financialYearId = rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ''
        ? Number(rawFinancialYearId)
        : null;

    // ---- Mode toggle: Purchase Entry <-> Purchase Return Entry ----
    const [mode, setMode] = useState('purchase'); // 'purchase' | 'purchaseReturn'
    const config = mode === 'purchase' ? PURCHASE_CONFIG : PURCHASE_RETURN_CONFIG;

    // ---- Main doc (Purchase / Purchase Return) ----
    const [mainForm, setMainForm] = useState(EMPTY_MAIN_FORM);
    const [mainId, setMainId] = useState(null);
    const [docNo, setDocNo] = useState('');
    const [isSavingMain, setIsSavingMain] = useState(false);

    const [existingMains, setExistingMains] = useState([]);
    const [isLoadingMains, setIsLoadingMains] = useState(false);

    const [purchaseGrns, setPurchaseGrns] = useState([]);
    const [isLoadingPurchaseGrns, setIsLoadingPurchaseGrns] = useState(false);
    const mainPurchaseGrnRef = useRef(null);

    // ---- Chart Of Account (suppliers) ----
    const [chartOfAccounts, setChartOfAccounts] = useState([]);
    const [chartOfAccountsLoaded, setChartOfAccountsLoaded] = useState(false);

    // ---- Sub Item (item sub-category, used only to narrow the Item Name search) ----
    const [subItems, setSubItems] = useState([]);
    const [subItemsLoaded, setSubItemsLoaded] = useState(false);

    // ---- Item Detail (items) ----
    const [items, setItems] = useState([]);
    const [itemsLoaded, setItemsLoaded] = useState(false);

    // ---- Details (line entries under the current main doc) ----
    const [details, setDetails] = useState([]);
    const [isLoadingDetails, setIsLoadingDetails] = useState(false);
    const [detailForm, setDetailForm] = useState(EMPTY_DETAIL_FORM);
    const [editingDetailId, setEditingDetailId] = useState(null);
    const [isSavingDetail, setIsSavingDetail] = useState(false);

    // ------Auto Entries (for the current main doc) ----
    const [showAutoEntries, setShowAutoEntries] = useState(false);
    const [autoEntries, setAutoEntries] = useState(null);
    const [isLoadingAutoEntries, setIsLoadingAutoEntries] = useState(false);

    // ---- Field refs, used purely to drive "Enter moves to the next field"
    // navigation across both the main-doc form and the detail-entry form.
    const docNoRef = useRef(null);
    const mainDateRef = useRef(null);
    const mainSupplierRef = useRef(null);
    const mainInvoiceNoRef = useRef(null);
    const mainInvoiceDateRef = useRef(null);
    const mainGpNoRef = useRef(null);
    const mainGpDateRef = useRef(null);
    const mainFreightRef = useRef(null);
    const mainSubmitRef = useRef(null);

    const itemSubRef = useRef(null);
    const itemNameRef = useRef(null);
    const piecesRef = useRef(null);
    const netWeightRef = useRef(null);
    const rateRef = useRef(null);
    const detailSubmitRef = useRef(null);

    const pendingHandledRef = useRef(false);
    const lastNavPayloadRef = useRef(null); // NEW

    // Coming from Ledger double-click: switch to the matching mode first
    // (Purchase for P/P(Auto), Purchase Return for PR/PR(Auto)).
    useEffect(() => {
        if (!navPayload?.mode) return;
        if (navPayload.mode !== mode) {
            setMode(navPayload.mode);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [navPayload]);

    // Once we're in the right mode (and its doc list has (re)loaded for it),
    // open the doc matching the number field for that mode.
    useEffect(() => {
        if (!navPayload) return;
        if (lastNavPayloadRef.current === navPayload) return; // already processed this exact payload

        const targetConfig = navPayload.mode === 'purchaseReturn' ? PURCHASE_RETURN_CONFIG : PURCHASE_CONFIG;
        if (mode !== targetConfig.key) return; // wait for the mode-switch effect + refetch above

        const targetNo = navPayload[targetConfig.numberField];
        if (!targetNo || existingMains.length === 0) return;

        const m = existingMains.find((r) => String(r[targetConfig.numberField]) === String(targetNo));
        if (m) {
            handleOpenMain(m);
            lastNavPayloadRef.current = navPayload;
            onNavPayloadConsumed && onNavPayloadConsumed();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [existingMains, navPayload, mode]);

    const fetchAutoEntries = async () => {
        if (!mainId) return;
        setIsLoadingAutoEntries(true);
        try {
            const res = await api.get(`${config.mainApi}/${mainId}/auto-entries`);
            setAutoEntries(res.data);
            setShowAutoEntries(true);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load auto entries');
        } finally {
            setIsLoadingAutoEntries(false);
        }
    };

    const fetchPurchaseGrns = async () => {
        if (!companyId || !financialYearId) return;
        setIsLoadingPurchaseGrns(true);
        try {
            const res = await api.get(`${PURCHASE_CONFIG.mainApi}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            setPurchaseGrns(
                list.filter(
                    (m) => m.entry === 'user' &&
                        Number(m.company_id) === Number(companyId) &&
                        Number(m.financialyear_id) === Number(financialYearId)
                )
            );
        } catch (error) {
            toast.error('Failed to load purchase GRNs');
        } finally {
            setIsLoadingPurchaseGrns(false);
        }
    };

    // =============================================================================
    // Lookups (shared across both modes)
    // =============================================================================
    const fetchChartOfAccounts = async () => {
        const res = await api.get(`${LOOKUP_API.chartOfAccount}/`);
        const data = res.data?.data || [];
        setChartOfAccounts(data);
        setChartOfAccountsLoaded(true);
    };
    const ensureChartOfAccountsLoaded = async () => (chartOfAccountsLoaded ? chartOfAccounts : fetchChartOfAccounts());

    const fetchSubItems = async () => {
        const res = await api.get(`${LOOKUP_API.subItem}/`);
        const data = res.data?.data || [];
        setSubItems(data);
        setSubItemsLoaded(true);
    };
    const ensureSubItemsLoaded = async () => (subItemsLoaded ? subItems : fetchSubItems());

    const fetchItems = async () => {
        const res = await api.get(`${LOOKUP_API.itemDetail}/`);
        const data = res.data?.data || res.data || [];
        setItems(Array.isArray(data) ? data : []);
        setItemsLoaded(true);
    };
    const ensureItemsLoaded = async () => (itemsLoaded ? items : fetchItems());

    const companySuppliers = useMemo(
        () => chartOfAccounts.filter((coa) => coa.company_id === companyId),
        [chartOfAccounts, companyId]
    );
    const grnOptionsForSupplier = useMemo(
        () => purchaseGrns
            .filter((g) => String(g.supplier_code) === String(mainForm.supplier_code).trim())
            .map((g) => ({
                ...g,
                grn_date_display: g.grn_date ? isoToDisplayDate(String(g.grn_date).slice(0, 10)) : '',
            })),
        [purchaseGrns, mainForm.supplier_code]
    );
    const companySubItems = useMemo(
        () => subItems.filter((si) => si.company_id === companyId),
        [subItems, companyId]
    );
    const companyItems = useMemo(
        () => items.filter((item) => item.company_id === companyId),
        [items, companyId]
    );

    // The selected sub item (by its code, as typed/picked in the Item Sub
    // field) narrows down which items show up in the Item Name field.
    const selectedSubItem = useMemo(
        () => companySubItems.find((si) => String(si.code) === String(detailForm.subitem_code).trim()),
        [companySubItems, detailForm.subitem_code]
    );
    const itemOptionsForSubItem = useMemo(
        () => (selectedSubItem
            ? companyItems.filter((item) => Number(item.subitem_id) === Number(selectedSubItem.id))
            : []),
        [companyItems, selectedSubItem]
    );

    // The item actually chosen in the Item Name field (source of truth for
    // GL validation - independent of whatever is currently typed into the
    // Item Sub filter, so this stays correct even while editing a row).
    const selectedItem = useMemo(
        () => companyItems.find((item) => String(item.code) === String(detailForm.Item_code).trim()),
        [companyItems, detailForm.Item_code]
    );
    const selectedItemSubItem = useMemo(
        () => (selectedItem
            ? companySubItems.find((si) => Number(si.id) === Number(selectedItem.subitem_id))
            : null),
        [companySubItems, selectedItem]
    );

    // Adds supplier_name + a display-formatted date to each doc, purely for
    // the DocSearchField dropdown/search - doesn't touch existingMains itself.
    const existingMainsForSearch = useMemo(
        () =>
            existingMains.map((m) => {
                const supplier = companySuppliers.find((s) => String(s.code) === String(m.supplier_code));
                const rawDate = m[config.dateField];
                return {
                    ...m,
                    supplier_name: supplier?.account_name || m.supplier_name || m.supplier_code,
                    doc_date_display: rawDate ? isoToDisplayDate(String(rawDate).slice(0, 10)) : '',
                };
            }),
        [existingMains, companySuppliers, config.dateField]
    );
    // An item can only post to the ledger if its Item Sub has a GL_purchase
    // account configured - otherwise the auto GL entry has nowhere to go
    // and the trial balance stops balancing. Same rule applies to returns,
    // which post back to the same GL_purchase account.
    const missingGlPurchase = !!selectedItem && !hasGlCode(selectedItemSubItem?.GL_purchase);

    // The GL_purchase account (from the item's Item Sub) can never be the
    // same account as the supplier/customer on the doc - the auto entry
    // would be posting an account against itself. Compare by code.
    const glPurchaseMatchesSupplier =
        !!selectedItem &&
        hasGlCode(selectedItemSubItem?.GL_purchase) &&
        String(selectedItemSubItem.GL_purchase).trim() === String(mainForm.supplier_code).trim();

    useEffect(() => {
        if (!companyId) return;
        ensureChartOfAccountsLoaded();
        ensureSubItemsLoaded();
        ensureItemsLoaded();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    useEffect(() => {
        if (!companyId) return;
        handleNewMain();
        fetchExistingMains();
        if (mode === 'purchaseReturn') fetchPurchaseGrns();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId, financialYearId, mode]);

    // =============================================================================
    // Main doc (Purchase / Purchase Return)
    // =============================================================================
    const fetchExistingMains = async () => {
        if (!companyId || !financialYearId) return;
        setIsLoadingMains(true);
        try {
            const res = await api.get(`${config.mainApi}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            const filtered = list
                .filter(
                    (m) =>
                        m.entry === 'user' &&
                        Number(m.company_id) === Number(companyId) &&
                        Number(m.financialyear_id) === Number(financialYearId)
                )
                .sort((a, b) => {
                    const numA = parseInt(String(a[config.numberField]).split('-').pop() || a[config.numberField] || '0');
                    const numB = parseInt(String(b[config.numberField]).split('-').pop() || b[config.numberField] || '0');
                    return numB - numA;
                });
            setExistingMains(filtered);
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to load ${config.docNoun}s`);
        } finally {
            setIsLoadingMains(false);
        }
    };

    const handleNewMain = () => {
        setMainId(null);
        setDocNo('');
        setMainForm(EMPTY_MAIN_FORM);
        setDetails([]);
        resetDetailForm();
    };

    const handleOpenMain = (m) => {
        setMainId(Number(m.id));
        setDocNo(m[config.numberField]);
        const rawDate = m[config.dateField];
        setMainForm({
            doc_date: rawDate ? isoToDisplayDate(String(rawDate).slice(0, 10)) : '',
            gp_no: m.gp_no || '',
            gp_date: m.gp_date ? isoToDisplayDate(String(m.gp_date).slice(0, 10)) : '',
            supplier_code: m.supplier_code || '',
            invoice_no: m.invoice_no || '',
            invoice_date: m.invoice_date ? isoToDisplayDate(String(m.invoice_date).slice(0, 10)) : '',
            freight: m.freight || 0,
            purchase_grn: m.purchase_grn || '',
        });
        resetDetailForm();
        fetchDetails(Number(m.id));
    };

    const handleSaveMain = async (e) => {
        e.preventDefault();

        if (!mainForm.doc_date) {
            toast.error(`Please select a ${config.dateLabel.toLowerCase()}`);
            return;
        }
        if (!mainForm.supplier_code) {
            toast.error('Please select a supplier');
            return;
        }
        if (mainForm.gp_no && !mainForm.gp_date) {
            toast.error('GP date is required when GP number is entered');
            return;
        }
        if (mainForm.gp_date && !mainForm.gp_no) {
            toast.error('GP number is required when GP date is entered');
            return;
        }
        if (!financialYearId) {
            toast.error('No financial year selected');
            return;
        }

        const docDateIso = displayDateToIso(mainForm.doc_date);
        const invoiceDateIso = displayDateToIso(mainForm.invoice_date);
        const gpDateIso = mainForm.gp_date ? displayDateToIso(mainForm.gp_date) : null;

        if (!docDateIso) {
            toast.error(`${config.dateLabel} must be in dd-mm-yyyy format`);
            return;
        }
        if (!invoiceDateIso) {
            toast.error('Invoice date must be in dd-mm-yyyy format');
            return;
        }

        setIsSavingMain(true);
        try {
            if (mainId) {
                await api.put(`${config.mainApi}/${mainId}`, {
                    company_id: companyId,
                    financialyear_id: financialYearId,
                    [config.numberField]: docNo,
                    [config.dateField]: docDateIso,
                    gp_no: mainForm.gp_no || null,
                    gp_date: gpDateIso,
                    supplier_code: mainForm.supplier_code,
                    invoice_no: mainForm.invoice_no.trim(),
                    invoice_date: invoiceDateIso,
                    freight: mainForm.freight || 0,
                    ...(config.linkedField ? { [config.linkedField]: mainForm.purchase_grn || null } : {}),
                });
                toast.success(`${config.title.replace(' Entry', '')} updated`);
            } else {
                const res = await api.post(`${config.mainApi}/`, {
                    company_id: companyId,
                    financialyear_id: financialYearId,
                    [config.dateField]: docDateIso,
                    gp_no: mainForm.gp_no || null,
                    gp_date: gpDateIso,
                    supplier_code: mainForm.supplier_code,
                    invoice_no: mainForm.invoice_no.trim(),
                    invoice_date: invoiceDateIso,
                    freight: mainForm.freight || 0,
                    ...(config.linkedField ? { [config.linkedField]: mainForm.purchase_grn || null } : {}),
                });
                const newId = Number(res.data?.id);
                const assignedNo = res.data?.[config.numberField];
                setMainId(newId);
                setDocNo(assignedNo);
                toast.success(`${config.numberLabel} #${assignedNo} created`);
            }
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to save ${config.docNoun}`);
        } finally {
            setIsSavingMain(false);
        }
    };

    const handleDeleteMain = async () => {
        if (!mainId) return;
        if (!window.confirm(`Delete ${config.docNoun} "${docNo}" and all of its entries?`)) return;
        try {
            const res = await api.get(config.detailByMainPath(mainId));
            const list = Array.isArray(res.data) ? res.data : [];
            for (const d of list) {
                // eslint-disable-next-line no-await-in-loop
                await api.delete(`${config.detailApi}/${d.id}`);
            }
            await api.delete(`${config.mainApi}/${mainId}`);
            toast.success(`${config.title.replace(' Entry', '')} deleted`);
            handleNewMain();
            await fetchExistingMains();
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to delete ${config.docNoun}`);
        }
    };

    // =============================================================================
    // Details
    // =============================================================================
    const fetchDetails = async (id) => {
        setIsLoadingDetails(true);
        try {
            const res = await api.get(config.detailByMainPath(id));
            const list = Array.isArray(res.data) ? res.data : [];
            setDetails(list.sort((a, b) => a.entry_no - b.entry_no));
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load entries');
        } finally {
            setIsLoadingDetails(false);
        }
    };

    const resetDetailForm = () => {
        setDetailForm(EMPTY_DETAIL_FORM);
        setEditingDetailId(null);
    };

    // Same as resetDetailForm, but keeps the previously used Item Sub in
    // place - most entries in a doc share the same Item Sub, so after a
    // save we leave it pre-filled (and selected, via focusAndSelect) so the
    // user can just keep typing to move on, or hit Backspace to change it.
    const resetDetailFormKeepSubitem = () => {
        setDetailForm((prev) => ({ ...EMPTY_DETAIL_FORM, subitem_code: prev.subitem_code }));
        setEditingDetailId(null);
    };

    const handleEditDetailRow = (row) => {
        // Reverse-lookup which Item Sub this item belongs to, purely so the
        // Item Sub field shows something sensible while editing.
        const item = companyItems.find((i) => String(i.code) === String(row.Item_code));
        const subitem = item ? companySubItems.find((si) => Number(si.id) === Number(item.subitem_id)) : null;

        setEditingDetailId(row.id);
        setDetailForm({
            subitem_code: subitem ? subitem.code : '',
            Item_code: row.Item_code ?? '',
            pieces: row.pieces || 0,
            net_weight: row.net_weight || 0,
            rate: row.rate || 0,
        });
    };

    // Live preview of amount/gst/further-tax/total for the entry being
    // typed - purely informational, the backend recomputes the authoritative
    // values on save.
    const detailPreview = useMemo(() => {
        const netWeight = Number(detailForm.net_weight) || 0;
        const rate = Number(detailForm.rate) || 0;

        const amount = netWeight * rate;
        return { amount, total: amount };
    }, [detailForm]);

    const detailsTotals = useMemo(() => {
        return details.reduce(
            (acc, row) => {
                acc.amount += Number(row.amount) || 0;
                acc.gst_amount += Number(row.gst_amount) || 0;
                acc.total += Number(row.total) || 0;
                return acc;
            },
            { amount: 0, gst_amount: 0, total: 0 }
        );
    }, [details]);

    const handleSaveDetail = async (e) => {
        e.preventDefault();

        if (!mainId) {
            toast.error(`Save the ${config.docNoun} details first`);
            return;
        }
        if (!detailForm.Item_code) {
            toast.error('Select or enter an item');
            return;
        }

        // Guard: an item whose Item Sub has no GL_purchase account has
        // nowhere for the auto GL entry to post to, which would leave the
        // trial balance out of balance. Block the save instead of letting
        // it through silently.
        const itemForSave = companyItems.find((item) => String(item.code) === String(detailForm.Item_code).trim());
        const subItemForSave = itemForSave
            ? companySubItems.find((si) => Number(si.id) === Number(itemForSave.subitem_id))
            : null;

        if (!hasGlCode(subItemForSave?.GL_purchase)) {
            toast.error(
                'This item\'s Item Sub has no GL Purchase account set. Assign a GL Purchase account to it before adding this entry, otherwise the trial balance will not balance.'
            );
            return;
        }

        // Guard: the GL_purchase account can't be the same account as the
        // supplier on this doc - posting an account against itself would be
        // invalid, so block the entry.
        if (String(subItemForSave.GL_purchase).trim() === String(mainForm.supplier_code).trim()) {
            toast.error(
                "Entry can't be made: this item's GL Purchase account is the same as the supplier account."
            );
            return;
        }

        const nextEntryNo = editingDetailId
            ? details.find((d) => d.id === editingDetailId)?.entry_no
            : (details.length > 0 ? Math.max(...details.map((d) => d.entry_no)) + 1 : 1);

        // amount, gst_amount, further_tax_amount, and total are all computed
        // server-side from these inputs - the frontend doesn't send them.
        const payload = {
            company_id: companyId,
            [config.detailMainIdKey]: mainId,
            Item_code: detailForm.Item_code,
            entry_no: nextEntryNo,
            pieces: detailForm.pieces || 0,
            net_weight: detailForm.net_weight || 0,
            rate: detailForm.rate || 0,
        };
        if (config.linkedField) {
            payload[config.linkedField] = mainForm.purchase_grn || null;
        }

        setIsSavingDetail(true);
        try {
            if (editingDetailId) {
                await api.put(`${config.detailApi}/${editingDetailId}`, payload);
                toast.success('Entry updated');
            } else {
                await api.post(`${config.detailApi}/`, payload);
                toast.success('Entry added');
            }
            resetDetailFormKeepSubitem();
            await fetchDetails(mainId);
            focusAndSelect(itemSubRef);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save entry');
        } finally {
            setIsSavingDetail(false);
        }
    };

    const handleDeleteDetail = async (row) => {
        if (!window.confirm(`Delete entry #${row.entry_no}?`)) return;
        try {
            await api.delete(`${config.detailApi}/${row.id}`);
            toast.success('Entry deleted');
            await fetchDetails(mainId);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete entry');
        }
    };

    // =============================================================================
    // Mode toggle
    // =============================================================================
    const handleToggleMode = (nextMode) => {
        if (nextMode === mode) return;
        setMode(nextMode);
        // handleNewMain() + fetchExistingMains() run automatically via the
        // [companyId, financialYearId, mode] effect above.
    };

    // =============================================================================
    // Print
    // =============================================================================
    // Opens a plain print dialog with just the doc header (number, customer,
    // date) and the line entries (Sr, Item name, weight, rate, amount) -
    // nothing else is shown on the printed page.
    const handlePrint = () => {
        if (!mainId) return;

        const supplier = companySuppliers.find((s) => String(s.code) === String(mainForm.supplier_code));
        const supplierName = supplier?.account_name || mainForm.supplier_code || '';

        const escapeHtml = (val) =>
            String(val ?? '').replace(/[&<>"']/g, (c) => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
            }[c]));

        const rowsHtml = details.map((row, idx) => `
            <tr>
                <td>${idx + 1}</td>
                <td>${escapeHtml(row.item_name || row.Item_code)}</td>
                <td class="num">${escapeHtml(row.net_weight)}</td>
                <td class="num">${escapeHtml(row.rate)}</td>
                <td class="num">${escapeHtml(Number(row.total ?? row.amount ?? 0).toFixed(2))}</td>
            </tr>
        `).join('');

        const totalAmount = details.reduce((sum, row) => sum + (Number(row.total ?? row.amount) || 0), 0);

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8" />
                <style>
                    * { box-sizing: border-box; }
                    body { font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #111; padding: 24px; }
                    .header { display: flex; justify-content: space-between; margin-bottom: 4px; }
                    .header div { flex: 1; }
                    .header .label { color: #555; font-size: 11px; }
                    .header .value { font-weight: 600; font-size: 14px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 16px; }
                    th, td { border: 1px solid #999; padding: 5px 8px; font-size: 12px; }
                    th { background: #f0f0f0; text-align: left; }
                    td.num, th.num { text-align: right; }
                    tfoot td { font-weight: 700; background: #f7f7f7; }
                    @media print {
                        body { padding: 0; }
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <div><div class="label">${escapeHtml(config.numberLabel)}</div><div class="value">${escapeHtml(docNo)}</div></div>
                    <div><div class="label">Customer</div><div class="value">${escapeHtml(supplierName)}</div></div>
                    <div><div class="label">${escapeHtml(config.dateLabel)}</div><div class="value">${escapeHtml(mainForm.doc_date)}</div></div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th style="width:40px;">Sr.</th>
                            <th>Item Name</th>
                            <th class="num">Weight</th>
                            <th class="num">Rate</th>
                            <th class="num">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsHtml || '<tr><td colspan="5" style="text-align:center;color:#888;">No entries</td></tr>'}
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" style="text-align:right;">Total</td>
                            <td class="num">${totalAmount.toFixed(2)}</td>
                        </tr>
                    </tfoot>
                </table>
            </body>
            </html>
        `;

        const printWindow = window.open('', '_blank', 'width=850,height=650');
        if (!printWindow) {
            toast.error('Please allow pop-ups to print');
            return;
        }
        printWindow.document.open();
        printWindow.document.write(html);
        printWindow.document.close();
        printWindow.focus();
        printWindow.onload = () => {
            printWindow.print();
        };
    };

    // =============================================================================
    // Render
    // =============================================================================
    return (
        <>
            <div className="bg-gray-50 p-4">
                {onBack && (
                    <button
                        type="button"
                        onClick={onBack}
                        className="mb-2 flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700"
                    >
                        ← Back to Ledger
                    </button>
                )}

                <div className="flex items-center justify-between mb-2">
                    <h1 className="text-xl font-bold text-gray-800">{config.title}</h1>

                    {/* Purchase / Purchase Return toggle */}
                    <div className="inline-flex rounded-lg border border-gray-300 bg-white p-0.5 text-sm">
                        {[PURCHASE_CONFIG, PURCHASE_RETURN_CONFIG].map((c) => {
                            const isActive = mode === c.key;
                            const isReturnTab = c.key === PURCHASE_RETURN_CONFIG.key;
                            return (
                                <button
                                    key={c.key}
                                    type="button"
                                    onClick={() => handleToggleMode(c.key)}
                                    className={`px-3 py-1 rounded-md font-medium transition-colors ${isActive
                                        ? isReturnTab
                                            ? 'bg-red-500 text-white shadow-sm'
                                            : 'bg-blue-500 text-white shadow-sm'
                                        : 'text-gray-600 hover:bg-gray-100'
                                        }`}
                                >
                                    {c.toggleLabel}
                                </button>
                            );
                        })}
                    </div>
                </div>

                <div className="max-w-6xl mx-auto">
                    {!companyId ? (
                        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 text-center text-gray-500 text-sm">
                            No company context found. Please select a company first.
                        </div>
                    ) : (
                        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">

                            {/* Main form - Doc No lives in row 1 alongside the rest of the header fields */}
                            <form onSubmit={handleSaveMain} className="pb-3 mb-3">
                                <div className={`grid grid-cols-2 gap-2 mb-2 ${mode === 'purchaseReturn' ? 'sm:grid-cols-7' : 'sm:grid-cols-6'}`}>
                                    <div>
                                        <div className="flex items-center justify-between mb-0.5">
                                            <label className="block text-xs font-medium text-gray-600">{config.numberLabel}</label>
                                            <div className="flex items-center gap-2">
                                                {mainId && (
                                                    <button
                                                        type="button"
                                                        onClick={fetchAutoEntries}
                                                        title="View auto GL entries"
                                                        className="hover:opacity-70 text-sm"
                                                    >
                                                        🧾
                                                    </button>
                                                )}
                                                {mainId && (
                                                    <button
                                                        type="button"
                                                        onClick={handlePrint}
                                                        title={`Print ${config.docNoun}`}
                                                        className="hover:opacity-70 text-sm"
                                                    >
                                                        🖨️
                                                    </button>
                                                )}
                                                {mainId && (
                                                    <button type="button" onClick={handleDeleteMain} title={`Delete this ${config.docNoun}`} className="hover:opacity-70">
                                                        <img src={deleteIcon} alt="Delete" className="w-3.5 h-3.5" />
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                        <DocSearchField
                                            ref={docNoRef}
                                            value={docNo}
                                            onChange={(val) => setDocNo(val)}
                                            options={existingMainsForSearch}
                                            numberKey={config.numberField}
                                            newLabel={config.newLabel}
                                            placeholder={config.searchPlaceholder}
                                            onSelectExisting={(m) => handleOpenMain(m)}
                                            onSelectNew={() => handleNewMain()}
                                            onEnterNext={() => focusAndSelect(mainDateRef)}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-medium text-gray-600 mb-0.5">{config.dateLabel}</label>
                                        <input
                                            ref={mainDateRef}
                                            type="text"
                                            value={mainForm.doc_date}
                                            onChange={(e) => setMainForm({ ...mainForm, doc_date: e.target.value })}
                                            onFocus={(e) => e.target.select()}
                                            onKeyDown={makeEnterToNext(mainSupplierRef)}
                                            placeholder="dd-mm-yyyy"
                                            className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                        />
                                    </div>
                                    <div className="sm:col-span-2">
                                        <SearchField
                                            ref={mainSupplierRef}
                                            label="Supplier"
                                            value={mainForm.supplier_code}
                                            onChange={(val) => setMainForm({ ...mainForm, supplier_code: val })}
                                            options={companySuppliers}
                                            codeKey="code"
                                            labelKey="account_name"
                                            placeholder="Search supplier"
                                            onEnterNext={() => focusAndSelect(mode === 'purchaseReturn' ? mainPurchaseGrnRef : mainInvoiceNoRef)}
                                        />
                                    </div>
                                    {mode === 'purchaseReturn' && (
                                        <div className="sm:col-span-1">
                                            <SearchField
                                                ref={mainPurchaseGrnRef}
                                                label="Purchase GRN"
                                                value={mainForm.purchase_grn}
                                                onChange={(val) => setMainForm({ ...mainForm, purchase_grn: val })}
                                                options={grnOptionsForSupplier}
                                                codeKey="grn_no"
                                                labelKey="grn_no"
                                                subLabelKey="grn_date_display"
                                                wide
                                                placeholder={mainForm.supplier_code ? 'Search GRN' : 'Pick supplier first'}
                                                disabled={!mainForm.supplier_code}
                                                showAllOnFocus
                                                onEnterNext={() => focusAndSelect(mainInvoiceNoRef)}
                                            />
                                        </div>
                                    )}
                                    <div>
                                        <label className="block text-xs font-medium text-gray-600 mb-0.5">Invoice No</label>
                                        <input
                                            ref={mainInvoiceNoRef}
                                            type="text"
                                            value={mainForm.invoice_no}
                                            onChange={(e) => setMainForm({ ...mainForm, invoice_no: e.target.value })}
                                            onFocus={(e) => e.target.select()}
                                            onKeyDown={makeEnterToNext(mainInvoiceDateRef)}
                                            className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-medium text-gray-600 mb-0.5">Invoice Date</label>
                                        <input
                                            ref={mainInvoiceDateRef}
                                            type="text"
                                            value={mainForm.invoice_date}
                                            onChange={(e) => setMainForm({ ...mainForm, invoice_date: e.target.value })}
                                            onFocus={(e) => e.target.select()}
                                            onKeyDown={makeEnterToNext(mainGpNoRef)}
                                            placeholder="dd-mm-yyyy"
                                            className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                        />
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
                                    <div>
                                        <label className="block text-xs font-medium text-gray-600 mb-0.5">GP No</label>
                                        <input
                                            ref={mainGpNoRef}
                                            type="text"
                                            value={mainForm.gp_no}
                                            onChange={(e) => setMainForm({ ...mainForm, gp_no: e.target.value })}
                                            onFocus={(e) => e.target.select()}
                                            onKeyDown={makeEnterToNext(mainGpDateRef)}
                                            className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-medium text-gray-600 mb-0.5">GP Date</label>
                                        <input
                                            ref={mainGpDateRef}
                                            type="text"
                                            value={mainForm.gp_date}
                                            onChange={(e) => setMainForm({ ...mainForm, gp_date: e.target.value })}
                                            onFocus={(e) => e.target.select()}
                                            onKeyDown={makeEnterToNext(mainFreightRef)}
                                            placeholder="dd-mm-yyyy"
                                            className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                        />
                                    </div>
                                    <div className="sm:col-span-2" />
                                    <div>
                                        <label className="block text-xs font-medium text-gray-600 mb-0.5">Freight</label>
                                        <input
                                            ref={mainFreightRef}
                                            type="number"
                                            value={mainForm.freight}
                                            onChange={(e) => setMainForm({ ...mainForm, freight: e.target.value })}
                                            onFocus={(e) => e.target.select()}
                                            onKeyDown={makeEnterToNext(mainSubmitRef)}
                                            min="0"
                                            step="0.01"
                                            className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                        />
                                    </div>
                                    <div className="flex items-end">
                                        <button
                                            ref={mainSubmitRef}
                                            type="submit"
                                            disabled={isSavingMain}
                                            className={`w-full px-4 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 ${mode === PURCHASE_RETURN_CONFIG.key
                                                ? 'bg-red-500 hover:bg-red-600'
                                                : 'bg-blue-500 hover:bg-blue-600'
                                                }`}
                                        >
                                            {isSavingMain ? 'Saving...' : mainId ? 'Update' : 'Create'}
                                        </button>
                                    </div>
                                </div>
                            </form>

                            {/* Detail entries - only once the main doc exists */}
                            {mainId && (
                                <>
                                    <div className="border-t border-gray-200 pt-3 mb-3">
                                        <h3 className="text-sm font-semibold text-gray-700 mb-2">
                                            {editingDetailId ? 'Edit Entry' : 'Add Entry'}
                                        </h3>
                                        <form onSubmit={handleSaveDetail} className="space-y-2">
                                            <div className="grid grid-cols-8 gap-2 items-end">
                                                <div className="col-span-1">
                                                    <SearchField
                                                        ref={itemSubRef}
                                                        label="Item Sub"
                                                        value={detailForm.subitem_code}
                                                        onChange={(val) => setDetailForm({ ...detailForm, subitem_code: val, Item_code: '' })}
                                                        options={companySubItems}
                                                        codeKey="code"
                                                        labelKey="details"
                                                        placeholder="Search"
                                                        showAllOnFocus
                                                        onEnterNext={() => focusAndSelect(itemNameRef)}
                                                    />
                                                </div>

                                                <div className="col-span-2">
                                                    <SearchField
                                                        ref={itemNameRef}
                                                        label="Item Name"
                                                        value={detailForm.Item_code}
                                                        onChange={(val) => setDetailForm({ ...detailForm, Item_code: val })}
                                                        options={itemOptionsForSubItem}
                                                        codeKey="code"
                                                        labelKey="details"
                                                        placeholder={selectedSubItem ? 'Search item' : 'Pick item sub first'}
                                                        disabled={!selectedSubItem}
                                                        showAllOnFocus
                                                        onEnterNext={() => focusAndSelect(piecesRef)}
                                                    />
                                                    {missingGlPurchase && (
                                                        <div className="text-[11px] text-red-600 font-semibold mt-1">
                                                            ⚠ No GL Purchase account is set for this item's Item Sub. Assign one before this entry can be added.
                                                        </div>
                                                    )}
                                                    {!missingGlPurchase && glPurchaseMatchesSupplier && (
                                                        <div className="text-[11px] text-red-600 font-semibold mt-1">
                                                            ⚠ This item's GL Purchase account is the same as the supplier account. Entry can't be made.
                                                        </div>
                                                    )}
                                                </div>

                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Pieces</label>
                                                    <input
                                                        ref={piecesRef}
                                                        type="number"
                                                        value={detailForm.pieces}
                                                        onChange={(e) => setDetailForm({ ...detailForm, pieces: e.target.value })}
                                                        onFocus={(e) => e.target.select()}
                                                        onKeyDown={makeEnterToNext(netWeightRef)}
                                                        min="0"
                                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                    />
                                                </div>

                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Net Weight</label>
                                                    <input
                                                        ref={netWeightRef}
                                                        type="number"
                                                        value={detailForm.net_weight}
                                                        onChange={(e) => setDetailForm({ ...detailForm, net_weight: e.target.value })}
                                                        onFocus={(e) => e.target.select()}
                                                        onKeyDown={makeEnterToNext(rateRef)}
                                                        min="0"
                                                        step="0.01"
                                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                    />
                                                </div>

                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Rate</label>
                                                    <input
                                                        ref={rateRef}
                                                        type="number"
                                                        value={detailForm.rate}
                                                        onChange={(e) => setDetailForm({ ...detailForm, rate: e.target.value })}
                                                        onFocus={(e) => e.target.select()}
                                                        onKeyDown={makeEnterToNext(detailSubmitRef)}
                                                        min="0"
                                                        step="0.01"
                                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                    />
                                                </div>

                                                <div className="col-span-1">
                                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Total</label>
                                                    <input
                                                        type="text"
                                                        value={detailPreview.total.toFixed(2)}
                                                        disabled
                                                        className="w-full px-2 py-1.5 border border-gray-200 bg-gray-50 rounded-md text-sm text-right text-gray-600"
                                                    />
                                                </div>

                                                <div className="col-span-1">
                                                    <button
                                                        ref={detailSubmitRef}
                                                        type="submit"
                                                        disabled={isSavingDetail || missingGlPurchase || glPurchaseMatchesSupplier}
                                                        title={
                                                            missingGlPurchase
                                                                ? "This item's Item Sub has no GL Purchase account set"
                                                                : glPurchaseMatchesSupplier
                                                                    ? "This item's GL Purchase account is the same as the supplier account"
                                                                    : undefined
                                                        }
                                                        className={`w-full px-3 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 disabled:cursor-not-allowed ${mode === PURCHASE_RETURN_CONFIG.key
                                                            ? 'bg-red-500 hover:bg-red-600'
                                                            : 'bg-blue-500 hover:bg-blue-600'
                                                            }`}
                                                    >
                                                        {isSavingDetail ? 'Saving...' : editingDetailId ? 'Update' : 'Save'}
                                                    </button>
                                                    {editingDetailId && (
                                                        <button
                                                            type="button"
                                                            onClick={resetDetailForm}
                                                            title="Cancel edit"
                                                            className="text-sm text-gray-500 hover:text-gray-700 ml-1"
                                                        >
                                                            ✕
                                                        </button>
                                                    )}
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    {/* Entries table */}
                                    <div className="border-t border-gray-200 pt-3">
                                        <h3 className="text-sm font-semibold text-gray-700 mb-2">Entries</h3>
                                        {isLoadingDetails ? (
                                            <div className="text-xs text-gray-400 py-3 text-center">Loading...</div>
                                        ) : details.length === 0 ? (
                                            <div className="text-xs text-gray-400 py-3 text-center">No entries yet</div>
                                        ) : (
                                            <div className="overflow-x-auto border border-gray-200 rounded-lg">
                                                <table className="min-w-full divide-y divide-gray-200 text-sm">
                                                    <thead className="bg-gray-50">
                                                        <tr>
                                                            <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Entry No</th>
                                                            <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Item</th>
                                                            <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Pieces</th>
                                                            <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Net Weight</th>
                                                            <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Rate</th>
                                                            <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Total</th>
                                                            <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="bg-white divide-y divide-gray-100">
                                                        {details.map((row) => (
                                                            <tr key={row.id} className="hover:bg-gray-50">
                                                                <td className="px-2.5 py-1.5 text-gray-600">{row.entry_no}</td>
                                                                <td className="px-2.5 py-1.5 text-gray-800">{row.item_name || row.Item_code}</td>
                                                                <td className="px-2.5 py-1.5 text-right text-gray-800">{row.pieces}</td>
                                                                <td className="px-2.5 py-1.5 text-right text-gray-800">{row.net_weight}</td>
                                                                <td className="px-2.5 py-1.5 text-right text-gray-800">{row.rate}</td>
                                                                <td className="px-2.5 py-1.5 text-right text-gray-800 font-semibold">{row.total}</td>
                                                                <td className="px-2.5 py-1.5">
                                                                    <div className="flex items-center justify-end gap-2">
                                                                        <button onClick={() => handleEditDetailRow(row)} title="Edit">
                                                                            <img src={editIcon} alt="Edit" className="w-4 h-4" />
                                                                        </button>
                                                                        <button onClick={() => handleDeleteDetail(row)} title="Delete">
                                                                            <img src={deleteIcon} alt="Delete" className="w-4 h-4" />
                                                                        </button>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                    <tfoot className="bg-gray-50 border-t-2 border-gray-200">
                                                        <tr>
                                                            <td className="px-2.5 py-1.5 font-semibold text-gray-700" colSpan={5}>
                                                                Total
                                                            </td>
                                                            <td className="px-2.5 py-1.5 text-right font-semibold text-gray-800">
                                                                {detailsTotals.total.toFixed(2)}
                                                            </td>
                                                            <td className="px-2.5 py-1.5"></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        )}
                                    </div>
                                </>
                            )}
                        </div>
                    )}
                </div>
            </div>

            {showAutoEntries && (
                <div
                    className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4"
                    onClick={() => setShowAutoEntries(false)}
                >
                    <div
                        className="bg-white rounded-xl shadow-lg max-w-4xl w-full max-h-[85vh] overflow-y-auto p-5"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex items-center justify-between mb-3">
                            <h2 className="text-lg font-bold text-gray-800">
                                Auto GL Entries - {config.numberLabel} {autoEntries?.[config.numberField]}
                            </h2>
                            <button
                                onClick={() => setShowAutoEntries(false)}
                                className="text-gray-400 hover:text-gray-700 text-xl leading-none"
                            >
                                ✕
                            </button>
                        </div>

                        {isLoadingAutoEntries ? (
                            <div className="text-sm text-gray-400 text-center py-6">Loading...</div>
                        ) : !autoEntries || autoEntries.groups.length === 0 ? (
                            <div className="text-sm text-gray-400 text-center py-6">No auto entries generated yet.</div>
                        ) : (
                            autoEntries.groups.map((g) => (
                                <div key={g.id} className="border border-gray-200 rounded-lg mb-4 overflow-hidden">
                                    <div className="bg-gray-50 px-3 py-2 flex flex-wrap gap-x-6 gap-y-1 text-sm">
                                        <span>
                                            <span className="text-gray-500">GL Account:</span>{' '}
                                            <span className="font-semibold">{g.supplier_name || g.supplier_code}</span>{' '}
                                            <span className="text-gray-400">({g.supplier_code})</span>
                                        </span>
                                        <span><span className="text-gray-500">Invoice:</span> {g.invoice_no}</span>
                                        <span>
                                            <span className="text-gray-500">Total:</span>{' '}
                                            <span className="font-semibold">{g.totals.total.toFixed(2)}</span>
                                        </span>
                                    </div>
                                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                                        <thead className="bg-white">
                                            <tr>
                                                <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Item</th>
                                                <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Amount</th>
                                                <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">GST</th>
                                                <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Further Tax</th>
                                                <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Total</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-100">
                                            {g.details.map((d) => (
                                                <tr key={d.id}>
                                                    <td className="px-2.5 py-1.5">{d.item_name || d.Item_code}</td>
                                                    <td className="px-2.5 py-1.5 text-right">{Number(d.amount).toFixed(2)}</td>
                                                    <td className="px-2.5 py-1.5 text-right">{Number(d.gst_amount).toFixed(2)}</td>
                                                    <td className="px-2.5 py-1.5 text-right">{Number(d.further_tax_amount).toFixed(2)}</td>
                                                    <td className="px-2.5 py-1.5 text-right font-semibold">{Number(d.total).toFixed(2)}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}
        </>
    );
}

export default PurchaseEntry;