import React, { useState, useEffect, useMemo, useRef } from 'react';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';
import api from '../../../services/api'

import editIcon from '../../../assets/edit.png';
import deleteIcon from '../../../assets/delete.png';

// Sale-mode and Return-mode endpoints are identical in shape, just
// different base paths + a different FK field name on the detail table.
const ENDPOINTS = {
    sale: {
        main: '/sales-main',
        detail: '/sales-detail',
        mainIdField: 'sale_main',      // FK field name expected by SalesDetail payload
    },
    return: {
        main: '/sales-return-main',
        detail: '/sales-return-detail',
        mainIdField: 'sales_return_main',
        linkedField: 'sales_invoice',
    },
};

const LOOKUP_API = {
    chartOfAccount: '/chart-of-account',
    itemDetail: '/item-detail',
    subItem: '/sub-item',
};

const todayStr = () => new Date().toISOString().slice(0, 10);

// dd-mm-yyyy (what the user sees) <-> yyyy-mm-dd (what the backend/DB expects)
const isoToDisplayDate = (iso) => {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    if (!y || !m || !d) return '';
    return `${d}-${m}-${y}`;
};

const displayDateToIso = (display) => {
    if (!display) return '';
    const parts = display.split('-');
    if (parts.length !== 3) return '';
    const [d, m, y] = parts;
    if (!d || !m || !y || y.length !== 4) return '';
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
};

const dbDateToIso = (raw) => {
    if (!raw) return '';
    const str = String(raw);
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str; // already plain, no shift risk
    const d = new Date(raw);
    if (isNaN(d.getTime())) return str.slice(0, 10);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
};

const EMPTY_MAIN_FORM = {
    gp_no: '',
    gp_date: '',
    po_no: '',
    po_date: '',
    invoice_date: isoToDisplayDate(todayStr()),
    builty_no: '',
    customer_code: '',
    freight: 0,
    sales_invoice: '',
};

const EMPTY_DETAIL_FORM = {
    subitem_code: '',
    Item_code: '',
    pieces: 0,
    net_weight: 0,
    rate: 0,
    freight: 0,
};

// A GL code counts as "set" only if it's a non-empty, non-whitespace string.
const hasGlCode = (value) => value !== null && value !== undefined && String(value).trim() !== '';

// A rate counts as "entered" only if it's a positive number - the Rate
// field is mandatory, so 0/blank/negative all block the save.
const hasRate = (value) => value !== null && value !== undefined && value !== '' && Number(value) > 0;

// Pulls the trailing numeric run out of an invoice/GRN-style code, e.g.
// "INV-2026-00042" -> 42, so a purely numeric, sequence-aware sort can be
// done instead of a lexical or date-based one (mirrors the GRN No sort
// used in Purchase Entry).
const trailingNumber = (code) => {
    const match = String(code ?? '').match(/(\d+)(?!.*\d)/);
    return match ? parseInt(match[1], 10) : NaN;
};

// Focuses a field (input DOM node) and selects its text, so the next
// keystroke replaces the whole value (or a single Backspace clears it).
// Safe to call with refs pointing at plain <input> nodes or at buttons
// (buttons don't have .select(), so that part is skipped for them).
const focusAndSelect = (ref) => {
    if (!ref || !ref.current) return;
    ref.current.focus();
    if (typeof ref.current.select === 'function') {
        ref.current.select();
    }
};

// Generic "Enter moves to next field" keydown handler for plain <input>
// elements (i.e. ones that don't have their own suggestion dropdown).
const makeEnterToNext = (nextRef) => (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    focusAndSelect(nextRef);
};

// Simple searchable field - same pattern as the account search field used in
// Voucher Entry / Purchase Entry, generalized to match against any
// `codeKey`/`labelKey` pair. `onEnterNext` (optional) fires after Enter has
// been handled - i.e. after a suggestion has been picked (or, if nothing
// was highlighted, immediately) - so callers can move focus on to the next
// field in the form.
const SearchField = React.forwardRef(({ label, value, onChange, options, codeKey, labelKey, subLabelKey, placeholder, disabled, showAllOnFocus, onEnterNext, wide }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = term
        ? options
            .filter(
                (opt) =>
                    String(opt[labelKey] ?? '').toLowerCase().includes(term) ||
                    String(opt[codeKey] ?? '').includes(term)
            )
            .slice(0, 8)
        : (showAllOnFocus ? options.slice(0, 8) : []);

    const matched = options.find((opt) => String(opt[codeKey]) === term);

    useEffect(() => {
        setHighlightedIndex(suggestions.length > 0 ? 0 : -1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectSuggestion = (opt) => {
        onChange(String(opt[codeKey]));
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (showSuggestions && suggestions.length > 0 && highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
                selectSuggestion(suggestions[highlightedIndex]);
            } else {
                setShowSuggestions(false);
            }
            onEnterNext && onEnterNext();
            return;
        }

        if (!showSuggestions || suggestions.length === 0) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev + 1) % suggestions.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div>
            {label && <label className="block text-xs font-medium text-gray-600 mb-0.5">{label}</label>}
            <div className="relative">
                <input
                    ref={ref}
                    type="text"
                    value={value ?? ''}
                    disabled={disabled}
                    onChange={(e) => {
                        onChange(e.target.value);
                        setShowSuggestions(true);
                    }}
                    onFocus={(e) => {
                        if ((value ?? '').toString().trim() || showAllOnFocus) setShowSuggestions(true);
                        e.target.select();
                    }}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    onKeyDown={handleKeyDown}
                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-400"
                    placeholder={placeholder || 'Search'}
                />
                {matched && (
                    <div className="text-[11px] text-blue-800 font-bold mt-0.5 truncate px-2 py-0.5 rounded">→ {matched[labelKey]}</div>
                )}
                {showSuggestions && suggestions.length > 0 && (
                    <div className={`absolute left-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-20 ${wide ? 'w-[200%]' : 'right-0'}`}>
                        {suggestions.map((opt, index) => (
                            <div
                                key={opt[codeKey]}
                                className={`px-2.5 py-1.5 cursor-pointer text-sm flex items-center justify-between border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-100' : 'hover:bg-blue-50'}`}
                                onMouseEnter={() => setHighlightedIndex(index)}
                                onMouseDown={() => selectSuggestion(opt)}
                            >
                                <span className="font-medium">{opt[labelKey]}</span>
                                {subLabelKey && opt[subLabelKey] && (
                                    <span className="text-xs text-gray-400">{opt[subLabelKey]}</span>
                                )}
                                {codeKey !== labelKey && (
                                    <span className="text-xs font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded ml-4">
                                        {opt[codeKey]}
                                    </span>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
});

// Doc-No field that doubles as the "load an existing sale / return" search.
// `onEnterNext` (optional) fires right after Enter resolves to either the
// "+ New ..." row or a matched doc, so the caller can move focus onward.
const DocSearchField = React.forwardRef(({ value, onChange, options, onSelectExisting, onSelectNew, disabled, numberKey, newLabel, placeholder, onEnterNext }, ref) => {
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [highlightedIndex, setHighlightedIndex] = useState(-1);

    const term = (value ?? '').toString().trim().toLowerCase();
    const suggestions = options
        .filter(
            (opt) =>
                String(opt[numberKey] ?? '').toLowerCase().includes(term) ||
                String(opt.customer_name ?? '').toLowerCase().includes(term) ||
                String(opt.doc_date_display ?? '').toLowerCase().includes(term)
        )
        .slice(0, 8);

    useEffect(() => {
        setHighlightedIndex(-1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [term, options.length, showSuggestions]);

    const selectNew = () => {
        onSelectNew();
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const selectExisting = (opt) => {
        onSelectExisting(opt);
        setShowSuggestions(false);
        setHighlightedIndex(-1);
    };

    const handleKeyDown = (e) => {
        if (!showSuggestions) {
            if (e.key === 'Enter') {
                e.preventDefault();
                onEnterNext && onEnterNext();
            }
            return;
        }
        const minIndex = -1;
        const maxIndex = suggestions.length - 1;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev >= maxIndex ? minIndex : prev + 1));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setHighlightedIndex((prev) => (prev <= minIndex ? maxIndex : prev - 1));
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (highlightedIndex === -1) selectNew();
            else if (highlightedIndex >= 0 && highlightedIndex < suggestions.length) selectExisting(suggestions[highlightedIndex]);
            onEnterNext && onEnterNext();
        } else if (e.key === 'Escape') {
            setShowSuggestions(false);
        }
    };

    return (
        <div className="relative">
            <input
                ref={ref}
                type="text"
                value={value ?? ''}
                disabled={disabled}
                onChange={(e) => {
                    onChange(e.target.value);
                    setShowSuggestions(true);
                }}
                onFocus={(e) => {
                    setShowSuggestions(true);
                    e.target.select();
                }}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                onKeyDown={handleKeyDown}
                className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-400"
                placeholder={placeholder}
            />
            {showSuggestions && (
                <div className="absolute left-0 mt-1 w-[420px] max-w-[90vw] bg-white border border-gray-200 rounded-lg shadow-lg max-h-56 overflow-y-auto z-30">
                    <div
                        className={`px-2.5 py-1.5 cursor-pointer text-sm font-semibold text-blue-600 border-b border-gray-100 ${highlightedIndex === -1 ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                        onMouseEnter={() => setHighlightedIndex(-1)}
                        onMouseDown={selectNew}
                    >
                        {newLabel}
                    </div>
                    {suggestions.map((opt, index) => (
                        <div
                            key={opt.id}
                            className={`px-2.5 py-1.5 cursor-pointer text-sm grid grid-cols-3 gap-2 border-b border-gray-100 last:border-0 ${index === highlightedIndex ? 'bg-blue-50' : 'hover:bg-blue-50'}`}
                            onMouseEnter={() => setHighlightedIndex(index)}
                            onMouseDown={() => selectExisting(opt)}
                        >
                            <span className="font-medium truncate">{opt[numberKey]}</span>
                            <span className="text-gray-600 truncate">{opt.customer_name}</span>
                            <span className="text-gray-400 text-xs">{opt.doc_date_display}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
});

function SalesEntry({ navPayload, onNavPayloadConsumed, onBack }) {
    const {
        companyId: rawCompanyId,
        financialYearId: rawFinancialYearId,
    } = useSelector((state) => state.company);

    const companyId = rawCompanyId !== null && rawCompanyId !== undefined && rawCompanyId !== ''
        ? Number(rawCompanyId)
        : null;
    const financialYearId = rawFinancialYearId !== null && rawFinancialYearId !== undefined && rawFinancialYearId !== ''
        ? Number(rawFinancialYearId)
        : null;

    // ---- Mode toggle: Sale vs Sale Return ----
    // Everything below reads from `api = ENDPOINTS[isReturn ? 'return' : 'sale']`
    // rather than a hardcoded API object, so the same component/state drives
    // both tables. Flipping the toggle always resets to "new" (see
    // handleToggleReturn) so a half-loaded Sale can never get PUT to the
    // Return endpoint or vice versa.
    const [isReturn, setIsReturn] = useState(false);
    const endpoints = isReturn ? ENDPOINTS.return : ENDPOINTS.sale;

    // ---- Sales/Return Main ----
    const [mainForm, setMainForm] = useState(EMPTY_MAIN_FORM);
    const [salesMainId, setSalesMainId] = useState(null);
    const [isSavingMain, setIsSavingMain] = useState(false);

    const [existingSales, setExistingSales] = useState([]);
    const [isLoadingSales, setIsLoadingSales] = useState(false);

    // ---- Chart Of Account (customers) ----
    const [chartOfAccounts, setChartOfAccounts] = useState([]);
    const [chartOfAccountsLoaded, setChartOfAccountsLoaded] = useState(false);

    // ---- Sub Item (item sub-category, used only to narrow the Item Name search) ----
    const [subItems, setSubItems] = useState([]);
    const [subItemsLoaded, setSubItemsLoaded] = useState(false);

    // ---- Item Detail (items) ----
    const [items, setItems] = useState([]);
    const [itemsLoaded, setItemsLoaded] = useState(false);

    // ---- Detail lines (line entries under the current Main) ----
    const [details, setDetails] = useState([]);
    const [isLoadingDetails, setIsLoadingDetails] = useState(false);
    const [detailForm, setDetailForm] = useState(EMPTY_DETAIL_FORM);
    const [editingDetailId, setEditingDetailId] = useState(null);
    const [isSavingDetail, setIsSavingDetail] = useState(false);

    const [showAutoEntries, setShowAutoEntries] = useState(false);
    const [autoEntries, setAutoEntries] = useState(null);
    const [isLoadingAutoEntries, setIsLoadingAutoEntries] = useState(false);

    const [salesInvoices, setSalesInvoices] = useState([]);
    const [isLoadingSalesInvoices, setIsLoadingSalesInvoices] = useState(false);
    const salesInvoiceRef = useRef(null);

    const [availableLots, setAvailableLots] = useState([]);
    const [isLoadingLots, setIsLoadingLots] = useState(false);

    const [showStockDetails, setShowStockDetails] = useState(false);

    useEffect(() => {
        setShowStockDetails(false);
    }, [detailForm.Item_code]);

    // ---- Field refs, used purely to drive "Enter moves to the next field"
    // navigation across both the main-doc form and the detail-entry form.
    const invoiceNoRef = useRef(null);
    const billDateRef = useRef(null);
    const customerRef = useRef(null);
    const gpNoRef = useRef(null);
    const gpDateRef = useRef(null);
    const freightRef = useRef(null);
    const poNoRef = useRef(null);
    const poDateRef = useRef(null);
    const builtyNoRef = useRef(null);
    const mainSubmitRef = useRef(null);

    const itemSubRef = useRef(null);
    const itemNameRef = useRef(null);
    const piecesRef = useRef(null);
    const netWeightRef = useRef(null);
    const rateRef = useRef(null);
    const detailSubmitRef = useRef(null);

    const fetchAutoEntries = async () => {
        if (!salesMainId) return;
        setIsLoadingAutoEntries(true);
        try {
            const res = await api.get(`${endpoints.main}/${salesMainId}/auto-entries`);
            setAutoEntries(res.data);
            setShowAutoEntries(true);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load auto entries');
        } finally {
            setIsLoadingAutoEntries(false);
        }
    };

    const pendingHandledRef = useRef(false);
    const lastNavPayloadRef = useRef(null);

    const [invoiceNo, setInvoiceNo] = useState('');

    // Coming from Ledger double-click: switch to the matching mode first
    // (Sale for S/S(Auto), Sale Return for SR/SR(Auto)).
    useEffect(() => {
        if (!navPayload?.mode) return;
        const shouldBeReturn = navPayload.mode === 'return';
        if (shouldBeReturn !== isReturn) {
            setIsReturn(shouldBeReturn);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [navPayload]);

    // Once we're in the right mode (and its list has (re)loaded for it),
    // open the sale/return matching invoice_no.
    useEffect(() => {
        if (!navPayload) return;
        if (lastNavPayloadRef.current === navPayload) return; // already processed this exact payload

        const targetIsReturn = navPayload.mode === 'return';
        if (isReturn !== targetIsReturn) return; // wait for the mode-switch effect + refetch above

        const targetInvoice = navPayload.invoice_no;
        if (!targetInvoice || existingSales.length === 0) return;

        const sm = existingSales.find((s) => String(s.invoice_no) === String(targetInvoice));
        if (sm) {
            handleOpenSale(sm);
            lastNavPayloadRef.current = navPayload;
            onNavPayloadConsumed && onNavPayloadConsumed();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [existingSales, navPayload, isReturn]);

    useEffect(() => {
        const fetchLots = async () => {
            if (!detailForm.Item_code || !companyId) {
                setAvailableLots([]);
                return;
            }
            setIsLoadingLots(true);
            try {
                const res = await api.get('/sales-detail/available-stock', {
                    params: { company_id: companyId, item_code: detailForm.Item_code },
                });
                setAvailableLots(res.data || []);
            } catch {
                setAvailableLots([]);
            } finally {
                setIsLoadingLots(false);
            }
        };
        fetchLots();
    }, [detailForm.Item_code, companyId, salesMainId]);

    useEffect(() => {
        if (!companyId) return;
        fetchExistingSales();
        handleNewSale();
        if (isReturn) fetchSalesInvoices();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId, financialYearId, isReturn]);


    const fetchSalesInvoices = async () => {
        if (!companyId || !financialYearId) return;
        setIsLoadingSalesInvoices(true);
        try {
            const res = await api.get(`${ENDPOINTS.sale.main}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            setSalesInvoices(
                list.filter(
                    (sm) => sm.entry === 'user' &&
                        Number(sm.company_id) === Number(companyId) &&
                        Number(sm.financialyear_id) === Number(financialYearId)
                )
            );
        } catch {
            toast.error('Failed to load sales invoices');
        } finally {
            setIsLoadingSalesInvoices(false);
        }
    };

    // =============================================================================
    // Lookups (shared between Sale and Return modes)
    // =============================================================================
    const fetchChartOfAccounts = async () => {
        const res = await api.get(`${LOOKUP_API.chartOfAccount}/`);
        const data = res.data?.data || [];
        setChartOfAccounts(data);
        setChartOfAccountsLoaded(true);
    };
    const ensureChartOfAccountsLoaded = async () => (chartOfAccountsLoaded ? chartOfAccounts : fetchChartOfAccounts());

    const fetchSubItems = async () => {
        const res = await api.get(`${LOOKUP_API.subItem}/`);
        const data = res.data?.data || [];
        setSubItems(data);
        setSubItemsLoaded(true);
    };
    const ensureSubItemsLoaded = async () => (subItemsLoaded ? subItems : fetchSubItems());

    const fetchItems = async () => {
        const res = await api.get(`${LOOKUP_API.itemDetail}/`);
        const data = res.data?.data || res.data || [];
        setItems(Array.isArray(data) ? data : []);
        setItemsLoaded(true);
    };
    const ensureItemsLoaded = async () => (itemsLoaded ? items : fetchItems());

    const companyCustomers = useMemo(
        () => chartOfAccounts.filter((coa) => coa.company_id === companyId),
        [chartOfAccounts, companyId]
    );
    const invoiceOptionsForCustomer = useMemo(
        () => salesInvoices
            .filter((s) => String(s.customer_code) === String(mainForm.customer_code).trim())
            .map((s) => ({
                ...s,
                invoice_date_display: s.invoice_date ? isoToDisplayDate(dbDateToIso(s.invoice_date)) : '',
            })),
        [salesInvoices, mainForm.customer_code]
    );
    const companySubItems = useMemo(
        () => subItems.filter((si) => si.company_id === companyId),
        [subItems, companyId]
    );
    const companyItems = useMemo(
        () => items.filter((item) => item.company_id === companyId),
        [items, companyId]
    );

    const selectedSubItem = useMemo(
        () => companySubItems.find((si) => String(si.code) === String(detailForm.subitem_code).trim()),
        [companySubItems, detailForm.subitem_code]
    );
    const itemOptionsForSubItem = useMemo(
        () => (selectedSubItem
            ? companyItems.filter((item) => Number(item.subitem_id) === Number(selectedSubItem.id))
            : []),
        [companyItems, selectedSubItem]
    );

    const selectedItem = useMemo(
        () => companyItems.find((item) => String(item.code) === String(detailForm.Item_code).trim()),
        [companyItems, detailForm.Item_code]
    );
    const selectedItemSubItem = useMemo(
        () => (selectedItem
            ? companySubItems.find((si) => Number(si.id) === Number(selectedItem.subitem_id))
            : null),
        [companySubItems, selectedItem]
    );

    const lotAllocationPreview = useMemo(() => {
        const requested = Number(detailForm.net_weight) || 0;
        let remaining = requested;
        return availableLots.map((lot) => {
            const take = remaining > 0 ? Math.min(lot.remaining_net_weight, remaining) : 0;
            remaining -= take;
            return { ...lot, taken: take, willUse: take > 0 };
        });
    }, [availableLots, detailForm.net_weight]);

    const totalAvailable = useMemo(
        () => availableLots.reduce((s, l) => s + Number(l.remaining_net_weight), 0),
        [availableLots]
    );

    const existingSalesForSearch = useMemo(
        () =>
            existingSales.map((sm) => {
                const customer = companyCustomers.find((c) => String(c.code) === String(sm.customer_code));
                return {
                    ...sm,
                    customer_name: customer?.account_name || sm.customer_name || sm.customer_code,
                    doc_date_display: sm.invoice_date ? isoToDisplayDate(dbDateToIso(sm.invoice_date)) : '',
                };
            }),
        [existingSales, companyCustomers]
    );
    const insufficientStock = (Number(detailForm.net_weight) || 0) > totalAvailable;
    // Same GL_sale requirement applies to returns - the auto entry still
    // needs somewhere to post to (a return just posts opposite of a sale).
    const missingGlSale = !!selectedItem && !hasGlCode(selectedItemSubItem?.GL_sale);

    // The GL_sale account (from the item's Item Sub) can never be the same
    // account as the customer on this doc - the auto entry would be posting
    // an account against itself. Compare by code.
    const glSaleMatchesCustomer =
        !!selectedItem &&
        hasGlCode(selectedItemSubItem?.GL_sale) &&
        String(selectedItemSubItem.GL_sale).trim() === String(mainForm.customer_code).trim();


    useEffect(() => {
        if (!companyId) return;
        ensureChartOfAccountsLoaded();
        ensureSubItemsLoaded();
        ensureItemsLoaded();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [companyId]);

    // =============================================================================
    // Toggle handler
    // =============================================================================
    const handleToggleReturn = () => {
        // Reset everything main-side; the effect above will refetch the list
        // and prefill a fresh "next number" for whichever mode we land on.
        setIsReturn((prev) => !prev);
    };

    // =============================================================================
    // Main (Sale / Return)
    // =============================================================================
    const fetchExistingSales = async () => {
        if (!companyId || !financialYearId) return;
        setIsLoadingSales(true);
        try {
            const res = await api.get(`${endpoints.main}/`);
            const list = Array.isArray(res.data) ? res.data : [];
            const filtered = list
                .filter(
                    (sm) =>
                        sm.entry === "user" &&
                        Number(sm.company_id) === Number(companyId) &&
                        Number(sm.financialyear_id) === Number(financialYearId)
                )
                .sort((a, b) => {
                    const numA = trailingNumber(a.invoice_no);
                    const numB = trailingNumber(b.invoice_no);
                    if (!Number.isNaN(numA) && !Number.isNaN(numB) && numA !== numB) {
                        return numB - numA;
                    }
                    return new Date(b.invoice_date) - new Date(a.invoice_date);
                });
            setExistingSales(filtered);
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to load ${isReturn ? 'sale returns' : 'sales'}`);
        } finally {
            setIsLoadingSales(false);
        }
    };

    const fetchNextInvoiceNumber = async () => {
        if (!companyId || !financialYearId) return '';
        try {
            const res = await api.get(`${endpoints.main}/next/${companyId}/${financialYearId}`);
            const next = res.data?.next_invoice_number;
            return next !== undefined && next !== null ? String(next) : '';
        } catch (error) {
            return '';
        }
    };

    const handleNewSale = async () => {
        setSalesMainId(null);
        setInvoiceNo('');
        setDetails([]);
        resetDetailForm();
        setMainForm({ ...EMPTY_MAIN_FORM });
    };

    const handleOpenSale = (sm) => {
        setSalesMainId(Number(sm.id));
        setInvoiceNo(sm.invoice_no || '');
        setMainForm({
            gp_no: sm.gp_no || '',
            gp_date: sm.gp_date ? isoToDisplayDate(dbDateToIso(sm.gp_date)) : '',
            po_no: sm.po_no || '',
            po_date: sm.po_date ? isoToDisplayDate(dbDateToIso(sm.po_date)) : '',
            invoice_date: sm.invoice_date ? isoToDisplayDate(dbDateToIso(sm.invoice_date)) : '',
            builty_no: sm.builty_no || '',
            customer_code: sm.customer_code || '',
            freight: sm.freight || 0,
            sales_invoice: sm.sales_invoice || '',
        });
        resetDetailForm();
        fetchSalesDetails(Number(sm.id));
    };

    const handleSaveMain = async (e) => {
        e.preventDefault();
        if (!mainForm.customer_code) {
            toast.error('Please select a customer');
            return;
        }
        if (!mainForm.invoice_date) {
            toast.error('Please select an invoice date');
            return;
        }
        if (mainForm.gp_no && !mainForm.gp_date) {
            toast.error('GP date is required when GP number is entered');
            return;
        }
        if (mainForm.gp_date && !mainForm.gp_no) {
            toast.error('GP number is required when GP date is entered');
            return;
        }
        if (mainForm.po_no && !mainForm.po_date) {
            toast.error('PO date is required when PO number is entered');
            return;
        }
        if (mainForm.po_date && !mainForm.po_no) {
            toast.error('PO number is required when PO date is entered');
            return;
        }
        if (!financialYearId) {
            toast.error('No financial year selected');
            return;
        }

        const invoiceDateIso = displayDateToIso(mainForm.invoice_date);
        const gpDateIso = mainForm.gp_date ? displayDateToIso(mainForm.gp_date) : null;
        const poDateIso = mainForm.po_date ? displayDateToIso(mainForm.po_date) : null;

        if (!invoiceDateIso) {
            toast.error('Invoice date must be in dd-mm-yyyy format');
            return;
        }

        const payload = {
            company_id: companyId,
            financialyear_id: financialYearId,
            gp_no: mainForm.gp_no || null,
            gp_date: gpDateIso,
            po_no: mainForm.po_no || null,
            po_date: poDateIso,
            invoice_date: invoiceDateIso,
            builty_no: mainForm.builty_no || null,
            customer_code: mainForm.customer_code,
            freight: mainForm.freight || 0,
        };
        if (isReturn) {
            payload.sales_invoice = mainForm.sales_invoice || null;
        }
        if (salesMainId) {
            payload.invoice_no = invoiceNo; // only send/allow edit on update, like grn_no
        }

        setIsSavingMain(true);
        try {
            if (salesMainId) {
                await api.put(`${endpoints.main}/${salesMainId}`, payload);
                toast.success(isReturn ? 'Sale return updated' : 'Sale updated');
            } else {
                const res = await api.post(`${endpoints.main}/`, payload);
                const newId = Number(res.data?.id);
                const assignedInvoiceNo = res.data?.invoice_no || '';
                setSalesMainId(newId);
                setInvoiceNo(assignedInvoiceNo);
                toast.success(
                    isReturn
                        ? `Sale return created (Invoice ${assignedInvoiceNo})`
                        : `Sale created (Invoice ${assignedInvoiceNo})`
                );
            }
            await fetchExistingSales();
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to save ${isReturn ? 'sale return' : 'sale'}`);
        } finally {
            setIsSavingMain(false);
        }
    };

    const handleDeleteSale = async () => {
        if (!salesMainId) return;
        const label = isReturn ? 'sale return' : 'sale';
        if (!window.confirm(`Delete ${label} for invoice "${invoiceNo}" and all of its entries?`)) return;
        try {
            const res = await api.get(`${endpoints.detail}/${isReturn ? 'return' : 'sale'}/${salesMainId}`);
            const list = Array.isArray(res.data) ? res.data : [];
            for (const d of list) {
                // eslint-disable-next-line no-await-in-loop
                await api.delete(`${endpoints.detail}/${d.id}`);
            }
            await api.delete(`${endpoints.main}/${salesMainId}`);
            toast.success(isReturn ? 'Sale return deleted' : 'Sale deleted');
            await handleNewSale();
            await fetchExistingSales();
        } catch (error) {
            toast.error(error?.response?.data?.message || `Failed to delete ${label}`);
        }
    };

    // =============================================================================
    // Details
    // =============================================================================
    const fetchSalesDetails = async (mainId) => {
        setIsLoadingDetails(true);
        try {
            const res = await api.get(`${endpoints.detail}/${isReturn ? 'return' : 'sale'}/${mainId}`);
            const list = Array.isArray(res.data) ? res.data : [];
            setDetails(list.sort((a, b) => a.entry_no - b.entry_no));
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to load entries');
        } finally {
            setIsLoadingDetails(false);
        }
    };

    const resetDetailForm = () => {
        setDetailForm(EMPTY_DETAIL_FORM);
        setEditingDetailId(null);
    };

    // Same as resetDetailForm, but keeps the previously used Item Sub in
    // place - most entries in a doc share the same Item Sub, so after a
    // save we leave it pre-filled (and selected, via focusAndSelect) so the
    // user can just keep typing to move on, or hit Backspace to change it.
    const resetDetailFormKeepSubitem = () => {
        setDetailForm((prev) => ({ ...EMPTY_DETAIL_FORM, subitem_code: prev.subitem_code }));
        setEditingDetailId(null);
    };

    const handleEditDetailRow = (row) => {
        const item = companyItems.find((i) => String(i.code) === String(row.Item_code));
        const subitem = item ? companySubItems.find((si) => Number(si.id) === Number(item.subitem_id)) : null;

        setEditingDetailId(row.id);
        setDetailForm({
            subitem_code: subitem ? subitem.code : '',
            Item_code: row.Item_code ?? '',
            pieces: row.pieces || 0,
            net_weight: row.net_weight || 0,
            rate: row.rate || 0,
        });
    };

    const detailPreview = useMemo(() => {
        const netWeight = Number(detailForm.net_weight) || 0;
        const rate = Number(detailForm.rate) || 0;
        const amount = netWeight * rate;
        return { netWeight, amount, total: amount };
    }, [detailForm]);

    const detailsTotals = useMemo(() => {
        return details.reduce(
            (acc, row) => {
                acc.amount += Number(row.amount) || 0;
                acc.total += Number(row.total) || 0;
                return acc;
            },
            { amount: 0, total: 0 }
        );
    }, [details]);

    const handleSaveDetail = async (e) => {
        e.preventDefault();

        if (!salesMainId) {
            toast.error(`Save the ${isReturn ? 'return' : 'sale'} details first`);
            return;
        }
        if (!detailForm.Item_code) {
            toast.error('Select or enter an item');
            return;
        }

        // Rate is mandatory - block the save until it's entered.
        if (!hasRate(detailForm.rate)) {
            toast.error('Rate is required');
            return;
        }

        const itemForSave = companyItems.find((item) => String(item.code) === String(detailForm.Item_code).trim());
        const subItemForSave = itemForSave
            ? companySubItems.find((si) => Number(si.id) === Number(itemForSave.subitem_id))
            : null;

        if (insufficientStock) {
            toast.error('Not enough stock for this item.');
            return;
        }

        if (!hasGlCode(subItemForSave?.GL_sale)) {
            toast.error(
                'This item\'s Item Sub has no GL Sale account set. Assign a GL Sale account to it before adding this entry, otherwise the trial balance will not balance.'
            );
            return;
        }

        // Guard: the GL_sale account can't be the same account as the
        // customer on this doc - posting an account against itself would be
        // invalid, so block the entry.
        if (String(subItemForSave.GL_sale).trim() === String(mainForm.customer_code).trim()) {
            toast.error(
                "Entry can't be made: this item's GL Sale account is the same as the customer account."
            );
            return;
        }

        const nextEntryNo = editingDetailId
            ? details.find((d) => d.id === editingDetailId)?.entry_no
            : (details.length > 0 ? Math.max(...details.map((d) => d.entry_no)) + 1 : 1);

        // amount, gst_amount, further_tax_amount, and total are all computed
        // server-side from these inputs - the frontend doesn't send them.
        // The FK field name (sale_main vs sales_return_main) is the one
        // thing that actually differs between the two payload shapes.
        const payload = {
            company_id: companyId,
            [endpoints.mainIdField]: salesMainId,
            Item_code: detailForm.Item_code,
            entry_no: nextEntryNo,
            pieces: detailForm.pieces || 0,
            net_weight: detailForm.net_weight || 0,
            rate: detailForm.rate || 0,
        };

        setIsSavingDetail(true);
        try {
            if (editingDetailId) {
                const { data } = await api.put(`${endpoints.detail}/${editingDetailId}`, payload);
                toast.success('Entry updated');
                (data.warnings || []).forEach((w) => toast.warn(w));
            } else {
                const { data } = await api.post(`${endpoints.detail}/`, payload);
                if (data.entriesCreated > 1) {
                    toast.success(`${data.entriesCreated} entries were created (item split across ${data.entriesCreated} purchase lots).`);
                } else {
                    toast.success('Entry added');
                }
                (data.warnings || []).forEach((w) => toast.warn(w));
            }
            resetDetailFormKeepSubitem();
            await fetchSalesDetails(salesMainId);
            focusAndSelect(itemSubRef);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to save entry');
        } finally {
            setIsSavingDetail(false);
        }
    };

    const handleDeleteDetail = async (row) => {
        if (!window.confirm(`Delete entry #${row.entry_no}?`)) return;
        try {
            await api.delete(`${endpoints.detail}/${row.id}`);
            toast.success('Entry deleted');
            await fetchSalesDetails(salesMainId);
        } catch (error) {
            toast.error(error?.response?.data?.message || 'Failed to delete entry');
        }
    };

    // =============================================================================
    // Print
    // =============================================================================
    // Opens a plain print dialog with just the doc header (bill/return no,
    // customer, date) and the line entries (Sr, Item name, weight, rate,
    // amount) - nothing else is shown on the printed page.
    const handlePrint = () => {
        if (!salesMainId) return;

        const customer = companyCustomers.find((c) => String(c.code) === String(mainForm.customer_code));
        const customerName = customer?.account_name || mainForm.customer_code || '';

        const escapeHtml = (val) =>
            String(val ?? '').replace(/[&<>"']/g, (c) => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
            }[c]));

        const rowsHtml = details.map((row, idx) => `
            <tr>
                <td>${idx + 1}</td>
                <td>${escapeHtml(row.item_name || row.Item_code)}</td>
                <td class="num">${escapeHtml(row.net_weight)}</td>
                <td class="num">${escapeHtml(row.rate)}</td>
                <td class="num">${escapeHtml(Number(row.total ?? row.amount ?? 0).toFixed(2))}</td>
            </tr>
        `).join('');

        const totalAmount = details.reduce((sum, row) => sum + (Number(row.total ?? row.amount) || 0), 0);

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8" />
                <style>
                    * { box-sizing: border-box; }
                    body { font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #111; padding: 24px; }
                    .header { display: flex; justify-content: space-between; margin-bottom: 4px; }
                    .header div { flex: 1; }
                    .header .label { color: #555; font-size: 11px; }
                    .header .value { font-weight: 600; font-size: 14px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 16px; }
                    th, td { border: 1px solid #999; padding: 5px 8px; font-size: 12px; }
                    th { background: #f0f0f0; text-align: left; }
                    td.num, th.num { text-align: right; }
                    tfoot td { font-weight: 700; background: #f7f7f7; }
                    @media print {
                        body { padding: 0; }
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <div><div class="label">${isReturn ? 'Return Bill No' : 'Bill No'}</div><div class="value">${escapeHtml(invoiceNo)}</div></div>
                    <div><div class="label">Customer</div><div class="value">${escapeHtml(customerName)}</div></div>
                    <div><div class="label">Bill Date</div><div class="value">${escapeHtml(mainForm.invoice_date)}</div></div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th style="width:40px;">Sr.</th>
                            <th>Item Name</th>
                            <th class="num">Weight</th>
                            <th class="num">Rate</th>
                            <th class="num">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsHtml || '<tr><td colspan="5" style="text-align:center;color:#888;">No entries</td></tr>'}
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" style="text-align:right;">Total</td>
                            <td class="num">${totalAmount.toFixed(2)}</td>
                        </tr>
                    </tfoot>
                </table>
            </body>
            </html>
        `;

        const printWindow = window.open('', '_blank', 'width=850,height=650');
        if (!printWindow) {
            toast.error('Please allow pop-ups to print');
            return;
        }
        printWindow.document.open();
        printWindow.document.write(html);
        printWindow.document.close();
        printWindow.focus();
        printWindow.onload = () => {
            printWindow.print();
        };
    };

    // =============================================================================
    // Render
    // =============================================================================
    return (
        <div className="bg-gray-50 p-3">
            {onBack && (
                <button
                    type="button"
                    onClick={onBack}
                    className="mb-2 flex items-center gap-1 text-sm font-medium text-blue-600 hover:text-blue-700"
                >
                    ← Back to Ledger
                </button>
            )}

            <div className="flex items-center justify-between mb-2">
                <h1 className="text-xl font-bold text-gray-800">
                    {isReturn ? 'Sales Return Entry' : 'Sales Entry'}
                </h1>

                {/* Sale / Sale Return toggle */}
                <div className="inline-flex rounded-lg border border-gray-300 bg-white p-0.5 text-sm">
                    <button
                        type="button"
                        onClick={() => isReturn && handleToggleReturn()}
                        className={`px-3 py-1 rounded-md font-medium transition-colors ${!isReturn
                            ? 'bg-blue-500 text-white shadow-sm'
                            : 'text-gray-600 hover:bg-gray-100'
                            }`}
                    >
                        Sale
                    </button>
                    <button
                        type="button"
                        onClick={() => !isReturn && handleToggleReturn()}
                        className={`px-3 py-1 rounded-md font-medium transition-colors ${isReturn
                            ? 'bg-red-500 text-white shadow-sm'
                            : 'text-gray-600 hover:bg-gray-100'
                            }`}
                    >
                        Sale Return
                    </button>
                </div>
            </div>

            <div className="max-w-6xl mx-auto">
                {!companyId ? (
                    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 text-center text-gray-500 text-sm">
                        No company context found. Please select a company first.
                    </div>
                ) : (
                    <div className={`bg-white rounded-xl shadow-sm border p-4 ${isReturn ? 'border-red-200' : 'border-gray-200'}`}>

                        {/* Main form */}
                        <form onSubmit={handleSaveMain} className="pb-3 mb-3">
                            <div className={`grid grid-cols-2 sm:grid-cols-4 gap-2 mb-2 ${isReturn ? 'lg:grid-cols-8' : 'lg:grid-cols-7'}`}>
                                <div>
                                    <div className="flex items-center justify-between mb-0.5">
                                        <label className="block text-xs font-medium text-gray-600">
                                            {isReturn ? 'Return Bill No' : 'Bill No'}
                                        </label>
                                        <div className="flex items-center gap-2">
                                            {salesMainId && (
                                                <button
                                                    type="button"
                                                    onClick={fetchAutoEntries}
                                                    title="View auto GL entries"
                                                    className="hover:opacity-70 text-sm"
                                                >
                                                    🧾
                                                </button>
                                            )}
                                            {salesMainId && (
                                                <button
                                                    type="button"
                                                    onClick={handlePrint}
                                                    title={isReturn ? 'Print this return' : 'Print this sale'}
                                                    className="hover:opacity-70 text-sm"
                                                >
                                                    🖨️
                                                </button>
                                            )}
                                            {salesMainId && (
                                                <button
                                                    type="button"
                                                    onClick={handleDeleteSale}
                                                    title={isReturn ? 'Delete this return' : 'Delete this sale'}
                                                    className="hover:opacity-70"
                                                >
                                                    <img src={deleteIcon} alt="Delete" className="w-3.5 h-3.5" />
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                    <DocSearchField
                                        ref={invoiceNoRef}
                                        value={invoiceNo}
                                        onChange={(val) => setInvoiceNo(val)}
                                        options={existingSalesForSearch}
                                        numberKey="invoice_no"
                                        newLabel="+ New Invoice"
                                        placeholder="New Bill"
                                        onSelectExisting={(sm) => handleOpenSale(sm)}
                                        onSelectNew={() => handleNewSale()}
                                        onEnterNext={() => focusAndSelect(billDateRef)}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Bill Date</label>
                                    <input
                                        ref={billDateRef}
                                        type="text"
                                        value={mainForm.invoice_date}
                                        onChange={(e) => setMainForm({ ...mainForm, invoice_date: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(customerRef)}
                                        placeholder="dd-mm-yyyy"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div className="col-span-2">
                                    <SearchField
                                        ref={customerRef}
                                        label="Customer"
                                        value={mainForm.customer_code}
                                        onChange={(val) => setMainForm({ ...mainForm, customer_code: val })}
                                        options={companyCustomers}
                                        codeKey="code"
                                        labelKey="account_name"
                                        placeholder="Search customer"
                                        showAllOnFocus
                                        onEnterNext={() => focusAndSelect(isReturn ? salesInvoiceRef : gpNoRef)}
                                    />
                                </div>
                                {isReturn && (
                                    <div className="col-span-1">
                                        <SearchField
                                            ref={salesInvoiceRef}
                                            label="Sales Invoice"
                                            value={mainForm.sales_invoice}
                                            onChange={(val) => setMainForm({ ...mainForm, sales_invoice: val })}
                                            options={invoiceOptionsForCustomer}
                                            codeKey="invoice_no"
                                            labelKey="invoice_no"
                                            subLabelKey="invoice_date_display"
                                            wide
                                            placeholder={mainForm.customer_code ? 'Search invoice' : 'Pick customer first'}
                                            disabled={!mainForm.customer_code}
                                            showAllOnFocus
                                            onEnterNext={() => focusAndSelect(gpNoRef)}
                                        />
                                    </div>
                                )}
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">GP No</label>
                                    <input
                                        ref={gpNoRef}
                                        type="text"
                                        value={mainForm.gp_no}
                                        onChange={(e) => setMainForm({ ...mainForm, gp_no: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(gpDateRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">GP Date</label>
                                    <input
                                        ref={gpDateRef}
                                        type="text"
                                        value={mainForm.gp_date}
                                        onChange={(e) => setMainForm({ ...mainForm, gp_date: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(freightRef)}
                                        placeholder="dd-mm-yyyy"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Freight</label>
                                    <input
                                        ref={freightRef}
                                        type="number"
                                        value={mainForm.freight}
                                        onChange={(e) => setMainForm({ ...mainForm, freight: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(poNoRef)}
                                        min="0"
                                        step="0.01"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 mb-2">
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">PO No</label>
                                    <input
                                        ref={poNoRef}
                                        type="text"
                                        value={mainForm.po_no}
                                        onChange={(e) => setMainForm({ ...mainForm, po_no: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(poDateRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">PO Date</label>
                                    <input
                                        ref={poDateRef}
                                        type="text"
                                        value={mainForm.po_date}
                                        onChange={(e) => setMainForm({ ...mainForm, po_date: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(builtyNoRef)}
                                        placeholder="dd-mm-yyyy"
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div aria-hidden="true"></div>
                                <div aria-hidden="true"></div>
                                <div aria-hidden="true"></div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-600 mb-0.5">Builty No</label>
                                    <input
                                        ref={builtyNoRef}
                                        type="text"
                                        value={mainForm.builty_no}
                                        onChange={(e) => setMainForm({ ...mainForm, builty_no: e.target.value })}
                                        onFocus={(e) => e.target.select()}
                                        onKeyDown={makeEnterToNext(mainSubmitRef)}
                                        className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                    />
                                </div>
                                <div className="flex items-end">
                                    <button
                                        ref={mainSubmitRef}
                                        type="submit"
                                        disabled={isSavingMain}
                                        className={`w-full px-4 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 ${isReturn ? 'bg-red-500 hover:bg-red-600' : 'bg-blue-500 hover:bg-blue-600'
                                            }`}
                                    >
                                        {isSavingMain ? 'Saving...' : salesMainId ? 'Update' : 'Add'}
                                    </button>
                                </div>
                            </div>
                        </form>

                        {/* Detail entries - only once the main record exists */}
                        {salesMainId && (
                            <>
                                <div className="border-t border-gray-200 pt-3 mb-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">
                                        {editingDetailId ? 'Edit Entry' : 'Add Entry'}
                                    </h3>
                                    <form onSubmit={handleSaveDetail} className="space-y-2">
                                        <div className="grid grid-cols-8 gap-2 items-end">
                                            <div className="col-span-1">
                                                <SearchField
                                                    ref={itemSubRef}
                                                    label="Item Sub"
                                                    value={detailForm.subitem_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, subitem_code: val, Item_code: '' })}
                                                    options={companySubItems}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder="Search"
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(itemNameRef)}
                                                />
                                            </div>
                                            <div className="col-span-2">
                                                <SearchField
                                                    ref={itemNameRef}
                                                    label="Item Name"
                                                    value={detailForm.Item_code}
                                                    onChange={(val) => setDetailForm({ ...detailForm, Item_code: val })}
                                                    options={itemOptionsForSubItem}
                                                    codeKey="code"
                                                    labelKey="details"
                                                    placeholder={selectedSubItem ? 'Search item' : 'Pick item sub first'}
                                                    disabled={!selectedSubItem}
                                                    showAllOnFocus
                                                    onEnterNext={() => focusAndSelect(piecesRef)}
                                                />
                                                {missingGlSale && (
                                                    <div className="text-[11px] text-red-600 font-semibold mt-1">
                                                        ⚠ No GL Sale account is set for this item's Item Sub. Assign one before this entry can be added.
                                                    </div>
                                                )}
                                                {!missingGlSale && glSaleMatchesCustomer && (
                                                    <div className="text-[11px] text-red-600 font-semibold mt-1">
                                                        ⚠ This item's GL Sale account is the same as the customer account. Entry can't be made.
                                                    </div>
                                                )}
                                            </div>
                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Pieces</label>
                                                <input
                                                    ref={piecesRef}
                                                    type="number"
                                                    value={detailForm.pieces}
                                                    onChange={(e) => setDetailForm({ ...detailForm, pieces: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(netWeightRef)}
                                                    min="0"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Net Weight</label>
                                                <input
                                                    ref={netWeightRef}
                                                    type="number"
                                                    value={detailForm.net_weight}
                                                    onChange={(e) => setDetailForm({ ...detailForm, net_weight: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(rateRef)}
                                                    min="0"
                                                    step="0.01"
                                                    className="w-full px-2 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                                                />
                                            </div>

                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">
                                                    Rate <span className="text-red-500">*</span>
                                                </label>
                                                <input
                                                    ref={rateRef}
                                                    type="number"
                                                    value={detailForm.rate}
                                                    onChange={(e) => setDetailForm({ ...detailForm, rate: e.target.value })}
                                                    onFocus={(e) => e.target.select()}
                                                    onKeyDown={makeEnterToNext(detailSubmitRef)}
                                                    min="0"
                                                    step="0.01"
                                                    required
                                                    className={`w-full px-2 py-1.5 border rounded-md text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent`}
                                                />
                                            </div>

                                            <div className="col-span-1">
                                                <label className="block text-xs font-medium text-gray-600 mb-0.5">Total</label>
                                                <input
                                                    type="text"
                                                    value={detailPreview.total.toFixed(2)}
                                                    disabled
                                                    className="w-full px-2 py-1.5 border border-gray-200 bg-gray-50 rounded-md text-sm text-right text-gray-600"
                                                />
                                            </div>

                                            <div className="col-span-1">
                                                <button
                                                    ref={detailSubmitRef}
                                                    type="submit"
                                                    disabled={isSavingDetail || missingGlSale || glSaleMatchesCustomer}
                                                    title={
                                                        missingGlSale
                                                            ? "This item's Item Sub has no GL Sale account set"
                                                            : glSaleMatchesCustomer
                                                                ? "This item's GL Sale account is the same as the customer account"
                                                                : undefined
                                                    }
                                                    className={`w-full px-5 py-1.5 text-white text-sm font-medium rounded-md transition-colors disabled:opacity-60 disabled:cursor-not-allowed ${isReturn ? 'bg-red-500 hover:bg-red-600' : 'bg-blue-500 hover:bg-blue-600'
                                                        }`}
                                                >
                                                    {isSavingDetail ? 'Saving...' : editingDetailId ? 'Update' : 'Save'}
                                                </button>
                                                {editingDetailId && (
                                                    <button
                                                        type="button"
                                                        onClick={resetDetailForm}
                                                        className="text-sm text-gray-500 hover:text-gray-700 mt-1 block text-center w-full"
                                                    >
                                                        Cancel edit
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                        {detailForm.Item_code && (
                                            <div className="col-span-8 mt-2">
                                                <button
                                                    type="button"
                                                    onClick={() => setShowStockDetails((prev) => !prev)}
                                                    disabled={isLoadingLots || availableLots.length === 0}
                                                    className="w-full flex items-center justify-between px-2.5 py-1.5 border border-gray-200 rounded-md text-xs bg-gray-50 hover:bg-gray-100 disabled:opacity-70 disabled:cursor-default"
                                                >
                                                    <span className="font-semibold text-gray-600">
                                                        Available Stock (FIFO)
                                                        {!isLoadingLots && availableLots.length > 0 && (
                                                            <span className="font-normal text-gray-500 ml-1">
                                                                · {availableLots.length} lot{availableLots.length > 1 ? 's' : ''} · {totalAvailable} total
                                                            </span>
                                                        )}
                                                    </span>
                                                    {isLoadingLots ? (
                                                        <span className="text-gray-400">Loading...</span>
                                                    ) : availableLots.length === 0 ? (
                                                        <span className="text-red-500">No stock available</span>
                                                    ) : (
                                                        <span className="text-gray-400">{showStockDetails ? '▲ Hide' : '▼ Show'}</span>
                                                    )}
                                                </button>

                                                {showStockDetails && availableLots.length > 0 && (
                                                    <div className="mt-1 border border-gray-200 rounded overflow-hidden">
                                                        <div className="max-h-40 overflow-y-auto">
                                                            <table className="min-w-full text-xs">
                                                                <thead className="bg-gray-50 sticky top-0">
                                                                    <tr>
                                                                        <th className="px-2 py-1 text-left">✓</th>
                                                                        <th className="px-2 py-1 text-left">Source</th>
                                                                        <th className="px-2 py-1 text-left">Entry No</th>
                                                                        <th className="px-2 py-1 text-right">Pieces</th>
                                                                        <th className="px-2 py-1 text-right">Net Weight (Available)</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {lotAllocationPreview.map((lot) => (
                                                                        <tr key={`${lot.source_type}-${lot.source_detail_id}`} className={lot.willUse ? 'bg-blue-50' : ''}>
                                                                            <td className="px-2 py-1">{lot.willUse ? '☑' : '☐'}</td>
                                                                            <td className="px-2 py-1">{lot.source_type === 'purchase' ? `GRN ${lot.label}` : `Return ${lot.label}`}</td>
                                                                            <td className="px-2 py-1">{lot.entry_no}</td>
                                                                            <td className="px-2 py-1 text-right">{lot.remaining_pieces}</td>
                                                                            <td className="px-2 py-1 text-right">{lot.remaining_net_weight}</td>
                                                                        </tr>
                                                                    ))}
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                )}

                                                {insufficientStock && (
                                                    <div className="text-xs text-red-600 font-semibold mt-1">
                                                        ⚠ Requested net weight exceeds available stock ({totalAvailable}).
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </form>
                                </div>

                                {/* Entries table */}
                                <div className="border-t border-gray-200 pt-3">
                                    <h3 className="text-sm font-semibold text-gray-700 mb-2">Entries</h3>
                                    {isLoadingDetails ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">Loading...</div>
                                    ) : details.length === 0 ? (
                                        <div className="text-xs text-gray-400 py-3 text-center">No entries yet</div>
                                    ) : (
                                        <div className="overflow-x-auto border border-gray-200 rounded-lg">
                                            <table className="min-w-full divide-y divide-gray-200 text-sm">
                                                <thead className="bg-gray-50">
                                                    <tr>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Entry No</th>
                                                        <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Item</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Pieces</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Net Weight</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Rate</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Total</th>
                                                        <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="bg-white divide-y divide-gray-100">
                                                    {details.map((row) => (
                                                        <tr key={row.id} className="hover:bg-gray-50">
                                                            <td className="px-2.5 py-1.5 text-gray-600">{row.entry_no}</td>
                                                            <td className="px-2.5 py-1.5 text-gray-800">{row.item_name || row.Item_code}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.pieces}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.net_weight}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800">{row.rate}</td>
                                                            <td className="px-2.5 py-1.5 text-right text-gray-800 font-semibold">{row.total}</td>
                                                            <td className="px-2.5 py-1.5">
                                                                <div className="flex items-center justify-end gap-2">
                                                                    <button onClick={() => handleEditDetailRow(row)} title="Edit">
                                                                        <img src={editIcon} alt="Edit" className="w-4 h-4" />
                                                                    </button>
                                                                    <button onClick={() => handleDeleteDetail(row)} title="Delete">
                                                                        <img src={deleteIcon} alt="Delete" className="w-4 h-4" />
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                                <tfoot className="bg-gray-50 border-t-2 border-gray-200">
                                                    <tr>
                                                        <td className="px-2.5 py-1.5 font-semibold text-gray-700" colSpan={5}>
                                                            Total
                                                        </td>
                                                        <td className="px-2.5 py-1.5 text-right font-semibold text-gray-800">
                                                            {detailsTotals.total.toFixed(2)}
                                                        </td>
                                                        <td className="px-2.5 py-1.5"></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                )}
            </div>
            {showAutoEntries && (
                <div
                    className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4"
                    onClick={() => setShowAutoEntries(false)}
                >
                    <div
                        className="bg-white rounded-xl shadow-lg max-w-4xl w-full max-h-[85vh] overflow-y-auto p-5"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex items-center justify-between mb-3">
                            <h2 className="text-lg font-bold text-gray-800">
                                Auto GL Entries - Invoice {autoEntries?.invoice_no}
                            </h2>
                            <button
                                onClick={() => setShowAutoEntries(false)}
                                className="text-gray-400 hover:text-gray-700 text-xl leading-none"
                            >
                                ✕
                            </button>
                        </div>

                        {isLoadingAutoEntries ? (
                            <div className="text-sm text-gray-400 text-center py-6">Loading...</div>
                        ) : !autoEntries || autoEntries.groups.length === 0 ? (
                            <div className="text-sm text-gray-400 text-center py-6">No auto entries generated yet.</div>
                        ) : (
                            autoEntries.groups.map((g) => (
                                <div key={g.id} className="border border-gray-200 rounded-lg mb-4 overflow-hidden">
                                    <div className="bg-gray-50 px-3 py-2 flex flex-wrap gap-x-6 gap-y-1 text-sm">
                                        <span>
                                            <span className="text-gray-500">GL Account:</span>{' '}
                                            <span className="font-semibold">{g.customer_name || g.customer_code}</span>{' '}
                                            <span className="text-gray-400">({g.customer_code})</span>
                                        </span>
                                        <span><span className="text-gray-500">Invoice:</span> {g.invoice_no}</span>
                                        <span>
                                            <span className="text-gray-500">Total:</span>{' '}
                                            <span className="font-semibold">{g.totals.total.toFixed(2)}</span>
                                        </span>
                                        <span>
                                            <span className="text-gray-500">Freight:</span>{' '}
                                            <span className="font-semibold">{g.totals.freight?.toFixed(2) || '0.00'}</span>
                                        </span>
                                    </div>
                                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                                        <thead className="bg-white">
                                            <tr>
                                                <th className="px-2.5 py-1.5 text-left text-xs font-semibold text-gray-500 uppercase">Item</th>
                                                <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Amount</th>
                                                <th className="px-2.5 py-1.5 text-right text-xs font-semibold text-gray-500 uppercase">Total</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-100">
                                            {g.details.map((d) => (
                                                <tr key={d.id}>
                                                    <td className="px-2.5 py-1.5">{d.item_name || d.Item_code}</td>
                                                    <td className="px-2.5 py-1.5 text-right">{Number(d.amount).toFixed(2)}</td>
                                                    <td className="px-2.5 py-1.5 text-right font-semibold">{Number(d.total).toFixed(2)}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                        {g.totals.freight > 0 && (
                                            <tfoot className="border-t border-gray-200">
                                                <tr className="bg-gray-50">
                                                    <td className="px-2.5 py-1.5 font-medium text-gray-700">Freight</td>
                                                    <td className="px-2.5 py-1.5 text-right text-gray-700"></td>
                                                    <td className="px-2.5 py-1.5 text-right text-gray-700"></td>
                                                    <td className="px-2.5 py-1.5 text-right text-gray-700"></td>
                                                    <td className="px-2.5 py-1.5 text-right font-semibold text-gray-700">
                                                        {g.totals.freight.toFixed(2)}
                                                    </td>
                                                </tr>
                                                <tr className="bg-gray-50 border-t border-gray-200">
                                                    <td className="px-2.5 py-1.5 font-bold text-gray-800">Sub Total</td>
                                                    <td className="px-2.5 py-1.5 text-right font-bold text-gray-800"></td>
                                                    <td className="px-2.5 py-1.5 text-right font-bold text-gray-800"></td>
                                                    <td className="px-2.5 py-1.5 text-right font-bold text-gray-800"></td>
                                                    <td className="px-2.5 py-1.5 text-right font-bold text-gray-800">
                                                        {(g.totals.total + (g.totals.freight || 0)).toFixed(2)}
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        )}
                                    </table>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default SalesEntry;