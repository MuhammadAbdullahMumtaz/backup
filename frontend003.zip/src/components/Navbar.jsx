import React, { useState, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { logout, setCurrentMonth } from '../store/slices/companySlice';

import logoImg from '../assets/logo.png';
import settingsImg from '../assets/settings.png';
import userImg from '../assets/user.png';
import sideImg from '../assets/side.png';

const Navbar = ({ isOpen, toggleNavbar, onLogoClick, onCompanyClick, onFinancialYearClick, onLoginClick }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [showToolsDropdown, setShowToolsDropdown] = useState(false);
  const [showMonthDropdown, setShowMonthDropdown] = useState(false);

  const { companyName, financialYearName, currentMonth, user } = useSelector((state) => state.company);

  const isAdmin = user?.role === 'Admin';

  const APP_VERSION = '1.0';

  const toolsRef = useRef(null);
  const profileRef = useRef(null);
  const monthRef = useRef(null);

  // List of months
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (toolsRef.current && !toolsRef.current.contains(event.target)) {
        setShowToolsDropdown(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setShowProfileDropdown(false);
      }
      if (monthRef.current && !monthRef.current.contains(event.target)) {
        setShowMonthDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    dispatch(logout());
    toast.success('Logged out successfully');
    navigate('/login');
  };

  const handleEditProfile = () => {
    toast.info('Edit profile functionality coming soon');
    setShowProfileDropdown(false);
  };

  const handleDataBackup = () => {
    toast.info('Data backup functionality coming soon');
    setShowToolsDropdown(false);
  };

  const handleLogoClick = () => {
    if (onLogoClick) onLogoClick();
  };

  const handleCompanyNameClick = () => {
    if (isAdmin && companyName === 'AAM Tech Solutions' && onCompanyClick) {
      onCompanyClick();
    } else if (!isAdmin) {
      toast.warning('You do not have permission to access company settings');
    } else if (companyName !== 'AAM Tech Solutions') {
      toast.warning('Company settings are only available for AAM Tech Solutions');
    }
  };

  const handleFinancialYearClick = () => {
    if (isAdmin && onFinancialYearClick) {
      onFinancialYearClick();
    } else {
      toast.warning('You do not have permission to access financial year settings');
    }
  };

  const handleAddLoginClick = () => {
    if (isAdmin && onLoginClick) {
      onLoginClick();
      setShowProfileDropdown(false);
    } else {
      toast.warning('You do not have permission to add users');
      setShowProfileDropdown(false);
    }
  };

  const handleMonthChange = (month) => {
    // Update month in Redux (which will also save to localStorage)
    dispatch(setCurrentMonth(month));
    setShowMonthDropdown(false);
    toast.success(`Month changed to ${month}`);
  };

  const handleMonthClick = (e) => {
    e.stopPropagation();
    setShowMonthDropdown(!showMonthDropdown);
    setShowToolsDropdown(false);
    setShowProfileDropdown(false);
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 h-16 bg-white px-6 flex justify-between items-center z-[10] transition-transform duration-300 ${
          isOpen ? 'translate-y-0' : '-translate-y-full'
        }`}
      >
        <div className="flex items-center space-x-6">
          {/* Logo - click to go back to Dashboard's default view */}
          <img
            src={logoImg}
            alt="Logo"
            onClick={handleLogoClick}
            className="h-9 w-auto cursor-pointer hover:opacity-80 transition-opacity"
          />

          {/* Company Name - only visible and clickable for admin */}
          {isAdmin && companyName === 'AAM Tech Solutions' ? (
            <h1
              onClick={handleCompanyNameClick}
              className="text-xl font-bold text-gray-800 cursor-pointer relative inline-block
        after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-[2px] 
        after:bottom-0 after:left-0 after:bg-gray-600 after:origin-bottom-right 
        after:transition-transform after:duration-300 hover:after:scale-x-100 
        hover:after:origin-bottom-left hover:text-gray-600 transition-colors"
              title="Manage companies"
            >
              {companyName || 'Company Name'}
            </h1>
          ) : (
            <h1 className="text-xl font-bold text-gray-800 cursor-default">
              {companyName || 'Company Name'}
            </h1>
          )}
          {/* Financial Year - only visible and clickable for admin */}
          {isAdmin ? (
            <div
              onClick={handleFinancialYearClick}
              className="cursor-pointer relative inline-block space-x-2
                after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-[2px] 
                after:bottom-0 after:left-0 after:bg-gray-600 after:origin-bottom-right 
                after:transition-transform after:duration-300 hover:after:scale-x-100 
                hover:after:origin-bottom-left hover:text-gray-600 transition-colors"
              title="Manage financial years"
            >
              <span className="text-lg font-semibold text-gray-500 group-hover:text-gray-600 transition-colors">
                Financial Year
              </span>
              <span className="text-lg font-medium text-gray-800 group-hover:text-gray-600 transition-colors">
                {financialYearName || '-'}
              </span>
            </div>
          ) : (
            <div className="inline-block space-x-2 cursor-default">
              <span className="text-lg font-semibold text-gray-500">
                Financial Year
              </span>
              <span className="text-lg font-medium text-gray-800">
                {financialYearName || '-'}
              </span>
            </div>
          )}

          {/* Month - Clickable with dropdown */}
          <div className="relative" ref={monthRef}>
            <div
              onClick={handleMonthClick}
              className="cursor-pointer relative inline-block space-x-2
                after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-[2px] 
                after:bottom-0 after:left-0 after:bg-gray-600 after:origin-bottom-right 
                after:transition-transform after:duration-300 hover:after:scale-x-100 
                hover:after:origin-bottom-left hover:text-gray-600 transition-colors
                flex items-center gap-1"
              title="Change month"
            >
              <span className="text-sm text-gray-500 bg-blue-50 px-3 py-0.5 rounded-full hover:bg-blue-100 transition-colors flex items-center">
                {currentMonth || 'Select Month'}
                <svg 
                  className={`w-4 h-4 ml-1 transition-transform duration-200 ${showMonthDropdown ? 'rotate-180' : ''}`}
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </span>
            </div>

            {showMonthDropdown && (
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200 max-h-64 overflow-y-auto">
                {months.map((month) => (
                  <button
                    key={month}
                    onClick={() => handleMonthChange(month)}
                    className={`block w-full text-left px-4 py-2 text-sm transition-colors
                      ${currentMonth === month 
                        ? 'bg-blue-50 text-blue-700 font-medium' 
                        : 'text-gray-700 hover:bg-gray-100'
                      }`}
                  >
                    {month}
                    {currentMonth === month && (
                      <span className="float-right text-blue-500">✓</span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Version Badge */}
          <div className="bg-green-100 text-green-700 text-xs font-semibold px-2 py-1 rounded-md">
            {APP_VERSION}
          </div>

          {/* Tools Icon */}
          <div className="relative" ref={toolsRef}>
            <button
              onClick={() => {
                setShowToolsDropdown(!showToolsDropdown);
                setShowProfileDropdown(false);
                setShowMonthDropdown(false);
              }}
              className="focus:outline-none"
            >
              <img
                src={settingsImg}
                alt="Tools"
                className="w-6 h-6 cursor-pointer hover:opacity-70 transition-opacity"
              />
            </button>

            {showToolsDropdown && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                <button
                  onClick={handleDataBackup}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  Data Backup
                </button>
              </div>
            )}
          </div>

          {/* Profile Icon */}
          <div className="relative" ref={profileRef}>
            <button
              onClick={() => {
                setShowProfileDropdown(!showProfileDropdown);
                setShowToolsDropdown(false);
                setShowMonthDropdown(false);
              }}
              className="focus:outline-none"
            >
              <img
                src={userImg}
                alt="Profile"
                className="w-6 h-6 cursor-pointer hover:opacity-70 transition-opacity"
              />
            </button>

            {showProfileDropdown && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                <button
                  onClick={handleEditProfile}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  Edit Login
                </button>

                {/* Add Login - only visible for admin */}
                {isAdmin && (
                  <button
                    onClick={handleAddLoginClick}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                  >
                    Add Login
                  </button>
                )}

                <button
                  onClick={handleLogout}
                  className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100 transition-colors"
                >
                  Logout
                </button>
              </div>
            )}
          </div>

          {/* Collapse Navbar toggle - same pattern as Sidebar's collapse icon */}
          <button
            onClick={toggleNavbar}
            className="p-1 rounded-md hover:bg-gray-100 transition-colors"
            title="Collapse navbar"
          >
            <img
              src={sideImg}
              alt="Collapse Navbar"
              className="w-4 h-4 rotate-90"
            />
          </button>
        </div>
      </nav>

      {/* Floating reopen tab, only visible when navbar is closed */}
      {!isOpen && (
        <button
          onClick={toggleNavbar}
          className="fixed top-0 right-6 z-40 bg-white py-1 px-3 rounded-b-lg shadow-md hover:shadow-lg transition-shadow"
          title="Expand navbar"
        >
          <img
            src={sideImg}
            alt="Expand Navbar"
            className="w-4 h-4 -rotate-90"
          />
        </button>
      )}
    </>
  );
};

export default Navbar;