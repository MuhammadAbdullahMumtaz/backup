const db = require("../../config/db");

// =============================
// Add Financial Year
// =============================
exports.addFinancialYear = async (req, res) => {
    try {
        const {
            company_id,
            year_detail,
            status,
            start_date,
            end_date
        } = req.body;

        // Validate required fields
        if (!company_id || !year_detail || !start_date || !end_date) {
            return res.status(400).json({
                success: false,
                message: "Company ID, year detail, start date, and end date are required"
            });
        }

        // Check if financial year already exists
        const [exist] = await db.query(
            `SELECT id FROM FinancialYear 
             WHERE company_id = ? AND year_detail = ?`,
            [company_id, year_detail]
        );

        if (exist.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Financial Year Already Exists"
            });
        }

        // Validate date range
        if (new Date(start_date) >= new Date(end_date)) {
            return res.status(400).json({
                success: false,
                message: "Start date must be before end date"
            });
        }

        // Set default status if not provided
        const finalStatus = status || 'Inactive';

        const { current_month } = req.body;

        const [result] = await db.query(
            `INSERT INTO FinancialYear 
             (company_id, year_detail, status, start_date, end_date, current_month)
             VALUES(?, ?, ?, ?, ?, ?)`,
            [
                company_id,
                year_detail,
                finalStatus,
                start_date,
                end_date,
                current_month
            ]
        );

        res.status(201).json({
            success: true,
            message: "Financial Year Added Successfully",
            data: {
                id: result.insertId,
                company_id,
                year_detail,
                status: finalStatus,
                start_date,
                end_date,
                current_month: current_month
            }
        });

    } catch (err) {
        console.error('Error adding financial year:', err);
        res.status(500).json({
            success: false,
            message: "Error adding financial year",
            error: err.message
        });
    }
};

// =============================
// Update Financial Year
// =============================
exports.updateFinancialYear = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            year_detail,
            status,
            start_date,
            end_date
        } = req.body;

        // Validate required fields
        if (!company_id || !year_detail || !start_date || !end_date) {
            return res.status(400).json({
                success: false,
                message: "Company ID, year detail, start date, and end date are required"
            });
        }

        // Check if financial year exists
        const [existing] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ?`,
            [id]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Financial Year Not Found"
            });
        }

        // Check for duplicate year_detail (excluding current record)
        const [duplicate] = await db.query(
            `SELECT id FROM FinancialYear 
             WHERE company_id = ? AND year_detail = ? AND id != ?`,
            [company_id, year_detail, id]
        );

        if (duplicate.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Financial Year Already Exists with this year detail"
            });
        }

        // Validate date range
        if (new Date(start_date) >= new Date(end_date)) {
            return res.status(400).json({
                success: false,
                message: "Start date must be before end date"
            });
        }

        const { current_month } = req.body;

        await db.query(
            `UPDATE FinancialYear 
             SET company_id = ?,
                 year_detail = ?,
                 status = ?,
                 start_date = ?,
                 end_date = ?,
                 current_month = ?
             WHERE id = ?`,
            [
                company_id,
                year_detail,
                status || 'Inactive',
                start_date,
                end_date,
                current_month,
                id
            ]
        );

        res.json({
            success: true,
            message: "Financial Year Updated Successfully"
        });

    } catch (err) {
        console.error('Error updating financial year:', err);
        res.status(500).json({
            success: false,
            message: "Error updating financial year",
            error: err.message
        });
    }
};

// =============================
// Delete Financial Year
// =============================
exports.deleteFinancialYear = async (req, res) => {
    try {
        const { id } = req.params;

        // Check if financial year exists
        const [existing] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ?`,
            [id]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Financial Year Not Found"
            });
        }

        // Check if financial year is being used in any vouchers
        const [voucherCheck] = await db.query(
            `SELECT id FROM VoucherMain WHERE financialyear_id = ? LIMIT 1`,
            [id]
        );

        if (voucherCheck.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Cannot delete financial year as it is being used in existing vouchers"
            });
        }

        await db.query(
            "DELETE FROM FinancialYear WHERE id = ?",
            [id]
        );

        res.json({
            success: true,
            message: "Financial Year Deleted Successfully"
        });

    } catch (err) {
        console.error('Error deleting financial year:', err);
        res.status(500).json({
            success: false,
            message: "Error deleting financial year",
            error: err.message
        });
    }
};

// =============================
// Get Financial Years
// =============================
exports.getFinancialYears = async (req, res) => {
    try {
        const { companyId } = req.query;

        let query = `
            SELECT
                fy.id,
                fy.company_id,
                c.company_name,
                fy.year_detail,
                fy.status,
                fy.start_date,
                fy.end_date,
                fy.current_month,
                fy.add_date,
                fy.update_date
            FROM FinancialYear fy
            INNER JOIN CompanyName c
                ON c.id = fy.company_id
        `;

        const params = [];

        // Filter by company if companyId is provided
        if (companyId) {
            query += ` WHERE fy.company_id = ?`;
            params.push(companyId);
        }

        query += ` ORDER BY fy.start_date DESC`;

        const [rows] = await db.query(query, params);

        // Calculate if financial year is active based on current date
        const currentDate = new Date();
        const processedRows = rows.map(row => {
            const startDate = new Date(row.start_date);
            const endDate = new Date(row.end_date);
            const isCurrent = currentDate >= startDate && currentDate <= endDate;
            
            return {
                ...row,
                is_current: isCurrent,
                // Override status if it's the current financial year
                computed_status: isCurrent ? 'Current' : row.status
            };
        });

        res.json({
            success: true,
            data: processedRows
        });

    } catch (err) {
        console.error('Error fetching financial years:', err);
        res.status(500).json({
            success: false,
            message: "Error fetching financial years",
            error: err.message
        });
    }
};

// =============================
// Get Financial Year By Id
// =============================
exports.getFinancialYearById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT
                fy.id,
                fy.company_id,
                c.company_name,
                fy.year_detail,
                fy.status,
                fy.start_date,
                fy.end_date,
                fy.current_month,
                fy.add_date,
                fy.update_date
            FROM FinancialYear fy
            INNER JOIN CompanyName c
                ON c.id = fy.company_id
            WHERE fy.id = ?`,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Financial Year Not Found"
            });
        }

        const row = rows[0];
        const currentDate = new Date();
        const startDate = new Date(row.start_date);
        const endDate = new Date(row.end_date);
        const isCurrent = currentDate >= startDate && currentDate <= endDate;

        res.json({
            success: true,
            data: {
                ...row,
                is_current: isCurrent,
                computed_status: isCurrent ? 'Current' : row.status
            }
        });

    } catch (err) {
        console.error('Error fetching financial year:', err);
        res.status(500).json({
            success: false,
            message: "Error fetching financial year",
            error: err.message
        });
    }
};

// =============================
// Get Current Month by Financial Year Id
// =============================
exports.getCurrentMonth = async (req, res) => {
    try {
        const { id } = req.params;

        if (!id) {
            return res.status(400).json({
                success: false,
                message: "Financial Year ID is required"
            });
        }

        const [rows] = await db.query(
            `SELECT id, current_month FROM FinancialYear WHERE id = ?`,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Financial Year Not Found"
            });
        }

        res.json({
            success: true,
            data: {
                financialYearId: rows[0].id,
                current_month: rows[0].current_month
            }
        });

    } catch (err) {
        console.error('Error fetching current month:', err);
        res.status(500).json({
            success: false,
            message: "Error fetching current month",
            error: err.message
        });
    }
};

// =============================
// Update Only Current Month
// =============================
exports.updateOnlyMonth = async (req, res) => {
    try {
        const { id } = req.params;
        const { current_month } = req.body;

        const VALID_MONTHS = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];

        if (!current_month) {
            return res.status(400).json({
                success: false,
                message: "current_month is required"
            });
        }

        if (!VALID_MONTHS.includes(current_month)) {
            return res.status(400).json({
                success: false,
                message: "current_month must be a valid month name"
            });
        }

        const [existing] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ?`,
            [id]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Financial Year Not Found"
            });
        }

        await db.query(
            `UPDATE FinancialYear SET current_month = ? WHERE id = ?`,
            [current_month, id]
        );

        res.json({
            success: true,
            message: "Current month updated successfully",
            data: {
                financialYearId: Number(id),
                current_month
            }
        });

    } catch (err) {
        console.error('Error updating current month:', err);
        res.status(500).json({
            success: false,
            message: "Error updating current month",
            error: err.message
        });
    }
};