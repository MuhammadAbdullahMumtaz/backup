const db = require("../../../../config/db");

// ======================================================
// Get All Item Details
// ======================================================
exports.getAllItemDetails = async (req, res) => {

    try {

        const sql = `
            SELECT

                i.id,

                i.company_id,
                c.company_name,

                i.subitem_id,
                s.details AS sub_item,
                s.code AS sub_item_code,

                i.code,
                i.details,

                i.HSCode,
                i.Unit,
                i.PackingUnit,
                i.Barcode,
                i.Image,
                i.Location,
                i.MinLimit,
                i.MaxLimit,

                i.add_date,
                i.update_date

            FROM ItemDetail i

            INNER JOIN CompanyName c
                ON i.company_id = c.id

            INNER JOIN SubItem s
                ON i.subitem_id = s.id

            ORDER BY i.id DESC
        `;

        const [rows] = await db.query(sql);

        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};


// ======================================================
// Get Item Detail By ID
// ======================================================
exports.getItemDetailById = async (req, res) => {

    try {

        const { id } = req.params;

        const sql = `
            SELECT

                i.id,

                i.company_id,
                c.company_name,

                i.subitem_id,
                s.details AS sub_item,
                s.code AS sub_item_code,

                i.code,
                i.details,

                i.HSCode,
                i.Unit,
                i.PackingUnit,
                i.Barcode,
                i.Image,
                i.Location,
                i.MinLimit,
                i.MaxLimit,

                i.add_date,
                i.update_date

            FROM ItemDetail i

            INNER JOIN CompanyName c
                ON i.company_id = c.id

            INNER JOIN SubItem s
                ON i.subitem_id = s.id

            WHERE i.id = ?
        `;

        const [rows] = await db.query(sql, [id]);

        if (rows.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Item Detail not found."
            });

        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};


// ======================================================
// Add Item Detail
// ======================================================
exports.addItemDetail = async (req, res) => {

    try {

        const {

            company_id,
            subitem_id,
            details,
            HSCode,
            Unit,
            PackingUnit,
            Barcode,
            Image,
            Location,
            MinLimit,
            MaxLimit

        } = req.body;

        if (!company_id || !subitem_id || !details) {

            return res.status(400).json({
                success: false,
                message: "Company, Sub Item and Details are required."
            });

        }

        // Duplicate Check
        const [duplicate] = await db.query(
            `
            SELECT id
            FROM ItemDetail
            WHERE company_id = ?
            AND subitem_id = ?
            AND details = ?
            `,
            [
                company_id,
                subitem_id,
                details
            ]
        );

        if (duplicate.length > 0) {

            return res.status(400).json({
                success: false,
                message: "Item Detail already exists."
            });

        }

        // ==========================================
        // Fetch parent Sub Item code (4-digit)
        // ==========================================
        const [subItemRows] = await db.query(
            `
            SELECT code
            FROM SubItem
            WHERE id = ?
            AND company_id = ?
            `,
            [subitem_id, company_id]
        );

        if (subItemRows.length === 0) {
            return res.status(400).json({
                success: false,
                message: "Sub Item not found for this company."
            });
        }

        const subItemCode = subItemRows[0].code;

        // ==========================================
        // Generate Item Detail's own 4-digit sequence
        // (scoped by company_id + subitem_id)
        // ==========================================
        const [codeRows] = await db.query(
            `
            SELECT
                COALESCE(MAX(CAST(RIGHT(code, 4) AS UNSIGNED)), 0) + 1 AS nextNo
            FROM ItemDetail
            WHERE company_id = ?
            AND subitem_id = ?
            `,
            [company_id, subitem_id]
        );

        const nextNo = codeRows[0].nextNo;

        const itemCode = String(nextNo).padStart(4, "0");

        // Combine: SubItem code (4) + ItemDetail sequence (4) = 8-digit code
        const code = `${subItemCode}${itemCode}`;

        const sql = `
            INSERT INTO ItemDetail
            (
                company_id,
                subitem_id,
                code,
                details,
                HSCode,
                Unit,
                PackingUnit,
                Barcode,
                Image,
                Location,
                MinLimit,
                MaxLimit
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const [result] = await db.query(sql, [

            company_id,
            subitem_id,
            code,
            details,

            HSCode || null,
            Unit || null,
            PackingUnit || null,
            Barcode || null,
            Image || null,
            Location || null,
            MinLimit || 0,
            MaxLimit || 0

        ]);

        res.status(201).json({

            success: true,
            message: "Item Detail added successfully.",
            id: result.insertId,
            code: code

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            success: false,
            message: error.message

        });

    }

};

// ======================================================
// Update Item Detail
// ======================================================
exports.updateItemDetail = async (req, res) => {

    try {

        const { id } = req.params;

        const {

            company_id,
            subitem_id,
            details,
            HSCode,
            Unit,
            PackingUnit,
            Barcode,
            Image,
            Location,
            MinLimit,
            MaxLimit

        } = req.body;

        // Check if record exists
        const [exist] = await db.query(
            "SELECT id FROM ItemDetail WHERE id = ?",
            [id]
        );

        if (exist.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Item Detail not found."
            });
        }

        // Duplicate Check
        const [duplicate] = await db.query(
            `
            SELECT id
            FROM ItemDetail
            WHERE company_id = ?
              AND subitem_id = ?
              AND details = ?
              AND id <> ?
            `,
            [
                company_id,
                subitem_id,
                details,
                id
            ]
        );

        if (duplicate.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Item Detail already exists."
            });
        }

        // NOTE: code is intentionally NOT regenerated on update, to avoid
        // desyncing from the SubItem code it was originally derived from.
        const sql = `
            UPDATE ItemDetail
            SET
                company_id = ?,
                subitem_id = ?,
                details = ?,
                HSCode = ?,
                Unit = ?,
                PackingUnit = ?,
                Barcode = ?,
                Image = ?,
                Location = ?,
                MinLimit = ?,
                MaxLimit = ?
            WHERE id = ?
        `;

        await db.query(sql, [

            company_id,
            subitem_id,
            details,
            HSCode || null,
            Unit || null,
            PackingUnit || null,
            Barcode || null,
            Image || null,
            Location || null,
            MinLimit || 0,
            MaxLimit || 0,
            id

        ]);

        res.status(200).json({
            success: true,
            message: "Item Detail updated successfully."
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};


// ======================================================
// Delete Item Detail
// ======================================================
exports.deleteItemDetail = async (req, res) => {

    try {

        const { id } = req.params;

        const [exist] = await db.query(
            "SELECT id FROM ItemDetail WHERE id = ?",
            [id]
        );

        if (exist.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Item Detail not found."
            });
        }

        await db.query(
            "DELETE FROM ItemDetail WHERE id = ?",
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Item Detail deleted successfully."
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};