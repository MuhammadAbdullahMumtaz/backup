const db = require("../../../../config/db");

// ======================================================
// Get All Voucher Mains
// ======================================================
exports.getAllVoucherMains = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                vm.id,
                vm.company_id,
                c.company_name,

                vm.vouchertype_id,
                vt.type AS voucher_type_code,
                vt.details AS voucher_type_details,

                vm.financialyear_id,
                fy.year_detail,

                vm.voucher_no,
                DATE_FORMAT(vm.voucher_date, '%Y-%m-%d') AS voucher_date,
                vm.voucher_month,
                vm.isBalanced,

                vm.created_at,
                vm.updated_at

            FROM VoucherMain vm

            INNER JOIN CompanyName c
                ON vm.company_id = c.id

            INNER JOIN VoucherType vt
                ON vm.vouchertype_id = vt.id

            INNER JOIN FinancialYear fy
                ON vm.financialyear_id = fy.id

            ORDER BY vm.voucher_no ASC
        `);

        res.status(200).json(rows);

    } catch (error) {
        console.error("Error fetching vouchers:", error);
        res.status(500).json({
            message: "Failed to fetch vouchers.",
            error: error.message
        });
    }
};

// ======================================================
// Get Next Voucher Number
// ======================================================
exports.getNextVoucherNumber = async (req, res) => {
    try {
        const { company_id, financialyear_id, vouchertype_id } = req.params;
        const { month } = req.query;

        if (!company_id || !financialyear_id || !vouchertype_id || !month) {
            return res.status(400).json({
                message: "Company ID, Financial Year ID, Voucher Type ID, and month are required."
            });
        }

        // Scoped by voucher_month — voucher numbers restart at 1 every month,
        // so e.g. June's 423 vouchers don't carry their sequence into July.
        // This matches VoucherMain's UNIQUE(company_id, financialyear_id,
        // voucher_month, voucher_no) constraint.
        const [rows] = await db.query(
            `
            SELECT MAX(CAST(SUBSTRING_INDEX(voucher_no, '-', -1) AS UNSIGNED)) as max_voucher_no
            FROM VoucherMain
            WHERE company_id = ? 
              AND financialyear_id = ? 
              AND vouchertype_id = ?
              AND voucher_month = ?
            `,
            [company_id, financialyear_id, vouchertype_id, month]
        );

        const maxVoucherNo = rows[0].max_voucher_no || 0;
        const nextNumber = maxVoucherNo + 1;

        res.status(200).json({
            next_voucher_number: nextNumber
        });

    } catch (error) {
        console.error("Error generating next voucher number:", error);
        res.status(500).json({
            message: "Failed to generate next voucher number.",
            error: error.message
        });
    }
};

// ======================================================
// Get Voucher Main By ID
// ======================================================
exports.getVoucherMainById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                vm.id,
                vm.company_id,
                c.company_name,

                vm.vouchertype_id,
                vt.type AS voucher_type_code,
                vt.details AS voucher_type_details,

                vm.financialyear_id,
                fy.year_detail,

                vm.voucher_no,
                DATE_FORMAT(vm.voucher_date, '%Y-%m-%d') AS voucher_date,
                vm.voucher_month,
                vm.isBalanced,

                vm.created_at,
                vm.updated_at

            FROM VoucherMain vm

            INNER JOIN CompanyName c
                ON vm.company_id = c.id

            INNER JOIN VoucherType vt
                ON vm.vouchertype_id = vt.id

            INNER JOIN FinancialYear fy
                ON vm.financialyear_id = fy.id

            WHERE vm.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Voucher not found."
            });
        }

        res.status(200).json(rows[0]);

    } catch (error) {
        console.error("Error fetching voucher:", error);
        res.status(500).json({
            message: "Failed to fetch voucher.",
            error: error.message
        });
    }
};

// ======================================================
// Add Voucher Main
// ======================================================
exports.addVoucherMain = async (req, res) => {
    try {
        const {
            company_id,
            vouchertype_id,
            financialyear_id,
            voucher_no,
            voucher_date,
            voucher_month,
            isBalanced
        } = req.body;

        // Validate required fields
        if (!company_id || !vouchertype_id || !financialyear_id || !voucher_no || !voucher_date || !voucher_month) {
            return res.status(400).json({
                message: "Company, voucher type, financial year, voucher number, voucher date, and month are all required."
            });
        }

        // Validate voucher number is not empty
        if (!voucher_no.trim()) {
            return res.status(400).json({
                message: "Voucher number cannot be empty."
            });
        }

        // Validate month against a fixed list, same as FinancialYear's current_month
        const VALID_MONTHS = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];
        if (!VALID_MONTHS.includes(voucher_month)) {
            return res.status(400).json({
                message: "voucher_month must be a valid month name."
            });
        }

        // Check if voucher type exists
        const [voucherTypeCheck] = await db.query(
            `SELECT id FROM VoucherType WHERE id = ? AND company_id = ?`,
            [vouchertype_id, company_id]
        );

        if (voucherTypeCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid voucher type for this company."
            });
        }

        // Check if financial year exists
        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ?`,
            [financialyear_id]
        );

        if (financialYearCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid financial year."
            });
        }

        const VALID_BALANCE_STATUS = ['Balanced', 'Unbalanced'];
        if (isBalanced !== undefined && !VALID_BALANCE_STATUS.includes(isBalanced)) {
            return res.status(400).json({
                message: "isBalanced must be either 'Balanced' or 'Unbalanced'."
            });
        }


        const [result] = await db.query(
            `
    INSERT INTO VoucherMain
    (
        company_id,
        vouchertype_id,
        financialyear_id,
        voucher_no,
        voucher_date,
        voucher_month,
        isBalanced
    )
    VALUES (?, ?, ?, ?, ?, ?, ?)
    `,
            [
                company_id,
                vouchertype_id,
                financialyear_id,
                voucher_no.trim(),
                voucher_date,
                voucher_month,
                isBalanced || 'Unbalanced'
            ]
        );

        res.status(201).json({
            message: "Voucher created successfully.",
            id: result.insertId
        });

    } catch (error) {
        console.error("Error adding voucher:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This voucher number already exists for the selected company, financial year, and month."
            });
        }

        res.status(500).json({
            message: "Failed to create voucher.",
            error: error.message
        });
    }
};

// ======================================================
// Update Voucher Main
// ======================================================
exports.updateVoucherMain = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            vouchertype_id,
            financialyear_id,
            voucher_no,
            voucher_date,
            voucher_month,
            isBalanced
        } = req.body;

        // Validate required fields
        if (!company_id || !vouchertype_id || !financialyear_id || !voucher_no || !voucher_date || !voucher_month) {
            return res.status(400).json({
                message: "Company, voucher type, financial year, voucher number, voucher date, and month are all required."
            });
        }

        if (!voucher_no.trim()) {
            return res.status(400).json({
                message: "Voucher number cannot be empty."
            });
        }

        const VALID_MONTHS = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];
        if (!VALID_MONTHS.includes(voucher_month)) {
            return res.status(400).json({
                message: "voucher_month must be a valid month name."
            });
        }

        const VALID_BALANCE_STATUS = ['Balanced', 'Unbalanced'];
        if (isBalanced !== undefined && !VALID_BALANCE_STATUS.includes(isBalanced)) {
            return res.status(400).json({
                message: "isBalanced must be either 'Balanced' or 'Unbalanced'."
            });
        }

        // Check if voucher exists
        const [voucherCheck] = await db.query(
            `SELECT id FROM VoucherMain WHERE id = ?`,
            [id]
        );

        if (voucherCheck.length === 0) {
            return res.status(404).json({
                message: "Voucher not found."
            });
        }

        // Check if voucher type exists for the company
        const [voucherTypeCheck] = await db.query(
            `SELECT id FROM VoucherType WHERE id = ? AND company_id = ?`,
            [vouchertype_id, company_id]
        );

        if (voucherTypeCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid voucher type for this company."
            });
        }

        // Check if financial year exists
        const [financialYearCheck] = await db.query(
            `SELECT id FROM FinancialYear WHERE id = ?`,
            [financialyear_id]
        );

        if (financialYearCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid financial year."
            });
        }

        await db.query(
            `
    UPDATE VoucherMain
    SET
        company_id = ?,
        vouchertype_id = ?,
        financialyear_id = ?,
        voucher_no = ?,
        voucher_date = ?,
        voucher_month = ?,
        isBalanced = ?
    WHERE id = ?
    `,
            [
                company_id,
                vouchertype_id,
                financialyear_id,
                voucher_no.trim(),
                voucher_date,
                voucher_month,
                isBalanced || 'Unbalanced',
                id
            ]
        );

        res.status(200).json({
            message: "Voucher updated successfully."
        });

    } catch (error) {
        console.error("Error updating voucher:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This voucher number already exists for the selected company, financial year, and month."
            });
        }

        res.status(500).json({
            message: "Failed to update voucher.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Voucher Main
// ======================================================
exports.deleteVoucherMain = async (req, res) => {
    try {
        const { id } = req.params;

        const [detailCheck] = await db.query(
            `SELECT COUNT(*) as count FROM VoucherDetail WHERE vouchermain_id = ?`,
            [id]
        );

        if (detailCheck[0].count > 0) {
            return res.status(409).json({
                message: "Cannot delete voucher as it has associated details. Please delete voucher details first."
            });
        }

        const [result] = await db.query(
            `DELETE FROM VoucherMain WHERE id = ?`,
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Voucher not found."
            });
        }

        res.status(200).json({
            message: "Voucher deleted successfully."
        });

    } catch (error) {
        console.error("Error deleting voucher:", error);
        res.status(500).json({
            message: "Failed to delete voucher.",
            error: error.message
        });
    }
};

// ======================================================
// Update Voucher Date Only (used by the "update date" popup
// once a voucher is locked / already has entries)
// ======================================================
exports.updateVoucherDate = async (req, res) => {
    try {
        const { id } = req.params;
        const { voucher_date } = req.body;

        if (!voucher_date) {
            return res.status(400).json({
                message: "voucher_date is required."
            });
        }

        const [voucherCheck] = await db.query(
            `SELECT id, voucher_month FROM VoucherMain WHERE id = ?`,
            [id]
        );

        if (voucherCheck.length === 0) {
            return res.status(404).json({
                message: "Voucher not found."
            });
        }

        // The voucher's month is fixed at creation time (it's part of the
        // unique key and drives voucher numbering), so a date edit is only
        // allowed to move within that same month - not to reassign it.
        const MONTHS = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];
        const parts = String(voucher_date).split('-'); // expects yyyy-mm-dd
        const monthIndex = Number(parts[1]) - 1;
        const monthOfNewDate = MONTHS[monthIndex];

        if (!monthOfNewDate || monthOfNewDate !== voucherCheck[0].voucher_month) {
            return res.status(400).json({
                message: `Voucher date must remain within ${voucherCheck[0].voucher_month}.`
            });
        }

        await db.query(
            `UPDATE VoucherMain SET voucher_date = ? WHERE id = ?`,
            [voucher_date, id]
        );

        res.status(200).json({
            message: "Voucher date updated successfully."
        });

    } catch (error) {
        console.error("Error updating voucher date:", error);
        res.status(500).json({
            message: "Failed to update voucher date.",
            error: error.message
        });
    }
};