const db = require("../../../../config/db");

// ==========================================
// Get All Chart Details
// ==========================================
exports.getAllChartDetails = async (req, res) => {
    try {

        const [rows] = await db.query(`
            SELECT
                cd.id,
                cd.company_id,
                c.company_name,

                cd.chartofaccount_id,
                coa.account_name,

                cd.address,
                cd.province,
                cd.city,
                cd.cell_no,
                cd.income_tax_no,
                cd.group_no,

                cd.add_date,
                cd.update_date

            FROM ChartDetail cd

            INNER JOIN CompanyName c
                ON cd.company_id = c.id

            INNER JOIN ChartOfAccount coa
                ON cd.chartofaccount_id = coa.id

            ORDER BY coa.account_name
        `);

        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching Chart Details.",
            error: err.message
        });

    }
};

// ==========================================
// Get Chart Detail By Id
// ==========================================
exports.getChartDetailById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(`
            SELECT
                cd.*,
                c.company_name,
                coa.account_name

            FROM ChartDetail cd

            INNER JOIN CompanyName c
                ON cd.company_id = c.id

            INNER JOIN ChartOfAccount coa
                ON cd.chartofaccount_id = coa.id

            WHERE cd.id = ?
        `, [id]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Chart Detail not found."
            });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching Chart Detail.",
            error: err.message
        });

    }

};

// ==========================================
// Add Chart Detail
// ==========================================
exports.addChartDetail = async (req, res) => {

    try {

        const {
            company_id,
            chartofaccount_id,
            address,
            province,
            city,
            cell_no,
            income_tax_no,
            group_no
        } = req.body;

        if (!company_id || !chartofaccount_id) {
            return res.status(400).json({
                success: false,
                message: "Company and Chart Of Account are required."
            });
        }

        // Company Exists
        const [company] = await db.query(
            `SELECT id FROM CompanyName WHERE id=?`,
            [company_id]
        );

        if (company.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Company not found."
            });
        }

        // Chart Of Account Exists
        const [account] = await db.query(
            `SELECT company_id
             FROM ChartOfAccount
             WHERE id=?`,
            [chartofaccount_id]
        );

        if (account.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Chart Of Account not found."
            });
        }

        if (account[0].company_id != company_id) {
            return res.status(400).json({
                success: false,
                message: "Chart Of Account belongs to another company."
            });
        }

        // One Detail Per Account
        const [duplicate] = await db.query(
            `SELECT id
             FROM ChartDetail
             WHERE chartofaccount_id=?`,
            [chartofaccount_id]
        );

        if (duplicate.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Chart Detail already exists for this account."
            });
        }

        const [result] = await db.query(
            `INSERT INTO ChartDetail
            (
                company_id,
                chartofaccount_id,
                address,
                province,
                city,
                cell_no,
                income_tax_no,
                group_no
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                company_id,
                chartofaccount_id,
                address,
                province,
                city,
                cell_no,
                income_tax_no,
                group_no
            ]
        );

        const [newRow] = await db.query(
            `SELECT *
             FROM ChartDetail
             WHERE id=?`,
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            message: "Chart Detail added successfully.",
            data: newRow[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error adding Chart Detail.",
            error: err.message
        });

    }

};

// ==========================================
// Update Chart Detail
// ==========================================
exports.updateChartDetail = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            company_id,
            chartofaccount_id,
            address,
            province,
            city,
            cell_no,
            income_tax_no,
            group_no
        } = req.body;

        const [record] = await db.query(
            `SELECT id
             FROM ChartDetail
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Chart Detail not found."
            });
        }

        const [duplicate] = await db.query(
            `SELECT id
             FROM ChartDetail
             WHERE chartofaccount_id=?
             AND id<>?`,
            [chartofaccount_id, id]
        );

        if (duplicate.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Chart Detail already exists for this account."
            });
        }

        await db.query(
            `UPDATE ChartDetail
             SET
                company_id=?,
                chartofaccount_id=?,
                address=?,
                province=?,
                city=?,
                cell_no=?,
                income_tax_no=?,
                group_no=?
             WHERE id=?`,
            [
                company_id,
                chartofaccount_id,
                address,
                province,
                city,
                cell_no,
                income_tax_no,
                group_no,
                id
            ]
        );

        const [updated] = await db.query(
            `SELECT *
             FROM ChartDetail
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Chart Detail updated successfully.",
            data: updated[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error updating Chart Detail.",
            error: err.message
        });

    }

};

// ==========================================
// Delete Chart Detail
// ==========================================
exports.deleteChartDetail = async (req, res) => {

    try {

        const { id } = req.params;

        const [record] = await db.query(
            `SELECT id
             FROM ChartDetail
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Chart Detail not found."
            });
        }

        await db.query(
            `DELETE
             FROM ChartDetail
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Chart Detail deleted successfully."
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error deleting Chart Detail.",
            error: err.message
        });

    }

};