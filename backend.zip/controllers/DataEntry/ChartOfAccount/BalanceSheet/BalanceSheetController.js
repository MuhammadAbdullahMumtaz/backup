const db = require("../../../../config/db");

// ==========================================
// Get All Balance Sheets
// ==========================================
exports.getAllBalanceSheets = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                bs.id,
                bs.company_id,
                c.company_name,
                bs.details,
                bs.add_date,
                bs.update_date
            FROM BalanceSheet bs
            INNER JOIN CompanyName c
                ON bs.company_id = c.id
            ORDER BY bs.details ASC
        `);

        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (err) {
        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching balance sheets.",
            error: err.message
        });
    }
};

// ==========================================
// Get Balance Sheet By ID
// ==========================================
exports.getBalanceSheetById = async (req, res) => {
    try {

        const { id } = req.params;

        const [rows] = await db.query(`
            SELECT
                bs.id,
                bs.company_id,
                c.company_name,
                bs.details,
                bs.add_date,
                bs.update_date
            FROM BalanceSheet bs
            INNER JOIN CompanyName c
                ON bs.company_id = c.id
            WHERE bs.id = ?
        `, [id]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Balance Sheet not found."
            });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching balance sheet.",
            error: err.message
        });
    }
};

// ==========================================
// Add Balance Sheet
// ==========================================
exports.addBalanceSheet = async (req, res) => {

    try {

        const {
            company_id,
            details
        } = req.body;

        if (!company_id || !details) {
            return res.status(400).json({
                success: false,
                message: "Company and Details are required."
            });
        }

        // Company Exists
        const [company] = await db.query(
            `SELECT id FROM CompanyName WHERE id=?`,
            [company_id]
        );

        if (company.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Company not found."
            });
        }

        // Duplicate Check
        const [exist] = await db.query(
            `SELECT id
             FROM BalanceSheet
             WHERE company_id = ?
             AND details = ?`,
            [company_id, details]
        );

        if (exist.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Balance Sheet already exists."
            });
        }

        const [result] = await db.query(
            `INSERT INTO BalanceSheet
            (company_id, details)
            VALUES (?, ?)`,
            [company_id, details]
        );

        const [newRow] = await db.query(
            `SELECT *
             FROM BalanceSheet
             WHERE id=?`,
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            message: "Balance Sheet added successfully.",
            data: newRow[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error adding balance sheet.",
            error: err.message
        });

    }
};

// ==========================================
// Update Balance Sheet
// ==========================================
exports.updateBalanceSheet = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            company_id,
            details
        } = req.body;

        const [record] = await db.query(
            `SELECT id
             FROM BalanceSheet
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Balance Sheet not found."
            });
        }

        // Duplicate Check
        const [duplicate] = await db.query(
            `SELECT id
             FROM BalanceSheet
             WHERE company_id=?
             AND details=?
             AND id<>?`,
            [company_id, details, id]
        );

        if (duplicate.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Another Balance Sheet already exists."
            });
        }

        await db.query(
            `UPDATE BalanceSheet
            SET
                company_id=?,
                details=?
            WHERE id=?`,
            [
                company_id,
                details,
                id
            ]
        );

        const [updated] = await db.query(
            `SELECT *
             FROM BalanceSheet
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Balance Sheet updated successfully.",
            data: updated[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error updating balance sheet.",
            error: err.message
        });

    }

};

// ==========================================
// Delete Balance Sheet
// ==========================================
exports.deleteBalanceSheet = async (req, res) => {

    try {

        const { id } = req.params;

        const [record] = await db.query(
            `SELECT id
             FROM BalanceSheet
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Balance Sheet not found."
            });
        }

        await db.query(
            `DELETE
             FROM BalanceSheet
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Balance Sheet deleted successfully."
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error deleting balance sheet.",
            error: err.message
        });

    }

};