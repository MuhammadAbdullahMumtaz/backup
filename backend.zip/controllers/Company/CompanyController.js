const db = require("../../config/db");

// =============================
// Add Company
// =============================
exports.addCompany = async (req, res) => {
    try {

        const { company_name } = req.body;

        const [exist] = await db.query(
            "SELECT id FROM CompanyName WHERE company_name=?",
            [company_name]
        );

        if (exist.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Company already exists."
            });
        }

        await db.query(
            "INSERT INTO CompanyName(company_name) VALUES(?)",
            [company_name]
        );

        res.json({
            success: true,
            message: "Company Added Successfully"
        });

    } catch (err) {

        res.status(500).json(err);

    }
};


// =============================
// Update Company
// =============================
exports.updateCompany = async (req, res) => {

    try {

        const { id } = req.params;
        const { company_name } = req.body;

        await db.query(
            "UPDATE CompanyName SET company_name=? WHERE id=?",
            [company_name, id]
        );

        res.json({
            success: true,
            message: "Company Updated Successfully"
        });

    } catch (err) {

        res.status(500).json(err);

    }

};


// =============================
// Delete Company
// =============================
exports.deleteCompany = async (req, res) => {

    try {

        const { id } = req.params;

        await db.query(
            "DELETE FROM CompanyName WHERE id=?",
            [id]
        );

        res.json({
            success: true,
            message: "Company Deleted Successfully"
        });

    } catch (err) {

        res.status(500).json(err);

    }

};

// =============================
// Get All Companies
// =============================
exports.getCompanies = async (req, res) => {

    try {

        const [rows] = await db.query(
            `SELECT
                id,
                company_name,
                add_date,
                update_date
            FROM CompanyName
            ORDER BY company_name ASC`
        );

        res.json({
            success: true,
            data: rows
        });

    } catch (err) {

        res.status(500).json(err);

    }
};


// =============================
// Get Company By Id
// =============================
exports.getCompanyById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT
                id,
                company_name,
                add_date,
                update_date
            FROM CompanyName
            WHERE id=?`,
            [id]
        );

        if (rows.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Company Not Found"
            });

        }

        res.json({
            success: true,
            data: rows[0]
        });

    } catch (err) {

        res.status(500).json(err);

    }

};