require("dotenv").config();

const express = require("express");
const cors = require("cors");
const db = require("./config/db");

const app = express();

app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true,
  })
);

app.use(express.json());

app.use("/api/company", require("./routes/Compay/CompanyRoutes"));

app.use("/api/login", require("./routes/Logins/LoginsRoutes"));

app.use("/api/financial-year", require("./routes/FinancialYear/FinancialYearRoutes"));

// Chart of Account Routes
app.use("/api/balance-sheet", require("./routes/DataEntry/ChartOfAccount/BalanceSheet/BalanceSheetRoutes"));

app.use("/api/main-code", require("./routes/DataEntry/ChartOfAccount/MainCode/MainCodeRoutes"));

app.use("/api/sub-code", require("./routes/DataEntry/ChartOfAccount/SubCode/SubCodeRoutes"));

app.use("/api/chart-of-account", require("./routes/DataEntry/ChartOfAccount/ChartAccount/ChartOfAccountRoutes"));

app.use("/api/chart-detail", require("./routes/DataEntry/ChartOfAccount/ChartDetail/ChartDetailRoutes"));

app.use("/api/opening-balance", require("./routes/DataEntry/ChartOfAccount/OpeningBalance/OpeningBalanceRoutes"));

// Item Entry Routes
app.use("/api/main-item", require("./routes/DataEntry/ItemEntry/MainItem/MainItemRoutes"));

app.use("/api/sub-item", require("./routes/DataEntry/ItemEntry/SubItem/SubItemRoutes"));

app.use("/api/item-detail", require("./routes/DataEntry/ItemEntry/ItemDetail/ItemDetailRoutes"));

app.use("/api/item-opening", require("./routes/DataEntry/ItemEntry/ItemOpening/ItemOpeningRoutes"));


// Voucher Entry Routes
app.use("/api/voucher-type", require("./routes/DataEntry/VoucherEntry/VoucherType/VoucherTypeRoutes"));

app.use("/api/voucher-main", require("./routes/DataEntry/VoucherEntry/VoucherMain/VoucherMainRoutes"));

app.use("/api/voucher-detail", require("./routes/DataEntry/VoucherEntry/VoucherDetail/VoucherDetailRoutes"));


app.get("/", (req, res) => {
  res.send("API Running");
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server Started On ${PORT}`);
});