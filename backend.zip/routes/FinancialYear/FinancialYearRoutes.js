const express = require("express");

const router = express.Router();

const {
    addFinancialYear,
    getCurrentMonth,
    updateOnlyMonth,
    updateFinancialYear,
    deleteFinancialYear,
    getFinancialYears,
    getFinancialYearById
} = require("../../controllers/FinancialYear/FinancialYearController");

router.get("/", getFinancialYears);

router.get("/current-month/:id", getCurrentMonth);

router.patch("/update-month/:id", updateOnlyMonth); 

router.get("/:id", getFinancialYearById);

router.post("/add", addFinancialYear);

router.put("/update/:id", updateFinancialYear);

router.delete("/delete/:id", deleteFinancialYear);

module.exports = router;