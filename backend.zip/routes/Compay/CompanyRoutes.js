const express = require("express");

const router = express.Router();

const {
    addCompany,
    updateCompany,
    deleteCompany,
    getCompanies,
    getCompanyById
} = require("../../controllers/Company/CompanyController");

router.get("/", getCompanies);

router.get("/:id", getCompanyById);

router.post("/add", addCompany);

router.put("/update/:id", updateCompany);

router.delete("/delete/:id", deleteCompany);

module.exports = router;