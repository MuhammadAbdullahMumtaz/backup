const express = require("express");

const router = express.Router();

const {
    getAllMainItems,
    getMainItemById,
    addMainItem,
    updateMainItem,
    deleteMainItem
} = require("../../../../controllers/DataEntry/ItemEntry/MainItem/MainItemController");


// Get All
router.get("/", getAllMainItems);

// Get By ID
router.get("/:id", getMainItemById);

// Add
router.post("/", addMainItem);

// Update
router.put("/:id", updateMainItem);

// Delete
router.delete("/:id", deleteMainItem);

module.exports = router;