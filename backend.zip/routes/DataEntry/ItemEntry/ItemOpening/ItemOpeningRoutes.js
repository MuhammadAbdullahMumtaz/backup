const express = require("express");
const router = express.Router();

const {
    getAllItemOpenings,
    getItemOpeningById,
    addItemOpening,
    updateItemOpening,
    deleteItemOpening
} = require("../../../../controllers/DataEntry/ItemEntry/ItemOpening/ItemOpeningController");

// ==========================================
// Item Opening Routes
// ==========================================

// Get All Item Openings
router.get("/", getAllItemOpenings);

// Get Item Opening By ID
router.get("/:id", getItemOpeningById);

// Add Item Opening
router.post("/add", addItemOpening);

// Update Item Opening
router.put("/update/:id", updateItemOpening);

// Delete Item Opening
router.delete("/delete/:id", deleteItemOpening);

module.exports = router;