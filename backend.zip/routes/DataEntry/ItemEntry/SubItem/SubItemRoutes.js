const express = require("express");

const router = express.Router();

const {

    getAllSubItems,
    getSubItemById,
    addSubItem,
    updateSubItem,
    deleteSubItem

} = require("../../../../controllers/DataEntry/ItemEntry/SubItem/SubItemController");


// Get All
router.get("/", getAllSubItems);

// Get By ID
router.get("/:id", getSubItemById);

// Add
router.post("/", addSubItem);

// Update
router.put("/:id", updateSubItem);

// Delete
router.delete("/:id", deleteSubItem);

module.exports = router;