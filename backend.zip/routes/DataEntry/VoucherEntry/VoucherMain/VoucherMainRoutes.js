const express = require("express");
const router = express.Router();

const {
    getAllVoucherMains,
    getNextVoucherNumber,
    getVoucherMainById,
    addVoucherMain,
    updateVoucherMain,
    deleteVoucherMain,
    updateVoucherDate
} = require("../../../../controllers/DataEntry/VoucherEntry/VoucherMain/VoucherMainController");


// ==========================================
// Voucher Main Routes
// ==========================================

// Get All
router.get("/", getAllVoucherMains);

// Get Next Voucher
router.get("/:company_id/:financialyear_id/:vouchertype_id", getNextVoucherNumber);

// Get By ID
router.get("/:id", getVoucherMainById);

// Insert
router.post("/", addVoucherMain);

// Update
router.put("/:id", updateVoucherMain);

// Update Voucher Date
router.patch("/:id/date", updateVoucherDate);

// Delete
router.delete("/:id", deleteVoucherMain);

module.exports = router;