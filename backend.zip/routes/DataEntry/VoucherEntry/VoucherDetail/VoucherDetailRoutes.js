const express = require("express");
const router = express.Router();

const {
    getAllVoucherDetails,
    getVoucherDetailById,
    addVoucherDetail,
    updateVoucherDetail,
    deleteVoucherDetail
} = require("../../../../controllers/DataEntry/VoucherEntry/VoucherDetail/VoucherDetailController");


// ==========================================
// Voucher Detail Routes
// ==========================================

// Get All
router.get("/", getAllVoucherDetails);

// Get By ID
router.get("/:id", getVoucherDetailById);

// Insert
router.post("/", addVoucherDetail);

// Update
router.put("/:id", updateVoucherDetail);

// Delete
router.delete("/:id", deleteVoucherDetail);

module.exports = router;