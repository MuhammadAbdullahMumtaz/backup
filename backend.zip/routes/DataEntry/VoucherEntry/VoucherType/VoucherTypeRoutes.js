const express = require("express");
const router = express.Router();

const {
    getAllVoucherTypes,
    getVoucherTypeById,
    addVoucherType,
    updateVoucherType,
    deleteVoucherType
} = require("../../../../controllers/DataEntry/VoucherEntry/VoucherType/VoucherTypeController");


// ==========================================
// Voucher Type Routes
// ==========================================

// Get All
router.get("/", getAllVoucherTypes);

// Get By ID
router.get("/:id", getVoucherTypeById);

// Insert
router.post("/", addVoucherType);

// Update
router.put("/:id", updateVoucherType);

// Delete
router.delete("/:id", deleteVoucherType);

module.exports = router;