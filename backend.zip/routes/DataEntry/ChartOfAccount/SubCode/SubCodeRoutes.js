const express = require("express");

const router = express.Router();

const {
    getAllSubCodes,
    getSubCodeById,
    addSubCode,
    updateSubCode,
    deleteSubCode
} = require("../../../../controllers/DataEntry/ChartOfAccount/SubCode/SubCodeController");

router.get("/", getAllSubCodes);

router.get("/:id", getSubCodeById);

router.post("/", addSubCode);

router.put("/:id", updateSubCode);

router.delete("/:id", deleteSubCode);

module.exports = router;