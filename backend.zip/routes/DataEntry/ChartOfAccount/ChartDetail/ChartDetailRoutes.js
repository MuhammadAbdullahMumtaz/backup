const express = require("express");

const router = express.Router();

const {

    getAllChartDetails,
    getChartDetailById,
    addChartDetail,
    updateChartDetail,
    deleteChartDetail

} = require("../../../../controllers/DataEntry/ChartOfAccount/ChartDetail/ChartDetailController");

router.get("/", getAllChartDetails);

router.get("/:id", getChartDetailById);

router.post("/", addChartDetail);

router.put("/:id", updateChartDetail);

router.delete("/:id", deleteChartDetail);

module.exports = router;