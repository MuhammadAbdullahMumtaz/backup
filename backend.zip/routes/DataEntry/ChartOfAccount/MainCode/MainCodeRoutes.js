const express = require("express");
const router = express.Router();

const {
    getAllMainCodes,
    getMainCodeById,
    addMainCode,
    updateMainCode,
    deleteMainCode
} = require("../../../../controllers/DataEntry/ChartOfAccount/MainCode/MainCodeController");

router.get("/", getAllMainCodes);

router.get("/:id", getMainCodeById);

router.post("/", addMainCode);

router.put("/:id", updateMainCode);

router.delete("/:id", deleteMainCode);

module.exports = router;