const express = require("express");
const router = express.Router();

const {
    getAllBalanceSheets,
    getBalanceSheetById,
    addBalanceSheet,
    updateBalanceSheet,
    deleteBalanceSheet
} = require("../../../../controllers/DataEntry/ChartOfAccount/BalanceSheet/BalanceSheetController");

// GET
router.get("/", getAllBalanceSheets);

// GET BY ID
router.get("/:id", getBalanceSheetById);

// POST
router.post("/", addBalanceSheet);

// PUT
router.put("/:id", updateBalanceSheet);

// DELETE
router.delete("/:id", deleteBalanceSheet);

module.exports = router;