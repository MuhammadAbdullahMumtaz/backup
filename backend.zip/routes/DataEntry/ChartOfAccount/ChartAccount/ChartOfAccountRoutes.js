const express = require("express");

const router = express.Router();

const {

    getAllChartOfAccounts,
    getChartOfAccountById,
    addChartOfAccount,
    updateChartOfAccount,
    deleteChartOfAccount

} = require("../../../../controllers/DataEntry/ChartOfAccount/ChartAccount/ChartOfAccountController");

router.get("/", getAllChartOfAccounts);

router.get("/:id", getChartOfAccountById);

router.post("/", addChartOfAccount);

router.put("/:id", updateChartOfAccount);

router.delete("/:id", deleteChartOfAccount);

module.exports = router;