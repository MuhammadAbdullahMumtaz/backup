const express = require("express");

const router = express.Router();

const {

    getAllOpeningBalances,
    getOpeningBalanceById,
    addOpeningBalance,
    updateOpeningBalance,
    deleteOpeningBalance

} = require("../../../../controllers/DataEntry/ChartOfAccount/OpeningBalance/OpeningBalanceController");

router.get("/", getAllOpeningBalances);

router.get("/:id", getOpeningBalanceById);

router.post("/", addOpeningBalance);

router.put("/:id", updateOpeningBalance);

router.delete("/:id", deleteOpeningBalance);

module.exports = router;