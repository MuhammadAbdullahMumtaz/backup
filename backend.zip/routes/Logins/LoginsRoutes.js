const express = require("express");

const router = express.Router();

const {
    addLogin,
    updateLogin,
    deleteLogin,
    getLogins,
    getLoginById,
    loginUser
} = require("../../controllers/Logins/LoginsController");

router.get("/", getLogins);

router.get("/:id", getLoginById);

router.post("/add", addLogin);

router.put("/update/:id", updateLogin);

router.delete("/delete/:id", deleteLogin);

router.post("/login", loginUser);

module.exports = router;