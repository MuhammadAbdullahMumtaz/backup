$(function(){
    var navbar = $('.navbar');
    $(window).scroll(function(){
      if($(window).scrollTop() <=10)
      {
        navbar.removeClass('nav-scroll');
      }
      else
      {
        navbar.addClass('nav-scroll');
      }
    });
    });

    const nav = document.querySelector('.nav-links');
    const line_01 = document.querySelector('.line-01');
    const line_02 = document.querySelector('.line-02');
    const line_03 = document.querySelector('.line-03');
    const img = document.querySelector('.cross-image');
    function showMenu(){
        nav.classList.toggle('translate-x-[0rem]');
        nav.classList.toggle('duration-500');
        img.classList.toggle('visible');
        line_01.classList.toggle('hidden');
        line_02.classList.toggle('hidden');
        line_03.classList.toggle('hidden');
      }