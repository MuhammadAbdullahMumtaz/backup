var typed = new Typed(".auto-type", {
    strings: ["your business performance", "your uplift", "inventory management", "personalization", "mulitistores management", "business analysis", "account accuracy", "customer relationship management", "return on investement", "business flow", "time to value", "company's finantials"],
    typeSpeed: 70,
    backSpeed: 20,
    loop: true
});
