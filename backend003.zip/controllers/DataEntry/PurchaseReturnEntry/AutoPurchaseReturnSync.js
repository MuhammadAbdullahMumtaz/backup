const db = require("../../../config/db");

async function syncAutoEntriesForPurchaseReturnMain(userPurchaseReturnMainId) {
    const warnings = [];
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        const [mainRows] = await connection.query(
            `SELECT id, company_id, financialyear_id, return_no, return_date,
                    gp_no, gp_date, invoice_no, invoice_date, supplier_code
             FROM PurchaseReturnMain
             WHERE id = ? AND entry = 'user'
             FOR UPDATE`,
            [userPurchaseReturnMainId]
        );

        if (mainRows.length === 0) {
            await connection.commit();
            return { warnings };
        }
        const userMain = mainRows[0];

        const [detailRows] = await connection.query(
            `SELECT prd.Item_code, prd.pieces, prd.gross_weight, prd.tear_weight,
                    prd.net_weight, prd.rate, prd.amount, prd.gst_percent,
                    prd.gst_amount, prd.further_tax_rate, prd.further_tax_amount,
                    prd.other_tax, prd.total,
                    si.details AS subitem_details, coa.code AS account_code
             FROM PurchaseReturnDetail prd
             INNER JOIN ItemDetail i
                ON prd.Item_code = i.code AND prd.company_id = i.company_id
             INNER JOIN SubItem si
                ON i.subitem_id = si.id
             LEFT JOIN ChartOfAccount coa
                ON si.GL_purchase = coa.code AND coa.company_id = prd.company_id
             WHERE prd.purchasereturnmain_id = ? AND prd.entry = 'user'`,
            [userPurchaseReturnMainId]
        );

        const groups = new Map(); // account_code -> detail rows
        for (const row of detailRows) {
            if (!row.account_code) {
                warnings.push(
                    `Item "${row.Item_code}" (Sub Item "${row.subitem_details}") has no GL Purchase account configured - skipped in auto entry.`
                );
                continue;
            }
            if (!groups.has(row.account_code)) groups.set(row.account_code, []);
            groups.get(row.account_code).push(row);
        }

        const [existingAutoMains] = await connection.query(
            `SELECT id, supplier_code
             FROM PurchaseReturnMain
             WHERE company_id = ? AND financialyear_id = ? AND return_no = ? AND entry = 'auto'`,
            [userMain.company_id, userMain.financialyear_id, userMain.return_no]
        );
        const existingByCode = new Map(existingAutoMains.map((m) => [m.supplier_code, m.id]));

        // Drop auto mains whose account code is no longer represented
        for (const [code, id] of existingByCode) {
            if (!groups.has(code)) {
                await connection.query(`DELETE FROM PurchaseReturnDetail WHERE purchasereturnmain_id = ?`, [id]);
                await connection.query(`DELETE FROM PurchaseReturnMain WHERE id = ?`, [id]);
                existingByCode.delete(code);
            }
        }

        for (const [code, rows] of groups) {
            // Guard: (company_id, financialyear_id, return_no, supplier_code) is
            // unique on PurchaseReturnMain. If an item's GL account happens to equal
            // this return's own supplier code, that slot is already taken by
            // the user row - creating an auto row there would collide.
            if (!existingByCode.has(code) && String(userMain.supplier_code) === String(code)) {
                warnings.push(
                    `GL Purchase account "${code}" matches this return's own supplier - its items were skipped in auto entry to avoid a duplicate entry.`
                );
                continue;
            }

            let autoMainId = existingByCode.get(code);

            try {
                if (autoMainId) {
                    await connection.query(
                        `UPDATE PurchaseReturnMain
                         SET return_date = ?, gp_no = ?, gp_date = ?, invoice_no = ?, invoice_date = ?
                         WHERE id = ?`,
                        [userMain.return_date, userMain.gp_no, userMain.gp_date,
                         userMain.invoice_no, userMain.invoice_date, autoMainId]
                    );
                    await connection.query(`DELETE FROM PurchaseReturnDetail WHERE purchasereturnmain_id = ?`, [autoMainId]);
                } else {
                    const [insertResult] = await connection.query(
                        `INSERT INTO PurchaseReturnMain
                            (company_id, financialyear_id, return_no, return_date, gp_no, gp_date,
                             supplier_code, invoice_no, invoice_date, freight, entry)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'auto')`,
                        [userMain.company_id, userMain.financialyear_id, userMain.return_no, userMain.return_date,
                         userMain.gp_no, userMain.gp_date, code, userMain.invoice_no, userMain.invoice_date]
                    );
                    autoMainId = insertResult.insertId;
                }
            } catch (err) {
                if (err.code === "ER_DUP_ENTRY") {
                    warnings.push(`Could not create auto entry for GL Purchase account "${code}" - a conflicting entry already exists.`);
                    continue;
                }
                throw err;
            }

            let entryNo = 1;
            for (const row of rows) {
                await connection.query(
                    `INSERT INTO PurchaseReturnDetail
                        (company_id, purchasereturnmain_id, financialyear_id, Item_code, entry_no, entry,
                         pieces, gross_weight, tear_weight, net_weight, rate, amount, freight,
                         gst_percent, gst_amount, further_tax_rate, further_tax_amount, other_tax, total)
                     VALUES (?, ?, ?, ?, ?, 'auto', ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?)`,
                    [userMain.company_id, autoMainId, userMain.financialyear_id, row.Item_code, entryNo++,
                     row.pieces, row.gross_weight, row.tear_weight, row.net_weight, row.rate, row.amount,
                     row.gst_percent, row.gst_amount, row.further_tax_rate, row.further_tax_amount,
                     row.other_tax, row.total]
                );
            }
        }

        await connection.commit();
        return { warnings };
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
}

async function deleteAutoEntriesForReturn(connection, { company_id, financialyear_id, return_no }) {
    const [autoMains] = await connection.query(
        `SELECT id FROM PurchaseReturnMain
         WHERE company_id = ? AND financialyear_id = ? AND return_no = ? AND entry = 'auto'`,
        [company_id, financialyear_id, return_no]
    );
    for (const m of autoMains) {
        await connection.query(`DELETE FROM PurchaseReturnDetail WHERE purchasereturnmain_id = ?`, [m.id]);
        await connection.query(`DELETE FROM PurchaseReturnMain WHERE id = ?`, [m.id]);
    }
}

module.exports = {
    syncAutoEntriesForPurchaseReturnMain,
    deleteAutoEntriesForReturn,
};