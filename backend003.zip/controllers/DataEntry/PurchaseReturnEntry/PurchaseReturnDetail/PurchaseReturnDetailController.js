const db = require("../../../../config/db");
const { syncAutoEntriesForPurchaseReturnMain } = require("../AutoPurchaseReturnSync");

// ======================================================
// Get All Purchase Return Details
// ======================================================
exports.getAllPurchaseReturnDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                prd.id,
                prd.company_id,
                c.company_name,
                prd.purchasereturnmain_id,
                prm.return_no,
                prd.financialyear_id,
                fy.year_detail,
                prd.Item_code,
                item.details AS item_name,
                prd.entry_no,
                prd.pieces,
                prd.gross_weight,
                prd.tear_weight,
                prd.net_weight,
                prd.rate,
                prd.amount,
                prd.freight,
                prd.total,
                prd.add_date,
                prd.update_date
            FROM PurchaseReturnDetail prd
            INNER JOIN CompanyName c
                ON prd.company_id = c.id
            INNER JOIN PurchaseReturnMain prm
                ON prd.purchasereturnmain_id = prm.id
            INNER JOIN FinancialYear fy
                ON prd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON prd.Item_code = item.code AND prd.company_id = item.company_id
            ORDER BY
                prm.return_no,
                prd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching purchase return details:", error);
        res.status(500).json({
            message: "Failed to fetch purchase return details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Purchase Return Details By Purchase Return Main ID
// ======================================================
exports.getPurchaseReturnDetailsByPurchaseReturnMain = async (req, res) => {
    try {
        const { purchasereturnmain_id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                prd.id,
                prd.company_id,
                c.company_name,
                prd.purchasereturnmain_id,
                prm.return_no,
                prd.financialyear_id,
                fy.year_detail,
                prd.Item_code,
                item.details AS item_name,
                prd.entry_no,
                prd.pieces,
                prd.gross_weight,
                prd.tear_weight,
                prd.net_weight,
                prd.rate,
                prd.amount,
                prd.freight,
                prd.total,
                prd.add_date,
                prd.update_date
            FROM PurchaseReturnDetail prd
            INNER JOIN CompanyName c
                ON prd.company_id = c.id
            INNER JOIN PurchaseReturnMain prm
                ON prd.purchasereturnmain_id = prm.id
            INNER JOIN FinancialYear fy
                ON prd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON prd.Item_code = item.code AND prd.company_id = item.company_id
            WHERE prd.purchasereturnmain_id = ?
            ORDER BY prd.entry_no ASC
            `,
            [purchasereturnmain_id]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching purchase return details by return:", error);
        res.status(500).json({
            message: "Failed to fetch purchase return details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Purchase Return Detail By ID
// ======================================================
exports.getPurchaseReturnDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                prd.id,
                prd.company_id,
                c.company_name,
                prd.purchasereturnmain_id,
                prm.return_no,
                prd.financialyear_id,
                fy.year_detail,
                prd.Item_code,
                item.details AS item_name,
                prd.entry_no,
                prd.pieces,
                prd.gross_weight,
                prd.tear_weight,
                prd.net_weight,
                prd.rate,
                prd.amount,
                prd.freight,
                prd.total,
                prd.add_date,
                prd.update_date
            FROM PurchaseReturnDetail prd
            INNER JOIN CompanyName c
                ON prd.company_id = c.id
            INNER JOIN PurchaseReturnMain prm
                ON prd.purchasereturnmain_id = prm.id
            INNER JOIN FinancialYear fy
                ON prd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON prd.Item_code = item.code AND prd.company_id = item.company_id
            WHERE prd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Purchase return detail not found."
            });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching purchase return detail:", error);
        res.status(500).json({
            message: "Failed to fetch purchase return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Purchase Return Detail
// ======================================================
exports.addPurchaseReturnDetail = async (req, res) => {
    try {
        const {
            company_id,
            purchasereturnmain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            rate,
            freight,
            total
        } = req.body;

        // Validate required fields
        // NOTE: financialyear_id is NOT taken from req.body - it's always
        // derived from the parent PurchaseReturnMain row below, so it can never
        // drift out of sync with the return it belongs to.
        if (!company_id || !purchasereturnmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Purchase Return Main, Item Code, and Entry No are required."
            });
        }

        // Validate entry_no is positive
        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        // Validate Item_code length (matches VARCHAR(8) column)
        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const freightValue = parseFloat(freight) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({
                message: "Pieces cannot be negative."
            });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({
                message: "Net weight cannot be negative."
            });
        }
        if (rateValue < 0) {
            return res.status(400).json({
                message: "Rate cannot be negative."
            });
        }

        const amountValue = netWeightValue * rateValue;

        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue;

        // Check if purchase return exists, and pull its financialyear_id so this
        // detail row always inherits the parent return's financial year.
        const [returnCheck] = await db.query(
            `SELECT id, financialyear_id FROM PurchaseReturnMain WHERE id = ? AND company_id = ?`,
            [purchasereturnmain_id, company_id]
        );
        if (returnCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid purchase return for this company."
            });
        }
        const { financialyear_id } = returnCheck[0];

        // Check if item exists in item master
        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        const [result] = await db.query(
            `
            INSERT INTO PurchaseReturnDetail
            (
                company_id,
                purchasereturnmain_id,
                financialyear_id,
                Item_code,
                entry_no,
                pieces,
                gross_weight,
                tear_weight,
                net_weight,
                rate,
                amount,
                freight,
                total
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
                company_id,
                purchasereturnmain_id,
                financialyear_id,
                Item_code,
                entry_no,
                piecesValue,
                grossWeightValue,
                tearWeightValue,
                netWeightValue,
                rateValue,
                amountValue,
                freightValue,
                totalValue
            ]
        );

        let warnings = [];
        try {
            const syncResult = await syncAutoEntriesForPurchaseReturnMain(purchasereturnmain_id);
            warnings = syncResult.warnings;
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Purchase return entry was saved, but auto GL entries could not be fully synced.");
        }

        res.status(201).json({
            message: "Purchase return detail added successfully.",
            id: result.insertId,
            warnings
        });
    } catch (error) {
        console.error("Error adding purchase return detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this purchase return."
            });
        }
        res.status(500).json({
            message: "Failed to add purchase return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Purchase Return Detail
// ======================================================
exports.updatePurchaseReturnDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            purchasereturnmain_id,
            Item_code,
            entry_no,
            pieces,
            gross_weight,
            tear_weight,
            net_weight,
            rate,
            freight,
            total
        } = req.body;

        // Block direct edits of auto-generated rows, and remember which
        // return main this row belonged to before the update (it may move).
        const [existingRow] = await db.query(
            `SELECT purchasereturnmain_id, entry FROM PurchaseReturnDetail WHERE id = ?`,
            [id]
        );
        if (existingRow.length === 0) {
            return res.status(404).json({ message: "Purchase return detail not found." });
        }
        if (existingRow[0].entry === "auto") {
            return res.status(400).json({
                message: "Auto-generated entries cannot be edited directly."
            });
        }

        const oldPurchaseReturnMainId = existingRow[0].purchasereturnmain_id;
        if (!company_id || !purchasereturnmain_id || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Purchase Return Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const grossWeightValue = parseFloat(gross_weight) || 0;
        const tearWeightValue = parseFloat(tear_weight) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const freightValue = parseFloat(freight) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({
                message: "Pieces cannot be negative."
            });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({
                message: "Net weight cannot be negative."
            });
        }
        if (rateValue < 0) {
            return res.status(400).json({
                message: "Rate cannot be negative."
            });
        }

        const amountValue = netWeightValue * rateValue;
        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue;

        // Check if purchase return detail exists
        const [detailCheck] = await db.query(
            `SELECT id FROM PurchaseReturnDetail WHERE id = ?`,
            [id]
        );
        if (detailCheck.length === 0) {
            return res.status(404).json({
                message: "Purchase return detail not found."
            });
        }

        // Check if purchase return exists, and re-derive financialyear_id from it -
        // covers the case where purchasereturnmain_id itself changed on update.
        const [returnCheck] = await db.query(
            `SELECT id, financialyear_id FROM PurchaseReturnMain WHERE id = ? AND company_id = ?`,
            [purchasereturnmain_id, company_id]
        );
        if (returnCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid purchase return for this company."
            });
        }
        const { financialyear_id } = returnCheck[0];

        // Check if item exists
        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        await db.query(
            `
            UPDATE PurchaseReturnDetail
            SET
                company_id = ?,
                purchasereturnmain_id = ?,
                financialyear_id = ?,
                Item_code = ?,
                entry_no = ?,
                pieces = ?,
                gross_weight = ?,
                tear_weight = ?,
                net_weight = ?,
                rate = ?,
                amount = ?,
                freight = ?,
                total = ?
            WHERE id = ?
            `,
            [
                company_id,
                purchasereturnmain_id,
                financialyear_id,
                Item_code,
                entry_no,
                piecesValue,
                grossWeightValue,
                tearWeightValue,
                netWeightValue,
                rateValue,
                amountValue,
                freightValue,
                totalValue,
                id
            ]
        );

        let warnings = [];
        try {
            if (oldPurchaseReturnMainId && Number(oldPurchaseReturnMainId) !== Number(purchasereturnmain_id)) {
                const oldSync = await syncAutoEntriesForPurchaseReturnMain(oldPurchaseReturnMainId);
                warnings.push(...oldSync.warnings);
            }
            const newSync = await syncAutoEntriesForPurchaseReturnMain(purchasereturnmain_id);
            warnings.push(...newSync.warnings);
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Entry was updated, but auto GL entries could not be fully synced.");
        }

        res.status(200).json({
            message: "Purchase return detail updated successfully.",
            warnings
        });

    } catch (error) {
        console.error("Error updating purchase return detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this purchase return."
            });
        }
        res.status(500).json({
            message: "Failed to update purchase return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Purchase Return Detail
// ======================================================
exports.deletePurchaseReturnDetail = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT purchasereturnmain_id, entry FROM PurchaseReturnDetail WHERE id = ?`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Purchase return detail not found." });
        }
        const { purchasereturnmain_id, entry } = rows[0];

        if (entry === "auto") {
            return res.status(400).json({
                message: "Auto-generated entries cannot be deleted directly. Delete or edit the corresponding user entry instead."
            });
        }

        const [result] = await db.query(`DELETE FROM PurchaseReturnDetail WHERE id = ?`, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Purchase return detail not found." });
        }

        let warnings = [];
        try {
            const syncResult = await syncAutoEntriesForPurchaseReturnMain(purchasereturnmain_id);
            warnings = syncResult.warnings;
        } catch (syncError) {
            console.error("Error syncing auto entries:", syncError);
            warnings.push("Entry was deleted, but auto GL entries could not be fully synced.");
        }

        res.status(200).json({ message: "Purchase return detail deleted successfully.", warnings });
    } catch (error) {
        console.error("Error deleting purchase return detail:", error);
        res.status(500).json({
            message: "Failed to delete purchase return detail.",
            error: error.message
        });
    }
};