const db = require("../../../config/db");
// adjust the path above to wherever this file actually sits relative to
// controllers/purchase/main and controllers/purchase/detail

async function syncAutoEntriesForPurchaseMain(userPurchaseMainId) {
    const warnings = [];
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        const [mainRows] = await connection.query(
            `SELECT id, company_id, financialyear_id, grn_no, grn_date,
                    gp_no, gp_date, invoice_no, invoice_date, supplier_code
             FROM PurchaseMain
             WHERE id = ? AND entry = 'user'
             FOR UPDATE`,
            [userPurchaseMainId]
        );

        if (mainRows.length === 0) {
            await connection.commit();
            return { warnings };
        }
        const userMain = mainRows[0];

        const [detailRows] = await connection.query(
            `SELECT pd.Item_code, pd.pieces, pd.gross_weight, pd.tear_weight,
                    pd.net_weight, pd.rate, pd.amount, pd.total,
                    si.details AS subitem_details, coa.code AS account_code
             FROM PurchaseDetail pd
             INNER JOIN ItemDetail i
                ON pd.Item_code = i.code AND pd.company_id = i.company_id
             INNER JOIN SubItem si
                ON i.subitem_id = si.id
             LEFT JOIN ChartOfAccount coa
                ON si.GL_purchase = coa.code AND coa.company_id = pd.company_id
             WHERE pd.purchasemain_id = ? AND pd.entry = 'user'`,
            [userPurchaseMainId]
        );

        const groups = new Map(); // account_code -> detail rows
        for (const row of detailRows) {
            if (!row.account_code) {
                warnings.push(
                    `Item "${row.Item_code}" (Sub Item "${row.subitem_details}") has no GL Purchase account configured - skipped in auto entry.`
                );
                continue;
            }
            if (!groups.has(row.account_code)) groups.set(row.account_code, []);
            groups.get(row.account_code).push(row);
        }

        const [existingAutoMains] = await connection.query(
            `SELECT id, supplier_code
             FROM PurchaseMain
             WHERE company_id = ? AND financialyear_id = ? AND grn_no = ? AND entry = 'auto'`,
            [userMain.company_id, userMain.financialyear_id, userMain.grn_no]
        );
        const existingByCode = new Map(existingAutoMains.map((m) => [m.supplier_code, m.id]));

        // Drop auto mains whose account code is no longer represented
        for (const [code, id] of existingByCode) {
            if (!groups.has(code)) {
                await connection.query(`DELETE FROM PurchaseDetail WHERE purchasemain_id = ?`, [id]);
                await connection.query(`DELETE FROM PurchaseMain WHERE id = ?`, [id]);
                existingByCode.delete(code);
            }
        }

        for (const [code, rows] of groups) {
            // Guard: (company_id, financialyear_id, grn_no, supplier_code) is
            // unique on PurchaseMain. If an item's GL account happens to equal
            // this purchase's own supplier code, that slot is already taken by
            // the user row - creating an auto row there would collide.
            if (!existingByCode.has(code) && String(userMain.supplier_code) === String(code)) {
                warnings.push(
                    `GL Purchase account "${code}" matches this purchase's own supplier - its items were skipped in auto entry to avoid a duplicate entry.`
                );
                continue;
            }

            let autoMainId = existingByCode.get(code);

            try {
                if (autoMainId) {
                    await connection.query(
                        `UPDATE PurchaseMain
                         SET grn_date = ?, gp_no = ?, gp_date = ?, invoice_no = ?, invoice_date = ?
                         WHERE id = ?`,
                        [userMain.grn_date, userMain.gp_no, userMain.gp_date,
                         userMain.invoice_no, userMain.invoice_date, autoMainId]
                    );
                    await connection.query(`DELETE FROM PurchaseDetail WHERE purchasemain_id = ?`, [autoMainId]);
                } else {
                    const [insertResult] = await connection.query(
                        `INSERT INTO PurchaseMain
                            (company_id, financialyear_id, grn_no, grn_date, gp_no, gp_date,
                             supplier_code, invoice_no, invoice_date, freight, entry)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'auto')`,
                        [userMain.company_id, userMain.financialyear_id, userMain.grn_no, userMain.grn_date,
                         userMain.gp_no, userMain.gp_date, code, userMain.invoice_no, userMain.invoice_date]
                    );
                    autoMainId = insertResult.insertId;
                }
            } catch (err) {
                if (err.code === "ER_DUP_ENTRY") {
                    warnings.push(`Could not create auto entry for GL Purchase account "${code}" - a conflicting entry already exists.`);
                    continue;
                }
                throw err;
            }

            let entryNo = 1;
            for (const row of rows) {
                await connection.query(
                    `INSERT INTO PurchaseDetail
                        (company_id, purchasemain_id, financialyear_id, Item_code, entry_no, entry,
                         pieces, gross_weight, tear_weight, net_weight, rate, amount, freight, total)
                     VALUES (?, ?, ?, ?, ?, 'auto', ?, ?, ?, ?, ?, ?, 0, ?)`,
                    [userMain.company_id, autoMainId, userMain.financialyear_id, row.Item_code, entryNo++,
                     row.pieces, row.gross_weight, row.tear_weight, row.net_weight, row.rate, row.amount,
                     row.total]
                );
            }
        }

        await connection.commit();
        return { warnings };
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
}

async function deleteAutoEntriesForGrn(connection, { company_id, financialyear_id, grn_no }) {
    const [autoMains] = await connection.query(
        `SELECT id FROM PurchaseMain
         WHERE company_id = ? AND financialyear_id = ? AND grn_no = ? AND entry = 'auto'`,
        [company_id, financialyear_id, grn_no]
    );
    for (const m of autoMains) {
        await connection.query(`DELETE FROM PurchaseDetail WHERE purchasemain_id = ?`, [m.id]);
        await connection.query(`DELETE FROM PurchaseMain WHERE id = ?`, [m.id]);
    }
}

module.exports = {
    syncAutoEntriesForPurchaseMain,
    deleteAutoEntriesForGrn,
};