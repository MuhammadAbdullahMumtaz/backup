const db = require("../../../../config/db");


// Recomputes total debit/credit for a voucher's line items and syncs
// VoucherMain.isBalanced so the flag never drifts from the actual data.
// Called after every insert/update/delete of a VoucherDetail row.
const syncVoucherBalanceStatus = async (vouchermain_id) => {
    const [rows] = await db.query(
        `
        SELECT
            SUM(debit) as total_debit,
            SUM(credit) as total_credit
        FROM VoucherDetail
        WHERE vouchermain_id = ?
        `,
        [vouchermain_id]
    );

    const totalDebit = parseFloat(rows[0].total_debit) || 0;
    const totalCredit = parseFloat(rows[0].total_credit) || 0;
    const balanced = totalDebit > 0 && totalDebit === totalCredit;

    await db.query(
        `UPDATE VoucherMain SET isBalanced = ? WHERE id = ?`,
        [balanced ? 'Balanced' : 'Unbalanced', vouchermain_id]
    );
};
// ======================================================
// Get All Voucher Details
// ======================================================
exports.getAllVoucherDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                vd.id,
                vd.company_id,
                c.company_name,
                vd.vouchermain_id,
                vm.voucher_no,
                vd.financialyear_id,
                fy.year_detail,
                vd.voucher_month,
                vd.accountcode,
                coa.account_name,
                vd.entry_no,
                vd.narration,
                vd.debit,
                vd.credit,
                vd.cheque_no,
                vd.cheque_date,
                vd.status,
                vd.created_at,
                vd.updated_at
            FROM VoucherDetail vd
            INNER JOIN CompanyName c
                ON vd.company_id = c.id
            INNER JOIN VoucherMain vm
                ON vd.vouchermain_id = vm.id
            INNER JOIN FinancialYear fy
                ON vd.financialyear_id = fy.id
            INNER JOIN ChartOfAccount coa
                ON vd.accountcode = coa.code
            ORDER BY
                vm.voucher_no,
                vd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching voucher details:", error);
        res.status(500).json({
            message: "Failed to fetch voucher details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Voucher Details By Voucher Main ID
// ======================================================
exports.getVoucherDetailsByVoucherMain = async (req, res) => {
    try {
        const { vouchermain_id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                vd.id,
                vd.company_id,
                c.company_name,
                vd.vouchermain_id,
                vm.voucher_no,
                vd.financialyear_id,
                fy.year_detail,
                vd.voucher_month,
                vd.accountcode,
                coa.account_name,
                vd.entry_no,
                vd.narration,
                vd.debit,
                vd.credit,
                vd.cheque_no,
                vd.cheque_date,
                vd.status,
                vd.created_at,
                vd.updated_at
            FROM VoucherDetail vd
            INNER JOIN CompanyName c
                ON vd.company_id = c.id
            INNER JOIN VoucherMain vm
                ON vd.vouchermain_id = vm.id
            INNER JOIN FinancialYear fy
                ON vd.financialyear_id = fy.id
            INNER JOIN ChartOfAccount coa
                ON vd.accountcode = coa.code
            WHERE vd.vouchermain_id = ?
            ORDER BY vd.entry_no ASC
            `,
            [vouchermain_id]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching voucher details by voucher:", error);
        res.status(500).json({
            message: "Failed to fetch voucher details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Voucher Detail By ID
// ======================================================
exports.getVoucherDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                vd.id,
                vd.company_id,
                c.company_name,
                vd.vouchermain_id,
                vm.voucher_no,
                vd.financialyear_id,
                fy.year_detail,
                vd.voucher_month,
                vd.accountcode,
                coa.account_name,
                vd.entry_no,
                vd.narration,
                vd.debit,
                vd.credit,
                vd.cheque_no,
                vd.cheque_date,
                vd.status,
                vd.created_at,
                vd.updated_at
            FROM VoucherDetail vd
            INNER JOIN CompanyName c
                ON vd.company_id = c.id
            INNER JOIN VoucherMain vm
                ON vd.vouchermain_id = vm.id
            INNER JOIN FinancialYear fy
                ON vd.financialyear_id = fy.id
            INNER JOIN ChartOfAccount coa
                ON vd.accountcode = coa.id
            WHERE vd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Voucher detail not found."
            });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching voucher detail:", error);
        res.status(500).json({
            message: "Failed to fetch voucher detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Voucher Detail
// ======================================================
exports.addVoucherDetail = async (req, res) => {
    try {
        const {
            company_id,
            vouchermain_id,
            accountcode,
            entry_no,
            narration,
            debit,
            credit,
            cheque_no,
            cheque_date,
            status
        } = req.body;

        // Validate required fields
        // NOTE: financialyear_id and voucher_month are NOT taken from req.body -
        // they are always derived from the parent VoucherMain row below, so they
        // can never drift out of sync with the voucher they belong to.
        if (!company_id || !vouchermain_id || !accountcode ||
            entry_no === undefined || entry_no === null || !status) {
            return res.status(400).json({
                message: "Company, Voucher Main, Account Code, Entry No, and Status are required."
            });
        }

        // Validate entry_no is positive
        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        // Validate account code range (9-digit)
        if (accountcode < 100000000 || accountcode > 999999999) {
            return res.status(400).json({
                message: "Account code must be a 9-digit number."
            });
        }

        // Validate debit and credit (either one or both can be zero, but not both positive)
        const debitValue = parseFloat(debit) || 0;
        const creditValue = parseFloat(credit) || 0;

        if (debitValue > 0 && creditValue > 0) {
            return res.status(400).json({
                message: "Both debit and credit cannot have positive values simultaneously."
            });
        }

        // Validate status
        const validStatuses = ['Pending', 'Approved', 'Rejected', 'Posted', 'Cancelled'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                message: "Invalid status. Allowed values: Pending, Approved, Rejected, Posted, Cancelled"
            });
        }

        // Validate cheque fields (if cheque_no is provided, cheque_date must also be provided)
        if (cheque_no && !cheque_date) {
            return res.status(400).json({
                message: "Cheque date is required when cheque number is provided."
            });
        }
        if (cheque_date && !cheque_no) {
            return res.status(400).json({
                message: "Cheque number is required when cheque date is provided."
            });
        }

        // Check if voucher exists, and pull its financialyear_id / voucher_month
        // so this detail row always inherits the parent voucher's year and month.
        const [voucherCheck] = await db.query(
            `SELECT id, financialyear_id, voucher_month FROM VoucherMain WHERE id = ? AND company_id = ?`,
            [vouchermain_id, company_id]
        );
        if (voucherCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid voucher for this company."
            });
        }
        const { financialyear_id, voucher_month } = voucherCheck[0];

        // Check if account exists in chart of accounts
        const [accountCheck] = await db.query(
            `SELECT code FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [accountcode, company_id]
        );
        if (accountCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid account code for this company."
            });
        }

        const [result] = await db.query(
            `
            INSERT INTO VoucherDetail
            (
                company_id,
                vouchermain_id,
                financialyear_id,
                accountcode,
                entry_no,
                narration,
                debit,
                credit,
                voucher_month,
                cheque_no,
                cheque_date,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
                company_id,
                vouchermain_id,
                financialyear_id,
                accountcode,
                entry_no,
                narration || null,
                debitValue,
                creditValue,
                voucher_month,
                cheque_no || null,
                cheque_date || null,
                status
            ]
        );

        await syncVoucherBalanceStatus(vouchermain_id);

        res.status(201).json({
            message: "Voucher detail added successfully.",
            id: result.insertId
        });
    } catch (error) {
        console.error("Error adding voucher detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this voucher."
            });
        }
        res.status(500).json({
            message: "Failed to add voucher detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Voucher Detail
// ======================================================
exports.updateVoucherDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            vouchermain_id,
            accountcode,
            entry_no,
            narration,
            debit,
            credit,
            cheque_no,
            cheque_date,
            status
        } = req.body;

        // Validate required fields
        if (!company_id || !vouchermain_id || !accountcode ||
            entry_no === undefined || entry_no === null || !status) {
            return res.status(400).json({
                message: "Company, Voucher Main, Account Code, Entry No, and Status are required."
            });
        }

        // Validate entry_no is positive
        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        // Validate account code range (9-digit)
        if (accountcode < 100000000 || accountcode > 999999999) {
            return res.status(400).json({
                message: "Account code must be a 9-digit number."
            });
        }

        // Validate debit and credit
        const debitValue = parseFloat(debit) || 0;
        const creditValue = parseFloat(credit) || 0;

        if (debitValue > 0 && creditValue > 0) {
            return res.status(400).json({
                message: "Both debit and credit cannot have positive values simultaneously."
            });
        }

        // Validate status
        const validStatuses = ['Pending', 'Approved', 'Rejected', 'Posted', 'Cancelled'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                message: "Invalid status. Allowed values: Pending, Approved, Rejected, Posted, Cancelled"
            });
        }

        // Validate cheque fields
        if (cheque_no && !cheque_date) {
            return res.status(400).json({
                message: "Cheque date is required when cheque number is provided."
            });
        }
        if (cheque_date && !cheque_no) {
            return res.status(400).json({
                message: "Cheque number is required when cheque date is provided."
            });
        }

        // Check if voucher detail exists
        const [detailCheck] = await db.query(
            `SELECT id, vouchermain_id FROM VoucherDetail WHERE id = ?`,   // CHANGED - added vouchermain_id
            [id]
        );
        if (detailCheck.length === 0) {
            return res.status(404).json({
                message: "Voucher detail not found."
            });
        }
        const oldVouchermainId = detailCheck[0].vouchermain_id;   // NEW


        // Check if voucher exists, and re-derive financialyear_id / voucher_month
        // from it - covers the case where vouchermain_id itself changed on update.
        const [voucherCheck] = await db.query(
            `SELECT id, financialyear_id, voucher_month FROM VoucherMain WHERE id = ? AND company_id = ?`,
            [vouchermain_id, company_id]
        );
        if (voucherCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid voucher for this company."
            });
        }
        const { financialyear_id, voucher_month } = voucherCheck[0];

        // Check if account exists in chart of accounts
        const [accountCheck] = await db.query(
            `SELECT id FROM ChartOfAccount WHERE code = ? AND company_id = ?`,
            [accountcode, company_id]
        );
        if (accountCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid account code for this company."
            });
        }

        await db.query(
            `
            UPDATE VoucherDetail
            SET
                company_id = ?,
                vouchermain_id = ?,
                financialyear_id = ?,
                accountcode = ?,
                entry_no = ?,
                narration = ?,
                debit = ?,
                credit = ?,
                voucher_month = ?,
                cheque_no = ?,
                cheque_date = ?,
                status = ?
            WHERE id = ?
            `,
            [
                company_id,
                vouchermain_id,
                financialyear_id,
                accountcode,
                entry_no,
                narration || null,
                debitValue,
                creditValue,
                voucher_month,
                cheque_no || null,
                cheque_date || null,
                status,
                id
            ]
        );

        // ...existing UPDATE query...

        await syncVoucherBalanceStatus(vouchermain_id);   // NEW
        if (Number(oldVouchermainId) !== Number(vouchermain_id)) {   // NEW - covers a detail row being moved to a different voucher
            await syncVoucherBalanceStatus(oldVouchermainId);
        }

        res.status(200).json({
            message: "Voucher detail updated successfully."
        });

    } catch (error) {
        console.error("Error updating voucher detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this voucher."
            });
        }
        res.status(500).json({
            message: "Failed to update voucher detail.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Voucher Detail
// ======================================================
exports.deleteVoucherDetail = async (req, res) => {
    try {
        const { id } = req.params;

        // Need the parent voucher's info before deleting, both to check
        // BillPayment and to resync balance after.
        const [detailRow] = await db.query(
            `
            SELECT
                vd.vouchermain_id,
                vd.company_id,
                vd.financialyear_id,
                vd.entry_no,
                vm.voucher_no
            FROM VoucherDetail vd
            INNER JOIN VoucherMain vm ON vd.vouchermain_id = vm.id
            WHERE vd.id = ?
            `,
            [id]
        );
        if (detailRow.length === 0) {
            return res.status(404).json({
                message: "Voucher detail not found."
            });
        }
        const { vouchermain_id, company_id, financialyear_id, entry_no, voucher_no } = detailRow[0];

        // Block deletion if this exact entry has already been used in a bill payment.
        const [billPaymentCheck] = await db.query(
            `
            SELECT id FROM BillPayment
            WHERE company_id = ?
              AND financialyear_id = ?
              AND voucher_no = ?
              AND voucher_entry_no = ?
            LIMIT 1
            `,
            [company_id, financialyear_id, voucher_no, entry_no]
        );
        if (billPaymentCheck.length > 0) {
            return res.status(409).json({
                message: "This entry cannot be deleted because it is referenced by a bill payment."
            });
        }

        const [result] = await db.query(
            `DELETE FROM VoucherDetail WHERE id = ?`,
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Voucher detail not found."
            });
        }

        await syncVoucherBalanceStatus(vouchermain_id);

        res.status(200).json({
            message: "Voucher detail deleted successfully."
        });
    } catch (error) {
        console.error("Error deleting voucher detail:", error);
        res.status(500).json({
            message: "Failed to delete voucher detail.",
            error: error.message
        });
    }
};

// ======================================================
// Validate Voucher Balance
// ======================================================
exports.validateVoucherBalance = async (req, res) => {
    try {
        const { vouchermain_id } = req.params;

        const [rows] = await db.query(
            `
            SELECT 
                SUM(debit) as total_debit,
                SUM(credit) as total_credit
            FROM VoucherDetail
            WHERE vouchermain_id = ?
            `,
            [vouchermain_id]
        );

        const totalDebit = parseFloat(rows[0].total_debit) || 0;
        const totalCredit = parseFloat(rows[0].total_credit) || 0;

        const isBalanced = totalDebit === totalCredit;

        res.status(200).json({
            vouchermain_id: parseInt(vouchermain_id),
            total_debit: totalDebit,
            total_credit: totalCredit,
            is_balanced: isBalanced,
            difference: Math.abs(totalDebit - totalCredit)
        });
    } catch (error) {
        console.error("Error validating voucher balance:", error);
        res.status(500).json({
            message: "Failed to validate voucher balance.",
            error: error.message
        });
    }
};