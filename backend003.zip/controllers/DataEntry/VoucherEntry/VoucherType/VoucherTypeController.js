const db = require("../../../../config/db");

// ======================================================
// Get All Voucher Types
// ======================================================
exports.getAllVoucherTypes = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                vt.id,
                vt.company_id,
                c.company_name,
                vt.type,
                vt.details,
                vt.created_at,
                vt.updated_at
            FROM VoucherType vt
            INNER JOIN CompanyName c
                ON vt.company_id = c.id
            ORDER BY vt.details ASC
        `);

        res.status(200).json(rows);

    } catch (error) {
        console.error("Error fetching voucher types:", error);
        res.status(500).json({
            message: "Failed to fetch voucher types.",
            error: error.message
        });
    }
};

// ======================================================
// Get Voucher Type By ID
// ======================================================
exports.getVoucherTypeById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                vt.id,
                vt.company_id,
                c.company_name,
                vt.type,
                vt.details,
                vt.created_at,
                vt.updated_at
            FROM VoucherType vt
            INNER JOIN CompanyName c
                ON vt.company_id = c.id
            WHERE vt.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Voucher type not found."
            });
        }

        res.status(200).json(rows[0]);

    } catch (error) {
        console.error("Error fetching voucher type:", error);
        res.status(500).json({
            message: "Failed to fetch voucher type.",
            error: error.message
        });
    }
};

// ======================================================
// Add Voucher Type
// ======================================================
exports.addVoucherType = async (req, res) => {
    try {
        const {
            company_id,
            type,
            details
        } = req.body;

        // Validate required fields
        if (!company_id || !type || !details) {
            return res.status(400).json({
                message: "Company, Type, and Details are required."
            });
        }

        const [result] = await db.query(
            `
            INSERT INTO VoucherType
            (
                company_id,
                type,
                details
            )
            VALUES (?, ?, ?)
            `,
            [
                company_id,
                type.toUpperCase().trim(),
                details.trim()
            ]
        );

        res.status(201).json({
            message: "Voucher type added successfully.",
            id: result.insertId
        });

    } catch (error) {
        console.error("Error adding voucher type:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This voucher type details already exists for the selected company."
            });
        }

        res.status(500).json({
            message: "Failed to add voucher type.",
            error: error.message
        });
    }
};

// ======================================================
// Update Voucher Type
// ======================================================
exports.updateVoucherType = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            type,
            details
        } = req.body;

        // Validate required fields
        if (!company_id || !type || !details) {
            return res.status(400).json({
                message: "Company, Type, and Details are required."
            });
        }

        // Validate type against allowed values
        const validTypes = ['JV', 'PV', 'RV', 'CV', 'BP', 'BR', 'CN', 'DN'];
        if (!validTypes.includes(type.toUpperCase())) {
            return res.status(400).json({
                message: "Invalid voucher type. Allowed types are: JV, PV, RV, CV, BP, BR, CN, DN"
            });
        }

        const [result] = await db.query(
            `
            UPDATE VoucherType
            SET
                company_id = ?,
                type = ?,
                details = ?
            WHERE id = ?
            `,
            [
                company_id,
                type.toUpperCase().trim(),
                details.trim(),
                id
            ]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Voucher type not found."
            });
        }

        res.status(200).json({
            message: "Voucher type updated successfully."
        });

    } catch (error) {
        console.error("Error updating voucher type:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "This voucher type details already exists for the selected company."
            });
        }

        res.status(500).json({
            message: "Failed to update voucher type.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Voucher Type
// ======================================================
exports.deleteVoucherType = async (req, res) => {
    try {
        const { id } = req.params;

        // Check if voucher type is being used in VoucherMain
        const [checkResult] = await db.query(
            `
            SELECT COUNT(*) as count 
            FROM VoucherMain 
            WHERE vouchertype_id = ?
            `,
            [id]
        );

        if (checkResult[0].count > 0) {
            return res.status(409).json({
                message: "Cannot delete voucher type as it is being used in existing vouchers."
            });
        }

        const [result] = await db.query(
            `
            DELETE FROM VoucherType
            WHERE id = ?
            `,
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Voucher type not found."
            });
        }

        res.status(200).json({
            message: "Voucher type deleted successfully."
        });

    } catch (error) {
        console.error("Error deleting voucher type:", error);
        res.status(500).json({
            message: "Failed to delete voucher type.",
            error: error.message
        });
    }
};