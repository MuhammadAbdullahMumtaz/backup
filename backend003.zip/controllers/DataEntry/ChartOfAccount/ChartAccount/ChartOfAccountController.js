const db = require("../../../../config/db");

// ==========================================
// Get All Chart Of Accounts
// ==========================================
exports.getAllChartOfAccounts = async (req, res) => {

    try {

        const [rows] = await db.query(`
            SELECT
                coa.id,
                coa.company_id,
                c.company_name,

                coa.subcode_id,
                sc.details AS sub_code,

                coa.financialyear_id,
                fy.year_detail,

                coa.code,

                coa.account_name,
                coa.budget,

                coa.add_date,
                coa.update_date

            FROM ChartOfAccount coa

            INNER JOIN CompanyName c
                ON coa.company_id = c.id

            INNER JOIN SubCode sc
                ON coa.subcode_id = sc.id

            INNER JOIN FinancialYear fy
                ON coa.financialyear_id = fy.id

            ORDER BY coa.code
        `);

        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching Chart Of Accounts.",
            error: err.message
        });

    }

};

// ==========================================
// Get Chart Of Account By Id
// ==========================================
exports.getChartOfAccountById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(`
            SELECT
                coa.*,
                c.company_name,
                sc.details AS sub_code,
                fy.year_detail

            FROM ChartOfAccount coa

            INNER JOIN CompanyName c
                ON coa.company_id = c.id

            INNER JOIN SubCode sc
                ON coa.subcode_id = sc.id

            INNER JOIN FinancialYear fy
                ON coa.financialyear_id = fy.id

            WHERE coa.id = ?
        `, [id]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Chart Of Account not found."
            });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching Chart Of Account.",
            error: err.message
        });

    }
};

// ==========================================
// Add Chart Of Account
// ==========================================
exports.addChartOfAccount = async (req, res) => {

    try {

        const {
            company_id,
            subcode_id,
            financialyear_id,
            account_name,
            budget
        } = req.body;

        if (
            !company_id ||
            !subcode_id ||
            !financialyear_id ||
            !account_name
        ) {
            return res.status(400).json({
                success: false,
                message: "Company, Sub Code, Financial Year and Account Name are required."
            });
        }

        // Company Exists
        const [company] = await db.query(
            `SELECT id
             FROM CompanyName
             WHERE id=?`,
            [company_id]
        );

        if (company.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Company not found."
            });
        }

        // Sub Code Exists
        const [subCode] = await db.query(
            `SELECT id, company_id, code
             FROM SubCode
             WHERE id=?`,
            [subcode_id]
        );

        if (subCode.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Sub Code not found."
            });
        }

        if (subCode[0].company_id != company_id) {
            return res.status(400).json({
                success: false,
                message: "Sub Code belongs to another company."
            });
        }

        // Financial Year Exists
        const [financialYear] = await db.query(
            `SELECT id, company_id
             FROM FinancialYear
             WHERE id=?`,
            [financialyear_id]
        );

        if (financialYear.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Financial Year not found."
            });
        }

        if (financialYear[0].company_id != company_id) {
            return res.status(400).json({
                success: false,
                message: "Financial Year belongs to another company."
            });
        }

        // Duplicate Account Name
        const [duplicate] = await db.query(
            `SELECT id
             FROM ChartOfAccount
             WHERE company_id=?
             AND account_name=?`,
            [
                company_id,
                account_name
            ]
        );

        if (duplicate.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Account already exists."
            });
        }

        // Get Next Sequence Number for this Sub Code
        const [sequence] = await db.query(
            `SELECT
                COALESCE(MAX(CAST(RIGHT(code,4) AS UNSIGNED)),0) + 1 AS nextNo
             FROM ChartOfAccount
             WHERE company_id = ?
             AND subcode_id = ?`,
            [
                company_id,
                subcode_id
            ]
        );

        const nextNo = sequence[0].nextNo;

        if (nextNo > 9999) {
            return res.status(400).json({
                success: false,
                message: "Maximum Chart Of Accounts (9999) reached for this Sub Code."
            });
        }

        // Generate Code
        const generatedCode =
            subCode[0].code +
            String(nextNo).padStart(4, "0");

        // Insert Record
        const [result] = await db.query(
            `INSERT INTO ChartOfAccount
            (
                company_id,
                subcode_id,
                financialyear_id,
                code,
                account_name,
                budget
            )
            VALUES
            (?, ?, ?, ?, ?, ?)`,
            [
                company_id,
                subcode_id,
                financialyear_id,
                generatedCode,
                account_name,
                budget || 0
            ]
        );

        // Return Inserted Row
        const [newRow] = await db.query(
            `SELECT *
             FROM ChartOfAccount
             WHERE id=?`,
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            message: "Chart Of Account created successfully.",
            data: newRow[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error adding Chart Of Account.",
            error: err.message
        });

    }

};

// ==========================================
// Update Chart Of Account
// ==========================================
exports.updateChartOfAccount = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            company_id,
            subcode_id,
            financialyear_id,
            account_name,
            budget
        } = req.body;

        const [record] = await db.query(
            `SELECT id
             FROM ChartOfAccount
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Chart Of Account not found."
            });

        }

        // Duplicate
        const [duplicate] = await db.query(
            `SELECT id
             FROM ChartOfAccount
             WHERE company_id=?
             AND account_name=?
             AND id<>?`,
            [
                company_id,
                account_name,
                id
            ]
        );

        if (duplicate.length > 0) {

            return res.status(409).json({
                success: false,
                message: "Another account already exists."
            });

        }

        await db.query(
            `UPDATE ChartOfAccount
             SET
                company_id=?,
                subcode_id=?,
                financialyear_id=?,
                account_name=?,
                budget=?
             WHERE id=?`,
            [
                company_id,
                subcode_id,
                financialyear_id,
                account_name,
                budget || 0,
                id
            ]
        );

        const [updated] = await db.query(
            `SELECT *
             FROM ChartOfAccount
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Chart Of Account updated successfully.",
            data: updated[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error updating Chart Of Account.",
            error: err.message
        });

    }

};

// ==========================================
// Delete Chart Of Account
// ==========================================
exports.deleteChartOfAccount = async (req, res) => {

    try {

        const { id } = req.params;

        const [record] = await db.query(
            `SELECT id, company_id, code
             FROM ChartOfAccount
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Chart Of Account not found."
            });

        }

        const { company_id, code } = record[0];

        // Check Voucher Entries
        const [voucherUsage] = await db.query(
            `SELECT id
             FROM VoucherDetail
             WHERE company_id=?
             AND accountcode=?
             LIMIT 1`,
            [company_id, code]
        );

        if (voucherUsage.length > 0) {
            return res.status(409).json({
                success: false,
                message: "This account has Voucher entries. Please delete the related Voucher(s) first before deleting this account."
            });
        }

        // Check Purchase Entries (supplier_code)
        const [purchaseUsage] = await db.query(
            `SELECT id
             FROM PurchaseMain
             WHERE company_id=?
             AND supplier_code=?
             LIMIT 1`,
            [company_id, code]
        );

        if (purchaseUsage.length > 0) {
            return res.status(409).json({
                success: false,
                message: "This account has Purchase entries. Please delete the related Purchase(s) first before deleting this account."
            });
        }

        // Check Sales Entries (customer_code)
        const [salesUsage] = await db.query(
            `SELECT id
             FROM SalesMain
             WHERE company_id=?
             AND customer_code=?
             LIMIT 1`,
            [company_id, code]
        );

        if (salesUsage.length > 0) {
            return res.status(409).json({
                success: false,
                message: "This account has Sales entries. Please delete the related Sale(s) first before deleting this account."
            });
        }

        // Check Chart Detail (party address/contact info)
        const [chartDetailUsage] = await db.query(
            `SELECT id
             FROM ChartDetail
             WHERE chartofaccount_id=?
             LIMIT 1`,
            [id]
        );

        if (chartDetailUsage.length > 0) {
            return res.status(409).json({
                success: false,
                message: "This account has Party Detail information linked to it. Please delete that first before deleting this account."
            });
        }

        await db.query(
            `DELETE
             FROM ChartOfAccount
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Chart Of Account deleted successfully."
        });

    } catch (err) {

        console.error(err);

        if (err.code === "ER_ROW_IS_REFERENCED_2" || err.errno === 1451) {
            return res.status(409).json({
                success: false,
                message: "This account is linked to other records (e.g. Opening Balance) and cannot be deleted. Please remove the related records first."
            });
        }

        res.status(500).json({
            success: false,
            message: "Error deleting Chart Of Account.",
            error: err.message
        });

    }

};