const db = require("../../../../config/db");

// ==========================================
// Get All Sub Codes
// ==========================================
exports.getAllSubCodes = async (req, res) => {
    try {

        const [rows] = await db.query(`
            SELECT
                sc.id,
                sc.company_id,
                c.company_name,
                sc.maincode_id,
                mc.details AS main_code,
                sc.code,
                sc.details,
                sc.add_date,
                sc.update_date
            FROM SubCode sc
            INNER JOIN CompanyName c
                ON sc.company_id = c.id
            INNER JOIN MainCode mc
                ON sc.maincode_id = mc.id
            ORDER BY
                mc.details,
                sc.code
        `);

        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error fetching Sub Codes.",
            error: err.message
        });

    }
};

// ==========================================
// Get Sub Code By ID
// ==========================================
exports.getSubCodeById = async (req, res) => {

    try {

        const { id } = req.params;

        const [rows] = await db.query(`
            SELECT
                sc.id,
                sc.company_id,
                c.company_name,
                sc.maincode_id,
                mc.details AS main_code,
                sc.code,
                sc.details,
                sc.add_date,
                sc.update_date
            FROM SubCode sc
            INNER JOIN CompanyName c
                ON sc.company_id = c.id
            INNER JOIN MainCode mc
                ON sc.maincode_id = mc.id
            WHERE sc.id = ?
        `,[id]);

        if(rows.length === 0){
            return res.status(404).json({
                success:false,
                message:"Sub Code not found."
            });
        }

        res.status(200).json({
            success:true,
            data:rows[0]
        });

    } catch (err){

        console.error(err);

        res.status(500).json({
            success:false,
            message:"Error fetching Sub Code.",
            error:err.message
        });

    }
};

// ==========================================
// Add Sub Code
// ==========================================
exports.addSubCode = async (req, res) => {

    try {

        const {
            company_id,
            maincode_id,
            details
        } = req.body;

        if (!company_id || !maincode_id || !details) {
            return res.status(400).json({
                success: false,
                message: "Company, Main Code and Details are required."
            });
        }

        // Company Exists
        const [company] = await db.query(
            `SELECT id
             FROM CompanyName
             WHERE id=?`,
            [company_id]
        );

        if (company.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Company not found."
            });
        }

        // Main Code Exists
        const [mainCode] = await db.query(
            `SELECT id, company_id, code
             FROM MainCode
             WHERE id=?`,
            [maincode_id]
        );

        if (mainCode.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Main Code not found."
            });
        }

        // Company Validation
        if (mainCode[0].company_id != company_id) {
            return res.status(400).json({
                success: false,
                message: "Main Code does not belong to selected Company."
            });
        }

        // Duplicate Details Check
        const [duplicate] = await db.query(
            `SELECT id
             FROM SubCode
             WHERE company_id = ?
             AND maincode_id = ?
             AND details = ?`,
            [
                company_id,
                maincode_id,
                details
            ]
        );

        if (duplicate.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Sub Code already exists."
            });
        }

        // Get Next Sequence Number for this Main Code
        const [sequence] = await db.query(
            `SELECT
                COALESCE(MAX(CAST(RIGHT(code, 2) AS UNSIGNED)), 0) + 1 AS nextNo
             FROM SubCode
             WHERE company_id = ?
             AND maincode_id = ?`,
            [
                company_id,
                maincode_id
            ]
        );

        const nextNo = sequence[0].nextNo;

        if (nextNo > 99) {
            return res.status(400).json({
                success: false,
                message: "Maximum Sub Codes (99) reached for this Main Code."
            });
        }

        // Generate Code
        const generatedCode =
            mainCode[0].code +
            String(nextNo).padStart(2, "0");

        // Insert Record
        const [result] = await db.query(
            `INSERT INTO SubCode
            (
                company_id,
                maincode_id,
                code,
                details
            )
            VALUES
            (?, ?, ?, ?)`,
            [
                company_id,
                maincode_id,
                generatedCode,
                details
            ]
        );

        // Fetch Inserted Record
        const [newRow] = await db.query(
            `SELECT *
             FROM SubCode
             WHERE id=?`,
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            message: "Sub Code added successfully.",
            data: newRow[0]
        });

    } catch (err) {

        console.error(err);

        res.status(500).json({
            success: false,
            message: "Error adding Sub Code.",
            error: err.message
        });

    }

};

// ==========================================
// Update Sub Code
// ==========================================
exports.updateSubCode = async (req,res)=>{

    try{

        const {id}=req.params;

        const{
            company_id,
            maincode_id,
            details
        } = req.body;

        const [record]=await db.query(
            `SELECT id
             FROM SubCode
             WHERE id=?`,
            [id]
        );

        if(record.length===0){
            return res.status(404).json({
                success:false,
                message:"Sub Code not found."
            });
        }

        // Validate Main Code
        const [mainCode]=await db.query(
            `SELECT company_id
             FROM MainCode
             WHERE id=?`,
            [maincode_id]
        );

        if(mainCode.length===0){
            return res.status(404).json({
                success:false,
                message:"Main Code not found."
            });
        }

        if(mainCode[0].company_id != company_id){
            return res.status(400).json({
                success:false,
                message:"Main Code does not belong to selected Company."
            });
        }

        // Duplicate Check
        const [duplicate]=await db.query(
            `SELECT id
             FROM SubCode
             WHERE company_id=?
             AND maincode_id=?
             AND details=?
             AND id<>?`,
            [
                company_id,
                maincode_id,
                details,
                id
            ]
        );

        if(duplicate.length>0){
            return res.status(409).json({
                success:false,
                message:"Another Sub Code already exists."
            });
        }

        await db.query(
            `UPDATE SubCode
             SET
                company_id=?,
                maincode_id=?,
                details=?
             WHERE id=?`,
            [
                company_id,
                maincode_id,
                details,
                id
            ]
        );

        const [updated]=await db.query(
            `SELECT *
             FROM SubCode
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success:true,
            message:"Sub Code updated successfully.",
            data:updated[0]
        });

    }catch(err){

        console.error(err);

        res.status(500).json({
            success:false,
            message:"Error updating Sub Code.",
            error:err.message
        });

    }

};

// ==========================================
// Delete Sub Code
// ==========================================
exports.deleteSubCode = async (req, res) => {

    try {

        const { id } = req.params;

        const [record] = await db.query(
            `SELECT id
             FROM SubCode
             WHERE id=?`,
            [id]
        );

        if (record.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Sub Code not found."
            });
        }

        await db.query(
            `DELETE
             FROM SubCode
             WHERE id=?`,
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Sub Code deleted successfully."
        });

    } catch (err) {

        console.error(err);

        if (err.code === "ER_ROW_IS_REFERENCED_2" || err.errno === 1451) {
            return res.status(409).json({
                success: false,
                message: "This Sub Code has Chart Of Account(s) linked to it. Please delete those first before deleting this item."
            });
        }

        res.status(500).json({
            success: false,
            message: "Error deleting Sub Code.",
            error: err.message
        });

    }

};