const db = require("../../../../config/db");
const { syncAutoEntriesForSalesMain } = require("../SalesAutoEntry");
const { getAvailableLots, allocateFifo, revertStockIfNeeded } = require("../StockAllocation");

exports.getAvailableStock = async (req, res) => {
    try {
        const { company_id, item_code } = req.query;
        const lots = await getAvailableLots(company_id, item_code);
        res.status(200).json(lots);
    } catch (error) {
        res.status(500).json({ message: "Failed to fetch stock lots.", error: error.message });
    }
};

const recalcSalesMainTotal = async (sale_main) => {
    const [[{ totalSum }]] = await db.query(
        `SELECT COALESCE(SUM(total), 0) AS totalSum FROM SalesDetail WHERE sale_main = ?`,
        [sale_main]
    );
    await db.query(`UPDATE SalesMain SET total = ? WHERE id = ?`, [totalSum, sale_main]);
};

// ======================================================
// Get All Sales Details
// ======================================================
exports.getAllSalesDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                sd.id,
                sd.company_id,
                c.company_name,
                sd.sale_main,
                sm.invoice_no,
                sm.entry,
                sd.financialyear_id,
                fy.year_detail,
                sd.Item_code,
                item.details AS item_name,
                sd.entry_no,
                sd.grn_no,
                sd.purchase_entry_no,
                sd.pieces,
                sd.gross_weight,
                sd.tear_weight,
                sd.net_weight,
                sd.rate,
                sd.amount,
                sd.freight,
                sd.total,
                sd.add_date,
                sd.update_date
            FROM SalesDetail sd
            INNER JOIN CompanyName c
                ON sd.company_id = c.id
            INNER JOIN SalesMain sm
                ON sd.sale_main = sm.id
            INNER JOIN FinancialYear fy
                ON sd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON sd.Item_code = item.code AND sd.company_id = item.company_id
            ORDER BY
                sm.invoice_no,
                sd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sale details:", error);
        res.status(500).json({
            message: "Failed to fetch sale details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Details By Sales Main ID
// ======================================================
exports.getSalesDetailsBySalesMain = async (req, res) => {
    try {
        const { sale_main } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                sd.id,
                sd.company_id,
                c.company_name,
                sd.sale_main,
                sm.invoice_no,
                sd.financialyear_id,
                fy.year_detail,
                sd.Item_code,
                item.details AS item_name,
                sd.entry_no,
                sd.grn_no,
                sd.purchase_entry_no,
                sd.pieces,
                sd.gross_weight,
                sd.tear_weight,
                sd.net_weight,
                sd.rate,
                sd.amount,
                sd.freight,
                sd.total,
                sd.add_date,
                sd.update_date
            FROM SalesDetail sd
            INNER JOIN CompanyName c
                ON sd.company_id = c.id
            INNER JOIN SalesMain sm
                ON sd.sale_main = sm.id
            INNER JOIN FinancialYear fy
                ON sd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON sd.Item_code = item.code AND sd.company_id = item.company_id
            WHERE sd.sale_main = ?
            ORDER BY sd.entry_no ASC
            `,
            [sale_main]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sale details by sale:", error);
        res.status(500).json({
            message: "Failed to fetch sale details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Detail By ID
// ======================================================
exports.getSalesDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                sd.id,
                sd.company_id,
                c.company_name,
                sd.sale_main,
                sm.invoice_no,
                sd.financialyear_id,
                fy.year_detail,
                sd.Item_code,
                item.details AS item_name,
                sd.entry_no,
                sd.grn_no,
                sd.purchase_entry_no,
                sd.pieces,
                sd.gross_weight,
                sd.tear_weight,
                sd.net_weight,
                sd.rate,
                sd.amount,
                sd.freight,
                sd.total,
                sd.add_date,
                sd.update_date
            FROM SalesDetail sd
            INNER JOIN CompanyName c
                ON sd.company_id = c.id
            INNER JOIN SalesMain sm
                ON sd.sale_main = sm.id
            INNER JOIN FinancialYear fy
                ON sd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON sd.Item_code = item.code AND sd.company_id = item.company_id
            WHERE sd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Sale detail not found."
            });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching sale detail:", error);
        res.status(500).json({
            message: "Failed to fetch sale detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Sales Detail
// ======================================================
exports.addSalesDetail = async (req, res) => {
    try {
        const {
            company_id, sale_main, Item_code,
            pieces, net_weight, rate
        } = req.body;

        // Validate required fields
        // NOTE: financialyear_id is NOT taken from req.body - it's always
        // derived from the parent SalesMain row below, so it can never
        // drift out of sync with the sale it belongs to.
        if (!company_id || !sale_main || !Item_code) {
            return res.status(400).json({
                message: "Company, Sales Main, and Item Code are required."
            });
        }
        if (!net_weight || parseFloat(net_weight) <= 0) {
            return res.status(400).json({
                message: "Net weight must be greater than zero."
            });
        }

        // Validate Item_code length (matches VARCHAR(8) column)
        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        // AFTER
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;
        const piecesValue = parseInt(pieces) || 0;

        const lots = await getAvailableLots(company_id, Item_code);
        let allocations;
        try {
            allocations = allocateFifo(lots, netWeightValue, piecesValue);   // pass piecesValue now
        } catch (e) {
            if (e.code === "INSUFFICIENT_STOCK") {
                return res.status(400).json({ message: e.message });
            }
            throw e;
        }

        const [saleCheck] = await db.query(
            `SELECT id, financialyear_id FROM SalesMain WHERE id = ? AND company_id = ?`,
            [sale_main, company_id]
        );
        if (saleCheck.length === 0) {
            return res.status(400).json({ message: "Invalid sale for this company." });
        }
        const { financialyear_id } = saleCheck[0];

        const [existing] = await db.query(
            `SELECT COALESCE(MAX(entry_no),0) AS maxNo FROM SalesDetail WHERE sale_main = ?`,
            [sale_main]
        );
        let nextEntryNo = existing[0].maxNo + 1;

        // Distribute pieces proportionally to net_weight share (per your note,
        // pieces isn't the driver — just split proportionally, last row gets remainder)

        const insertedIds = [];
        for (let i = 0; i < allocations.length; i++) {
            const alloc = allocations[i];

            const amountValue = alloc.net_weight * rateValue;
            const totalValue = amountValue;

            const [result] = await db.query(
                `INSERT INTO SalesDetail
         (company_id, sale_main, financialyear_id, Item_code, entry_no,
          grn_no, purchase_entry_no, source_type, source_detail_id,
          pieces, net_weight, rate, amount, total)
         VALUES (?,?,?,?,?, ?,?,?,?, ?,?,?,?, ?)`,
                [
                    company_id, sale_main, financialyear_id, Item_code, nextEntryNo++,
                    alloc.grn_no, alloc.purchase_entry_no, alloc.source_type, alloc.source_detail_id,
                    alloc.pieces, alloc.net_weight, rateValue, amountValue, totalValue   // ← alloc.pieces, not piecesForRow
                ]
            );
            insertedIds.push(result.insertId);

            if (alloc.will_exhaust_lot) {
                const table = alloc.source_type === "purchase" ? "PurchaseDetail" : "SalesReturnDetail";
                await db.query(`UPDATE ${table} SET stocks = 'out' WHERE id = ?`, [alloc.source_detail_id]);
            }
        }

        await recalcSalesMainTotal(sale_main);
        const { warnings } = await syncAutoEntriesForSalesMain(sale_main);

        res.status(201).json({
            message: allocations.length > 1
                ? `Sale entry split across ${allocations.length} purchase lots and saved.`
                : "Sale detail added successfully.",
            ids: insertedIds,
            entriesCreated: allocations.length,
            warnings
        });
    } catch (error) {
        console.error("Error adding sale detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this sale."
            });
        }
        res.status(500).json({
            message: "Failed to add sale detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Sales Detail
// ======================================================
exports.updateSalesDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            sale_main,
            Item_code,
            entry_no,
            grn_no,
            purchase_entry_no,
            pieces,
            net_weight,
            rate,
            total
        } = req.body;

        if (!company_id || !sale_main || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Sales Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({
                message: "Pieces cannot be negative."
            });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({
                message: "Net weight cannot be negative."
            });
        }
        if (rateValue < 0) {
            return res.status(400).json({
                message: "Rate cannot be negative."
            });
        }

        const amountValue = netWeightValue * rateValue;
        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue;

        // Check if sale detail exists
        const [detailCheck] = await db.query(
            `SELECT id FROM SalesDetail WHERE id = ?`,
            [id]
        );
        if (detailCheck.length === 0) {
            return res.status(404).json({
                message: "Sale detail not found."
            });
        }

        // Check if sale exists, and re-derive financialyear_id from it -
        // covers the case where sale_main itself changed on update.
        const [saleCheck] = await db.query(
            `SELECT id, financialyear_id FROM SalesMain WHERE id = ? AND company_id = ?`,
            [sale_main, company_id]
        );
        if (saleCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid sale for this company."
            });
        }
        const { financialyear_id } = saleCheck[0];

        // Check if item exists
        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        await db.query(
            `
            UPDATE SalesDetail
            SET
                company_id = ?,
                sale_main = ?,
                financialyear_id = ?,
                Item_code = ?,
                entry_no = ?,
                grn_no = ?,
                purchase_entry_no = ?,
                pieces = ?,
                net_weight = ?,
                rate = ?,
                amount = ?,
                total = ?
            WHERE id = ?
            `,
            [
                company_id,
                sale_main,
                financialyear_id,
                Item_code,
                entry_no,
                grn_no,
                purchase_entry_no,
                piecesValue,
                netWeightValue,
                rateValue,
                amountValue,
                totalValue,
                id
            ]
        );

        await recalcSalesMainTotal(sale_main);
        const { warnings } = await syncAutoEntriesForSalesMain(sale_main);

        res.status(200).json({
            message: "Sale detail updated successfully.",
            warnings
        });
    } catch (error) {
        console.error("Error updating sale detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this sale."
            });
        }
        res.status(500).json({
            message: "Failed to update sale detail.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Sales Detail
// ======================================================
exports.deleteSalesDetail = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT sale_main, source_type, source_detail_id FROM SalesDetail WHERE id = ?`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Sale detail not found." });
        }
        const { sale_main, source_type, source_detail_id } = rows[0];

        const [result] = await db.query(`DELETE FROM SalesDetail WHERE id = ?`, [id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Sale detail not found." });
        }

        // Entry-level stock management: only this row's source lot is rechecked.
        await revertStockIfNeeded(source_type, source_detail_id);

        await recalcSalesMainTotal(sale_main);
        const { warnings } = await syncAutoEntriesForSalesMain(sale_main);

        res.status(200).json({ message: "Sale detail deleted successfully.", warnings });
    } catch (error) {
        console.error("Error deleting sale detail:", error);
        res.status(500).json({ message: "Failed to delete sale detail.", error: error.message });
    }
};