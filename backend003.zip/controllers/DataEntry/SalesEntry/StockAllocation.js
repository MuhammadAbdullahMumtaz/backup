const db = require("../../../config/db");

// Returns FIFO-ordered lots for an item with their REMAINING net_weight,
// i.e. lot net_weight minus whatever SalesDetail rows already consumed from it.
// excludeSalesMainId lets the sale-being-edited's own prior consumption be
// added back in (so editing an existing sale recomputes correctly).
async function getAvailableLots(company_id, Item_code) {
    const [purchaseLots] = await db.query(
        `SELECT pd.id AS source_detail_id, 'purchase' AS source_type,
                pm.grn_no AS label, pd.entry_no, pd.pieces, pd.net_weight,
                pm.grn_date AS lot_date, pd.stocks
         FROM PurchaseDetail pd
         JOIN PurchaseMain pm ON pd.purchasemain_id = pm.id
         WHERE pd.company_id = ? AND pd.Item_code = ?
           AND pd.stocks = 'available'
           AND pd.entry = 'user'
         ORDER BY pm.grn_date ASC, pd.id ASC`,
        [company_id, Item_code]
    );

    const [returnLots] = await db.query(
        `SELECT srd.id AS source_detail_id, 'sales_return' AS source_type,
            srm.invoice_no AS label, srd.entry_no, srd.pieces, srd.net_weight,
            srm.invoice_date AS lot_date, srd.stocks
     FROM SalesReturnDetail srd
     JOIN SalesReturnMain srm ON srd.sales_return_main = srm.id
     WHERE srd.company_id = ? AND srd.Item_code = ?
       AND srd.stocks = 'available'
       AND srd.entry = 'user'
     ORDER BY srm.invoice_date ASC, srd.id ASC`,
        [company_id, Item_code]
    );

    const lots = [...purchaseLots, ...returnLots].sort(
        (a, b) => new Date(a.lot_date) - new Date(b.lot_date) || a.source_detail_id - b.source_detail_id
    );

    // Live remaining = lot's net_weight minus SUM of every SalesDetail row
    // that has ever drawn from it — no matter which sale. This is what makes
    // Entry 2 in the SAME sale immediately see what Entry 1 just took.
    for (const lot of lots) {
        const [[{ consumed, consumedPieces }]] = await db.query(
            `SELECT COALESCE(SUM(net_weight),0) AS consumed,
                COALESCE(SUM(pieces),0) AS consumedPieces
         FROM SalesDetail
         WHERE source_type = ? AND source_detail_id = ?`,
            [lot.source_type, lot.source_detail_id]
        );
        lot.remaining_net_weight = Math.max(0, Number(lot.net_weight) - Number(consumed));
        lot.remaining_pieces = Number(lot.pieces) - Number(consumedPieces);
    }

    return lots.filter((l) => l.remaining_net_weight > 0);
}

function allocateFifo(lots, requestedNetWeight, requestedPieces) {
    let remainingWeight = Number(requestedNetWeight);
    const allocations = [];

    for (let i = 0; i < lots.length; i++) {
        const lot = lots[i];
        if (remainingWeight <= 0) break;

        const take = Math.min(lot.remaining_net_weight, remainingWeight);
        if (take <= 0) continue;

        allocations.push({
            source_type: lot.source_type,
            source_detail_id: lot.source_detail_id,
            grn_no: lot.source_type === "purchase" ? lot.label : null,
            purchase_entry_no: lot.entry_no,
            net_weight: take,
            will_exhaust_lot: take >= lot.remaining_net_weight,
        });

        remainingWeight -= take;
    }

    if (remainingWeight > 0.0001) {
        const err = new Error("Insufficient stock for this item.");
        err.code = "INSUFFICIENT_STOCK";
        throw err;
    }

    const piecesTotal = Number(requestedPieces) || 0;
    let piecesLeft = piecesTotal;
    allocations.forEach((alloc, i) => {
        const isLast = i === allocations.length - 1;
        const shareRatio = alloc.net_weight / Number(requestedNetWeight);
        const piecesForRow = isLast ? piecesLeft : Math.round(piecesTotal * shareRatio);
        alloc.pieces = piecesForRow;
        piecesLeft -= piecesForRow;
    });

    return allocations;
};

async function revertStockIfNeeded(source_type, source_detail_id) {
    const table = source_type === "purchase" ? "PurchaseDetail" : "SalesReturnDetail";

    const [[lotRow]] = await db.query(
        `SELECT net_weight, stocks FROM ${table} WHERE id = ?`,
        [source_detail_id]
    );
    if (!lotRow) return;

    const [[{ consumed }]] = await db.query(
        `SELECT COALESCE(SUM(net_weight),0) AS consumed
         FROM SalesDetail
         WHERE source_type = ? AND source_detail_id = ?`,
        [source_type, source_detail_id]
    );

    const stillFullyConsumed = Number(consumed) >= Number(lotRow.net_weight);
    if (!stillFullyConsumed && lotRow.stocks === 'out') {
        await db.query(`UPDATE ${table} SET stocks = 'available' WHERE id = ?`, [source_detail_id]);
    }
}

module.exports = { getAvailableLots, allocateFifo, revertStockIfNeeded };