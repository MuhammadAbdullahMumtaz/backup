const db = require("../../../../config/db");

// ======================================================
// Get All Sub Items
// ======================================================
exports.getAllSubItems = async (req, res) => {
    try {

        const sql = `
            SELECT
                s.id,
                s.company_id,
                c.company_name,

                s.mainitem_id,
                m.details AS main_item,
                m.code AS main_item_code,

                s.code,
                s.details,

                s.GL_purchase,
                coa_purchase.account_name AS purchase_account,

                s.GL_sale,
                coa_sale.account_name AS sale_account,

                s.GL_gst,
                coa_gst.account_name AS gst_account,

                s.GL_further,
                coa_further.account_name AS further_account,

                s.add_date,
                s.update_date

            FROM SubItem s

            INNER JOIN CompanyName c
                ON s.company_id = c.id

            INNER JOIN MainItem m
                ON s.mainitem_id = m.id

            LEFT JOIN ChartOfAccount coa_purchase
                ON s.GL_purchase = coa_purchase.id

            LEFT JOIN ChartOfAccount coa_sale
                ON s.GL_sale = coa_sale.id

            LEFT JOIN ChartOfAccount coa_gst
                ON s.GL_gst = coa_gst.id

            LEFT JOIN ChartOfAccount coa_further
                ON s.GL_further = coa_further.id

            ORDER BY s.id DESC
        `;

        const [rows] = await db.query(sql);

        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }
};



// ======================================================
// Get Sub Item By ID
// ======================================================
exports.getSubItemById = async (req, res) => {

    try {

        const { id } = req.params;

        const sql = `
            SELECT
                s.id,
                s.company_id,
                c.company_name,

                s.mainitem_id,
                m.details AS main_item,
                m.code AS main_item_code,

                s.code,
                s.details,

                s.GL_purchase,
                coa_purchase.account_name AS purchase_account,

                s.GL_sale,
                coa_sale.account_name AS sale_account,

                s.GL_gst,
                coa_gst.account_name AS gst_account,

                s.GL_further,
                coa_further.account_name AS further_account,

                s.add_date,
                s.update_date

            FROM SubItem s

            INNER JOIN CompanyName c
                ON s.company_id = c.id

            INNER JOIN MainItem m
                ON s.mainitem_id = m.id

            LEFT JOIN ChartOfAccount coa_purchase
                ON s.GL_purchase = coa_purchase.id

            LEFT JOIN ChartOfAccount coa_sale
                ON s.GL_sale = coa_sale.id

            LEFT JOIN ChartOfAccount coa_gst
                ON s.GL_gst = coa_gst.id

            LEFT JOIN ChartOfAccount coa_further
                ON s.GL_further = coa_further.id

            WHERE s.id = ?
        `;

        const [rows] = await db.query(sql, [id]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Sub Item not found."
            });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};



// ======================================================
// Add Sub Item
// ======================================================
exports.addSubItem = async (req, res) => {

    try {

        const {
            company_id,
            mainitem_id,
            details,
            GL_purchase,
            GL_sale,
            GL_gst,
            GL_further
        } = req.body;

        if (!company_id || !mainitem_id || !details) {

            return res.status(400).json({
                success: false,
                message: "Company, Main Item and Details are required."
            });

        }

        // Duplicate Check
        const [duplicate] = await db.query(
            `
            SELECT id
            FROM SubItem
            WHERE company_id = ?
              AND mainitem_id = ?
              AND details = ?
            `,
            [
                company_id,
                mainitem_id,
                details
            ]
        );

        if (duplicate.length > 0) {

            return res.status(400).json({
                success: false,
                message: "Sub Item already exists."
            });

        }

        // ==========================================
        // Fetch parent Main Item code (2-digit)
        // ==========================================
        const [mainItemRows] = await db.query(
            `
            SELECT code
            FROM MainItem
            WHERE id = ?
            AND company_id = ?
            `,
            [mainitem_id, company_id]
        );

        if (mainItemRows.length === 0) {
            return res.status(400).json({
                success: false,
                message: "Main Item not found for this company."
            });
        }

        const mainItemCode = mainItemRows[0].code;

        // ==========================================
        // Generate Sub Item's own 2-digit sequence
        // (scoped by company_id + mainitem_id)
        // ==========================================
        const [codeRows] = await db.query(
            `
            SELECT
                COALESCE(MAX(CAST(RIGHT(code, 2) AS UNSIGNED)), 0) + 1 AS nextNo
            FROM SubItem
            WHERE company_id = ?
            AND mainitem_id = ?
            `,
            [company_id, mainitem_id]
        );

        const nextNo = codeRows[0].nextNo;

        const subCode = String(nextNo).padStart(2, "0");

        // Combine: MainItem code (2) + SubItem sequence (2) = 4-digit code
        const code = `${mainItemCode}${subCode}`;

        // ==========================================
        // Insert Sub Item
        // ==========================================
        const sql = `
            INSERT INTO SubItem
            (
                company_id,
                mainitem_id,
                code,
                details,
                GL_purchase,
                GL_sale,
                GL_gst,
                GL_further
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const [result] = await db.query(sql, [

            company_id,
            mainitem_id,
            code,
            details,
            GL_purchase || null,
            GL_sale || null,
            GL_gst || null,
            GL_further || null

        ]);

        res.status(201).json({

            success: true,
            message: "Sub Item added successfully.",
            id: result.insertId,
            code: code

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            success: false,
            message: error.message

        });

    }

};

// ======================================================
// Update Sub Item
// ======================================================
exports.updateSubItem = async (req, res) => {

    try {

        const { id } = req.params;

        const {
            company_id,
            mainitem_id,
            details,
            GL_purchase,
            GL_sale,
            GL_gst,
            GL_further
        } = req.body;

        // Check existence
        const [exist] = await db.query(
            "SELECT id FROM SubItem WHERE id = ?",
            [id]
        );

        if (exist.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Sub Item not found."
            });
        }

        // Duplicate Check
        const [duplicate] = await db.query(
            `
            SELECT id
            FROM SubItem
            WHERE company_id = ?
            AND mainitem_id = ?
            AND details = ?
            AND id <> ?
            `,
            [
                company_id,
                mainitem_id,
                details,
                id
            ]
        );

        if (duplicate.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Sub Item already exists."
            });
        }

        // NOTE: code is intentionally NOT regenerated on update, since
        // ItemDetail codes are derived from this SubItem's code at
        // insert time and changing mainitem_id here would desync it.
        const sql = `
            UPDATE SubItem
            SET
                company_id = ?,
                mainitem_id = ?,
                details = ?,
                GL_purchase = ?,
                GL_sale = ?,
                GL_gst = ?,
                GL_further = ?
            WHERE id = ?
        `;

        await db.query(sql, [
            company_id,
            mainitem_id,
            details,
            GL_purchase || null,
            GL_sale || null,
            GL_gst || null,
            GL_further || null,
            id
        ]);

        res.status(200).json({
            success: true,
            message: "Sub Item updated successfully."
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};


// ======================================================
// Delete Sub Item
// ======================================================
exports.deleteSubItem = async (req, res) => {

    try {

        const { id } = req.params;

        const [exist] = await db.query(
            "SELECT id FROM SubItem WHERE id = ?",
            [id]
        );

        if (exist.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Sub Item not found."
            });

        }

        await db.query(
            "DELETE FROM SubItem WHERE id = ?",
            [id]
        );

        res.status(200).json({
            success: true,
            message: "Sub Item deleted successfully."
        });

    } catch (error) {

        console.error(error);

        if (error.code === "ER_ROW_IS_REFERENCED_2" || error.errno === 1451) {
            return res.status(409).json({
                success: false,
                message: "This Sub Item has Item(s) linked to it. Please delete those first before deleting this item."
            });
        }

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};