const db = require("../../../../config/db");
const { syncAutoEntriesForSalesReturnMain } = require("../AutoSalesReturnSync");

const recalcSalesReturnMainTotal = async (sales_return_main) => {
    const [[{ totalSum }]] = await db.query(
        `SELECT COALESCE(SUM(total), 0) AS totalSum FROM SalesReturnDetail WHERE sales_return_main = ?`,
        [sales_return_main]
    );
    await db.query(`UPDATE SalesReturnMain SET total = ? WHERE id = ?`, [totalSum, sales_return_main]);
};

// ======================================================
// Get All Sales Return Details
// ======================================================
exports.getAllSalesReturnDetails = async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT
                srd.id,
                srd.company_id,
                c.company_name,
                srd.sales_return_main,
                srm.invoice_no,
                srm.entry,
                srd.financialyear_id,
                fy.year_detail,
                srd.Item_code,
                item.details AS item_name,
                srd.entry_no,
                srd.pieces,
                srd.gross_weight,
                srd.tear_weight,
                srd.net_weight,
                srd.rate,
                srd.amount,
                srd.freight,
                srd.total,
                srd.add_date,
                srd.update_date
            FROM SalesReturnDetail srd
            INNER JOIN CompanyName c
                ON srd.company_id = c.id
            INNER JOIN SalesReturnMain srm
                ON srd.sales_return_main = srm.id
            INNER JOIN FinancialYear fy
                ON srd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON srd.Item_code = item.code AND srd.company_id = item.company_id
            ORDER BY
                srm.invoice_no,
                srd.entry_no
        `);

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sale return details:", error);
        res.status(500).json({
            message: "Failed to fetch sale return details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Return Details By Sales Return Main ID
// ======================================================
exports.getSalesReturnDetailsBySalesReturnMain = async (req, res) => {
    try {
        const { sales_return_main } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                srd.id,
                srd.company_id,
                c.company_name,
                srd.sales_return_main,
                srm.invoice_no,
                srd.financialyear_id,
                fy.year_detail,
                srd.Item_code,
                item.details AS item_name,
                srd.entry_no,
                srd.pieces,
                srd.gross_weight,
                srd.tear_weight,
                srd.net_weight,
                srd.rate,
                srd.amount,
                srd.freight,
                srd.total,
                srd.add_date,
                srd.update_date
            FROM SalesReturnDetail srd
            INNER JOIN CompanyName c
                ON srd.company_id = c.id
            INNER JOIN SalesReturnMain srm
                ON srd.sales_return_main = srm.id
            INNER JOIN FinancialYear fy
                ON srd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON srd.Item_code = item.code AND srd.company_id = item.company_id
            WHERE srd.sales_return_main = ?
            ORDER BY srd.entry_no ASC
            `,
            [sales_return_main]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching sale return details by return:", error);
        res.status(500).json({
            message: "Failed to fetch sale return details.",
            error: error.message
        });
    }
};

// ======================================================
// Get Sales Return Detail By ID
// ======================================================
exports.getSalesReturnDetailById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `
            SELECT
                srd.id,
                srd.company_id,
                c.company_name,
                srd.sales_return_main,
                srm.invoice_no,
                srd.financialyear_id,
                fy.year_detail,
                srd.Item_code,
                item.details AS item_name,
                srd.entry_no,
                srd.pieces,
                srd.gross_weight,
                srd.tear_weight,
                srd.net_weight,
                srd.rate,
                srd.amount,
                srd.freight,
                srd.total,
                srd.add_date,
                srd.update_date
            FROM SalesReturnDetail srd
            INNER JOIN CompanyName c
                ON srd.company_id = c.id
            INNER JOIN SalesReturnMain srm
                ON srd.sales_return_main = srm.id
            INNER JOIN FinancialYear fy
                ON srd.financialyear_id = fy.id
            INNER JOIN ItemDetail item
                ON srd.Item_code = item.code AND srd.company_id = item.company_id
            WHERE srd.id = ?
            `,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                message: "Sale return detail not found."
            });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error("Error fetching sale return detail:", error);
        res.status(500).json({
            message: "Failed to fetch sale return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Add Sales Return Detail
// ======================================================
exports.addSalesReturnDetail = async (req, res) => {
    try {
        const {
            company_id,
            sales_return_main,
            Item_code,
            entry_no,
            pieces,
            net_weight,
            rate,
            total
        } = req.body;

        if (!company_id || !sales_return_main || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Sales Return Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({ message: "Pieces cannot be negative." });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({ message: "Net weight cannot be negative." });
        }
        if (rateValue < 0) {
            return res.status(400).json({ message: "Rate cannot be negative." });
        }

        const amountValue = netWeightValue * rateValue;
        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue;

        // financialyear_id always inherited from the parent SalesReturnMain,
        // never taken from req.body.
        const [saleCheck] = await db.query(
            `SELECT id, financialyear_id FROM SalesReturnMain WHERE id = ? AND company_id = ?`,
            [sales_return_main, company_id]
        );
        if (saleCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid sale return for this company."
            });
        }
        const { financialyear_id } = saleCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        const [result] = await db.query(
            `
INSERT INTO SalesReturnDetail
(
    company_id,
    sales_return_main,
    financialyear_id,
    Item_code,
    entry_no,
    pieces,
    net_weight,
    rate,
    amount,
    total
)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`,
            [
                company_id,
                sales_return_main,
                financialyear_id,
                Item_code,
                entry_no,
                piecesValue,
                netWeightValue,
                rateValue,
                amountValue,
                totalValue
            ]
        );
        await recalcSalesReturnMainTotal(sales_return_main);
        const { warnings } = await syncAutoEntriesForSalesReturnMain(sales_return_main);

        res.status(201).json({
            message: "Sale return detail added successfully.",
            id: result.insertId,
            warnings
        });
    } catch (error) {
        console.error("Error adding sale return detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this sale return."
            });
        }
        res.status(500).json({
            message: "Failed to add sale return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Update Sales Return Detail
// ======================================================
exports.updateSalesReturnDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            company_id,
            sales_return_main,
            Item_code,
            entry_no,
            pieces,
            net_weight,
            rate,
            total
        } = req.body;

        if (!company_id || !sales_return_main || !Item_code ||
            entry_no === undefined || entry_no === null) {
            return res.status(400).json({
                message: "Company, Sales Return Main, Item Code, and Entry No are required."
            });
        }

        if (entry_no <= 0) {
            return res.status(400).json({
                message: "Entry number must be a positive integer."
            });
        }

        if (String(Item_code).length > 8) {
            return res.status(400).json({
                message: "Item code cannot be more than 8 characters."
            });
        }

        const piecesValue = parseInt(pieces) || 0;
        const netWeightValue = parseFloat(net_weight) || 0;
        const rateValue = parseFloat(rate) || 0;

        if (piecesValue < 0) {
            return res.status(400).json({ message: "Pieces cannot be negative." });
        }
        if (netWeightValue < 0) {
            return res.status(400).json({ message: "Net weight cannot be negative." });
        }
        if (rateValue < 0) {
            return res.status(400).json({ message: "Rate cannot be negative." });
        }

        const amountValue = netWeightValue * rateValue;
        const totalValue = total !== undefined && total !== null
            ? parseFloat(total) || 0
            : amountValue;

        const [detailCheck] = await db.query(
            `SELECT id FROM SalesReturnDetail WHERE id = ?`,
            [id]
        );
        if (detailCheck.length === 0) {
            return res.status(404).json({
                message: "Sale return detail not found."
            });
        }

        const [saleCheck] = await db.query(
            `SELECT id, financialyear_id FROM SalesReturnMain WHERE id = ? AND company_id = ?`,
            [sales_return_main, company_id]
        );
        if (saleCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid sale return for this company."
            });
        }
        const { financialyear_id } = saleCheck[0];

        const [itemCheck] = await db.query(
            `SELECT code FROM ItemDetail WHERE code = ? AND company_id = ?`,
            [Item_code, company_id]
        );
        if (itemCheck.length === 0) {
            return res.status(400).json({
                message: "Invalid item code for this company."
            });
        }

        await db.query(
            `
            UPDATE SalesReturnDetail
            SET
                company_id = ?,
                sales_return_main = ?,
                financialyear_id = ?,
                Item_code = ?,
                entry_no = ?,
                pieces = ?,
                net_weight = ?,
                rate = ?,
                amount = ?,
                total = ?
            WHERE id = ?
            `,
            [
                company_id,
                sales_return_main,
                financialyear_id,
                Item_code,
                entry_no,
                piecesValue,
                netWeightValue,
                rateValue,
                amountValue,
                totalValue,
                id
            ]
        );

        await recalcSalesReturnMainTotal(sales_return_main);
        const { warnings } = await syncAutoEntriesForSalesReturnMain(sales_return_main);

        res.status(200).json({
            message: "Sale return detail updated successfully.",
            warnings
        });
    } catch (error) {
        console.error("Error updating sale return detail:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "Entry number already exists for this sale return."
            });
        }
        res.status(500).json({
            message: "Failed to update sale return detail.",
            error: error.message
        });
    }
};

// ======================================================
// Delete Sales Return Detail
// ======================================================
exports.deleteSalesReturnDetail = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(`SELECT sales_return_main FROM SalesReturnDetail WHERE id = ?`, [id]);
        if (rows.length === 0) {
            return res.status(404).json({ message: "Sale return detail not found." });
        }
        const { sales_return_main } = rows[0];

        const [result] = await db.query(`DELETE FROM SalesReturnDetail WHERE id = ?`, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Sale return detail not found." });
        }

        await recalcSalesReturnMainTotal(sales_return_main);
        const { warnings } = await syncAutoEntriesForSalesReturnMain(sales_return_main);

        res.status(200).json({ message: "Sale return detail deleted successfully.", warnings });
    } catch (error) {
        console.error("Error deleting sale return detail:", error);
        res.status(500).json({ message: "Failed to delete sale return detail.", error: error.message });
    }
};

// ======================================================
// Update Sales Return Detail Stock Status (available -> out)
// ======================================================
exports.updateSalesReturnDetailStockStatus = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query(
            `SELECT id, stocks FROM SalesReturnDetail WHERE id = ?`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Sale return detail not found." });
        }
        if (rows[0].stocks === "out") {
            return res.status(400).json({ message: "Stock is already marked as out." });
        }

        await db.query(
            `UPDATE SalesReturnDetail SET stocks = 'out' WHERE id = ?`,
            [id]
        );

        res.status(200).json({ message: "Stock status updated to out." });
    } catch (error) {
        console.error("Error updating sale return detail stock status:", error);
        res.status(500).json({
            message: "Failed to update stock status.",
            error: error.message
        });
    }
};