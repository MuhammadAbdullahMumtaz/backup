const db = require("../../../config/db"); // adjust path to match your project

/**
 * Rebuilds every "auto" GL-side SalesReturnMain/SalesReturnDetail row that
 * belongs to a given user-entered SalesReturnMain (return invoice), based on
 * the current set of *user* SalesReturnDetail rows under it. Mirrors
 * syncAutoEntriesForSalesMain, grouped by GL_sale, keyed by invoice_no.
 */
async function syncAutoEntriesForSalesReturnMain(userSalesReturnMainId) {
    const warnings = [];
    const connection = await db.getConnection();

    try {
        await connection.beginTransaction();

        const [mainRows] = await connection.query(
            `SELECT id, company_id, financialyear_id, invoice_no, invoice_date,
                    gp_no, gp_date, po_no, po_date, builty_no
             FROM SalesReturnMain
             WHERE id = ? AND entry = 'user'
             FOR UPDATE`,
            [userSalesReturnMainId]
        );

        if (mainRows.length === 0) {
            await connection.commit();
            return { warnings };
        }
        const userMain = mainRows[0];

        const [detailRows] = await connection.query(
            `SELECT srd.Item_code, srd.pieces, srd.net_weight, srd.rate, srd.amount, srd.total,
                    si.details AS subitem_details, coa.code AS account_code
             FROM SalesReturnDetail srd
             INNER JOIN ItemDetail i
                ON srd.Item_code = i.code AND srd.company_id = i.company_id
             INNER JOIN SubItem si
                ON i.subitem_id = si.id
             LEFT JOIN ChartOfAccount coa
                ON si.GL_sale = coa.code
             WHERE srd.sales_return_main = ? AND srd.entry = 'user'`,
            [userSalesReturnMainId]
        );

        const groups = new Map(); // account_code -> array of detail rows
        for (const row of detailRows) {
            if (!row.account_code) {
                warnings.push(
                    `Item "${row.Item_code}" (Sub Item "${row.subitem_details}") has no GL Sale account configured - skipped in auto entry.`
                );
                continue;
            }
            if (!groups.has(row.account_code)) groups.set(row.account_code, []);
            groups.get(row.account_code).push(row);
        }

        const [existingAutoMains] = await connection.query(
            `SELECT id, customer_code
             FROM SalesReturnMain
             WHERE company_id = ? AND financialyear_id = ? AND invoice_no = ? AND entry = 'auto'`,
            [userMain.company_id, userMain.financialyear_id, userMain.invoice_no]
        );
        const existingByCode = new Map(existingAutoMains.map((m) => [m.customer_code, m.id]));

        // Drop auto mains whose account code is no longer represented
        for (const [code, id] of existingByCode) {
            if (!groups.has(code)) {
                await connection.query(`DELETE FROM SalesReturnDetail WHERE sales_return_main = ?`, [id]);
                await connection.query(`DELETE FROM SalesReturnMain WHERE id = ?`, [id]);
                existingByCode.delete(code);
            }
        }

        // Upsert one auto main per remaining/new account code
        for (const [code, rows] of groups) {
            let autoMainId = existingByCode.get(code);
            const groupTotal = rows.reduce((s, r) => s + Number(r.total), 0);

            if (autoMainId) {
                await connection.query(
                    `UPDATE SalesReturnMain
                     SET gp_no = ?, gp_date = ?, po_no = ?, po_date = ?,
                         invoice_date = ?, builty_no = ?, total = ?
                     WHERE id = ?`,
                    [
                        userMain.gp_no, userMain.gp_date,
                        userMain.po_no, userMain.po_date, userMain.invoice_date,
                        userMain.builty_no, groupTotal, autoMainId,
                    ]
                );
                await connection.query(`DELETE FROM SalesReturnDetail WHERE sales_return_main = ?`, [autoMainId]);
            } else {
                const [insertResult] = await connection.query(
                    `INSERT INTO SalesReturnMain
    (company_id, financialyear_id, gp_no, gp_date, po_no, po_date,
     invoice_no, invoice_date, builty_no, customer_code, freight, total, entry)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 'auto')`,
                    [
                        userMain.company_id, userMain.financialyear_id,
                        userMain.gp_no, userMain.gp_date, userMain.po_no, userMain.po_date,
                        userMain.invoice_no, userMain.invoice_date, userMain.builty_no,
                        code, groupTotal,
                    ]
                );
                autoMainId = insertResult.insertId;
            }

            let entryNo = 1;
            for (const row of rows) {
                await connection.query(
                    `INSERT INTO SalesReturnDetail
    (company_id, sales_return_main, financialyear_id, Item_code, entry_no, entry,
     pieces, net_weight, rate, amount, freight, total)
VALUES (?, ?, ?, ?, ?, 'auto', ?, ?, ?, ?, 0, ?)`,
                    [
                        userMain.company_id, autoMainId, userMain.financialyear_id,
                        row.Item_code, entryNo++, row.pieces, row.net_weight, row.rate, row.amount,
                        row.total,
                    ]
                );
            }
        }

        await connection.commit();
        return { warnings };
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
}

/**
 * Deletes every auto row belonging to a given return-invoice group. Used
 * when the user's SalesReturnMain itself is deleted. Caller controls the
 * transaction.
 */
async function deleteAutoEntriesForReturnInvoice(connection, { company_id, financialyear_id, invoice_no }) {
    const [autoMains] = await connection.query(
        `SELECT id FROM SalesReturnMain
         WHERE company_id = ? AND financialyear_id = ? AND invoice_no = ? AND entry = 'auto'`,
        [company_id, financialyear_id, invoice_no]
    );
    for (const m of autoMains) {
        await connection.query(`DELETE FROM SalesReturnDetail WHERE sales_return_main = ?`, [m.id]);
        await connection.query(`DELETE FROM SalesReturnMain WHERE id = ?`, [m.id]);
    }
}

module.exports = {
    syncAutoEntriesForSalesReturnMain,
    deleteAutoEntriesForReturnInvoice,
};