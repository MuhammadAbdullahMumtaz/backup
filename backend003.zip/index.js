require("dotenv").config();

const express = require("express");
const cors = require("cors");

const app = express();

const allowedOrigins = [
  "http://localhost:5173"
];

app.use(
  cors({
    origin: function (origin, callback) {
      // allow requests with no origin (like mobile apps, curl, Postman)
      if (!origin) return callback(null, true);

      if (allowedOrigins.includes(origin)) {
        return callback(null, true);
      } else {
        return callback(new Error("Not allowed by CORS"));
      }
    },
    credentials: true,
  })
);

app.use(express.json());

app.use("/api/company", require("./routes/Compay/CompanyRoutes"));

app.use("/api/login", require("./routes/Logins/LoginsRoutes"));

app.use("/api/financial-year", require("./routes/FinancialYear/FinancialYearRoutes"));

// Chart of Account Routes
app.use("/api/balance-sheet", require("./routes/DataEntry/ChartOfAccount/BalanceSheet/BalanceSheetRoutes"));

app.use("/api/main-code", require("./routes/DataEntry/ChartOfAccount/MainCode/MainCodeRoutes"));

app.use("/api/sub-code", require("./routes/DataEntry/ChartOfAccount/SubCode/SubCodeRoutes"));

app.use("/api/chart-of-account", require("./routes/DataEntry/ChartOfAccount/ChartAccount/ChartOfAccountRoutes"));

app.use("/api/chart-detail", require("./routes/DataEntry/ChartOfAccount/ChartDetail/ChartDetailRoutes"));

app.use("/api/opening-balance", require("./routes/DataEntry/ChartOfAccount/OpeningBalance/OpeningBalanceRoutes"));

// Item Entry Routes
app.use("/api/main-item", require("./routes/DataEntry/ItemEntry/MainItem/MainItemRoutes"));

app.use("/api/sub-item", require("./routes/DataEntry/ItemEntry/SubItem/SubItemRoutes"));

app.use("/api/item-detail", require("./routes/DataEntry/ItemEntry/ItemDetail/ItemDetailRoutes"));

app.use("/api/item-opening", require("./routes/DataEntry/ItemEntry/ItemOpening/ItemOpeningRoutes"));


// Voucher Entry Routes
app.use("/api/voucher-type", require("./routes/DataEntry/VoucherEntry/VoucherType/VoucherTypeRoutes"));

app.use("/api/voucher-main", require("./routes/DataEntry/VoucherEntry/VoucherMain/VoucherMainRoutes"));

app.use("/api/voucher-detail", require("./routes/DataEntry/VoucherEntry/VoucherDetail/VoucherDetailRoutes"));

// Purchase Entry Routes
app.use("/api/purchase-main", require("./routes/DataEntry/PurchaseEntry/PurchaseMain/PurchaseMainRoutes"));

app.use("/api/purchase-detail", require("./routes/DataEntry/PurchaseEntry/PurchaseDetail/PurchaseDetailRoutes"));

// Purchase Return Entry Routes
app.use("/api/purchase-return-main", require("./routes/DataEntry/PurchaseReturnEntry/PurchaseReturnMain/PurchaseReturnMainRoutes"));

app.use("/api/purchase-return-detail", require("./routes/DataEntry/PurchaseReturnEntry/PurchaseReturnDetail/PurchaseReturnDetailRoutes"));

// Sales Entry Routes
app.use("/api/sales-main", require("./routes/DataEntry/SalesEntry/SalesMain/SalesMainRoutes"));

app.use("/api/sales-detail", require("./routes/DataEntry/SalesEntry/SalesDetail/SalesDetailRoutes"));

// Sales Return Entry Routes
app.use("/api/sales-return-main", require("./routes/DataEntry/SalesReturnEntry/SalesReturnMain/SalesReturnMainRoutes"));
  
app.use("/api/sales-return-detail", require("./routes/DataEntry/SalesReturnEntry/SalesReturnDetail/SalesReturnDetailRoutes"));

// Ledger Report Routes
app.use("/api/ledger", require("./routes/Reporting/Ledger/LedgerRoutes"));

// Trial Balance Report Routes
app.use("/api/trial-balance", require("./routes/Reporting/TrialBalance/TrialBalanceRoutes"));

// Aging Routes
app.use("/api/aging-report", require("./routes/Reporting/Aging/AgingRoutes"))

// Sales Reports Routes
app.use("/api/sales-report", require("./routes/Reporting/SalesReport/SalesReportRoutes"))

// Purchase Reports Routes
app.use("/api/purchase-report", require("./routes/Reporting/PurchaseReport/PurchaseReportRoutes"))

app.get("/", (req, res) => {
  res.send("API Running");
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server Started On ${PORT}`);
});