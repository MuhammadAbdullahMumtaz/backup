const express = require("express");
const router = express.Router();

// adjust this path to match where your controller actually lives
const controller = require("../../../../controllers/DataEntry/PurchaseReturnEntry/PurchaseReturnDetail/PurchaseReturnDetailController");

router.get("/", controller.getAllPurchaseReturnDetails);
router.get("/purchasereturn/:purchasereturnmain_id", controller.getPurchaseReturnDetailsByPurchaseReturnMain);
router.get("/:id", controller.getPurchaseReturnDetailById);
router.post("/", controller.addPurchaseReturnDetail);
router.put("/:id", controller.updatePurchaseReturnDetail);
router.delete("/:id", controller.deletePurchaseReturnDetail);

module.exports = router;