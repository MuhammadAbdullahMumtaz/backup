const express = require("express");
const router = express.Router();

const {
    getAllSalesMains,
    getNextInvoiceNumber,
    updatePaymentStatus,
    getUnpaidSalesByCustomer,
    getSalesMainById,
    addSalesMain,
    updateSalesMain,
    updatePaymentStatusByInvoice,
    deleteSalesMain,
    getSaleWithDetails,
    getAutoEntriesForSalesMain,
} = require("../../../../controllers/DataEntry/SalesEntry/SalesMain/SalesMainController");

// Get All
router.get("/", getAllSalesMains);

// Get Next Invoice Number
router.get("/next/:company_id/:financialyear_id", getNextInvoiceNumber);

// Update Payment Status
router.patch('/status/:id', updatePaymentStatus);

// Get Unpaid Sales By Customer
router.get("/unpaid/:company_id/:customer_code", getUnpaidSalesByCustomer);

// Get Auto Entries
router.get("/:id/auto-entries", getAutoEntriesForSalesMain);

// Get With Details
router.get("/:id/details", getSaleWithDetails);

// Get By ID
router.get("/:id", getSalesMainById);

// Insert
router.post("/", addSalesMain);

// Update
router.put("/:id", updateSalesMain);

// Update Payment Status By Invoice
router.patch('/status-by-invoice/:company_id/:invoice_no', updatePaymentStatusByInvoice);

// Delete
router.delete("/:id", deleteSalesMain);

module.exports = router;