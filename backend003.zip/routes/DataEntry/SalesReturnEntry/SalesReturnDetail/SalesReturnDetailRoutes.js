const express = require("express");
const router = express.Router();

const controller = require("../../../../controllers/DataEntry/SalesReturnEntry/SalesReturnDetail/SalesReturnDetailController");

router.get("/", controller.getAllSalesReturnDetails);
router.get("/return/:sales_return_main", controller.getSalesReturnDetailsBySalesReturnMain);
router.get("/:id", controller.getSalesReturnDetailById);
router.post("/", controller.addSalesReturnDetail);
router.put("/:id", controller.updateSalesReturnDetail);
router.delete("/:id", controller.deleteSalesReturnDetail);
router.put("/:id", controller.updateSalesReturnDetailStockStatus);

module.exports = router;